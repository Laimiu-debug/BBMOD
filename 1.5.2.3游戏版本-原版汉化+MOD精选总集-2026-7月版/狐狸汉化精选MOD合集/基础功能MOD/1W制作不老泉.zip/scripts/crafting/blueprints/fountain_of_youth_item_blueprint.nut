this.fountain_of_youth_item_blueprint <- this.inherit("scripts/crafting/blueprint", {
	m = {},
	function create()
	{
		this.blueprint.create();
		this.m.ID = "blueprint.fountain_of_youth_item";
		this.m.PreviewCraftable = this.new("scripts/items/special/fountain_of_youth_item");
		this.m.Cost = 10000;
		gearCraft()
		local ingredients = [
			{
				Script = "scripts/items/misc/poisoned_apple_item",
				Num = 0
			}
		];
		this.init(ingredients);
	}

	function onCraft( _stash )
	{
		_stash.add(this.new("scripts/items/special/fountain_of_youth_item"));
	}

});