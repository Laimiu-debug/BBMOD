this.trade_jug_01_item_blueprint <- this.inherit("scripts/crafting/blueprint", {
	m = {},
	function create()
	{
		this.blueprint.create();
		this.m.ID = "blueprint.trade_jug_01_item";
		this.m.PreviewCraftable = this.new("scripts/items/special/trade_jug_01_item");
		this.m.Cost = 50000;
		gearCraft()
		local ingredients = [
			{
				Script = "scripts/items/misc/werewolf_pelt_item",
				Num = 0
			}
		];
		this.init(ingredients);
	}

	function onCraft( _stash )
	{
		_stash.add(this.new("scripts/items/special/trade_jug_01_item"));
	}

});