::mods_registerMod("mod_compare_bros", 1, "CompareBros");

local function pushTooltipLine(tooltip,_id,_text,_icon = null,_type = "text")
{
	if (_icon != null)
	{
		tooltip.push(
		{
			id = _id,
			type = _type,
			text = _text,
			icon = _icon
		});
	}
	else
	{
		tooltip.push(
		{
			id = _id,
			type = _type,
			text = _text,
		});
	}
	
return tooltip;
}

local function pushTooltipCompareBros(tooltip)
{
	local tohex = function(x)
	{
		local string=format("%x", this.Math.maxf(this.Math.minf(x,255),0).tointeger());
		if(string.len()<2)
		{
			string = "0"+string;
		}
		return string;
	}
	
	local colorize = function(text, x, level)
	{
		local color = "000000";
		if(x>0)
		{
			color="00"+tohex(x*11)+"00";
		}
		if(x<(-(level-1)))
		{
			color=tohex(-(x+(level-1))*22)+"00"+"00";
		}
		
		return "[color=#" + color + "]" + text + "[/color]";
		
		//return "[color=#" + tohex(-x*11)+ tohex(x*11) + "00" + "]" + text + "[/color]";
		/*
		x=this.Math.minf(this.Math.maxf(x,0.0),1.0);
		return "[color=#" + tohex(x*360-180)+ tohex((1 - x)*360-180) + "00" + "]" + text + "[/color]";
		*/
	};

	local a = {
		Hitpoints = [
			50,
			60
		],
		Stamina = [
			90,
			100
		],
		Bravery = [
			30,
			40
		],
		Initiative = [
			100,
			110
		]
		MeleeSkill = [
			47,
			57
		],
		RangedSkill = [
			32,
			42
		],
		MeleeDefense = [
			0,
			5
		],
		RangedDefense = [
			0,
			5
		],
	};
	local attrs = [
		"Hitpoints",
		"Stamina",
		"Bravery",
		"Initiative",
		"MeleeSkill",
		"RangedSkill",
		"MeleeDefense",
		"RangedDefense"
	];
	local constattrs = [
	"Hitpoints",
	"Fatigue",
	"Bravery",
	"Initiative",
	"MeleeSkill",
	"RangedSkill",
	"MeleeDefense",
	"RangedDefense"
	];
	local incrOnLvlUpAvg = [
		3,
		3,
		3,
		4,
		2,
		3,
		2,
		3
	];
	local icons = [
		"health.png",
		"fatigue.png",
		"bravery.png",
		"initiative.png",
		"melee_skill.png",
		"ranged_skill.png",
		"melee_defense.png",
		"ranged_defense.png"
	];
	local descriptions = [
		"Hitpoints",
		"Fatigue",
		"Resolve",
		"Initiative",
		"Melee Skill",
		"Ranged Skill",
		"Melee Defense",
		"Ranged Defense"
	];
	
	local _id = tooltip.len() + 1;
	local sectionText = "[u]Potential L11 Attributes[/u]";
	pushTooltipLine(tooltip,_id,sectionText);
	_id = _id + 1;
	
	local b = this.getBaseProperties().getClone();
	
	local traits = this.getSkills().query(this.Const.SkillType.Trait, false, true);
	foreach( i, trait in traits )
	{
		if (trait.getType() == this.Const.SkillType.Trait)
		{
			trait.onUpdate(b)
		}
	}
	local level = this.m.Level-this.m.LevelUps;
	if (level > 11)
		{
			level = 11;
		}
	local DAPT = 0;
	local DAPT11 = 0;
	
	for( local i = 0; i < attrs.len(); i++ )
	{
		local attribute = this.Const.Attributes[constattrs[i]]
		local talent=this.m.Talents[attribute];
		local lvlUpValues = this.m.Attributes[attribute];
		local baseAttr11 = b[attrs[i]];
		local apprenticebaseAttrAvg = (a[attrs[i]][1]+a[attrs[i]][0])/2.0;
		
		if(level<11)
		{
			for (local j= 0; j<lvlUpValues.len(); j++)
			{
				baseAttr11 += lvlUpValues[j];
			}
		}
		/*local DAP11=(baseAttr11-(apprenticebaseAttrAvg+incrOnLvlUpAvg[i]*10))/incrOnLvlUpAvg[i]; 
		DAP11=DAP11+5.0*(level-1)/attrs.len();*/
		
		local DAP=(b[attrs[i]]+talent*0.5*(11-level)-(apprenticebaseAttrAvg+incrOnLvlUpAvg[i]*(level-1)))/incrOnLvlUpAvg[i];//"Bonus attribute points" equivalent at Level 11
		local DAPC=DAP+5.0*(level-1)/attrs.len();//Every attribute that is not leveled during levelup gives -1 DAP (Delta Attribute points), so we have to add +50 DAP to the total at level 11, which is distributed over all attributes
		DAPT+=DAPC;
		//DAPT11+=DAP11;
		
		pushTooltipLine(tooltip,_id,colorize(baseAttr11,DAP,level)+" [img]gfx/ui/icons/talent_"+talent+".png[/img]","ui/icons/" + icons[i]);
		_id++;
	}
	pushTooltipLine(tooltip,_id,"DAPT: "+DAPT);
	_id++;
		return tooltip;
}

::mods_queue(null, null, function()
{
::mods_hookClass("entity/tactical/player", function(o)
{
while(!("getRosterTooltip" in o)) o = o[o.SuperName];
local getRosterTooltip = o.getRosterTooltip;
o.getRosterTooltip = function()
{
local tooltip = getRosterTooltip();
return pushTooltipCompareBros(tooltip);
}
});
});