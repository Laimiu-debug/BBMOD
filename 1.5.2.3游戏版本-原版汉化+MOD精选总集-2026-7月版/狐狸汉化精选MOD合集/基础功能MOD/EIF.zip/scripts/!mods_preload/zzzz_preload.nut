::mods_hookExactClass("entity/tactical/player", function ( obj )
{
	local setStartValuesEx = obj.setStartValuesEx;
	obj.setStartValuesEx = function ( _backgrounds, _addTraits = true )
	{
	   setStartValuesEx( _backgrounds, _addTraits = true )
	   
	   if (this.Math.rand(1, 100) <= 20 && this.getBackground().m.DailyCost >= 0)
	   {
	   this.m.Skills.add(this.new("scripts/skills/traits/elf_trait"));
	   }
	}
});
	
	