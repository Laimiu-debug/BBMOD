this.elf_trait <- this.inherit("scripts/skills/traits/character_trait", {
	m = {
			woman = 0,
			manhead = [
			"bust_elfhead_01",
			"bust_elfhead_06",
			"bust_elfhead_07",
			"bust_elfhead_08",
			"bust_elfhead_11",
			"bust_elfhead_12",
			"bust_elfhead_13"		
		    ],	
			womanhead = [
			"bust_elfhead_02",
			"bust_elfhead_03",
			"bust_elfhead_04",
			"bust_elfhead_05",
			"bust_elfhead_09",
			"bust_elfhead_10",
			"bust_elfhead_14",		
			"bust_elfhead_15"	
		    ],
			manhair = [
			"hair_blonde_59",
			"hair_blonde_60",
			"hair_blonde_61",
			"hair_blonde_62",		
			"hair_blonde_64",
			"hair_blonde_65",
			"hair_blonde_66",
			"hair_blonde_67",
			"hair_blonde_69",
			"hair_blonde_70"			
		    ],	
			womanhair = [
			"hair_blonde_59",
			"hair_blonde_60",
			"hair_blonde_61",
			"hair_blonde_62",	
			"hair_blonde_63",			
			"hair_blonde_64",
			"hair_blonde_65",
			"hair_blonde_67",
			"hair_blonde_68",			
			"hair_blonde_69",
			"hair_blonde_70"			
		    ]			
	    },
	function create()
	{
		this.character_trait.create();
		this.m.ID = "trait.elf";
		this.m.Name = "Elf";
		this.m.Icon = "ui/traits/elf_trait.png";
	}
	
	function getTooltip()
	{
		return [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			},	
			{
				id = 10,
				type = "text",
				icon = "ui/icons/initiative.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]+4[/color] Initiative"
			}
		];
	}

	function onUpdate( _properties )
	{
		_properties.Initiative += 4;			
	}
	
	function onAdded()
	{
		if (!this.m.IsNew)
		{
			return;
		}

		local actor = this.getContainer().getActor();
        
		if ("setGender" in actor)
		{
		  if (actor.m.Gender == 1)
		  {
		    this.m.woman = 0;
		  }
		  else
		  {
		    this.m.woman = 1;
		  }		  
		}
		else
		{
		this.m.woman = this.Math.rand(0, 1);
		}

	    if (this.m.woman == 1)
		{		
		this.m.Description = "This character is a elf. Compare to human, he is really fast. Because he has lived for so long time, his combat skill is amazing.";		
		}
	    else
		{		
		this.m.Description = "This character is a elf. Compare to human, she is really fast. Because she has lived for so long time, her combat skill is amazing.";		
		}		
		
	    if (this.m.woman == 1)
		{
			actor.getSprite("head").setBrush(this.m.manhead[this.Math.rand(0, this.m.manhead.len() - 1)]);
			actor.getSprite("hair").setBrush(this.m.manhair[this.Math.rand(0, this.m.manhair.len() - 1)]);
			actor.getSprite("body").setBrush("bust_naked_body_00");
			actor.getSprite("beard").setBrush("");
			actor.getSprite("beard_top").setBrush("");
		}
		else
		{
			actor.getSprite("head").setBrush(this.m.womanhead[this.Math.rand(0, this.m.womanhead.len() - 1)]);
			actor.getSprite("hair").setBrush(this.m.womanhair[this.Math.rand(0, this.m.womanhair.len() - 1)]);
			actor.getSprite("body").setBrush("bust_female_northern_body_01");
			actor.getSprite("beard").setBrush("");
			actor.getSprite("beard_top").setBrush("");			
		}
	}	
	
	function onCombatStarted()
	{
	    if (this.m.woman == 1)
		{
			return;
		}
		
		local actor = this.getContainer().getActor();
		actor.m.Sound[this.Const.Sound.ActorEvent.NoDamageReceived] = [
			"sounds/humans/legends/woman_light_01.wav",
			"sounds/humans/legends/woman_light_02.wav",
			"sounds/humans/legends/woman_light_03.wav",
			"sounds/humans/legends/woman_light_04.wav",
			"sounds/humans/legends/woman_light_05.wav"
		];
		actor.m.Sound[this.Const.Sound.ActorEvent.DamageReceived] = [
			"sounds/humans/legends/woman_injury_01.wav",
			"sounds/humans/legends/woman_injury_02.wav",
			"sounds/humans/legends/woman_injury_03.wav",
			"sounds/humans/legends/woman_injury_04.wav"
		];
		actor.m.Sound[this.Const.Sound.ActorEvent.Death] = [
			"sounds/humans/legends/woman_death_01.wav",
			"sounds/humans/legends/woman_death_02.wav",
			"sounds/humans/legends/woman_death_03.wav",
			"sounds/humans/legends/woman_death_04.wav",
			"sounds/humans/legends/woman_death_05.wav",
			"sounds/humans/legends/woman_death_06.wav",
			"sounds/humans/legends/woman_death_07.wav",
			"sounds/humans/legends/woman_death_08.wav"
		];
		actor.m.Sound[this.Const.Sound.ActorEvent.Fatigue] = [
			"sounds/humans/legends/woman_fatigue_01.wav",
			"sounds/humans/legends/woman_fatigue_02.wav",
			"sounds/humans/legends/woman_fatigue_03.wav",
			"sounds/humans/legends/woman_fatigue_04.wav",
			"sounds/humans/legends/woman_fatigue_05.wav",
			"sounds/humans/legends/woman_fatigue_06.wav",
			"sounds/humans/legends/woman_fatigue_07.wav"
		];
		actor.m.Sound[this.Const.Sound.ActorEvent.Flee] = [
			"sounds/humans/legends/woman_flee_01.wav",
			"sounds/humans/legends/woman_flee_02.wav",
			"sounds/humans/legends/woman_flee_03.wav",
			"sounds/humans/legends/woman_flee_04.wav",
			"sounds/humans/legends/woman_flee_05.wav",
			"sounds/humans/legends/woman_flee_06.wav"
		];
	}	

});

