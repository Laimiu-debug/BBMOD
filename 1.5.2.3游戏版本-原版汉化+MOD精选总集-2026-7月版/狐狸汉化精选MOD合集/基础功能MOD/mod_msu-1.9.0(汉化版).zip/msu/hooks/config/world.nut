// VANILLAFIX https://steamcommunity.com/app/365360/discussions/1/3436829654723733817/
if (::Hooks.getMod("vanilla").getVersion() < ::Hooks.SQClass.ModVersion("1.5.2-2"))
{
	::Const.World.RoadBrushes.add(::Const.DirectionAsBit.N, "road_N");
	::Const.World.RoadBrushes.add(::Const.DirectionAsBit.S, "road_S");
	::Const.World.RoadBrushes.add(::Const.DirectionAsBit.N | ::Const.DirectionAsBit.NE | ::Const.DirectionAsBit.NW, "road_NW_N_NE");
	::Const.World.RoadBrushes.add(::Const.DirectionAsBit.S | ::Const.DirectionAsBit.SE | ::Const.DirectionAsBit.SW, "road_SW_S_SE");
	::Const.World.ShoreBrushes.add(::Const.DirectionAsBit.N | ::Const.DirectionAsBit.S, "shore_n_s");
}
