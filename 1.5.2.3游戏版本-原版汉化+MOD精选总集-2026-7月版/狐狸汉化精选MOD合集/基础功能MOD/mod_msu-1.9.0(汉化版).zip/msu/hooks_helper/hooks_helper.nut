::MSU.HooksHelper <- {

}
