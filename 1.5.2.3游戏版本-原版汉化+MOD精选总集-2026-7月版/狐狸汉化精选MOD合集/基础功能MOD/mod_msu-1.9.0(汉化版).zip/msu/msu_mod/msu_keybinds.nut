::MSU.Mod.Keybinds.addSQKeybind("ClosePopup", "escape", ::MSU.Key.State.All, function()
{
	if (::MSU.Popup.isVisible() && !::MSU.Popup.isAnimating())
	{
		if (::MSU.Popup.isForceQuitting())
		{
			::MSU.Popup.quitGame();
		}
		else
		{
			::MSU.Popup.hide();
		}
		return true;
	}
	return false;
}, "关闭MSU弹窗");
::MSU.Mod.Keybinds.addSQKeybind("显示MSU弹窗", "ctrl+alt+p", ::MSU.Key.State.All, function()
{
	::MSU.Popup.setState(::MSU.Popup.State.Small);
}, "显示弹窗");
