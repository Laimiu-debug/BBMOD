local generalPage = ::MSU.Mod.ModSettings.addPage("一般");

local expandedSkillTooltips = generalPage.addBooleanSetting("ExpandedSkillTooltips", false, "技能提示栏扩展");
expandedSkillTooltips.setPersistence(false);
expandedSkillTooltips.setDescription("在技能提示栏中显示基于msu的信息，例如伤害类型");

local expandedItemTooltips = generalPage.addBooleanSetting("ExpandedItemTooltips", false, "物品提示栏扩展");
expandedItemTooltips.setPersistence(false);
expandedItemTooltips.setDescription("在物品提示栏中显示基于msu的信息，例如物品类型.");

local resetAllSettingsButton = generalPage.addButtonSetting("ResetAllSettings", null, "重置所有改动为默认设定");
resetAllSettingsButton.setDescription("重置每个mod的所有设置.");
resetAllSettingsButton.addCallback(function(_data = null){
	foreach (panel in ::MSU.System.ModSettings.getPanels()) panel.resetSettings();
})

local suppressBaseKeybinds = generalPage.addBooleanSetting("SuppressBaseKeybinds", false, "禁用系统默认的快捷键");
suppressBaseKeybinds.setDescription("是否屏蔽原版快捷键绑定。启用此选项后，将仅使用 MSU 的快捷键系统。\n例如，如果你将‘打开角色界面’从默认的‘c’键改为‘tab’键， 若未启用此设置，按下 ‘c’键 仍会打开角色界面，只要没有其他 MSU 快捷键绑定到 ‘c’键， 若启用此设置，则只有‘tab’键能打开角色界面，‘c’键将不再触发该功能。");

local blockSQInput = generalPage.addBooleanSetting("blockSQInput", true, "在输入文本时不触发快捷键");
blockSQInput.setDescription("是否在输入文本时屏蔽快捷键。\nBy 默认情况下，在类似 ‘修改名称’弹窗中输入文字时，游戏的常规快捷键仍然有效。例如，输入字母 ‘c’ 会打开储物界面。\nMSU 会在你输入文本时禁用游戏快捷键，但某些模组可能会因此出现兼容性问题。\n除非你遇到快捷键无法正常工作的问题，否则请保持此选项启用。");
blockSQInput.addAfterChangeCallback(@ (_oldValue) ::MSU.System.Keybinds.InputDenied = false); // use it as an opportunity to reset

local vanillaBBCode = generalPage.addBooleanSetting("VanillaBBCode", false, "使用粗体文字");
vanillaBBCode.setDescription("切换是否启用原版中对粗体字体的修改。在原版游戏中，这些修改实际上并不生效，但代码中却仍保留着。当 MSU 修复了这一机制使其能正常被模组使用后，这些粗体设置也会意外地在原版中生效。\n启用后，部分文本会显示为 [mb]粗体[/mb].");
vanillaBBCode.addCallback(@ (_value) ::MSU.UI.JSConnection.onVanillaBBCodeUpdated(_value));

local logPage = ::MSU.Mod.ModSettings.addPage("日志记录");

logPage.addTitle("msu_log", "MSU 日志记录");
logPage.addDivider("msu_divider");

foreach (flagID, value in ::MSU.System.Debug.Mods[::MSU.ID])
{
	local boolSetting = logPage.addBooleanSetting(flagID + "Log", value, ::MSU.String.capitalizeFirst(flagID));
	boolSetting.Data.FlagID <- flagID;
	boolSetting.addCallback(function(_value)
	{
		::MSU.Mod.Debug.setFlag(this.Data.FlagID, _value);
	});
}

logPage.addTitle("global_log", "全部日志");
logPage.addDivider("global_divider");

local verboseModeToggle = logPage.addBooleanSetting("verbose", false, "AI 行为日志记录");
verboseModeToggle.setDescription("If enabled, sets ::Const.AI.VerboseMode to true for AI related debugging.");
verboseModeToggle.addCallback(function(_data)
{
	::Const.AI.VerboseMode = _data;
})

local logToggle = logPage.addBooleanSetting("logall", false, "所有模组日志记录");
logToggle.setDescription("If enabled, considers every debug flag for every mod enabled, regardless of flag status.");
logToggle.addCallback(function(_data)
{
	::MSU.System.Debug.FullDebug = _data;
})
