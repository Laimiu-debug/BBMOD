::MSU.Mod.Tooltips.setTooltips({
	ModSettings = {
		Main = {
			Cancel = ::MSU.Class.BasicTooltip("取消", "不保存变更."),
			Reset = ::MSU.Class.BasicTooltip("重置", "重置页面上的所有设置."),
			Apply = ::MSU.Class.BasicTooltip("应用", "保存所有页面的设定，但不退出设置页面."),
			OK = ::MSU.Class.BasicTooltip("保存所有改动", "保存所有改动且退出设置页面.")
		},
		Element = {
			Tooltip = ::MSU.Class.CustomTooltip(@(_data) ::getModSetting(_data.elementModId, _data.settingsElementId).getTooltip(_data))
		},
		Keybind = {
			Popup = {
				Cancel = ::MSU.Class.BasicTooltip("取消", "不保存改动."),
				Add = ::MSU.Class.BasicTooltip("添加", "添加一个快捷键."),
				OK = ::MSU.Class.BasicTooltip("保存", "保存改动的设定."),
				Modify = ::MSU.Class.BasicTooltip("修改", "修改快捷键."),
				Delete = ::MSU.Class.BasicTooltip("删除", "删除绑定的快捷键."),
			}
		}
	}
});
