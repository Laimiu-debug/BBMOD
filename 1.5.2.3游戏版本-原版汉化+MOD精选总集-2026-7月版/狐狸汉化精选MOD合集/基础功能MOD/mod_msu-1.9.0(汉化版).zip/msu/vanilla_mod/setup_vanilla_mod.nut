local vanilla = ::Hooks.getMod("vanilla");
::MSU.Vanilla <- ::MSU.Class.Mod(vanilla.getID(), vanilla.getVersionString(), "原版 (MSU)");
