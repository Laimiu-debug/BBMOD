::MSU.Vanilla.Keybinds.addSQKeybind("character_closeCharacterScreen", "c/i/escape", ::MSU.Key.State.World | ::MSU.Key.State.Tactical, function()
{
	if (!this.isInCharacterScreen()) return;
	if (::MSU.isKindOf(this, "tactical_state"))
	{
		this.hideCharacterScreen();
	}
	else
	{
		this.toggleCharacterScreen();
	}
	return true;
}, "关闭角色界面");

::MSU.Vanilla.Keybinds.addSQKeybind("character_openCharacterScreen", "c/i", ::MSU.Key.State.World | ::MSU.Key.State.Tactical, function()
{
	if (::MSU.isKindOf(this, "tactical_state"))
	{
		if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen()) return;
		this.showCharacterScreen();
		return true;
	}
	else
	{
		if (!this.m.MenuStack.hasBacksteps() || this.m.CharacterScreen.isVisible() || this.m.WorldTownScreen.isVisible() && !this.m.EventScreen.isVisible())
		{
			if (!this.m.EventScreen.isVisible() && !this.m.EventScreen.isAnimating())
			{
				this.toggleCharacterScreen();
				return true;
			}
		}
	}
}, "打开角色界面");

::MSU.Vanilla.Keybinds.addSQKeybind("character_switchToPreviousBrother", "left/a", ::MSU.Key.State.World | ::MSU.Key.State.Tactical, function()
{
	if (!this.isInCharacterScreen()) return;
	this.m.CharacterScreen.switchToPreviousBrother();
	return true;
}, "切换到上一位兄弟");

::MSU.Vanilla.Keybinds.addSQKeybind("character_switchToNextBrother", "right/d/tab", ::MSU.Key.State.World | ::MSU.Key.State.Tactical, function()
{
	if (!this.isInCharacterScreen()) return;
	this.m.CharacterScreen.switchToNextBrother();
	return true;
}, "切换到下一位兄弟");

local function isCampfireScreen()
{
	return this.m.CampfireScreen != null && this.m.CampfireScreen.isVisible();
}

::MSU.Vanilla.Keybinds.addSQKeybind("toggleMenuScreen", "escape", ::MSU.Key.State.World | ::MSU.Key.State.Tactical, function()
{
	if (::MSU.isKindOf(this, "world_state"))
	{
		if (isCampfireScreen.call(this)) return;
		if (!this.m.WorldMenuScreen.isAnimating() && this.toggleMenuScreen())
		{
			return true;
		}
	}
	else
	{
		if (!this.m.MenuStack.hasBacksteps() || this.m.TacticalMenuScreen.isVisible())
		{
			if (this.toggleMenuScreen())
			{
				return true;
			}
		}
	}
}, "切换菜单界面");


//-------------------------------------------WORLD ONLY---------------------------------------------------------------------------------

::MSU.Vanilla.Keybinds.addDivider("world_divider");
::MSU.Vanilla.Keybinds.addTitle("world_title", "世界快捷键");

::MSU.Vanilla.Keybinds.addSQKeybind("world_closeCampfireScreen", "p/escape", ::MSU.Key.State.World, function()
{
	if (!isCampfireScreen.call(this)) return;
	this.m.CampfireScreen.onModuleClosed();
	return true;
}, "关闭篝火界面");

::MSU.Vanilla.Keybinds.addSQKeybind("world_toggleRelationScreen", "r", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps() && !this.m.EventScreen.isVisible() && !this.m.EventScreen.isAnimating())
	{
		this.topbar_options_module_onRelationsButtonClicked();
		return true;
	}
	else if (this.m.RelationsScreen.isVisible())
	{
		this.m.RelationsScreen.onClose();
		return true;
	}
}, "切换关系界面");

::MSU.Vanilla.Keybinds.addSQKeybind("world_toggleObituarysScreen", "o", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps() && !this.m.EventScreen.isVisible() && !this.m.EventScreen.isAnimating())
	{
		this.topbar_options_module_onObituaryButtonClicked();
		return true;
	}
	else if (this.m.ObituaryScreen.isVisible())
	{
		this.m.ObituaryScreen.onClose();
		return true;
	}
}, "切换阵亡记录界面");

::MSU.Vanilla.Keybinds.addSQKeybind("world_toggleCamping", "t", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		if (this.isCampingAllowed())
		{
			this.onCamp();
			return true;
		}
	}
}, "切换露营状态");


::MSU.Vanilla.Keybinds.addSQKeybind("world_toggleRetinueButton", "p", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps() && !this.m.EventScreen.isVisible() && !this.m.EventScreen.isAnimating())
	{
		this.topbar_options_module_onPerksButtonClicked();
		return true;
	}
}, "切换随从界面");

::MSU.Vanilla.Keybinds.addSQKeybind("world_pause", "0/space", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		this.setPause(!this.isPaused());
		return true;
	}
}, "暂停世界");

::MSU.Vanilla.Keybinds.addSQKeybind("world_speedNormal", "1", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		this.setNormalTime();
		return true;
	}
}, "正常世界速度 (1x)");

::MSU.Vanilla.Keybinds.addSQKeybind("world_speedFast", "2", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		this.setFastTime();
		return true;
	}
}, "快速世界速度 (2x)");

if (::Hooks.getMod("vanilla").getVersion() >= ::Hooks.SQClass.ModVersion("1.5.2-2"))
{
	::MSU.Vanilla.Keybinds.addSQKeybind("world_speedVeryFast", "3", ::MSU.Key.State.World, function()
	{
		if (!this.m.MenuStack.hasBacksteps())
		{
			this.setVeryFastTime();
			return true;
		}
	}, "非常快速世界速度 (3x)");
}

::MSU.Vanilla.Keybinds.addSQKeybind("world_trackingButton", "f", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		this.m.WorldScreen.getTopbarOptionsModule().onTrackingButtonPressed();
		return true;
	}
}, "切换足迹显示");

::MSU.Vanilla.Keybinds.addSQKeybind("world_cameraLockButton", "x", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps())
	{
		this.m.WorldScreen.getTopbarOptionsModule().onCameraLockButtonPressed();
		return true;
	}
}, "锁定镜头跟随队伍");

::MSU.Vanilla.Keybinds.addSQKeybind("world_quicksave", "f5", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps() && !::World.Assets.isIronman())
	{
		this.saveCampaign("quicksave");
		return true;
	}
}, "快速存档")

::MSU.Vanilla.Keybinds.addSQKeybind("world_quickload", "f9", ::MSU.Key.State.World, function()
{
	if (!this.m.MenuStack.hasBacksteps() && !::World.Assets.isIronman() && ::World.canLoad("quicksave"))
	{
		this.loadCampaign("quicksave");
		return true;
	}
}, "快速读档")

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_1", "1", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(0);
	return true;
}, "选择事件选项1", null, "点击世界事件中从上往下的第一个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_2", "2", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(1);
	return true;
}, "选择事件选项2", null, "点击世界事件中从上往下的第二个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_3", "3", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(2);
	return true;
}, "选择事件选项3", null, "点击世界事件中从上往下的第三个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_4", "4", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(3);
	return true;
}, "选择事件选项4", null, "点击世界事件中从上往下的第一个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_5", "5", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(4);
	return true;
}, "选择事件选项5", null, "点击世界事件中从上往下的第五个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_event_6", "6", ::MSU.Key.State.World, function()
{
	if (!this.m.EventScreen.isVisible() || this.m.EventScreen.isAnimating() || this.m.EventScreen.isJustShown())
	{
		return;
	}

	this.m.EventScreen.onButtonPressed(5);
	return true;
}, "选择事件选项6", null, "点击世界事件中从上往下的第六个按钮。");

::MSU.Vanilla.Keybinds.addSQKeybind("world_toggle_forceattack", "ctrl", ::MSU.Key.State.World, function()
{
	if (this.m.IsForcingAttack)
	{
		this.m.IsForcingAttack = false;
	}
	else
	{
		if (!this.m.MenuStack.hasBacksteps())
		{
			this.m.IsForcingAttack = true;
			return true;
		}
	}
}, "切换强制攻击", ::MSU.Key.KeyState.Release | ::MSU.Key.KeyState.Press);

// World Continuous, doesn't work cuz we handle keybinds differently from vanilla ):

// ::MSU.Vanilla.Keybinds.addSQKeybind("world_moveCamera_left", "left/a/q", ::MSU.Key.State.World, function()
// {
// 	if (::Settings.getTempGameplaySettings().CameraLocked)
// 	{
// 		this.m.WorldScreen.getTopbarOptionsModule().onCameraLockButtonPressed();
// 	}

// 	::World.getCamera().move(-1500.0 * ::Time.getDelta() * ::Math.maxf(1.0, ::World.getCamera().Zoom * 0.66), 0);
// 	return true;
// }, "Move Camera Up", null, ::MSU.Key.KeyState.Continuous | ::MSU.Key.KeyState.Press);

// ::MSU.Vanilla.Keybinds.addSQKeybind("world_moveCamera_right", "right/d", ::MSU.Key.State.World, function()
// {
// 	if (::Settings.getTempGameplaySettings().CameraLocked)
// 	{
// 		this.m.WorldScreen.getTopbarOptionsModule().onCameraLockButtonPressed();
// 	}

// 	::World.getCamera().move(1500.0 * ::Time.getDelta() * ::Math.maxf(1.0, ::World.getCamera().Zoom * 0.66), 0);
// 	return true;
// }, "Move Camera Right", null, ::MSU.Key.KeyState.Continuous | ::MSU.Key.KeyState.Press);

//-------------------------------------------TACTICAL ONLY---------------------------------------------------------------------------------

::MSU.Vanilla.Keybinds.addDivider("tactical_divider");
::MSU.Vanilla.Keybinds.addTitle("tactical_title", "战斗快捷键");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_hideCharacterScreen", "enter", ::MSU.Key.State.Tactical, function()
{
	if (!this.isInCharacterScreen()) return;
	if (this.m.CharacterScreen.isInBattlePreparationMode() == true)
	{
		this.hideCharacterScreen();
		return true;
	}
}, "关闭角色界面");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_toggleStatsOverlays", "alt", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps()) return;
	this.topbar_options_onToggleStatsOverlaysButtonClicked();
	return true;
}, "切换状态信息显示");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_toggleTreesButton", "t", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps()) return;
	this.topbar_options_onToggleTreesButtonClicked();
	return true;
}, "切换树木显示");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_toggleHighlightBlockedTiles", "b", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps()) return;
	this.topbar_options_onToggleHighlightBlockedTilesButtonClicked();
	return true;
}, "切换高亮显示被阻挡的地块");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_initNextTurn", "enter", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen()) return;
	 ::Tactical.TurnSequenceBar.initNextTurn();
	return true;
}, "结束角色回合");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_endTurnAll", "r", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen()) return;
	::Tactical.TurnSequenceBar.onEndTurnAllButtonPressed();
	return true;
}, "结束所有角色的回合");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_waitTurn", "end/space", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen()) return;
	if (::Tactical.TurnSequenceBar.getActiveEntity() != null && ::Tactical.TurnSequenceBar.getActiveEntity().isPlayerControlled())
	{
		local wasAbleToWait = ::Tactical.TurnSequenceBar.entityWaitTurn(::Tactical.TurnSequenceBar.getActiveEntity());

		if (!wasAbleToWait)
		{
			::Tactical.TurnSequenceBar.initNextTurn();
		}
		return true;
	}
}, "等待角色回合");

::MSU.Vanilla.Keybinds.addSQKeybind("tactical_focusActiveEntity", "shift", ::MSU.Key.State.Tactical, function()
{
	if (this.m.MenuStack.hasBacksteps() || this.isInputLocked() || this.isInCharacterScreen()) return;
	::Tactical.TurnSequenceBar.focusActiveEntity(true);
	return true;
}, "聚焦于当前活跃角色");


// ::MSU.System.Keybinds.registerMod(::MSU.ID)
// local jskeybind = ::MSU.Class.KeybindJS(::MSU.ID, "testkb", "ctrl+s");
// ::MSU.System.Keybinds.add(jskeybind);
