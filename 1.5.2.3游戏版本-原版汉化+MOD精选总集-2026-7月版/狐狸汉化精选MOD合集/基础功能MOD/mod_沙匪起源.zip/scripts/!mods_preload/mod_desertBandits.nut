::mods_registerMod("mod_desertBandits", 1, "Desert Bandits Background");

::mods_queue("mod_desertBandits", null, function(){
	::mods_hookNewObject("entity/tactical/player", function( obj )
	{
		::mods_addField(obj, null, "thrownDirt", false);
	});
	::mods_hookExactClass("states/world_state", function ( obj )
	{
		local onUpdate = obj.onUpdate;
		obj.onUpdate = function() {
			if (!this.m.IsUpdatedOnce && this.World.Assets.getOrigin().getID() == "scenario.desert_bandits") {
				local roster = this.World.getPlayerRoster().getAll();
				foreach (bro in roster) {
					bro.getSkills().removeByID("actives.throw_dirt");
					bro.getSkills().add(this.new("scripts/skills/actives/throw_dirt_skill"));
				}
			}
			onUpdate();
		}
	});
	::mods_hookNewObject("skills/actives/throw_dirt_skill", function ( obj )
	{
		::mods_overrideField(obj, "Name", "Dirty Trick");
		::mods_overrideField(obj, "Description", "Throw dirt, kick a shin, or otherwise perform some underhanded action to briefly distract a foe and reduce their combat ability.")
		::mods_overrideField(obj, "IconDisabled", "skills/active_215_sw.png")

		::mods_override(obj, "getTooltip", function()
		{
			local ret = this.getDefaultUtilityTooltip();
			ret.extend([
				{
					id = 6,
					type = "text",
					icon = "ui/icons/special.png",
					text = "Inflicts the Distracted condition for one turn."
				}
			]);
			ret.extend([
				{
					id = 7,
					type = "text",
					icon = "ui/icons/warning.png",
					text = "Can only be used once per battle."
				}
			]);

			if (this.Tactical.isActive() && this.getContainer().getActor().isPlayerControlled())
			{
				local actor = this.getContainer().getActor();
				if (actor.m.thrownDirt){
					ret.push({
						id = 8,
						type = "text",
						icon = "ui/tooltips/warning.png",
						text = "[color=" + this.Const.UI.Color.NegativeValue + "]Has already been used this battle.[/color]"
					});
				}
			}

			return ret;
		});

		::mods_override(obj, "isUsable", function()
		{
			local actor = this.getContainer().getActor();
			if ("getLevelUps" in actor) {
				local thrown = actor.m.thrownDirt;
				return !this.Tactical.isActive() || !this.getContainer().getActor().isPlayerControlled() || !thrown;
			}
			return true;
		});

		::mods_override(obj, "onCombatFinished", function()
		{
			local roster = this.World.getPlayerRoster();
			local bros = roster.getAll();
			foreach (bro in bros) {
				bro.getSkills().removeByID("actives.throw_dirt");
				bro.getSkills().add(this.new("scripts/skills/actives/throw_dirt_skill"));
			}
			return true;
		});

		::mods_override(obj, "onUse", function( _user, _targetTile )
		{
			local actor = this.getContainer().getActor();
			if (actor.isPlayerControlled() && "getLevelUps" in actor) {
				actor.m.thrownDirt = true;
			}
			if (_targetTile.getEntity().isAlliedWithPlayer()) {
				local effect = {
					Delay = 0,
					Quantity = 20,
					LifeTimeQuantity = 20,
					SpawnRate = 400,
					Brushes = [
						"sand_dust_01"
					],
					Stages = [
						{
							LifeTimeMin = 0.1,
							LifeTimeMax = 0.2,
							ColorMin = this.createColor("eeeeee00"),
							ColorMax = this.createColor("ffffff00"),
							ScaleMin = 0.5,
							ScaleMax = 0.5,
							RotationMin = 0,
							RotationMax = 359,
							VelocityMin = 60,
							VelocityMax = 100,
							DirectionMin = this.createVec(-0.7, -0.6),
							DirectionMax = this.createVec(-0.6, -0.6),
							SpawnOffsetMin = this.createVec(-35, -15),
							SpawnOffsetMax = this.createVec(35, 20)
						},
						{
							LifeTimeMin = 0.75,
							LifeTimeMax = 1.0,
							ColorMin = this.createColor("eeeeeeee"),
							ColorMax = this.createColor("ffffffff"),
							ScaleMin = 0.5,
							ScaleMax = 0.75,
							VelocityMin = 60,
							VelocityMax = 100,
							ForceMin = this.createVec(0, 0),
							ForceMax = this.createVec(0, 0)
						},
						{
							LifeTimeMin = 0.1,
							LifeTimeMax = 0.2,
							ColorMin = this.createColor("eeeeee00"),
							ColorMax = this.createColor("ffffff00"),
							ScaleMin = 0.75,
							ScaleMax = 1.0,
							VelocityMin = 0,
							VelocityMax = 0,
							ForceMin = this.createVec(0, -100),
							ForceMax = this.createVec(0, -100)
						}
					]
				};
				this.Tactical.spawnParticleEffect(false, effect.Brushes, _targetTile, effect.Delay, effect.Quantity, effect.LifeTimeQuantity, effect.SpawnRate, effect.Stages, this.createVec(30, 70));
			} else {
				local effect = {
					Delay = 0,
					Quantity = 20,
					LifeTimeQuantity = 20,
					SpawnRate = 400,
					Brushes = [
						"sand_dust_01"
					],
					Stages = [
						{
							LifeTimeMin = 0.1,
							LifeTimeMax = 0.2,
							ColorMin = this.createColor("eeeeee00"),
							ColorMax = this.createColor("ffffff00"),
							ScaleMin = 0.5,
							ScaleMax = 0.5,
							RotationMin = 0,
							RotationMax = 359,
							VelocityMin = 60,
							VelocityMax = 100,
							DirectionMin = this.createVec(0.6, -0.6),
							DirectionMax = this.createVec(0.7, -0.6),
							SpawnOffsetMin = this.createVec(-35, -15),
							SpawnOffsetMax = this.createVec(35, 20)
						},
						{
							LifeTimeMin = 1.0,
							LifeTimeMax = 1.25,
							ColorMin = this.createColor("eeeeeeee"),
							ColorMax = this.createColor("ffffffff"),
							ScaleMin = 0.5,
							ScaleMax = 0.75,
							VelocityMin = 60,
							VelocityMax = 100,
							ForceMin = this.createVec(0, 0),
							ForceMax = this.createVec(0, 0)
						},
						{
							LifeTimeMin = 0.1,
							LifeTimeMax = 0.2,
							ColorMin = this.createColor("eeeeee00"),
							ColorMax = this.createColor("ffffff00"),
							ScaleMin = 0.75,
							ScaleMax = 1.0,
							VelocityMin = 0,
							VelocityMax = 0,
							ForceMin = this.createVec(0, -100),
							ForceMax = this.createVec(0, -100)
						}
					]
				};
				this.Tactical.spawnParticleEffect(false, effect.Brushes, _targetTile, effect.Delay, effect.Quantity, effect.LifeTimeQuantity, effect.SpawnRate, effect.Stages, this.createVec(-30, 70));
			}

			local s = this.new("scripts/skills/effects/distracted_effect");
			_targetTile.getEntity().getSkills().add(s);
			this.Tactical.getShaker().shake(_targetTile.getEntity(), _user.getTile(), 4);

			if (!_user.isHiddenToPlayer() && _targetTile.IsVisibleForPlayer)
			{
				this.Tactical.EventLog.log(this.Const.UI.getColorizedEntityName(_user) + " throws dirt in " + this.Const.UI.getColorizedEntityName(_targetTile.getEntity()) + "\'s face to distract them");
			}

			// Remove the skill on use if this is a player
			if (_user.isPlayerControlled()){
				_user.getSkills().removeByID("actives.throw_dirt");
			}

			return true;
		});
	});
});