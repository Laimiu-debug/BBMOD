this.desert_bandits_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.desert_bandits_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_161.png[/img]{An utterly undignified scream rolls across the dunes around you. %db1% twists his blade again, the unfortunate merchant kneeling at his feet - this one particularly fat, even by the corpulant standard of Northerners - hollering and whimpering. You look down on him disdainfully.%SPEECH_ON%You did this to yourself, peddler. Had you simply handed over your goods, we would not be in this predicament. Now tell me again, where did you put the key?%SPEECH_OFF%The man, perhaps finding some long-lost scrap of backbone within himself, simply grits his teeth and stares up at you, eyes ablaze with a mix of hatred and fear. His lip quivers ever so slightly as you nod to %db1%. Another twist of the blade, another round of bleating and crying, another round of begging. It's all so tiresome.%SPEECH_ON%P-please... sirs... I d-dropped the key in m-my panic, it m-must have been buried in the s-sands...%SPEECH_OFF%You pinch the bridge of your nose, a single bead of sweat dripping from your brow in the rapidly warming late morning air. The bulk of the merchant's wares were worthless to you, but lazily hidden in the sniveling man's cart was a sterling lockbox assuredly containing quite the valuable haul. If only you could open it. Suddenly, you hear %db2%'s voice call out excitedly.%SPEECH_ON%Sir! I found the key.%SPEECH_OFF%The merchant had, apparently, fastened the key to the bottom of the cart and made a decent attempt to hide it. Not good enough to fool %db2%, of course, but admirable nonetheless. You take the key, small and cast of iron, from him, brandishing it over the merchant as his eyes widen with fear and understanding. Sliding the key into the lockbox, it clicks open pleasantly and reveals a trove of valuable incense and lavish silks inside. Calling your companions around you, you speak.%SPEECH_ON%Brothers. I tire of slaying peasants and cowards! This haul is the most we've made in months, and still it is a pittance compared to what the nobles and viziers will pay for the service of skilled swords such as ourselves. Let us be done with this for now, and seek our glory and riches as mercenaries!%SPEECH_OFF%There is a general cheer of agreement, and a distant grunt of pain. Looking towards the noise, you see the merchant has taken this speech as an opportunity to make an escape, hobbling on wounded legs over the nearest dune. You give a gesture to %db3% who nods and strides towards the escapee. The peddler, still scrambling for purchase on the dune, barely has time to utter half a plea for mercy before his pursuer ends him with a quick blow. You've already begun walking away, the soft shuffling sound of a body collapsing onto sand marking your journey from old life to new.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "Our new path will be gilded, brothers. I'm sure of it.",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "The Desert Bandits";
	}

	function onPrepareVariables( _vars )
	{
		local brothers = this.World.getPlayerRoster().getAll();
		_vars.push([
			"db1",
			brothers[0].getName()
		]);
		_vars.push([
			"db2",
			brothers[1].getName()
		]);
		_vars.push([
			"db3",
			brothers[2].getName()
		]);
	}

	function onClear()
	{
	}

});

