this.desert_bandits_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
	m = {},
	function create()
	{
		this.m.ID = "scenario.desert_bandits";
		this.m.Name = "Desert Bandits";
		this.m.Description = "[p=c][img]gfx/ui/events/event_170.png[/img][/p][p]For years you've combed the sands of the south for tired and vulnerable travellers to rob. But there are far greater riches to be made - and why not get paid for your pillaging?\n\n[color=#bcad8c]Desert Bandits:[/color] Start with three somewhat experienced nomads with decent equipment.\n[color=#bcad8c]Dirty Tricks:[/color] All men under your command fight dirty, gaining the ability to distract an opponent once per combat.\n[color=#bcad8c]Lowlifes:[/color] Start unfriendly, but not hostile, with most settlements. Highborn will never sully their reputation by joining you.[/p]";
		this.m.Difficulty = 2;
		this.m.Order = 180;
		this.m.IsFixedLook = true;
	}

	function isValid()
	{
		return this.Const.DLC.Desert;
	}

	function onSpawnAssets()
	{
		local roster = this.World.getPlayerRoster();

		for( local i = 0; i < 3; i = ++i )
		{
			local bro;
			bro = roster.create("scripts/entity/tactical/player");
			bro.setStartValuesEx([
				"nomad_background"
			]);
			bro.setPlaceInFormation(3 + i);
			//bro.getSprite("miniboss").setBrush("bust_miniboss_gladiators");
			bro.m.HireTime = this.Time.getVirtualTimeF();
			bro.m.Talents = [];
			bro.m.Attributes = [];
			bro.getSkills().add(this.new("scripts/skills/actives/throw_dirt_skill"));
			local items = bro.getItems();
			items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
			items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
			items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
			items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
		}

		local bros = roster.getAll();
		local a;
		local u;
		bros[0].setTitle("the Sandshark");
		bros[0].m.PerkPoints = 2;
		bros[0].m.LevelUps = 2;
		bros[0].m.Level = 3;
		bros[0].getTalents().resize(this.Const.Attributes.COUNT, 0);
		bros[0].getTalents()[this.Const.Attributes.MeleeDefense] = 2;
		bros[0].getTalents()[this.Const.Attributes.Fatigue] = 1;
		bros[0].getTalents()[this.Const.Attributes.MeleeSkill] = 2;
		bros[0].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[0].getItems().equip(this.new("scripts/items/armor/oriental/mail_and_lamellar_plating"));
		bros[0].getItems().equip(this.new("scripts/items/helmets/oriental/southern_head_wrap"));
		bros[0].getItems().equip(this.new("scripts/items/weapons/scimitar"));
		bros[0].improveMood(1.0, "Excited to move up in the world from banditry.");
		bros[1].m.PerkPoints = 1;
		bros[1].m.LevelUps = 1;
		bros[1].m.Level = 2;
		bros[1].getTalents().resize(this.Const.Attributes.COUNT, 0);
		bros[1].getTalents()[this.Const.Attributes.MeleeSkill] = 2;
		bros[1].getTalents()[this.Const.Attributes.Fatigue] = 2;
		bros[1].getTalents()[this.Const.Attributes.Hitpoints] = 2;
		bros[1].getItems().equip(this.new("scripts/items/armor/oriental/stitched_nomad_armor"));
		bros[1].getItems().equip(this.new("scripts/items/helmets/oriental/wrapped_southern_helmet"));
		bros[1].getItems().equip(this.new("scripts/items/weapons/boar_spear"));
		bros[1].getItems().equip(this.new("scripts/items/shields/oriental/southern_light_shield"));
		bros[1].improveMood(0.75, "Happy to have gotten some good plunder recently.");
		bros[2].m.PerkPoints = 1;
		bros[2].m.LevelUps = 1;
		bros[2].m.Level = 2;
		bros[2].getTalents().resize(this.Const.Attributes.COUNT, 0);
		bros[2].getTalents()[this.Const.Attributes.Initiative] = 3;
		bros[2].getTalents()[this.Const.Attributes.MeleeDefense] = 1;
		bros[2].getTalents()[this.Const.Attributes.MeleeSkill] = 1;
		bros[2].fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);
		bros[2].getItems().equip(this.new("scripts/items/armor/oriental/thick_nomad_robe"));
		bros[2].getItems().equip(this.new("scripts/items/helmets/oriental/assassin_head_wrap"));
		bros[2].getItems().equip(this.new("scripts/items/weapons/battle_whip"));
		bros[2].getItems().equip(this.new("scripts/items/tools/throwing_net"));
		bros[2].worsenMood(0.25, "Actually kind of liked being a bandit.");
		bros[0].getBackground().m.RawDescription = "{%fullname% has been your friend since childhood, growing up in the same tribe of desert nomads. As many such tribes did, yours turned to banditry to eke out a living. He took to it almost as well as you.}";
		bros[0].getBackground().buildDescription(true);
		bros[1].getBackground().m.RawDescription = "{Originally from one of the opulant southern city states, %fullname% was exiled from his rich family after he was accused of murder - one he likely committed. He met you shortly thereafter, where you put his skills to better use.}";
		bros[1].getBackground().buildDescription(true);
		bros[2].getBackground().m.RawDescription = "{%fullname% once aspired to be an assassin, but while he had ample talent for murder he had little for subtlety. Banditry suited him well, and you hope mercenary work will suit him even better.}";
		bros[2].getBackground().buildDescription(true);
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dried_lamb_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/supplies/dates_item"));
		this.World.Assets.m.BusinessReputation = 0;
		this.World.Assets.addMoralReputation(-20.0);
		this.World.Assets.getStash().add(this.new("scripts/items/trade/incense_item"));
		this.World.Assets.getStash().add(this.new("scripts/items/trade/silk_item"));
		this.World.Assets.m.Money = this.World.Assets.m.Money / 2 - (this.World.Assets.getEconomicDifficulty() == 0 ? 0 : 300);
		this.World.Assets.m.ArmorParts = this.World.Assets.m.ArmorParts / 2;
		this.World.Assets.m.Medicine = this.World.Assets.m.Medicine / 2;
		this.World.Assets.m.Ammo = 0;
	}

	function onSpawnPlayer()
	{
		local randomVillage;

		for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
		{
			randomVillage = this.World.EntityManager.getSettlements()[i];

			if (!randomVillage.isIsolatedFromRoads() && randomVillage.isSouthern())
			{
				break;
			}
		}

		local randomVillageTile = randomVillage.getTile();

		do
		{
			local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
			local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

			if (!this.World.isValidTileSquare(x, y))
			{
			}
			else
			{
				local tile = this.World.getTileSquare(x, y);

				if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
				{
				}
				else if (tile.getDistanceTo(randomVillageTile) == 0)
				{
				}
				else if (!tile.HasRoad)
				{
				}
				else
				{
					randomVillageTile = tile;
					break;
				}
			}
		}
		while (1);

		local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
		foreach (n in nobles) {
			n.addPlayerRelation(-10.0, "Your occupational history makes northern societies distrust you.");
		}
		local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);
		foreach (cs in cityStates) {
			cs.addPlayerRelation(-20.0, "The south is not fond of bandits. Even retired ones.");
		}

		this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
		this.World.Assets.updateLook(18);
		this.World.getCamera().setPos(this.World.State.m.Player.getPos());
		this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
		{
			this.Music.setTrackList([
				"music/gilded_02.ogg"
			], this.Const.Music.CrossFadeTime);
			this.World.Events.fire("event.desert_bandits_scenario_intro");
		}, null);
	}

	function onHired( _bro )
	{
		_bro.getSkills().add(this.new("scripts/skills/actives/throw_dirt_skill"));
	}

	function onUpdateHiringRoster( _roster )
	{
		local garbage = [];
		local bros = _roster.getAll();

		foreach( i, bro in bros )
		{
			if (bro.getBackground().isNoble())
			{
				garbage.push(bro);
			}
		}

		foreach( g in garbage )
		{
			_roster.remove(g);
		}
	}
});

