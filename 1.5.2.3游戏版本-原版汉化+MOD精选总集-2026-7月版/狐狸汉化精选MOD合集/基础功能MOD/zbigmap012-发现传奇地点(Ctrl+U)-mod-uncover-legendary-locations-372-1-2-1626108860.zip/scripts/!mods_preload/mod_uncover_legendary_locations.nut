  
::mods_registerMod("mod_uncover_legendary_locations", 1.0);
::mods_queue(null, null, function()
{	
	this.logInfo("hooked")
	local uncoverLegendaryLocations = function()
	{
		this.logInfo(format("ran function"));
		
		local locations = this.World.EntityManager.getLocations()
		foreach (location in locations)
		{
			if ((location.m.LocationType & this.Const.World.LocationType.Unique) != 0)
			{
				this.World.uncoverFogOfWar(location.getTile().Pos, 200);
				location.setDiscovered(true);
				location.getSprite("selection").Visible = true;
				location.setVisibleInFogOfWar(true)
			}
		}
	}

	::mods_hookNewObjectOnce("states/world_state", function (o) {

		local keyHandler = o.helper_handleContextualKeyInput;
		o.helper_handleContextualKeyInput = function(_key)
        {
            if(_key.getKey() == 31 && _key.getModifier() == 2 && _key.getState() == 0 && !isInCharacterScreen()) // CTRL + U
            {
                uncoverLegendaryLocations()
            }
            return keyHandler(_key);        
        }  
		
	})
})





