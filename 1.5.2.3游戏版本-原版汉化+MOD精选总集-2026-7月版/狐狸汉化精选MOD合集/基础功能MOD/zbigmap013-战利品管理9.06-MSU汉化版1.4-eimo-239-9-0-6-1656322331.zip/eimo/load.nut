local page = ::EIMO.Mod.ModSettings.addPage("保存设置");

::EIMO.RepairThresholdID <- "RepairThreshold";
page.addRangeSetting(::EIMO.RepairThresholdID, 125, 100, 500, 10, "修理的盈利阀值", "超过此盈利阈值的物品将通过修复按钮标记为修复(智能的使用等修阀值).\n\n阀值越大利润越大");

::EIMO.WaitThresholdID <- "WaitThreshold";
page.addRangeSetting(::EIMO.WaitThresholdID, 150, 100, 500, 10, "等待至修完的盈利阀值", "超过这一盈利阈值的物品在完全修复之前不会出售。在使用智能劫掠时自动修理。\n\n阀值越大利润越大");

if (::mods_getRegisteredMod("mod_legends") != null)
{
	::EIMO.SalvageThresholdID <- "SalvageThreshold";
	page.addRangeSetting(::EIMO.SalvageThresholdID, 40, 0, 200, 5, "回收的盈利阈值", "在使用“智能劫掠”或“标记回收品”按钮时，低于此盈利能力阈值的物品将被回收。\n\n阀值越小利润越大")
}

::EIMO.VisibilityLevelID <- "VisibilityLevel";
page.addEnumSetting(::EIMO.VisibilityLevelID, "Full", ["None", "Reduced", "Full"], "物品信息筛选", "如果您不想使用这些功能时可以隐藏EIMO提供的物品信息")

::EIMO.InventoryAddonsID <- "InventoryAddons";
page.addBooleanSetting(::EIMO.InventoryAddonsID, true, "库存功能按钮", "选中时，在库存右侧显示功能按钮。");

page.addTitle("debugTitle", "调式设置");
page.addDivider("debugDivider");

::EIMO.LogID <- "Log";
local log = page.addBooleanSetting(::EIMO.LogID, false, "允许记录日志");
log.addCallback(function ( _newValue )
{
	::EIMO.Mod.Debug.setFlag(::MSU.System.Debug.DefaultFlag, _newValue);
});

::EIMO.RepairBrothersData <- {
	SelectedBrotherPrice = 0,
	CompanyPrice = 0,
	CanRepairNearby = false
}

::EIMO.Mod.Keybinds.addJSKeybind("SetForSale", "ctrl+shift+rightclick", "标记为待售", "所有标记为待售的物品在使用自动出售时会全部自动出售掉。");
::EIMO.Mod.Keybinds.addJSKeybind("SetFavorite", "alt+shift+rightclick", "标记为收藏", "标记为收藏的物品不会被自动出售，当整理库存时收藏的物品会排在非收藏物品之前。");

::includeFile("eimo/", "global_functions.nut");
::includeLoad("eimo/", "hooks");
::includeLoad("eimo/", "ui");
