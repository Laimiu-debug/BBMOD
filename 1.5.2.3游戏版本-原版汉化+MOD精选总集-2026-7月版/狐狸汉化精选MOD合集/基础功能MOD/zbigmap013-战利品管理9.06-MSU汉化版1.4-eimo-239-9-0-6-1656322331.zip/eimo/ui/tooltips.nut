::EIMO.Mod.Tooltips.setTooltips({
	CharacterScreen = {
		RepairButton = ::MSU.Class.CustomTooltip(function(_data)
		{
			return [
			{
				id = 1,
				type = "title",
					text = "标记要修理的物品"
			},
			{
				id = 2,
				type = "description",
					text = "标记库存中所有值得修理的物品."
			},
			{
				id = 3,
				type = "hint",
				text = ::MSU.String.capitalizeFirst(::EIMO.Mod.ModSettings.getSetting("SetForSale").getValue()) + " 物品将其标记为待售。"
			},
			{
				id = 4,
				type = "hint",
				text = ::MSU.String.capitalizeFirst(::EIMO.Mod.ModSettings.getSetting("SetFavorite").getValue()) + " 物品将其标记为收藏。(他们将不会被出售)"
			}];
		}),
		SalvageButton = ::MSU.Class.BasicTooltip("标记要回收的物品", "将仓库中所有低于回收阀值的物品标记为回收"),
		RepairBrotherButton = ::MSU.Class.CustomTooltip(function(_data)
		{
			local ret = [
			{
				id = 1,
				type = "title",
					text = "修理当前队友的装备"
			},
			{
				id = 2,
				type = "description",
					text = "立即在当地的铁匠铺修理当前队友的装备,并支付维修费用.\n\n要求你与一个有铁匠铺的小镇相距不到两个世界格子,并且有足够的钱进行维修."
			}];

			if (::EIMO.RepairBrothersData.CanRepairNearby)
			{
				ret.push({
					id = 3,
					type = "hint",
					icon = "ui/icons/asset_money.png",
					text = "维修费用: " + ::EIMO.RepairBrothersData.SelectedBrotherPrice
				});
			}
			return ret;
		}),
		RepairCompanyButton = ::MSU.Class.CustomTooltip(function(_data)
		{
			local ret = [
			{
				id = 1,
				type = "title",
					text = "修理团队装备"
			},
			{
				id = 2,
				type = "description",
					text = "在当地的铁匠铺,通过支付费用立即修复团队的所有装备.\n\n要求你与一个有铁匠铺的小镇相距不到两个世界格子,并且有足够的钱进行维修."
			}];

			if (::EIMO.RepairBrothersData.CanRepairNearby)
			{
				ret.push({
					id = 3,
					type = "hint",
					icon = "ui/icons/asset_money.png",
					text = "维修费用: " + ::EIMO.RepairBrothersData.CompanyPrice
				});
			}
			return ret;
		})
	},
	TownShopDialogModule = {
		SellAllButton = ::MSU.Class.BasicTooltip("卖掉所有待售品", "出售所有标记为待售的物品,标记为待售的收藏物品将被忽略。盈利率为" + ::EIMO.Mod.ModSettings.getSetting(::EIMO.WaitThresholdID).getValue() + "的物品仅在修完状态下出售.")
	},
	TacticalCombatResultScreen = {
		SmartLootButton = ::MSU.Class.BasicTooltip("智能劫掠", "智能劫掠所有物品,移动物品到玩家库存,并根据阀值设置给物品标记各种状态。")
	}
})
