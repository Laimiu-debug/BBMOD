::MsuCustomSocket <- {
	ID = "mus_custom_socket",
	Version = "1.0.1",
	Name = "Custom Socket By Bigmap",
//底座 0-15
	CustomSocket = [
		"bust_base_rand",//每个人随机底座 0
		"bust_base_player",//玩家底座 1
		"bust_base_militia",//民兵底座 2
		"bust_base_military",//军队底座 3
		"bust_base_bandits",//强盗底座 4
		"bust_base_undead",//亡灵底座 5
		"bust_base_orcs",//兽人底座 6
		"bust_base_goblins",//哥布林底座 7
		"bust_base_wildmen_01",//野人底座 8
		"bust_base_beasts"//野兽底座 9
	],
	CustomPlayerDefaultSocket = "bust_base_player",//玩家底座序号 0-9 (默认1-玩家底座，自己按照上面对照序号修改数值)
//底座装饰 0-6
	CustomMiniBoss = [
		"bust_base_rand",//每个人随机底座装饰 0
		"bust_miniboss",//普通Boss装饰 1
		"bust_miniboss_lone_wolf",//独狼装饰 2
		"bust_miniboss_gladiators",//角斗士装饰 3
		"bust_miniboss_indebted",//负债者装饰 4
		"bust_miniboss_greenskins"//绿皮装饰 5
		"bust_miniboss_crusader"//十字军装饰(仅传奇) 6
	],
	CustomPlayerDefaultMiniBoss = "bust_miniboss_gladiators",//玩家底座装饰序号 0-5 (默认3-角斗士装饰，自己按照上面对照序号修改数值)
	CustomPlayerSwitch = false,//默认为false  值为 true 开启限定人物改底座，  值为 false 全队人物改底座。
	CustomPlayerSwitchTip = "如果选中，只有下面列表中的才更改底座，否则是全队更改。\n人物设定后一定要存档，否则可能会丢失。",
	CustomPlayerNameTip = "定制人物需要进入游戏后进行，完成后及时存档。\n输入内容一样要按照 姓名/底座序号/装饰序号 的格式，例如'关羽/1/6'，序号省略默认为0。\n底座序号：\n0-随机 1-玩家 2-民兵 3-军队 4-强盗\n5-亡灵 6-兽人 7-哥布林 8-野人 9-野兽\n装饰序号：\n0-随机 1-Boos 2-独狼 3-角斗士\n4-负债者 5-绿皮 6-十字军(仅传奇)",
	CustomPlayerName = [
		[
			"姓名",		//把需要改底盘的人物名字输入前面,多个人物可以往下扩展。
			0,			//玩家底座序号 0-9
			0			//玩家底座装饰序号 0-6
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		],
		[
			"姓名",
			0,
			0
		]
	],
//	flag = false,
//	str = "",
}


::mods_registerMod(::MsuCustomSocket.ID, ::MsuCustomSocket.Version, ::MsuCustomSocket.Name);
::mods_queue(::MsuCustomSocket.ID, "mod_msu(>=1.0.0-beta),>mod_legends_PTR,>mod_legends_STR,>mod_nggh_skills,>mod_nggh_magic_concept", function()
{
	::mods_registerJS("trans.js");
	::MsuCustomSocket.Mod <- ::MSU.Class.Mod(::MsuCustomSocket.ID, ::MsuCustomSocket.Version, ::MsuCustomSocket.Name);
	
	::MsuCustomSocket.checkStr <- function ( _str )
	{
		local str = ["0","1","2","3","4","5","6","7","8","9","10","11","12","13"];
		if(_str == null)
			return false;
		foreach( v in str )
		{
			if (_str == v)
				return true;
		}
		return false;
	}

	::MsuCustomSocket.spiltCustomName <- function ( _num , _value )
	{
		if(_value != null)
		{
			local num = _value.find("/");
			if(num != null)
			{
				::MsuCustomSocket.CustomPlayerName[_num][0] = _value.slice(0,num);
				local txt = _value.slice(num+1);
				if(txt != null)
				{
					num = txt.find("/");
					if(num != null)
					{
						local num1 = txt.slice(0,num);
						if (num1 != null && ::MsuCustomSocket.checkStr(num1) && num1.tointeger() > 0 && num1.tointeger() < ::MsuCustomSocket.CustomSocket.len())
						{
							::MsuCustomSocket.CustomPlayerName[_num][1] = num1.tointeger();
						}
						else
						{
							::MsuCustomSocket.CustomPlayerName[_num][1] = 0;
						}
						
						num1 = txt.slice(num+1);
						if (num1 != null && ::MsuCustomSocket.checkStr(num1) && num1.tointeger() > 0 && num1.tointeger() < ::MsuCustomSocket.CustomMiniBoss.len())
						{
							if (::mods_getRegisteredMod("mod_legends") == null && num1.tointeger() == 6)
							{
								::MsuCustomSocket.CustomPlayerName[_num][2] = 0;
							}
							else
							{
								::MsuCustomSocket.CustomPlayerName[_num][2] = num1.tointeger();
							}
						}
						else
						{
							::MsuCustomSocket.CustomPlayerName[_num][2] = 0;
						}
					}
				}
				else
				{
				::MsuCustomSocket.CustomPlayerName[_num][1] = 0;
				::MsuCustomSocket.CustomPlayerName[_num][2] = 0;
				}
			}
			else
			{
			::MsuCustomSocket.CustomPlayerName[_num][0] = _value;
			::MsuCustomSocket.CustomPlayerName[_num][1] = 0;
			::MsuCustomSocket.CustomPlayerName[_num][2] = 0;
			}
		}
	return ::MsuCustomSocket.CustomPlayerName[_num][0]+"/"+::MsuCustomSocket.CustomPlayerName[_num][1]+"/"+::MsuCustomSocket.CustomPlayerName[_num][2];
	};
	
//	::MsuCustomSocket.Mod.PersistentData.loadFile( "ModSetting" );
//	::MsuCustomSocket.Mod.Name = "定制人物底座";
	local page = ::MsuCustomSocket.Mod.ModSettings.addPage("全队底座设置");
	page.addTitle("Title1", "按钮切换选择" );
	page.addDivider("Divider1");
	page.addEnumSetting("CustomPlayerDefaultSocket", ::MsuCustomSocket.CustomPlayerDefaultSocket, ::MsuCustomSocket.CustomSocket,"底座类型", "选择人物的底座类型。");
	page.addEnumSetting("CustomPlayerDefaultMiniBoss", ::MsuCustomSocket.CustomPlayerDefaultMiniBoss, ::MsuCustomSocket.CustomMiniBoss,"底座装饰", "选择人物的底座装饰。");

	local page1 = ::MsuCustomSocket.Mod.ModSettings.addPage("限定人物设置");
	page1.addBooleanSetting("CustomPlayerSwitch", ::MsuCustomSocket.CustomPlayerSwitch, "限定人物", ::MsuCustomSocket.CustomPlayerSwitchTip);
//	setting.addCallback(function(_value)
//	{
//		::MsuCustomSocket.CustomPlayerSwitch = _value;
//	});
	
//	setting = page1.addTitle("Title12", "请输入" );
	page1.addDivider("Divider2");

	for (local i = 0;i < ::MsuCustomSocket.CustomPlayerName.len(); i++)
	{
		page1.addStringSetting("Char"+i, ::MsuCustomSocket.CustomPlayerName[i][0]+"/"+::MsuCustomSocket.CustomPlayerName[i][1]+"/"+::MsuCustomSocket.CustomPlayerName[i][2], "人物" + (i + 1),::MsuCustomSocket.CustomPlayerNameTip);
	}

	::mods_hookExactClass("states/world_state", function(o)
	{
		local msu_settings_screen_onSavepressedFunc = o.msu_settings_screen_onSavepressed;
		o.msu_settings_screen_onSavepressed <- function( _data )
		{
			if ("mus_custom_socket" in _data)
			{
				if ("CustomPlayerDefaultMiniBoss" in _data["mus_custom_socket"])
				{
					if (::mods_getRegisteredMod("mod_legends") == null && _data["mus_custom_socket"]["CustomPlayerDefaultMiniBoss"] == "bust_miniboss_crusader")
					{
						_data["mus_custom_socket"]["CustomPlayerDefaultMiniBoss"] = "bust_base_rand";
					}
				}
				for (local i = 0;i < ::MsuCustomSocket.CustomPlayerName.len(); i++)
				{
					if ("Char" + i in _data["mus_custom_socket"])
					{
						_data["mus_custom_socket"]["Char" + i] = ::MsuCustomSocket.spiltCustomName(i,_data["mus_custom_socket"]["Char" + i]);
						this.logDebug("------------------xxx2:"+_data["mus_custom_socket"]["Char" + i]);
					}
				}
			}
			msu_settings_screen_onSavepressedFunc(_data);
		}
	});
	
	::mods_hookNewObject("entity/tactical/tactical_entity_manager", function(obj)
	{
		local assignBasesFunc = obj.assignBases;
		obj.assignBases = function()
		{
			this.logDebug("------------------z_custom_socket");
			assignBasesFunc();
			if (!("FactionManager" in this.World) || this.World.FactionManager == null)
			{
				return;
			}
			if (this.m.Instances[this.Const.Faction.Player] == null)
			{
			}
			else
			{
				foreach( p in this.m.Instances[this.Const.Faction.Player] )
				{
//					this.logDebug("------------------z_custom_socket Name:"+p.m.Name + "  Socket:" + ::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerDefaultSocket").getValue());
					if (!::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerSwitch").getValue() && p.hasSprite("socket"))
					{
//						this.logDebug("------------------z_custom_socket LName:"+p.m.Name + "  MiniBoss:" + ::MsuCustomSocket.CustomPlayerDefaultMiniBoss);
						if (::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerDefaultSocket").getValue() == "bust_base_rand")
						{
							p.getSprite("socket").setBrush(::MsuCustomSocket.CustomSocket[this.Math.rand(1, 9)]);
						}
						else
						{
							p.getSprite("socket").setBrush(::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerDefaultSocket").getValue());
						}
						
						if (::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerDefaultMiniBoss").getValue() == "bust_base_rand")
						{
							p.getSprite("miniboss").setBrush(::MsuCustomSocket.CustomMiniBoss[this.Math.rand(1, 6)]);
						}
						else
						{
							p.getSprite("miniboss").setBrush(::MsuCustomSocket.CustomPlayerDefaultMiniBoss);
						}
					}
					else if (::MsuCustomSocket.Mod.ModSettings.getSetting("CustomPlayerSwitch").getValue())
					{
//						foreach( v in ::MsuCustomSocket.CustomPlayerName )
						for (local i = 0;i < ::MsuCustomSocket.CustomPlayerName.len(); i++)
						{
							if (::MsuCustomSocket.Mod.ModSettings.getSetting("Char"+i).getValue() !=null )
								::MsuCustomSocket.spiltCustomName(i,::MsuCustomSocket.Mod.ModSettings.getSetting("Char"+i).getValue());
							this.logDebug("------------------z_custom_socket LName:"+p.m.Name );
							this.logDebug("------------------z_custom_socket VName:"+::MsuCustomSocket.CustomPlayerName[i][0] );
							
							if(p.m.Name == ::MsuCustomSocket.CustomPlayerName[i][0])
							{
								if (::MsuCustomSocket.CustomPlayerName[i][1] >= ::MsuCustomSocket.CustomSocket.len() || ::MsuCustomSocket.CustomPlayerName[i][1] < 1)
								{
									p.getSprite("socket").setBrush(::MsuCustomSocket.CustomSocket[this.Math.rand(1, ::MsuCustomSocket.CustomSocket.len() - 1)]);
								}
								else
								{
									p.getSprite("socket").setBrush(::MsuCustomSocket.CustomSocket[::MsuCustomSocket.CustomPlayerName[i][1]]);
//									this.logDebug("------------------z_custom_socket LName:"+::MsuCustomSocket.CustomSocket[::MsuCustomSocket.CustomPlayerName[i][1]] );
								}
						
								if (::MsuCustomSocket.CustomPlayerName[i][2] >= ::MsuCustomSocket.CustomMiniBoss.len() || ::MsuCustomSocket.CustomPlayerName[i][2] < 1)
								{
									p.getSprite("miniboss").setBrush(::MsuCustomSocket.CustomMiniBoss[this.Math.rand(1, ::MsuCustomSocket.CustomMiniBoss.len() - 1)]);
								}
								else
								{
									p.getSprite("miniboss").setBrush(::MsuCustomSocket.CustomMiniBoss[::MsuCustomSocket.CustomPlayerName[i][2]]);
//									this.logDebug("------------------z_custom_socket LName:"+::MsuCustomSocket.CustomMiniBoss[::MsuCustomSocket.CustomPlayerName[i][1]] );
								}
							}
						}
					}
				}
			}
		}
	});
});
