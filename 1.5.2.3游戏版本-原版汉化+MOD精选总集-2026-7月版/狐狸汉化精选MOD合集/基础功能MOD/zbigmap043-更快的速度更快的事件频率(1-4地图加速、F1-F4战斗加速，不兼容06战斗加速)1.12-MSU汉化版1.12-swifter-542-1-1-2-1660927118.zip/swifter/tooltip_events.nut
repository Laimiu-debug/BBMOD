::mods_hookNewObjectOnce("ui/screens/tooltip/tooltip_events", function( o )
{
	local general_queryUIElementTooltipData = o.general_queryUIElementTooltipData;
	o.general_queryUIElementTooltipData = function( _entityId, _elementId, _elementOwner )
	{
		local ret = general_queryUIElementTooltipData(_entityId, _elementId, _elementOwner);
		if (ret != null) return ret;

		switch (_elementId)
		{
			case "swifter.TimeVeryfastButton":
				return [
					{
						id = 1,
						type = "title",
						text = "非常快速 (" + ::getModSetting(::Swifter.ID, "veryfastTime").getValue() + ")"
					},
					{
						id = 2,
						type = "description",
						text = "设定时间以比正常情况快得多的速度流逝(四倍速度)"
					}
				];

			case "swifter.TimeSuperfastButton":
				return [
					{
						id = 1,
						type = "title",
						text = "超级快速 (" + ::getModSetting(::Swifter.ID, "superfastTime").getValue() + ")"
					},
					{
						id = 2,
						type = "description",
						text = "设定时间以比正常情况超级快的速度流逝(八倍速度)"
					}
				];
		}
	}
});
