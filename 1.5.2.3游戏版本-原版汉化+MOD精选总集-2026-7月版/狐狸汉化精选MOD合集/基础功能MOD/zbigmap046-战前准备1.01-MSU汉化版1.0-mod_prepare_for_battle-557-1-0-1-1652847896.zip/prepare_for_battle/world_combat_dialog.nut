::mods_hookNewObjectOnce("ui/screens/world/world_combat_dialog", function (o)
{
	o.PrepareForBattle_show <- function()
	{
		::PrepareForBattle.ShowingPrepareScreen = true;
		this.hide();
		::World.State.m.CharacterScreen.show();
	}
});
