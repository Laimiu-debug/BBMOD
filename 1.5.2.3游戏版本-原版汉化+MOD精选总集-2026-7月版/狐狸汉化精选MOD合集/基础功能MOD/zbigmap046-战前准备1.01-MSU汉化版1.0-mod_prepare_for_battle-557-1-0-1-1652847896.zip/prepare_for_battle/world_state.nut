::mods_hookExactClass("states/world_state", function (o)
{
	local cache;
	local character_screen_onClosePressed = o.character_screen_onClosePressed;
	o.character_screen_onClosePressed = function()
	{
		if (::PrepareForBattle.ShowingPrepareScreen)
		{
			this.m.MenuStack.pop();
			this.m.CharacterScreen.hide();
			this.showCombatDialog(cache.IsPlayerInitiated, cache.IsCombatantsVisible, cache.AllowFormationPicking, cache.Properties, cache.Pos);
			::PrepareForBattle.ShowingPrepareScreen = false;
		}
		else
		{
			return character_screen_onClosePressed();
		}
	}

	local showCombatDialog = o.showCombatDialog;
	o.showCombatDialog = function( _isPlayerInitiated = true, _isCombatantsVisible = true, _allowFormationPicking = true, _properties = null, _pos = null )
	{
		if (!this.m.CombatDialog.isAnimating() && !this.m.CombatDialog.isVisible()) // very stupid but vanilla does this at the end of world_combat_dialog.nut show so I have to do it as well
		{
			cache = {
				IsPlayerInitiated = _isPlayerInitiated,
				IsCombatantsVisible = _isCombatantsVisible,
				AllowFormationPicking = _allowFormationPicking,
				Properties = _properties,
				Pos = _pos
			};
		}
		return showCombatDialog(_isPlayerInitiated, _isCombatantsVisible, _allowFormationPicking, _properties, _pos);
	}

	local combat_dialog_module_onEngagePressed = o.combat_dialog_module_onEngagePressed; // fixes some sort of weird issue where contracts wouldn't complete after a battle  if Properties remained in memory throughout the fight
	o.combat_dialog_module_onEngagePressed = function()
	{
		cache = null
		combat_dialog_module_onEngagePressed();
	}
});
