::PrepareForBattle <- {
	ID = "mod_prepare_for_battle",
	Version = "1.0.1",
	Name = "Prepare For Battle",
	ShowingPrepareScreen = false
}

::mods_registerMod(::PrepareForBattle.ID, ::PrepareForBattle.Version, ::PrepareForBattle.Name);

::mods_queue(::PrepareForBattle.ID, "mod_msu(>=1.0.0-beta.4)", function()
{
	::PrepareForBattle.Mod <- ::MSU.Class.Mod(::PrepareForBattle.ID, ::PrepareForBattle.Version, ::PrepareForBattle.Name);

	local page = ::PrepareForBattle.Mod.ModSettings.addPage("Main");

	page.addBooleanSetting("ShowAmbushed", false, "Show Prepare For Battle When Ambushed", "Shows the prepare for battle button even when ambushed.");

	::include("prepare_for_battle/world_combat_dialog");
	::include("prepare_for_battle/world_state");
	::mods_registerJS("prepare_for_battle/world_combat_dialog.js");
	::mods_registerCSS("prepare_for_battle/css/world_combat_dialog.css");
});
