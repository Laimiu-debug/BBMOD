::mods_registerMod("mod_removableUpgradesVer2", 1, "Removable upgrades ver 2");
::mods_queue(null, null, function()
{
  ::mods_registerJS("mod_removableUpgradesVer2.js");

  ::mods_hookBaseClass("items/item", function(o)
  {
    if("setArmor" in o && "PreviousCondition" in o.m) // find the armor_upgrade derived class
    {
      local onUse = o.onUse;
      o.onUse = function(_actor, _item = null)
      {
        local prev = null; // get the previous upgrade, if any and if the actor is a player
        if(_actor.ClassName == "player")
        {
          local armor = _item == null ? _actor.getItems().getItemAtSlot(Const.ItemSlot.Body) : _item;
          if(armor != null) prev = armor.getUpgrade();
        }
        // Fix exploit with repairing armor upon detaching/attaching an upgrade.
        if (prev != null) {
          local cond = this.Math.maxf(0, prev.m.Armor.m.Condition - prev.m.ConditionModifier);
          prev.m.Armor.m.Condition = cond;
        }

        local used = onUse(_actor, _item);
        if(used && prev != null) // if we added the upgrade and there existed a previous upgrade...
        {
          prev.m.Armor = null; // restore the previous upgrade to an unused condition
          World.Assets.getStash().add(prev); // and put it back in the stash
        }
        return used;
      }
    }
  });

  ::mods_hookBaseClass("items/armor_upgrades/armor_upgrade", function(o)
  {
	while (!("getArmorTooltip" in o))
	{
		o = o[o.SuperName];
	}
	o.getArmorTooltip = function( _result )
	{
		this.onArmorTooltip(_result);
		_result.push({
			id = 15,
			type = "text",
			icon = "ui/icons/plus.png",
			text = "一块可以替代的盔甲配件，装备后可以按' [color=" + this.Const.UI.Color.NegativeValue + "]快捷键 U[/color] '卸除。"
		});
	}
  });
  
  ::mods_hookNewObjectOnce("ui/screens/character/character_screen", function(o) {
    o._ru_onBrotherSelected <- function(id) { m._ru_SelectedBrotherId <- id; }

    o.detachArmorUpgrade <- function()
    {
      if("_ru_SelectedBrotherId" in m)
      {
        local bro = Tactical.getEntityByID(m._ru_SelectedBrotherId);
        if(bro != null)
        {
          local armor = bro.getItems().getItemAtSlot(Const.ItemSlot.Body);
          if(armor != null)
          {
            local upgrade = armor.getUpgrade();
            if(upgrade != null && World.Assets.getStash().hasEmptySlot())
            {
              // Test
//              local skills = armor.getContainer().getActor().getSkills().query(this.Const.SkillType.Item);
//              foreach (i, skill in skills) {
//                this.logDebug(skill.getID() + "\n");
//              }
              // Fix exploit with repairing armor upon detaching/attaching an upgrade.
              local cond = this.Math.maxf(0, armor.m.Condition - upgrade.m.ConditionModifier);
              armor.m.Condition = cond;

              armor.setUpgrade(null);
              upgrade.m.Armor = null;
              bro.getSkills().update();
              World.Assets.getStash().add(upgrade);
              armor.onUnequip();
              armor.onEquip();
              loadData(); // refresh the brother and stash displays
            }
          }
        }
      }
    }
  });

  ::mods_hookNewObjectOnce("states/world_state", function(o) {
    local keyHandler = o.helper_handleContextualKeyInput;
    o.helper_handleContextualKeyInput = function(key)
    {
      // Press U in Character screen.
      if(key.getKey() == 31 && key.getState() == 0 && isInCharacterScreen())
      {
        if(!Tactical.isActive() && m.CharacterScreen.isInStashMode()) m.CharacterScreen.detachArmorUpgrade();
        return true;
      }
      else
      {
        return keyHandler(key);
      }
    }
  });
});
