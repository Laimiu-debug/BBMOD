::MsuAutopilot <- {
	ID = "mod_autopilot",
	Version = "1.2.3",
	Name = "Autopilot",
	AutoFreeWake = true, // 如果我们有未使用的AP，我们是否应该尝试自动将自己和盟友从各种网的束缚解救出来？
	AutoFreeWakeTip = "选中此项，在有剩余的AP情况下，会尝试将自己或附近的盟友从各种网的束缚中解救出来。",
	AutoReload = true, // 如果有未使用的AP，是否应尝试自动重新装填？
	AutoReloadTip = "选中此项，在有剩余的AP情况下，会尝试自动装填。",
}


::mods_registerMod(::MsuAutopilot.ID, ::MsuAutopilot.Version, ::MsuAutopilot.Name);
::mods_queue(::MsuAutopilot.ID, "mod_msu", function() {
	::MsuAutopilot.Mod <- ::MSU.Class.Mod(::MsuAutopilot.ID, ::MsuAutopilot.Version, ::MsuAutopilot.Name);
	local page = ::MsuAutopilot.Mod.ModSettings.addPage("设置");
	page.addBooleanSetting("AutoFreeWake", ::MsuAutopilot.AutoFreeWake, "自动解救", ::MsuAutopilot.AutoFreeWakeTip);
	page.addBooleanSetting("AutoReload", ::MsuAutopilot.AutoReload, "自动装填", ::MsuAutopilot.AutoReloadTip);

//	::mods_registerJS("autopilot_turnsequencebar_module.js");
  ::mods_hookBaseClass("entity/tactical/actor", function(o) {
    while(!("onTurnStart" in o)) o = o[o.SuperName];
  
    o.addAutoSkill <- function(skillId)
    {
      if(!("autoSkills" in this.m)) this.m.autoSkills <- [];
      this.m.autoSkills.append(skillId);
    }
  
    o.clearAutoSkills <- function()
    {
      if("autoSkills" in this.m) this.m.autoSkills.clear();
    }
  
    o.processAutoSkills <- function()
    {
      if (this.m.MoraleState != Const.MoraleState.Fleeing && "autoSkills" in this.m)
      {
        local skills = getSkills();
        foreach(id in this.m.autoSkills)
        {
          local skill = skills.getSkillByID(id);
          if (skill != null && skill.isUsable() && skill.isAffordable())
            skill.use(getTile());
        }
  
        this.m.autoSkills.clear();
      }
    }
  
	local onTurnStartFunc = o.onTurnStart;
	o.onTurnStart <- function()
    {
      onTurnStartFunc();
      processAutoSkills();
    }
	
	while(!("onTurnResumed" in o)) o = o[o.SuperName];
	local onTurnResumedFunc = o.onTurnResumed;
    o.onTurnResumed <- function()
    {
      onTurnResumedFunc();
      processAutoSkills();
    }
	
	while(!("onTurnEnd" in o)) o = o[o.SuperName];
	local onTurnEndFunc = o.onTurnEnd;
    o.onTurnEnd <- function()
    {
      if(ClassName == "player" && getMoraleState() != Const.MoraleState.Fleeing)
      {
        local skills = getSkills(), tile = getTile();
        local function tryUseSkill(id, t)
        {
          local s = skills.getSkillByID(id);
          return s != null && s.use(t);
        }

        if(::MsuAutopilot.Mod.ModSettings.getSetting("AutoFreeWake").getValue() || ::MsuAutopilot.Mod.ModSettings.getSetting("AutoReload").getValue())
        {
          // see if we can help ourselves first
          if(::MsuAutopilot.Mod.ModSettings.getSetting("AutoFreeWake").getValue()) tryUseSkill("actives.break_free", tile);
          if(::MsuAutopilot.Mod.ModSettings.getSetting("AutoReload").getValue())
          {
            foreach(s in ["actives.reload_bolt", "actives.reload_handgonne"]) tryUseSkill(s, tile);
          }

          // then try to help adjacent allies
          if(::MsuAutopilot.Mod.ModSettings.getSetting("AutoFreeWake").getValue())
          {
            foreach(s in ["actives.wake_ally", "actives.break_ally_free"])
            {
              local skill = skills.getSkillByID(s);
              if(skill != null && skill.isUsable() && skill.isAffordable())
              {
                for(local dir = 0; dir < 6; dir++)
                {
                  if(tile.hasNextTile(dir))
                  {
                    local adjTile = tile.getNextTile(dir);
                    if(adjTile.IsOccupiedByActor && adjTile.getEntity().isAlliedWith(this))
                    {
                      for(local i = 0; i < 3 && skill.use(adjTile); i++) { }
                    }
                  }
                }
              }
            }
          }
        }

        // finally, use the recover skill if it'd help
        if(getFatigue() > this.m.CurrentProperties.FatigueRecoveryRate) tryUseSkill("actives.recover", tile);
      }

      onTurnEndFunc();
      clearAutoSkills();
    }
  });

  ::mods_hookBaseClass("entity/tactical/human", function(o) {
    if("getLevelUps" in o) // if it's the player class...
    {
      o.isUnderAIControl <- function()
      {
//		this.logDebug("check isUnderAIControl---");
        return "_oldAgent" in this.m;
      }
  
      o.enableAIControl <- function()
      {
//		this.logDebug("enableAIControl---");
        this.m._oldAgent <- this.getAIAgent();
		
//		if ("_oldAgent" in this.m)
//			this.logDebug("check isUnderAIControl--yes-" + this.getName());
//		else
//			this.logDebug("check isUnderAIControl---no-" + this.getName());
//		
        local isRanged = isArmedWithRangedWeapon();
        if(isRanged) // if armed with a throwing weapon, use the melee AI instead of the ranged AI
        {
          local weapon = this.m.Items.getItemAtSlot(Const.ItemSlot.Mainhand);
          if(weapon.isItemType(Const.Items.ItemType.Ammo)) isRanged = false;
        }
        local agent = new("scripts/ai/tactical/agents/military_" + (isRanged ? "ranged" : "melee") + "_agent");
		switch (this.getBackground().getID())
		{
			case "background.hexen_commander":
			case "background.hexen":
				agent = new("scripts/ai/tactical/agents/hexe_agent");
//			case "background.legend_witch":
//				agent = new("scripts/ai/tactical/agents/legend_demonalp_agent");
		}
        // agent.compileKnownAllies optimizes itself to no-op for the player faction, but we need it to work
        agent.compileKnownAllies <- function()
        {
          local instances = this.Tactical.Entities.getAllInstances();
          this.m.KnownAllies = [];
          foreach( i, faction in instances )
          {
            if (faction.len() == 0 || this.m.Actor.getFaction() != i && !this.m.Actor.isAlliedWith(i))
            {
              continue;
            }

            foreach( entity in faction )
            {
              if (entity.isAlive() && !entity.isDying() && entity.isPlacedOnMap())
              {
                this.m.KnownAllies.push(entity);
              }
            }
          }
        }
//		if (agent.m.ID == this.Const.AI.Agent.ID.MilitaryMelee)
//		{
//			agent.addBehavior(this.new("scripts/ai/tactical/behaviors/ai_horse_charge")); 
//		}
        agent.removeBehavior(Const.AI.Behavior.ID.Retreat); // retreat is always chosen for players if available, so remove it
        agent.m.Properties.TargetPriorityHittingAlliesMult *= 0.2; // reduce the chance of friendly fire
        agent.setActor(this);
        setAIAgent(agent);
      }
  
      o.cancelAIControl <- function()
      {
        if(isUnderAIControl())
        {
          local agent = getAIAgent();
          if(agent.ClassName != "player_agent")
          {
            if(agent.getID() != Const.AI.Agent.ID.CharmedPlayer) setAIAgent(m._oldAgent);
            local skill = getSkills().getSkillByID("effects.charmed");
            if(skill != null) skill.m.OriginalAgent = m._oldAgent;
          }
          delete this.m._oldAgent;
        }
      }

      local onDeath = o.onDeath;
      o.onDeath <- function(killer, skill, tile, fatalityType)
      {
        this.cancelAIControl(); // if a bro dies while under AI control it may hang around as a "ghost"...
        onDeath(killer, skill, tile, fatalityType);
      }

      local onCombatFinished = o.onCombatFinished;
      o.onCombatFinished <- function()
      {
        clearAutoSkills();
        cancelAIControl();
        if("_isIgnored" in this.m) delete this.m._isIgnored;
        onCombatFinished();
      }

      o.querySwitchableItems <- function()
      {
        local items = [], inv = getItems();
        if(inv.isActionAffordable([])) // if we could afford any kind of action...
        {
          for(local itemType = Const.Items.ItemType, i = 0; i < inv.getUnlockedBagSlots(); i++)
          {
            local item = inv.getItemAtBagSlot(i);
            if(item == null) continue;
            local slot = item.getSlotType();
            if(slot == Const.ItemSlot.None || slot == Const.ItemSlot.Bag) continue;
            local currentItem = inv.getItemAtSlot(slot);
            if(item != null &&
               (item.isItemType(itemType.Weapon) || item.isItemType(itemType.Tool) || item.isItemType(itemType.Shield) ||
                item.isItemType(itemType.Accessory) || (item.isItemType(itemType.Ammo) && item.m.Ammo != 0)) &&
               inv.isActionAffordable(currentItem != null ? [currentItem, item] : [item]))
            {
              items.append(item);
            }
          }
        }
        return items;
      }

    }
  });
  
  ::mods_hookNewObject("states/tactical_state", function(o) {
    local handleKey = o.helper_handleContextualKeyInput;
    o.helper_handleContextualKeyInput <- function(key)
    {
      if(helper_handleDeveloperKeyInput(key)) return true;
  
      if(key.getKey() == 32 && key.getState() == 0 && key.getModifier() != 1 &&
         !isInLoadingScreen() && !isBattleEnded()) // V. allow cancel during enemy's turn
      {
        Tactical.TurnSequenceBar.onCancelButtonPressed();
        return true;
      }
  
      local result = handleKey(key);
      if (!result && key.getState() == 0 && key.getModifier() != 1 && !isInCharacterScreen())
      {
        if(key.getKey() == 18) // H
        {
          Tactical.TurnSequenceBar.onWaitTurnAllButtonPressed();
          return true;
        }
        else if(key.getKey() == 24) // N
        {
          Tactical.TurnSequenceBar.onShieldWallButtonPressed();
          return true;
        }
      }
      
      return result;
    }

    o.swapToItem <- function(entity, item)
    {
      if(m.CurrentActionState != null)
      {
        Tooltip.reload();
        Tactical.TurnSequenceBar.deselectActiveSkill();
        Tactical.getHighlighter().clear();
        m.CurrentActionState = null;
        m.SelectedSkillID = null;
        updateCursorAndTooltip();
      }
  
      m.CharacterScreen.onEquipBagItem([entity.getID(), item.getInstanceID()]);
    }

    local onSkillClickedFunc = o.turnsequencebar_onEntitySkillClicked;
    o.turnsequencebar_onEntitySkillClicked <- function(skillId)
    {
      local activeEntity = this.Tactical.TurnSequenceBar.getActiveEntity();
      if(activeEntity == null || activeEntity.getSkills().getSkillByID(skillId) != null)
      {
        onSkillClickedFunc(skillId);
      }
      else if(!isInputLocked())
      {
        local item = activeEntity.getItems().getItemByInstanceID(skillId);
        if(item) swapToItem(activeEntity, item);
      }
    }
  
    local setStateByIndexFunc = o.setActionStateBySkillIndex;
    o.setActionStateBySkillIndex <- function(index)
    {
      local e = this.Tactical.TurnSequenceBar.getActiveEntity(), itemIndex = -1;
      if(e != null && !isInputLocked()) itemIndex = index - e.getSkills().queryActives().len();
      if(itemIndex >= 0 && !e.getFlags().has("IsSummoned"))
      {
        local items = e.querySwitchableItems();
        if(itemIndex < items.len()) swapToItem(e, items[itemIndex]);
      }
      else
      {
        setStateByIndexFunc(index);
      }
    }
  
    o.updateCurrentEntity <- function()
    {
      if (this.m.IsGameFinishable && this.isBattleEnded())
      {
        return;
      }
  
      if (this.m.IsGamePaused)
      {
        return;
      }
  
      local activeEntity = this.Tactical.TurnSequenceBar.getActiveEntity();
  
      if (activeEntity == null)
      {
        this.Tactical.TurnSequenceBar.initNextTurn();
        return;
      }
  
      activeEntity.onUpdate();
  
      local agent = activeEntity.getAIAgent();
      if (!activeEntity.isPlayerControlled() || this.m.IsAutoRetreat ||
          agent != null && agent.ClassName != "player_agent")
      {
        this.setInputLocked(true);
  
        if (agent != null)
        {
          if (!this.m.IsAIPaused)
          {
            if (!this.Const.AI.ParallelizationMode || !agent.isEvaluating())
            {
              agent.think();
            }
  
            if (agent.isFinished() || !activeEntity.isAlive())
            {
              this.Tactical.TurnSequenceBar.initNextTurn();
            }
          }
        }
        else
        {
          this.Tactical.TurnSequenceBar.initNextTurn();
        }
      }
      else
      {
        if (agent != null && !this.m.IsAIPaused)
        {
          if (!agent.isFinished())
          {
            this.setInputLocked(true);
  
            if (!this.Const.AI.ParallelizationMode || !agent.isEvaluating())
            {
              agent.think();
            }
          }
          else if (!activeEntity.isAlive() || activeEntity.getMoraleState() == this.Const.MoraleState.Fleeing)
          {
            this.Tactical.TurnSequenceBar.initNextTurn();
          }
          else
          {
            this.setInputLocked(false);
          }
        }
        else
        {
          this.setInputLocked(false);
        }
  
        if (!this.isInputLocked())
        {
          switch(this.m.CurrentActionState)
          {
          case this.Const.Tactical.ActionState.SkillSelected:
          case this.Const.Tactical.ActionState.ComputePath:
          case null:
            if (activeEntity.isTurnDone())
            {
              this.Tactical.TurnSequenceBar.initNextTurn();
            }
            else if (!this.Tactical.getNavigator().isTravelling(activeEntity) && !activeEntity.isPlayingRenderAnimation())
            {
              this.Tactical.getShaker().shake(activeEntity, activeEntity.getTile(), 1);
            }
  
            break;
  
          case this.Const.Tactical.ActionState.TravelPath:
            if (!this.Tactical.getNavigator().travel(activeEntity, activeEntity.getActionPoints(), activeEntity.getFatigueMax() - activeEntity.getFatigue()))
            {
              this.Cursor.setCursor(this.Const.UI.Cursor.Hand);
              this.m.CurrentActionState = null;
              this.m.ActiveEntityNeedsUpdate = true;
  
              if (activeEntity.isAlive() && activeEntity.getTile().Level > this.Tactical.getCamera().Level)
              {
                this.Tactical.getCamera().Level = activeEntity.getTile().Level;
              }
            }
  
            if (activeEntity.isAlive() && this.m.ActiveEntityNeedsUpdate)
            {
              this.Tactical.TurnSequenceBar.updateEntity(activeEntity.getID());
              this.m.ActiveEntityNeedsUpdate = false;
            }
  
            break;
          }
        }
      }
    }
  });
  
  ::mods_hookNewObject("ui/screens/tooltip/tooltip_events", function(o) {
    local queryTooltipData = o.general_queryUIElementTooltipData;
    o.general_queryUIElementTooltipData = function(entityId, elementId, elementOwner)
    {
      local tooltip = queryTooltipData(entityId, elementId, elementOwner);
      if(tooltip != null) return tooltip;
      if(elementId == "tactical-screen.turn-sequence-bar-module.WaitTurnAllButton")
      {
        return [
          {
            id = 1,
            type = "title",
            text = "全体等待 (H)"
          },
          {
            id = 2,
            type = "description",
            text = "暂停所有角色的回合并将行动顺序移到队列末尾（如果他们尚未等待）。等待这一回合也会让他们在下一回合的行动顺序靠后。"
          }
        ];
      }
      else if(elementId == "tactical-screen.turn-sequence-bar-module.IgnoreButton")
      {
        return [
          {
            id = 1,
            type = "title",
            text = "忽略行动"
          },
          {
            id = 2,
            type = "description",
            text = "结束该角色的回合，并使他在后续的回合中忽略行动。"
          }
        ];
      }
      else if(elementId == "tactical-screen.turn-sequence-bar-module.CancelButton")
      {
        return [
          {
            id = 1,
            type = "title",
            text = "取消设定 (V)"
          },
          {
            id = 2,
            type = "description",
            text = "取消效果，例如结束回合、全体等待、全体盾墙、忽略行动和自动控制等设定。"
          }
        ];
      }
      else if(elementId == "tactical-screen.turn-sequence-bar-module.ShieldWallButton")
      {
        return [
          {
            id = 1,
            type = "title",
            text = "全体盾墙 (N)"
          },
          {
            id = 2,
            type = "description",
            text = "如果可能的话，使所有角色在本回合开始时自动使用盾墙技能。"
          }
        ];
      }
      else if(elementId == "tactical-screen.turn-sequence-bar-module.AIButton")
      {
        return [
          {
            id = 1,
            type = "title",
            text = "自动控制"
          },
          {
            id = 2,
            type = "description",
            text = "结束当前角色的回合，并将团队的控制权交给AI。"
          }
        ];
      }
  
      return null;
    }
  
    local querySkillTooltipFunc = o.onQuerySkillTooltipData;
    o.onQuerySkillTooltipData = function(entityId, skillId)
    {
      local tooltip = querySkillTooltipFunc(entityId, skillId);
      if(tooltip == null)
      {
        local entity = Tactical.getEntityByID(entityId), item = entity.getItems().getItemByInstanceID(skillId);
        if(item != null)
        {
          local currentItem = entity.getItems().getItemAtSlot(item.getSlotType());
          tooltip = [
            {
              id = 1,
              type = "title",
              text = "切换到" + item.getName()
            },
            {
              id = 2,
              type = "description",
              text = "快速切换到包中的其他物品。"
            },
            {
              id = 3,
              type = "text",
              text = "耗费 [b][color=" + Const.UI.Color.PositiveValue + "] " +
                     entity.getItems().getActionCost(currentItem != null ? [currentItem, item] : [item]) + "[/color][/b] AP 去切换。"
            }
          ];
        }
      }
      return tooltip;
    }
  });
  
  // allow player AI to break free from webs & nets
  ::mods_hookBaseClass("ai/tactical/behavior", function(o) {
    if("PossibleSkills" in o.m && o.m.PossibleSkills.len() == 1 &&
       o.m.PossibleSkills[0] == "actives.break_free")
    {
      o.onEvaluate = function(_entity)
      {
        this.m.Skill = null;
        local score = this.getProperties().BehaviorMult[this.m.ID];
  
        if (_entity.getActionPoints() < this.Const.Movement.AutoEndTurnBelowAP)
        {
          return this.Const.AI.Behavior.Score.Zero;
        }
  
        if (_entity.isPlayerControlled() && _entity.getMoraleState() != this.Const.MoraleState.Fleeing && !this.Tactical.State.isAutoRetreat() &&
            (_entity.getAIAgent() == null || _entity.getAIAgent().ClassName == "player_agent"))
        {
          return this.Const.AI.Behavior.Score.Zero;
        }
  
        if (!_entity.getCurrentProperties().IsRooted)
        {
          return this.Const.AI.Behavior.Score.Zero;
        }
  
        this.m.Skill = this.selectSkill(this.m.PossibleSkills);
  
        if (this.m.Skill == null || this.m.Skill.getChance() <= 30 && _entity.getTile().hasZoneOfControlOtherThan(_entity.getAlliedFactions()))
        {
          return this.Const.AI.Behavior.Score.Zero;
        }
  
        score = score * this.getFatigueScoreMult(this.m.Skill);

        if (this.m.Skill.getChance() <= 30 && _entity.getTile().hasZoneOfControlOtherThan(_entity.getAlliedFactions()))
        {
          return this.Const.AI.Behavior.Score.Zero;
        }

        return this.Const.AI.Behavior.Score.BreakFree;
      }
    }
  });
 
	::mods_hookExactClass("ui/screens/tactical/modules/turn_sequence_bar/turn_sequence_bar", function(o) {
		o.m.CancelPending <- false,
		o.m.IsWaitingRound <- false,
		
		o.isHumanControlled <- function(entity = null)
		{
			if(entity == null) entity = getActiveEntity();
			return entity != null && entity.isPlayerControlled() && (entity.getAIAgent() == null || entity.getAIAgent().ClassName == "player_agent");
		}

		o.initNextRound <- function()
		{
			if (this.m.IsBattleEnded)
			{
				this.logDebug("Info: Battle ended after " + this.m.CurrentRound + " Round(s).");
				return;
			}

			this.m.IsLocked = true;
			this.m.JSHandle.call("clear", null);

			foreach( entity in this.m.CurrentEntities )
			{
				entity.onTurnEnd();
			}

			foreach( entity in this.m.AllEntities )
			{
				entity.onRoundEnd();
			}

			this.m.CurrentEntities = [];
			this.m.ActiveEntityMouseHover = null;

			if (this.m.AllEntities.len() > 0)
			{
				++this.m.CurrentRound;

				if (this.m.OnNextRoundListener != null)
				{
					this.m.OnNextRoundListener(this.m.CurrentRound);
				}

				local temp = clone this.m.AllEntities;

				foreach( entity in temp )
				{
					entity.onRoundStart();
				}

				if (this.m.AllEntities.len() == 0)
				{
					return;
				}

				this.m.CurrentEntities = clone this.m.AllEntities;
				this.m.CurrentEntities.sort(this.compareEntitiesByInitiative);

				foreach( entity in this.m.CurrentEntities )
				{
					entity.setWaitActionSpent(false);
				}

				this.m.CurrentEntities[0].onBeforeActivation();
				this.m.TurnPosition = 0;
				local entitiesToAdd = this.Math.min(this.m.CurrentEntities.len(), this.m.MaxVisibleEntities);

				for( local i = 0; i < entitiesToAdd; i = ++i )
				{
					this.m.JSHandle.call("addEntity", this.convertEntityToUIData(this.m.CurrentEntities[i], i == this.m.CurrentEntities.len() - 1));
				}

				this.m.IsSkippingRound = false;
				this.m.IsWaitingRound = false;
				this.m.JSHandle.call("setEndTurnAllButtonVisible", true);
				this.m.JSHandle.call("setWaitTurnAllButtonVisible", true);
			}
		}
	
	
		o.initNextTurn <- function( _force = false )
		{
			if (this.m.IsBattleEnded)
			{
				return;
			}

			if (this.m.IsLocked)
			{
				return;
			}

			if (!_force && (this.Time.hasEventScheduled(this.TimeUnit.Virtual) || this.Tactical.State.isPaused()))
			{
				return;
			}

			if (this.m.OnNextTurnListener != null)
			{
				if (!this.m.OnNextTurnListener())
				{
					return;
				}
		}

			if (this.m.CurrentEntities.len() <= 1)
			{
				if (!this.m.IsInitNextRound)
				{
					this.m.IsInitNextRound = true;
					this.m.CheckEnemyRetreat = true;
				}

				return;
			}

			local activeEntity = this.m.CurrentEntities[0];

			if (this.m.CurrentEntities.len() > 1)
			{
					this.m.CurrentEntities[1].onBeforeActivation();
			}

			this.m.IsLocked = true;
			this.m.JSHandle.asyncCall("removeEntity", activeEntity.getID());
			activeEntity.onTurnEnd();
			this.m.CurrentEntities.remove(0);
			++this.m.TurnPosition;
			this.m.IsLastEntityPlayerControlled = activeEntity.isPlayerControlled() || "isUnderAIControl" in activeEntity && activeEntity.isUnderAIControl();

			if (this.m.CurrentEntities.len() >= this.m.MaxVisibleEntities)
			{
				local entityToAddIndex = this.Math.min(this.m.CurrentEntities.len() - 1, this.m.MaxVisibleEntities - 1);
				this.m.JSHandle.asyncCall("addEntity", this.convertEntityToUIData(this.m.CurrentEntities[entityToAddIndex], entityToAddIndex == this.m.CurrentEntities.len() - 1));
			}
		}
	

		o.onNextTurnButtonPressed <- function()
		{
			if (!isHumanControlled())
			{
				return;
			}

			this.initNextTurn();
		}

		o.onWaitTurnButtonPressed <- function()
		{
			if (!isHumanControlled())
			{
				return;
			}

			this.entityWaitTurn(this.getActiveEntity());
		}

		o.onEndTurnAllButtonPressed <- function()
		{
			if (this.m.IsSkippingRound || !isHumanControlled())
			{
				return;
			}

			this.Tactical.State.showDialogPopup("结束回合", "在下一轮开始之前，所有角色都跳过他们的回合吗？", function ()
			{
				this.m.IsSkippingRound = true;
				this.m.JSHandle.call("setEndTurnAllButtonVisible", false);
				this.m.JSHandle.call("setWaitTurnAllButtonVisible", false);

				foreach( e in this.m.CurrentEntities )
				{
					if (e.isPlayerControlled())
					{
						e.setSkipTurn(true);
					}
				}

				this.initNextTurn();
			}.bindenv(this), null);
		}

		o.onWaitTurnAllButtonPressed <- function()
		{
			if(this.m.IsSkippingRound || this.m.IsWaitingRound || !isHumanControlled())
			{
				return;
			}

			this.Tactical.State.showDialogPopup("全体等待", "所有的角色都要等到第二阶段吗？", function ()
			{
				this.m.IsWaitingRound = true;
				this.m.JSHandle.call("setWaitTurnAllButtonVisible", false);
				this.initNextTurnBecauseOfWait();
			}.bindenv(this), null);
		}

		o.onShieldWallButtonPressed <- function()
		{
			if(this.m.IsSkippingRound || !isHumanControlled())
			{
				return;
			}

			this.Tactical.State.showDialogPopup("全体盾墙", "如果可以的话，所有角色都会在这一回合使用盾墙吗？", function ()
			{
				foreach( e in this.m.CurrentEntities )
				{
					if (e.isPlayerControlled() && !e.m.IsTurnDone) e.addAutoSkill("actives.shieldwall");
				}

				this.getActiveEntity().processAutoSkills();
			}.bindenv(this), null);
		}

		o.onIgnoreButtonPressed <- function()
		{
			if(this.m.IsSkippingRound || !isHumanControlled())
			{
				return;
			}

			this.getActiveEntity().m._isIgnored <- true;
			this.initNextTurn();
		}

		o.onCancelButtonPressed <- function()
		{
			if(m.IsLocked || !isHumanControlled()) m.CancelPending = true;
			else cancelAutoActions();
		}

		o.cancelAutoActions <- function(cancelIgnorance = true)
		{
			m.IsSkippingRound = false;
			m.IsWaitingRound = false;
			Tactical.State.m.IsEnemyRetreatDialogShown = true; // show the "enemy retreating" popup again

			foreach(e in m.AllEntities)
			{
				if( e.getFlags().has("IsSummoned"))
				{
					if(e.getFlags().has("TempAuto"))
					{
						e.getFlags().remove("TempAuto");
						e.m.IsControlledByPlayer = true;
						e.onFactionChanged();
					}
				}
				else if(e.isPlayerControlled() || "isUnderAIControl" in e && e.isUnderAIControl())
				{
					e.clearAutoSkills();
					if(cancelIgnorance) e.m._isIgnored <- false;
					e.setSkipTurn(false);
					e.cancelAIControl();
				}
			}

			m.JSHandle.call("setEndTurnAllButtonVisible", true);
			m.JSHandle.call("setWaitTurnAllButtonVisible", true);
			m.JSHandle.call("setAIButtonVisible", true);
			m.CancelPending = false;
		}

		o.onAIButtonPressed <- function()
		{
			if(m.IsSkippingRound || !isHumanControlled())
			{
				return;
			}

			Tactical.State.showDialogPopup("自动控制", "将控制权移交给AI吗？(将跳过当前单位的回合,取消回合后可能出现没有技能图标的情况，按下快捷键解决。)", function ()
			{
				cancelAutoActions(false); // reset changes we may have made (except ignoring bros)
				m.JSHandle.call("setEndTurnAllButtonVisible", false);
				m.JSHandle.call("setWaitTurnAllButtonVisible", false);
				m.JSHandle.call("setAIButtonVisible", false);
				Tactical.State.m.IsEnemyRetreatDialogShown = true; // don't show the "enemy retreating" popup
				foreach(e in m.AllEntities)
				{
					if(e.isPlayerControlled() && e.getFlags().has("IsSummoned"))
					{
						e.getFlags().add("TempAuto");
						e.m.IsControlledByPlayer = false;
						e.onFactionChanged();
						initNextTurn();
					}
					else if(e.isPlayerControlled() && e.getAIAgent().ClassName == "player_agent" && !e.isGuest() &&
						(!("_isIgnored" in e.m) || !e.m._isIgnored))
					{
						e.enableAIControl();
						//agent.onTurnStarted(); // seems to cause intermittent crashes...
						initNextTurn();
					}
				}
			}.bindenv(this), null);
		}
/*
		local onEntityEntersFirstSlotFunc = o.onEntityEntersFirstSlot;
		o.onEntityEntersFirstSlot <- function(_entityId)
		{
			if(m.CancelPending) cancelAutoActions();
			onEntityEntersFirstSlotFunc(_entityId);
		}
*/

		o.onEntityEntersFirstSlot <- function(_entityId)
		{
			if(m.CancelPending) cancelAutoActions();
			local entity = this.findEntityByID(this.m.AllEntities, _entityId);

			if (entity)
			{
				if (!entity.entity.isWaitActionSpent() && !entity.entity.isTurnStarted())
				{
					entity.entity.onTurnStart();
				}
				else
				{
					entity.entity.onTurnResumed();
				}

				if (!entity.entity.isAlive())
				{
					return null;
				}

				this.moveToEntity(entity.entity, this.m.JumpToFirstEntity);
				this.m.JumpToFirstEntity = false;
				return this.convertEntityToUIData(entity.entity, entity.index == this.m.CurrentEntities.len() - 1);
			}

			return null;
		}

		o.onEntityEnteredFirstSlotFully <- function(_entityId)
		{
			local entity = this.findEntityByID(this.m.CurrentEntities, _entityId);

			if (entity)
			{
				if (this.m.OnEntityEnteredFirstSlotFullyListener != null)
				{
					this.m.OnEntityEnteredFirstSlotFullyListener(entity.entity);
				}

				this.m.IsLocked = false;
				local e = entity.entity;
				if(e.isPlayerControlled())
				{
					if("_isIgnored" in e.m && e.m._isIgnored) initNextTurn();
					else if(m.IsWaitingRound) onWaitTurnButtonPressed();
				}
			}
		}
	
		o.convertEntityToUIData <- function(_entity, isLastEntity = false)
		{
    // if it is or will be human controlled
			local humanControlled = _entity.isPlayerControlled() && (_entity.getAIAgent() == null || _entity.getAIAgent().ClassName == "player_agent" || m.CancelPending);
			local result = {
				id = _entity.getID(),
				name = _entity.getName(),
				nameOnly = _entity.getNameOnly(),
				levelImagePath = _entity.getLevelImagePath(),
				imageOffsetX = _entity.isDiscovered() ? _entity.getImageOffsetX() : 0,
				imageOffsetY = _entity.isDiscovered() ? _entity.getImageOffsetY() : 0,
				actionPoints = _entity.getActionPoints(),
				actionPointsMax = _entity.getActionPointsMax(),
				hitpoints = _entity.getHitpoints(),
				hitpointsMax = _entity.getHitpointsMax(),
				morale = _entity.getMoraleState(),
				moraleMax = this.Const.MoraleState.COUNT - 1,
				moraleLabel = this.Const.MoraleStateName[_entity.getMoraleState()],
				fatigue = _entity.getFatigue(),
				fatigueMax = _entity.getFatigueMax(),
				armorHead = _entity.getArmor(this.Const.BodyPart.Head),
				armorHeadMax = _entity.getArmorMax(this.Const.BodyPart.Head),
				armorBody = _entity.getArmor(this.Const.BodyPart.Body),
				armorBodyMax = _entity.getArmorMax(this.Const.BodyPart.Body),
				isEnemy = !humanControlled || this.Tactical.State.isAutoRetreat(),
				isHiddenToPlayer = _entity.isHiddenToPlayer() || _entity.getFaction() != 1 && this.Settings.getGameplaySettings().FasterAIMovement || this.Tactical.State.isAutoRetreat(),
				isWaitActionSpent = !this.canEntityWait(_entity)
			};
			if (_entity.isDiscovered())
			{
				result.imagePath <- _entity.getImagePath();
			}
			else
			{
				result.imagePathFoW <- _entity.getImagePath();
			}

			return result;
		}
		
		o.convertEntitySkillsToUIData <- function(_entity)
		{
			if (_entity.isPlayerControlled())
			{
				local result = [];
				local activeSkills = _entity.getSkills().queryActives();

				foreach( skill in activeSkills )
				{
					if (skill.isHidden())
					{
						continue;
					}

					local isSkillAffordable = skill.isAffordable();

					if (this.m.ActiveEntityCostsPreview != null && this.m.ActiveEntityCostsPreview.id == _entity.getID())
					{
						isSkillAffordable = skill.isAffordablePreview();
					}

					result.push({
						id = skill.getID(),
						imagePath = skill.getIcon(),
						isUsable = skill.isUsable() && skill.isAffordable(),
						isAffordable = isSkillAffordable
					});
				}
				if(!_entity.getFlags().has("IsSummoned"))
				{
					foreach(item in _entity.querySwitchableItems())
						result.push({ id = item.getInstanceID(), imagePath = "ui/items/" + item.getIcon(), isUsable = true, isAffordable = true });
				}
				return result;
			}

			return null;
		}
		
	});

	::mods_hookNewObject("skills/actives/actives_horsecharge", function ( o ) {
		local useFunc = o.use;
		o.use <- function( _targetTile, _forFree = false )
		{
			local user = this.m.Container.getActor();
			if (user.isPlayerControlled() && user.isUnderAIControl())
			{
				if (!_forFree && !this.isAffordable() || !this.isUsable())
				{
					return false;
				}
				
				if (!_forFree)
				{
					this.logDebug(user.getName() + "(Auto) uses skill " + this.getName());
				}
				
				if (this.isTargeted())
				{
					if (this.m.IsVisibleTileNeeded && !_targetTile.IsVisibleForEntity)
					{
						return false;
					}

					if (!this.onVerifyTarget(user.getTile(), _targetTile))
					{
//						this.logDebug("----------use(Auto) Checke no");
						this.m.IsSpent = true;
						return false;
					}
				}
			}
//			this.logDebug("----------use(Auto) Checke yes");
			useFunc( _targetTile, _forFree = false );
		}

		local isUsableFunc = o.isUsable;
		o.isUsable <- function()
		{
			local actor = this.getContainer().getActor();
			if (actor.isPlayerControlled() && actor.isUnderAIControl() && this.m.IsSpent)
			{
//				this.logDebug("----------isUsable(Auto) Checke no");
				return false;
			}
			else
			{
//				this.logDebug("----------isUsable(Auto) Checke yes");
				return isUsableFunc();
			}
		}

	});

});
