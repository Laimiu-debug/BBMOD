::mods_registerMod("sarisofoi_company_tabards", 1.5.2024, "Company Tabards");

::mods_queue(null, null, function() {

    ::mods_hookBaseClass("entity/world/settlement", function(s) {
        while(!("onUpdateShopList" in s)) s = s[s.SuperName];

        local onUpdateShopList = s.onUpdateShopList;

        s.onUpdateShopList = function( _id, _list ) {
            if (_id == "building.armorsmith" || _id == "building.armorsmith_oriental") {
			_list.extend([
			{
				R = 40,
				P = 1.0,
				S = "armor_upgrades/tabard_01_upgrade"
			},
			{
				R = 50,
				P = 1.1,
				S = "armor_upgrades/tabard_02_upgrade"
			},
			{
				R = 50,
				P = 1.1,
				S = "armor_upgrades/tabard_03_upgrade"
			},
			{
				R = 50,
				P = 1.1,
				S = "armor_upgrades/tabard_04_upgrade"
			},
			{
				R = 50,
				P = 1.1,
				S = "armor_upgrades/tabard_05_upgrade"
			},
			{
				R = 50,
				P = 1.1,
				S = "armor_upgrades/tabard_06_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_07_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_08_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_09_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_10_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_11_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_12_upgrade"
			},
			{
				R = 60,
				P = 1.2,
				S = "armor_upgrades/tabard_02_upgrade"
			}]);
            }

            onUpdateShopList( _id, _list );
        }
    });
});