this.tabard_03_upgrade_blueprint <- this.inherit("scripts/crafting/blueprint", {
	m = {},
	function create()
	{
		this.blueprint.create();
		this.m.ID = "blueprint.tabard_03_upgrade";
		this.m.PreviewCraftable = this.new("scripts/items/armor_upgrades/tabard_03_upgrade");
		this.m.Cost = 100;
		local ingredients = [
			{
				Script = "scripts/items/misc/spider_silk_item",
				Num = 3
			},
			{
				Script = "scripts/items/misc/paint_white_blue_item",
				Num = 1
			}
		];
		this.init(ingredients);
	}

	function onCraft( _stash )
	{
		_stash.add(this.new("scripts/items/armor_upgrades/tabard_03_upgrade"));
	}

});
