this.tabard_05_upgrade_blueprint <- this.inherit("scripts/crafting/blueprint", {
	m = {},
	function create()
	{
		this.blueprint.create();
		this.m.ID = "blueprint.tabard_05_upgrade";
		this.m.PreviewCraftable = this.new("scripts/items/armor_upgrades/tabard_05_upgrade");
		this.m.Cost = 100;
		local ingredients = [
			{
				Script = "scripts/items/misc/spider_silk_item",
				Num = 3
			},
			{
				Script = "scripts/items/misc/paint_black_item",
				Num = 1
			},
			{
				Script = "scripts/items/misc/paint_red_item",
				Num = 1
			}
		];
		this.init(ingredients);
	}

	function onCraft( _stash )
	{
		_stash.add(this.new("scripts/items/armor_upgrades/tabard_05_upgrade"));
	}

});
