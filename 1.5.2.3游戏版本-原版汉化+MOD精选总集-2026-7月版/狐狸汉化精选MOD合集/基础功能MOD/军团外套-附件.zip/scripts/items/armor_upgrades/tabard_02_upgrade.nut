this.tabard_02_upgrade <- this.inherit("scripts/items/armor_upgrades/armor_upgrade", {
	m = {},
	function create()
	{
		this.armor_upgrade.create();
		this.m.ID = "armor_upgrade.tabard_02";
		this.m.Name = "Tabard";
		this.m.Description = "Durable and light Tabard made from silk threads. Not only it offer some protection in this harsh world but also it boost wearer resolve. Can be put over armor.";
		this.m.ArmorDescription = "A cloth Tabbard has been attached to this armor.";
		this.m.Icon = "armor_upgrades/upgrade_102.png";
		this.m.IconLarge = this.m.Icon;
		this.m.OverlayIcon = "armor_upgrades/icon_upgrade_102.png";
		this.m.OverlayIconLarge = "armor_upgrades/inventory_upgrade_102.png";
		this.m.SpriteFront = null;
		this.m.SpriteBack = "upgrade_102_back";
		this.m.SpriteDamagedFront = null;
		this.m.SpriteDamagedBack = "upgrade_102_back_damaged";
		this.m.SpriteCorpseFront = null;
		this.m.SpriteCorpseBack = "upgrade_102_back_dead";
		this.m.Value = 250;
		this.m.ConditionModifier = 10;
		this.m.StaminaModifier = 0;
	}

	function getTooltip()
	{
		local result = this.armor_upgrade.getTooltip();
		result.push({
			id = 14,
			type = "text",
			icon = "ui/icons/armor_body.png",
			text = "[color=" + this.Const.UI.Color.PositiveValue + "]+10[/color] Durability"
		});
		result.push({
			id = 15,
			type = "text",
			icon = "ui/icons/special.png",
			text = "Increase the Resolve of the wearer  by [color=" + this.Const.UI.Color.PositiveValue + "]+5[/color]"
		});
		return result;
	}

	function onArmorTooltip( _result )
	{
		_result.push({
			id = 15,
			type = "text",
			icon = "ui/icons/special.png",
			text = "Increase the Resolve of the wearer  by [color=" + this.Const.UI.Color.PositiveValue + "]+5[/color]"
		});
	}

	function onUpdateProperties( _properties )
	{
		_properties.Bravery += 5;
	}

});
