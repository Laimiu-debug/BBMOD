::mods_registerMod("mod_hassassin", 1.1, "The Hassassin Origin");
::mods_queue("mod_hassassin", null, function()
{
    // Unique items
    ::mods_hookNewObject("items/weapons/duskrender", function(o) {
        o.create();
    });

    ::mods_hookNewObject("items/armor/dusk_cloak", function(o) {
        o.create();
    });

    ::mods_hookNewObject("items/helmets/nightveil", function(o) {
        o.create();
    });

    // skills
    ::mods_hookNewObject("skills/traits/daggermaster_trait", function(o) {
        o.create();
    });

    ::mods_hookNewObject("skills/traits/pc_trait", function(o) {
        o.create();
    });

    ::mods_hookNewObject("skills/actives/player_throw_dirt", function(o) {
        o.create();
    });

    ::mods_hookNewObject("skills/actives/player_swift_strike", function(o) {
        o.create();
    });

    ::mods_hookNewObject("skills/actives/player_counteract", function(o) {
        o.create();
    });

    ::mods_hookNewObject("skills/backgrounds/hassassin_background", function(o) {
        o.create();
    });
});