this.hassassin_intro_event <- this.inherit("scripts/events/event", {
	m = {},
	function create()
	{
		this.m.ID = "event.hassassin_scenario_intro";
		this.m.IsSpecial = true;
		this.m.Screens.push({
			ID = "A",
			Text = "[img]gfx/ui/events/event_99.png[/img]{The old order is gone, its masters buried, and its secrets scattered like dust in the wind. You have no regrets—loyalty was always a currency, and you were paid in blood. You\'ve lived in the shadows, striking with precision, vanishing without a trace. But the world moves on, and so must you. A notice in the town square offers coin for killers, swords for hire. Crude, but practical. The art of death is still in demand, and your hands remain steady. The creed is gone, but the blade remains. Now, it serves only your will.}",
			Image = "",
			Banner = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "[...]",
					function getResult( _event )
					{
						return 0;
					}

				}
			],
			function start( _event )
			{
				this.Banner = "ui/banners/" + this.World.Assets.getBanner() + "s.png";
			}

		});
	}

	function onUpdateScore()
	{
		return;
	}

	function onPrepare()
	{
		this.m.Title = "Hassassin";
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
	}

});