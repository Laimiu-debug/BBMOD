this.dusk_cloak <- this.inherit("scripts/items/armor/armor", {
	m = {},
	function create()
	{
		this.armor.create();
		this.m.ID = "armor.dusk_cloak";
		this.m.Name = "Dusk Cloak";
		this.m.Description = "The dark robes of an assassin. Disappears as quickly as it\'s wearer strikes his victim.";
		this.m.SlotType = this.Const.ItemSlot.Body;
		this.m.ItemType = this.Const.Items.ItemType.Armor;
		this.m.IsDroppedAsLoot = true;
		this.m.ShowOnCharacter = true;
		this.m.VariantString = "body_southern";
		this.m.Variant = 3;
		this.updateVariant();
		this.m.ImpactSound = this.Const.Sound.ArmorLeatherImpact;
		this.m.InventorySound = this.Const.Sound.ClothEquip;
		this.m.Condition = 120;
		this.m.ConditionMax = 120;
		this.m.StaminaModifier = -6;
		this.m.Value = 1200;
	}
});