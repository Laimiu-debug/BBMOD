this.nightveil <- this.inherit("scripts/items/helmets/helmet", {
	m = {},
	function create()
	{
		this.helmet.create();
		this.m.ID = "helmet.nightveil";
		this.m.Name = "Nightveil";
		this.m.Description = "The dark head wrap of an assassin. A veil of night\'s lethal silence.";
		this.m.SlotType = this.Const.ItemSlot.Head;
		this.m.ItemType = this.Const.Items.ItemType.Helmet;
		this.m.ShowOnCharacter = true;
		this.m.HideHair = true;
		this.m.HideBeard = true;
		this.m.IsDroppedAsLoot = true;
		this.m.VariantString = "helmet_southern";
		this.m.Variant = 10;
		this.updateVariant();
		this.m.ImpactSound = this.Const.Sound.ArmorLeatherImpact;
		this.m.InventorySound = this.Const.Sound.ClothEquip;
		this.m.Condition = 50;
		this.m.ConditionMax = 50;
		this.m.StaminaModifier = -6;
		this.m.Value = 1000;
	}
});