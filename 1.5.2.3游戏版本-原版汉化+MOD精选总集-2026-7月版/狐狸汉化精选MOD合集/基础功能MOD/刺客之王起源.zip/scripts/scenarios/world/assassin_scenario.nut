this.assassin_scenario <- this.inherit("scripts/scenarios/world/starting_scenario", {
    m = {},
    function create()
    {
        this.m.ID = "scenario.assassin";
        this.m.Name = "Hassassin";
        this.m.Description = "[p=c][img]gfx/ui/events/event_165.png[/img][/p][p]You are a lone assassin, a master of shadows and the blade. Your life has been dedicated to the art of killing, and now you seek a new purpose.\n\n[color=#bcad8c]Solo Assassin:[/color] Start with a trained assassin specialized in daggers.\n[color=#bcad8c]Trained:[/color] Starts with [color=#bcad8c]Mastery Dagger[/color], [color=#bcad8c]Backstabber[/color], [color=#bcad8c]Bloodthisrty[/color], [color=#bcad8c]Nimble[/color] and [color=#bcad8c]Lone Wolf[/color].\n[color=#bcad8c]One with the Blade:[/color] Dagger attacks ignore 10% more armor.\n[color=#bcad8c]Dressed to Kill:[/color] Begins with unique but balanced assassin material.\n[/p]";
        this.m.Difficulty = 3;
        this.m.Order = 210;
    }

    function isValid()
    {
        return this.Const.DLC.Wildmen;
        return this.Const.DLC.Desert;
    }

    function onSpawnAssets()
    {
        local roster = this.World.getPlayerRoster();
        local bro;
        bro = roster.create("scripts/entity/tactical/player");
        bro.setStartValuesEx(["hassassin_background"]);
        bro.getBackground().m.RawDescription = "You are a lone assassin, a master of shadows and the blade. Your life has been dedicated to the art of killing, and now you seek a new purpose.";
        bro.getBackground().buildDescription(true);
        bro.setTitle("The Last Hassassin");

        bro.getSprite("miniboss").setBrush("bust_miniboss_lone_wolf");

        bro.getSkills().removeByID("trait.survivor");
        bro.getSkills().removeByID("trait.greedy");
        bro.getSkills().removeByID("trait.loyal");
        bro.getSkills().removeByID("trait.disloyal");

        bro.getSkills().add(this.new("scripts/skills/traits/bloodthirsty_trait"));
        bro.getSkills().add(this.new("scripts/skills/traits/pc_trait"));
        bro.getSkills().add(this.new("scripts/skills/traits/daggermaster_trait"));

        bro.getSkills().add(this.new("scripts/skills/perks/perk_mastery_dagger"));
        bro.getSkills().add(this.new("scripts/skills/perks/perk_nimble"));
        bro.getSkills().add(this.new("scripts/skills/perks/perk_backstabber"));
        bro.getSkills().add(this.new("scripts/skills/perks/perk_lone_wolf"));

        bro.setPlaceInFormation(4);
        bro.getFlags().set("IsPlayerCharacter", true);
        bro.m.HireTime = this.Time.getVirtualTimeF();

        bro.m.PerkPoints = 4;
        bro.m.LevelUps = 4;
        bro.m.Level = 5;
        bro.getBaseProperties().MeleeSkill = 55;
        bro.getBaseProperties().MeleeDefense = 30;
        bro.getBaseProperties().Stamina = 80;
        bro.getBaseProperties().Hitpoints = 50;
        bro.getBaseProperties().Bravery = 50;
        bro.getBaseProperties().Initiative = 105;
        bro.getBaseProperties().RangedSkill = 10;
        bro.getBaseProperties().RangedDefense = 10;
        bro.m.Talents = [];
        bro.m.Attributes = [];

        local talents = bro.getTalents();
        talents.resize(this.Const.Attributes.COUNT, 0);
        talents[this.Const.Attributes.MeleeDefense] = 3;
        talents[this.Const.Attributes.Initiative] = 3;
        talents[this.Const.Attributes.MeleeSkill] = 3;
        bro.fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - 1);

        local items = bro.getItems();
        items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Body));
        items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Head));
        items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Mainhand));
        items.unequip(items.getItemAtSlot(this.Const.ItemSlot.Offhand));
        items.equip(this.new("scripts/items/armor/dusk_cloak"));
        items.equip(this.new("scripts/items/helmets/nightveil"));
        items.equip(this.new("scripts/items/weapons/duskrender"));

        this.World.Assets.m.BusinessReputation = 800;
        this.World.Assets.getStash().resize(this.World.Assets.getStash().getCapacity() - 9);
        this.World.Assets.getStash().add(this.new("scripts/items/supplies/smoked_ham_item"));
        this.World.Assets.m.Money = this.World.Assets.m.Money / 2 - (this.World.Assets.getEconomicDifficulty() == 0 ? 0 : 100);
        this.World.Assets.m.ArmorParts = this.World.Assets.m.ArmorParts / 2;
        this.World.Assets.m.Medicine = this.World.Assets.m.Medicine / 3;
        this.World.Assets.m.Ammo = 0;
    }

    function onSpawnPlayer()
    {
        local randomVillage;

        for( local i = 0; i != this.World.EntityManager.getSettlements().len(); i = ++i )
        {
            randomVillage = this.World.EntityManager.getSettlements()[i];

            if (!randomVillage.isIsolatedFromRoads() && randomVillage.isSouthern())
            {
                break;
            }
        }

        local randomVillageTile = randomVillage.getTile();

        do
        {
            local x = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.X - 1), this.Math.min(this.Const.World.Settings.SizeX - 2, randomVillageTile.SquareCoords.X + 1));
            local y = this.Math.rand(this.Math.max(2, randomVillageTile.SquareCoords.Y - 1), this.Math.min(this.Const.World.Settings.SizeY - 2, randomVillageTile.SquareCoords.Y + 1));

            if (!this.World.isValidTileSquare(x, y))
            {
            }
            else
            {
                local tile = this.World.getTileSquare(x, y);

                if (tile.Type == this.Const.World.TerrainType.Ocean || tile.Type == this.Const.World.TerrainType.Shore)
                {
                }
                else if (tile.getDistanceTo(randomVillageTile) == 0)
                {
                }
                else if (!tile.HasRoad)
                {
                }
                else
                {
                    randomVillageTile = tile;
                    break;
                }
            }
        }
        while (1);

        this.World.State.m.Player = this.World.spawnEntity("scripts/entity/world/player_party", randomVillageTile.Coords.X, randomVillageTile.Coords.Y);
        this.World.Assets.updateLook(6);
        this.World.getCamera().setPos(this.World.State.m.Player.getPos());

        this.Time.scheduleEvent(this.TimeUnit.Real, 1000, function ( _tag )
        {
            this.Music.setTrackList([
                "music/gilded_01.ogg"
            ], this.Const.Music.CrossFadeTime);
            this.World.Events.fire("event.hassassin_scenario_intro");
        }, null);
    }

    function onInit()
    {
        this.World.Assets.m.BrothersMax = 12;
    }

    function onCombatFinished()
    {
        local roster = this.World.getPlayerRoster().getAll();

        foreach( bro in roster )
        {
            if (bro.getFlags().get("IsPlayerCharacter"))
            {
                return true;
            }
        }

        return false;
    }
});