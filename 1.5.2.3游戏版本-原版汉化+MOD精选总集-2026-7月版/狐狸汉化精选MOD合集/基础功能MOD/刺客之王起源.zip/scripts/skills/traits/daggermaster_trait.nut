this.daggermaster_trait <- this.inherit("scripts/skills/traits/character_trait", {
	m = {},
	function create()
	{
		this.character_trait.create();
		this.m.ID = "trait.daggermaster";
		this.m.Name = "Dagger Master";
		this.m.Icon = "skills/status_effect_76.png";
		this.m.Description = "Proficient with the short blade. Able to ignore 10% of armor when dealing damage with a dagger.";
		this.m.Order = this.Const.SkillOrder.Trait;
		this.m.Type = this.m.Type;
		this.m.Excluded = [];
	}

	function getTooltip()
	{
		return [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			},
			{
				id = 10,
				type = "text",
				icon = "ui/icons/armor_damage.png",
				text = "[color=" + this.Const.UI.Color.PositiveValue + "]+" + "[/color]10% Direct damage with a [color=#6a5acd]Dagger[/color]"
			}
		];
	}

	function onAnySkillUsed( _skill, _targetEntity, _properties )
	{
		if (_skill.getID() == "actives.stab" || _skill.getID() == "actives.puncture" || _skill.getID() == "actives.player_counteract" || _skill.getID() == "actives.player_swift_strike")
		{
			_properties.DamageDirectAdd = 0.1;

		}
	}

});