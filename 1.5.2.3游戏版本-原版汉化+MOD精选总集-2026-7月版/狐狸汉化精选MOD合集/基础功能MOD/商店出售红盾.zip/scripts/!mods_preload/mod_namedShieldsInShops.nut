::mods_registerMod("mod_namedShieldsInShops", 1.0);
::mods_queue(null, null, function()
{
	::mods_hookNewObject("entity/world/settlements/buildings/armorsmith_building", function(o)
	{
		local fillStash = o.fillStash;
		o.fillStash = function (_list, _stash, _priceMult, _allowDamagedEquipment = false)
		{
			foreach( i in this.Const.Items.NamedShields )
			{
				if (this.Math.rand(1, 100) <= 33)
				{
					_list.push({
						R = 99,
						P = 2.0,
						S = i
					});
				}
			}
			
			fillStash(_list, _stash, _priceMult, _allowDamagedEquipment);
		};
	});
	
	::mods_hookNewObject("entity/world/settlements/buildings/armorsmith_oriental_building", function(o)
	{
		local fillStash = o.fillStash;
		o.fillStash = function (_list, _stash, _priceMult, _allowDamagedEquipment = false)
		{
			foreach( i in this.Const.Items.NamedShields )
			{
				if (this.Math.rand(1, 100) <= 33)
				{
					_list.push({
						R = 99,
						P = 2.0,
						S = i
					});
				}
			}
			
			fillStash(_list, _stash, _priceMult, _allowDamagedEquipment);
		};
	});
});
