::mods_registerMod("Lair_Info_Compilation", 1.0)

::mods_queue("Lair_Info_Compilation", null, function()
{
	::mods_hookBaseClass("entity/world/location", function(o) {
	
		while(!("getTooltip" in o)) o = o[o.SuperName];
		local getTooltip = o.getTooltip;	
		o.getTooltip = function() 
		{
			// this is the part that enables scouting from enduriel's scoutable locations
			if(!this.m.IsShowingDefenders)
			{
				this.m.IsShowingDefenders = true;
			}

			// this is the part that displays the chance of named item the code was posted by Adam in comments to Named Item Chance display mod (by CleverFool)
			local tooltip = getTooltip();
			if(isLocationType(Const.World.LocationType.Lair) && !isLocationType(Const.World.LocationType.Unique))
			{
				local tile = getTile(), nearestSettlement = 9000;
				foreach(s in World.EntityManager.getSettlements())
				{
					local d = tile.getDistanceTo(s.getTile());
					if(d < nearestSettlement) nearestSettlement = d;
				}

				local chance = Math.min(100, Math.round((nearestSettlement*4 + m.Resources) * 0.2 - 37));
				if(chance > 0)
				{
				tooltip.append({ id = 123, type = "description", text = "\nNamed Item Chance: " + chance + "%"});
				}
			}
			
			// and this is what I ended up with while trying to make tnf_seeNamedItems play nice with the above two mods
			// Looking at his code his method for pulling the actual names seemed freakishly needlesly roundabout
			// So I looked up how Named Items on Enemy Tooltip by unblest pulled those names and used that to write the following
			if (!this.getLoot().isEmpty())
			{
				local i = 0;
				foreach( item in this.getLoot().getItems() )
				{
					if (item.isItemType(this.Const.Items.ItemType.Named))
					{
						tooltip.push({
							id = 200 + i,
							type = "title",
							icon =  "ui/items/" + item.getIcon(),
							text = "[color=" + this.Const.UI.Color.NegativeEventValue + "]" + item.getName() + "[/color]"
						});
						i = i + 1;
					}
				}
			}
			return tooltip;
		}
	});
});