::mods_hookClass("crafting/blueprint", function(o) {
	while(!("isQualified" in o)) o = o[o.SuperName]; // find the base class
	if(!("tnf_allRecipes" in o))
	{
		o.tnf_allRecipes <- true; // only override the methods once per base instance
		o.isQualified = function()
		{
			return true;
		}
	}
});