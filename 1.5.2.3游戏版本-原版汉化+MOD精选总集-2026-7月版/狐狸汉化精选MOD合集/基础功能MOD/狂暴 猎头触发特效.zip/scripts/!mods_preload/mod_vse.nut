::VSE <- {
	Version = "1.0.2",
	ID = "mod_vse",
	Name = "Visual Skill Effects",
	KillingFrenzyBrushID = "VSE_KillingFrenzy",
	KillingFrenzyBrush = "zombie_rage_eyes",
	HeadHunterBrushID = "VSE_HeadHunter"
}
::mods_registerMod(::VSE.ID, ::VSE.Version, ::VSE.Name);

::mods_queue(::VSE.ID, "mod_msu(>=1.0.0-beta)", function()
{
	::VSE.Mod <- ::MSU.Class.Mod(::VSE.ID, ::VSE.Version, ::VSE.Name);

	local page = ::VSE.Mod.ModSettings.addPage("Main");

	local setting = page.addBooleanSetting("KillingFrenzy", true, "Killing Frenzy Eyes", "Enables the glowing eyes when killing frenzy is activated.");
	setting = page.addBooleanSetting("HeadHunter", true, "Head Hunter Puppet", "Enables the puppet effect when head hunter is activated.");

	setting = page.addEnumSetting("KillingFrenzyBrush", "Red", ["Blue", "Red"], "Eye Color", "Change the eye color displayed when the human gets killing frenzy.");
	setting.addCallback(function(_value)
	{
		local table = {
			Red = "zombie_rage_eyes",
			Blue = "bust_glowing_eyes"
		}
		if (_value in table) return table[_value]
	});

	::include("vse/actor");
	::include("vse/killing_frenzy_effect");
	::include("vse/perk_head_hunter");
});
