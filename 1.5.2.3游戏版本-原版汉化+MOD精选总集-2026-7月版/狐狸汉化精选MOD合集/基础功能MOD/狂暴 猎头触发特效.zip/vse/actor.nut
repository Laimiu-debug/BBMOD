::mods_hookExactClass("entity/tactical/actor", function (o)
{
	local create = o.create;
	o.create = function()
	{
		create();
		this.VSE_SpriteIDs <- [];
	}

	o.VSE_addSpriteWithBrush <- function( _sprite, _brush, _delay = true, _setDirty = false, _autoFlip = true )
	{
		local sprite = this.addSprite(_sprite)
		sprite.setBrush(_brush);
		sprite.Visible = true;
		if (_delay)
		{
			sprite.Alpha = 0;
			sprite.fadeIn(1000);
		}
		if (_autoFlip)
		{
			sprite.setHorizontalFlipping(!this.isAlliedWithPlayer());
		}
		if (_setDirty) this.setDirty(true);
		this.VSE_SpriteIDs.push(_sprite)
	}

	o.VSE_removeSpriteIfExists <- function( _sprite, _delay = true, _setDirty = false )
	{
		if (this.hasSprite(_sprite))
		{
			if (_delay)
			{
				this.getSprite(_sprite).fadeOutAndHide(1000);
				::Time.scheduleEvent(::TimeUnit.Real, 1000, function(_)
				{
					this.removeSprite(_sprite);
					if (_setDirty) this.setDirty(true)
				}.bindenv(this), null);
			}
			else
			{
				this.removeSprite(_sprite);
				if (_setDirty) this.setDirty(true);
			}
		}
		local idx = this.VSE_SpriteIDs.find(_sprite)
		if (idx != null) this.VSE_SpriteIDs.remove(idx);
	}

	local onFactionChanged = o.onFactionChanged;
	o.onFactionChanged = function()
	{
		local flip = !this.isAlliedWithPlayer();
		for (local i = this.VSE_SpriteIDs.len() - 1; i >= 0; --i) // reversed for loop so I can delete
		{
			if (this.hasSprite(this.VSE_SpriteIDs[i])) this.getSprite(this.VSE_SpriteIDs[i]).setHorizontalFlipping(flip);
			else this.VSE_SpriteIDs.remove(i);
		}
		onFactionChanged();
	}
});
