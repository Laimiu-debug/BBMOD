::mods_hookExactClass("skills/effects/killing_frenzy_effect", function (o)
{
	local onAdded = ::mods_getMember(o, "onAdded");
	o.onAdded <- function()
	{
		onAdded();
		if (::VSE.Mod.ModSettings.getSetting("KillingFrenzy").getValue())
		{
			this.getContainer().getActor().VSE_addSpriteWithBrush(::VSE.KillingFrenzyBrushID, ::VSE.KillingFrenzyBrush, true, true)
		}
	}

	local onRemoved = ::mods_getMember(o, "onRemoved");
	o.onRemoved <- function()
	{
		onRemoved();
		this.getContainer().getActor().VSE_removeSpriteIfExists(::VSE.KillingFrenzyBrushID, true, true)
	}
});
