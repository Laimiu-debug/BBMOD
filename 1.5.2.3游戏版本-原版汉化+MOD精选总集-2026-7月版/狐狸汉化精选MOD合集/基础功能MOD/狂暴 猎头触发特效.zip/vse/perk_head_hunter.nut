::mods_hookExactClass("skills/perks/perk_head_hunter", function (o)
{
	local create = ::mods_getMember(o, "create")
	o.create = function()
	{
		create();
		this.m.VSE_CachedTile <- null;
	}

	local onBeforeTargetHit = ::mods_getMember(o, "onBeforeTargetHit");
	o.onBeforeTargetHit <- function( _skill, _targetEntity, _hitInfo )
	{
		onBeforeTargetHit(_skill, _targetEntity, _hitInfo);
		this.m.VSE_CachedTile = _hitInfo.Tile;
	}

	local onTargetHit = ::mods_getMember(o, "onTargetHit");
	o.onTargetHit <- function( _skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor )
	{
		if (_bodyPart == ::Const.BodyPart.Head)
		{
			local actor = this.getContainer().getActor();

			if (this.m.Stacks == 0 && this.m.SkillCount != ::Const.SkillCounter)
			{
				this.spawnIcon("status_effect_108", actor.getTile()); // champion popup
				if (::VSE.Mod.ModSettings.getSetting("HeadHunter").getValue())
				{
					actor.VSE_addSpriteWithBrush(::VSE.HeadHunterBrushID, "mind_control");
				}
			}
			else
			{
				actor.VSE_removeSpriteIfExists(::VSE.HeadHunterBrushID, true, true);
				this.spawnIcon("vse-head_hunter", this.m.VSE_CachedTile);
			}
		}
		onTargetHit(_skill, _targetEntity, _bodyPart, _damageInflictedHitpoints, _damageInflictedArmor);
	}

	local onCombatFinished = ::mods_getMember(o, "onCombatFinished");
	o.onCombatFinished <- function()
	{
		// In case combat finished without the sprite getting removed
		this.getContainer().getActor().VSE_removeSpriteIfExists(::VSE.HeadHunterBrushID, false, true)
		onCombatFinished();
	}
});
