local wtp_onFactionChanged = function()
{
	if (!this.m.IsControlledByPlayer)
		return;
	
	if (this.m.OriginalAgent == null)
		this.m.OriginalAgent = this.getAIAgent();

	if (this.getSkills().hasSkill("effects.legend_intensely_charmed") || this.getSkills().hasSkill("effects.charmed") || this.getFlags().get("Charmed"))
		return;

	local f = this.getFaction();

	if (f == ::Const.Faction.PlayerAnimals)
	{
		if (this.getAIAgent().getID() == ::Const.AI.Agent.ID.Player)
			return;

		this.setAIAgent(::new("scripts/ai/tactical/player_agent"));
		this.getAIAgent().setActor(this);
	}
	else if (this.m.OriginalAgent != null && this.m.OriginalAgent.getID() != this.getAIAgent().getID())
	{
		this.setAIAgent(this.m.OriginalAgent);
		this.getAIAgent().setActor(this);
	}
	else if (f != ::Const.Faction.Player && this.getAIAgent().getID() == ::Const.AI.Agent.ID.Player)
	{
		this.getAIAgent().setActor(null);
		this.setAIAgent(::new("scripts/ai/tactical/agents/charmed_player_agent"));
		this.getAIAgent().setActor(this);
	}
};

if (::mods_getRegisteredMod("mod_nggh_magic_concept") == null)
{
	::mods_hookExactClass("entity/tactical/actor", function(obj)
	{
		obj.m.OriginalAgent <- null;

		obj.getBackground <- function() 
		{
			return null;
		}
		obj.getPerkPoints <- function() 
		{
			return 0;
		}
		obj.getPerkPointsSpent <- function() 
		{
			return 0;
		}
		obj.getDaysWithCompany <- function() 
		{
			return 0;
		}
		obj.getXP <- function()
		{
			return this.getXPValue();
		}
		obj.getXPForNextLevel <- function() 
		{
			return this.getXPValue();
		}
		obj.getDailyCost <- function() 
		{
			return 0;
		}
		obj.getDaysWounded <- function() 
		{
			return 0;
		}
		obj.isLeveled <- function() 
		{
			return false;
		}
		obj.getMoodState <- function() 
		{
			return 3;
		}
		obj.getLevelUps <- function() 
		{
			return 0;
		}
		obj.isInReserves <- function() 
		{
			return false;
		}
		obj.isStabled <- function() 
		{
			return false;
		}
		obj.getRiderID <- function() 
		{
			return "";
		}
		obj.getTalents <- function() 
		{
			return array(::Const.Attributes.COUNT, 0);
		}
		obj.isGuest <- function() 
		{
			return true;
		}
		obj.getPlaceInFormation <- function() 
		{
			return 21;
		}
		obj.getPercentOnKillOtherActorModifier <- function() 
		{
			return 1.0;
		}
		obj.getFlatOnKillOtherActorModifier <- function() 
		{
			return 1.0;
		}
		obj.getRosterTooltip <- function() 
		{
			return  [{
				id = 1,
				type = "title",
				text = this.getName()
			}];
		}
		obj.isPlayerControlled = function()
		{
			local f = this.getFaction();
			return this.m.IsControlledByPlayer && (f == ::Const.Faction.Player || f == ::Const.Faction.PlayerAnimals);
		}
		local onFactionChanged = obj.onFactionChanged;
		obj.onFactionChanged = function()
		{
			onFactionChanged();
			wtp_onFactionChanged.call(this);
		}
	});
}
else
{
	::mods_hookExactClass("entity/tactical/actor", function(obj)
	{
		obj.m.OriginalAgent <- null;

		local onFactionChanged = obj.onFactionChanged;
		obj.onFactionChanged = function()
		{
			onFactionChanged();
			wtp_onFactionChanged.call(this);
		}
	});
}