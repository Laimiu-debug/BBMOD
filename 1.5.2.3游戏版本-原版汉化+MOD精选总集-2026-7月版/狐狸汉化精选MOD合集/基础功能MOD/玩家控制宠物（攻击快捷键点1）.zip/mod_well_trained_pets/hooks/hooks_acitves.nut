if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

foreach (active in [
	"wolf_bite",
	"werewolf_bite",
	"warhound_bite",
	"wardog_bite",
	"spider_bite_skill",
	"serpent_bite_skill",
	"hyena_bite_skill",
	"legend_vala_warden_pale_touch",
	"legend_vala_warden_wail",
])
{
	::mods_hookExactClass("skills/actives/" + active, function(obj)
	{
		obj.getTooltip <- function()
		{
			return this.getDefaultTooltip();
		}
	});
}

foreach (active in [
	"grow_shield_skill",
	"serpent_hook_skill",
	"web_skill",
	"fling_back_skill",
	"unstoppable_charge_skill",
])
{
	::mods_hookExactClass("skills/actives/" + active, function(obj)
	{
		obj.getTooltip <- function()
		{
			return this.skill.getDefaultUtilityTooltip();
		}
	});
}