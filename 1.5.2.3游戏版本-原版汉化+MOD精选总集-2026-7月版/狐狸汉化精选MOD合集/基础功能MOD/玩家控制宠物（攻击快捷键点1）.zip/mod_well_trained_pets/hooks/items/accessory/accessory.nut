::mods_hookDescendants("items/accessory/accessory", function(obj)
{
	if (!("setEntity" in obj))
		return;
	
	local ws_setEntity = obj.setEntity;
	obj.setEntity = function( _e )
	{
		ws_setEntity(_e);

		if (_e == null)
			return;

		_e.m.IsControlledByPlayer = true;
		_e.onFactionChanged();
	}
});