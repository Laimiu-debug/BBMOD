if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

if (::mods_getRegisteredMod("mod_AC") == null)
	return;

::mods_hookExactClass("skills/actives/gorge_skill", function(obj)
{
	obj.getTooltip <- function()
	{
		local ret = this.getDefaultTooltip();
		ret.push({
			id = 7,
			type = "text",
			icon = "ui/icons/vision.png",
			text = "Has a range of [color=" + this.Const.UI.Color.PositiveValue + "]2[/color] tiles"
		});

		return ret;
	}
});