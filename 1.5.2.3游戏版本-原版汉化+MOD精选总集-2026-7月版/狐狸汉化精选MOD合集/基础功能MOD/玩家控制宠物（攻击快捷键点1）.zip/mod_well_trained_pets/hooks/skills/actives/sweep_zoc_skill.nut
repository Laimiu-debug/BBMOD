if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

if (::mods_getRegisteredMod("mod_AC") == null)
	return;

::mods_hookExactClass("skills/actives/sweep_zoc_skill", function(obj)
{
	obj.isHidden <- function()
	{
		return true;
	}

	obj.isUsable <- function()
	{
		return this.m.IsUsable && this.m.Container.getActor().getCurrentProperties().IsAbleToUseSkills && (!this.m.IsWeaponSkill || this.m.Container.getActor().getCurrentProperties().IsAbleToUseWeaponSkills);
	}
});