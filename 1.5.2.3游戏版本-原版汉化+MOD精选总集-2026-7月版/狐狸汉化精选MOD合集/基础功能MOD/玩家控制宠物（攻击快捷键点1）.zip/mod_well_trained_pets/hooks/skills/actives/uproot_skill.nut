if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

if (::mods_getRegisteredMod("mod_AC") == null)
	return;

::mods_hookExactClass("skills/actives/uproot_skill", function(obj)
{
	obj.getTooltip <- function()
	{
		local ret = this.getDefaultTooltip();
		ret.push({
			id = 10,
			type = "text",
			icon = "ui/icons/special.png",
			text = "Can hit up to 3 targets"
		});
		return ret;
	}

	obj.onTargetSelected <- function( _targetTile )
	{
		local ownTile = this.m.Container.getActor().getTile();
		local dir = ownTile.getDirectionTo(_targetTile);
		
		this.Tactical.getHighlighter().addOverlayIcon(this.Const.Tactical.Settings.AreaOfEffectIcon, _targetTile, _targetTile.Pos.X, _targetTile.Pos.Y);
		
		if (_targetTile.hasNextTile(dir))
		{
			local forwardTile = _targetTile.getNextTile(dir);
				
			if (forwardTile.IsOccupiedByActor || forwardTile.IsEmpty)
			{
				this.Tactical.getHighlighter().addOverlayIcon(this.Const.Tactical.Settings.AreaOfEffectIcon, forwardTile, forwardTile.Pos.X, forwardTile.Pos.Y);
			}
			
			if (forwardTile.hasNextTile(dir))
			{
				local followupTile = forwardTile.getNextTile(dir);
				
				if (followupTile.IsOccupiedByActor || followupTile.IsEmpty)
				{
					this.Tactical.getHighlighter().addOverlayIcon(this.Const.Tactical.Settings.AreaOfEffectIcon, followupTile, followupTile.Pos.X, followupTile.Pos.Y);
				}
			}
		}
	}
});