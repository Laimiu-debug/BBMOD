::mods_hookDescendants("skills/skill", function(o) {
	if (!("create" in o))
		return;

	local create = o.create;
	o.create = function()
	{
		create();

		if (!this.isType(this.Const.SkillType.Active) || !this.isActive())
			return;

		// when this skill has no icon
		if (this.m.Icon.len() == 0 || (this.m.Icon.find("/perks") == null && ::ModWellTrainedPets.Images.find(this.m.Icon) == null))
		{
			// finally found a shit
			if (this.m.Overlay.len() > 0 && ::ModWellTrainedPets.Images.find("skills/" + this.m.Overlay + ".png") != null)
				this.m.Icon = "skills/" + this.m.Overlay + ".png";
			else
				this.m.Icon = "skills/placeholder_skill.png";
		}

		if (this.m.IconDisabled == this.m.Icon || (this.m.IconDisabled.find("/perks") == null && ::ModWellTrainedPets.Images.find(this.m.IconDisabled) == null)) 
		{
			// finally found a shit
			if (this.m.Overlay.len() > 0 && ::ModWellTrainedPets.Images.find("skills/" + this.m.Overlay + "_sw.png") != null)
				this.m.IconDisabled = "skills/" + this.m.Overlay + "_sw.png";
			else if (this.m.Overlay.len() > 0 && ::ModWellTrainedPets.Images.find("skills/" + this.m.Overlay + "_bw.png") != null)
				this.m.IconDisabled = "skills/" + this.m.Overlay + "_bw.png";
			else
				this.m.IconDisabled = "skills/placeholder_skill_sw.png";
		}
	}
});