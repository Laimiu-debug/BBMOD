if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

// allow pet to retreat with player when the retreat order is given
::mods_hookExactClass("states/tactical_state", function ( obj )
{
	local ws_tactical_flee_screen_onFleePressed = obj.tactical_flee_screen_onFleePressed;
	obj.tactical_flee_screen_onFleePressed = function()
	{
		if (!this.isScenarioMode() && !this.isEveryoneSafe() && !this.m.IsAutoRetreat)
		{
			foreach( pet in ::Tactical.Entities.getInstancesOfFaction(::Const.Faction.PlayerAnimals) )
			{
				if (!pet.isAlive() || pet.isDying())
					continue;
				
				if (pet.getAIAgent().getID() == this.Const.AI.Agent.ID.Player)
				{
					pet.m.IsControlledByPlayer = false;
					pet.getAIAgent().setActor(null);

					if (pet.m.OriginalAgent != null && pet.m.OriginalAgent.getID() != this.Const.AI.Agent.ID.Player)
						pet.setAIAgent(pet.m.OriginalAgent);
					else
						pet.setAIAgent(::new("scripts/ai/tactical/agents/charmed_player_agent"));

					pet.getAIAgent().setActor(pet);
				}
				
				::Tactical.TurnSequenceBar.updateEntity(pet.getID());
			}
		}

		ws_tactical_flee_screen_onFleePressed()
	};
});