if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

// allow player pet to appear in inventory screen when open it in battle
::mods_hookExactClass("ui/screens/character/character_screen", function ( obj )
{
	local tactical_onQueryBrothersList = obj.tactical_onQueryBrothersList;
	obj.tactical_onQueryBrothersList = function()
	{
		local result = tactical_onQueryBrothersList();

		if (result == null || result.len() >= 27)
			return result;
		
		local activeEntity = this.Tactical.TurnSequenceBar.getActiveEntity();

		foreach( entity in ::Tactical.Entities.getInstancesOfFaction(::Const.Faction.PlayerAnimals) )
		{
			if (entity.isPlayerControlled())
				result.push(this.UIDataHelper.convertEntityToUIData(entity, activeEntity));

			if (result.len() == 27)
		    	break;
		}

		return result;
	}
});