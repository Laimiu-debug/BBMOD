::mods_hookExactClass("entity/tactical/legend_vala_warden_script", function(obj)
{
	local ws_create = obj.create;
	obj.create = function()
	{
		ws_create();
		this.m.IsControlledByPlayer = true;
	}
});