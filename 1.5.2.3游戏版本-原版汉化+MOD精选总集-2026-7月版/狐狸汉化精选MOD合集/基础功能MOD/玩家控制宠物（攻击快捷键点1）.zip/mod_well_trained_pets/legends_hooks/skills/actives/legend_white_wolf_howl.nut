if (::mods_getRegisteredMod("mod_nggh_magic_concept") != null)
	return;

// disable this skill cuz player is not allowed to use it
::mods_hookExactClass("skills/actives/legend_white_wolf_howl", function(obj)
{
	obj.isHidden <- function()
	{
		return this.getContainer().getActor().isPlayerControlled() || this.m.IsHidden;
	}
});