foreach (file in ::IO.enumerateFiles("mod_well_trained_pets/hooks"))
{
	::include(file);
}

if (::mods_getRegisteredMod("mod_legends_PTR") == null)
	return;

foreach (file in ::IO.enumerateFiles("mod_well_trained_pets/legends_hooks"))
{
	::include(file);
}