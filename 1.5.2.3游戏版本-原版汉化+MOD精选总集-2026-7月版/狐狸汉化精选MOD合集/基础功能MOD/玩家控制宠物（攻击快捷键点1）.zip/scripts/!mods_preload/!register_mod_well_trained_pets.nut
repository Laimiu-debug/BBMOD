::ModWellTrainedPets <- {
	ID = "mod_well_trained_pets",
	Name = "Well Trained Pets (Legends)",
	Version = "2.9.0",
	Images = [],
};

::mods_registerMod(::ModWellTrainedPets.ID, ::ModWellTrainedPets.Version, ::ModWellTrainedPets.Name);
::mods_queue(::ModWellTrainedPets.ID, "mod_msu, >mod_AC, <mod_nggh_magic_concept", function()
{
	// define mod class of this mod
	::ModWellTrainedPets.Mod <- ::MSU.Class.Mod(::ModWellTrainedPets.ID, ::ModWellTrainedPets.Version, ::ModWellTrainedPets.Name);

	// load hook files
	::include("mod_well_trained_pets/load.nut");

	// add another callbacks to compile certain data
	::MSU.UI.addOnConnectCallback(function() {
		foreach (directory in ::IO.enumerateFiles("gfx/skills/"))
		{
			::ModWellTrainedPets.Images.push(directory.slice(4) + ".png");
		}
	});
});
