::mods_hookClass("entity/tactical/human", function(o) {
  local onInit = o.onInit;
  o.onInit = function()
  {	
	onInit();
	this.m.Skills.add(this.new("scripts/skills/special/boneplateing"));
	//this.logDebug(" >> bone hook" );
    
  }
});