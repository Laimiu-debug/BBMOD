this.boneplateing <- this.inherit("scripts/skills/skill", {
	m = {},
	function create()
	{
		this.m.ID = "special.boneplateing";
		this.m.Name = "Boneplating";
		this.m.Description = "This unit is protected by boneplating.";
		this.m.Icon = "boneplateing-raw.png";
		this.m.IconMini = "icon_boneplateing_mini";
		this.m.Type = this.Const.SkillType.StatusEffect | this.Const.SkillType.Special;
		this.m.IsActive = false;
		this.m.IsSerialized = false;
	}

	function getTooltip()
	{
		local ret = [
			{
				id = 1,
				type = "title",
				text = this.getName()
			},
			{
				id = 2,
				type = "description",
				text = this.getDescription()
			}
		];		
		return ret;
	}

	function isHidden()
	{
		return this.skill.isHidden();
	}

	function onUpdate( _properties )
	{
		local armour = this.getContainer().getActor().getItems().getItemAtSlot(this.Const.ItemSlot.Body);
		if (armour != null && armour.getUpgrade() != null && armour.getUpgrade().getID() == "armor_upgrade.bone_platings" && armour.getUpgrade().m.IsUsed == false) 
		{
			this.m.IsHidden = false;
		} else 	{
			this.m.IsHidden = true;
		}
		//this.logDebug(" >> Boneplating onUpdate()" );
		
	}

});

