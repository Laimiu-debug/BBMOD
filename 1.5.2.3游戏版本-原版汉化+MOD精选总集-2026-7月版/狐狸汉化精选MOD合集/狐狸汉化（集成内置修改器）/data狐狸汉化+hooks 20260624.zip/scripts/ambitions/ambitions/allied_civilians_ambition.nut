this.allied_civilians_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.allied_civilians";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们需要盟友。与其中一座城镇建立友谊与信任的纽带，\n将为战团争取到更优惠的价格、更多的新兵以及更多的任务。";
		this.m.UIText = "与一个平民派系建立 \'友好\'关系";
		this.m.RewardTooltip = "良好的关系会让你获得更优惠的价格，并有更多的人手可供招募。";
		this.m.TooltipText = "通过履行派系定居点中的合同，将世界上某个村庄或城镇的平民派系的关系提升为 \'友好\'。违反合同或背叛他们会降低你们的关系。提升与城邦的关系比提升与小村庄的关系耗时更长。贵族家族不算平民派系。";
		this.m.SuccessText = "[img]gfx/ui/events/event_65.png[/img]你认定 %friendlytown% 是一个值得投入精力的地方，决定为那里提供战团的保护，接受任何适合你能力的工作。你在与当地人的交往中表现得像个绅士，并鼓励手下的弟兄们在定居点内注意言行举止。起初当然少不了一些牢骚。%brawler% 因为不能再和农民干架而感到非常失望，特别是考虑到 %companyname% 在 %friendlytown% 待了这么久。\n\n但你最终说服了弟兄们，让他们明白在这一行里拥有一个友好的行动基地非常重要，这意味着在市场上能获得更优惠的价格，也会有更多人愿意加入你们这帮乌合之众。而且不用整天躲避民兵，确实也轻松了不少。你甚至动员弟兄们去做一些仅仅为了换取好感的小差事。%SPEECH_ON%我找到了那个乱跑的小鬼，直接把他拽回了家。%SPEECH_OFF%%randombrother% 吹嘘道，紧接着就被 %randombrother2% 抢了风头。%SPEECH_ON%我帮那个寡妇去了趟市场，劈好了过冬的木柴，甚至还帮她晾了衣服，但我绝对不会去救什么困在树上的猫。%SPEECH_OFF%";
		this.m.SuccessButtonText = "这对我们大有裨益。";
	}

	function onUpdateScore()
	{
		local allies = this.World.FactionManager.getAlliedFactions(this.Const.Faction.Player);

		foreach( a in allies )
		{
			local f = this.World.FactionManager.getFaction(a);

			if (f != null && (f.getType() == this.Const.FactionType.Settlement || f.getType() == this.Const.FactionType.OrientalCityState) && f.getPlayerRelation() >= 70.0)
			{
				this.m.IsDone = true;
				return;
			}
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		local allies = this.World.FactionManager.getAlliedFactions(this.Const.Faction.Player);

		foreach( a in allies )
		{
			local f = this.World.FactionManager.getFaction(a);

			if (f != null && (f.getType() == this.Const.FactionType.Settlement || f.getType() == this.Const.FactionType.OrientalCityState) && f.getPlayerRelation() >= 70.0)
			{
				return true;
			}
		}

		return false;
	}

	function onPrepareVariables( _vars )
	{
		local allies = this.World.FactionManager.getAlliedFactions(this.Const.Faction.Player);

		foreach( a in allies )
		{
			local f = this.World.FactionManager.getFaction(a);

			if (f != null && (f.getType() == this.Const.FactionType.Settlement || f.getType() == this.Const.FactionType.OrientalCityState) && f.getPlayerRelation() >= 70.0)
			{
				_vars.push([
					"friendlytown",
					f.getName()
				]);
				break;
			}
		}

		local brothers = this.World.getPlayerRoster().getAll();

		if (brothers.len() > 1)
		{
			for( local i = 0; i < brothers.len(); i = ++i )
			{
				if (brothers[i].getSkills().hasSkill("trait.player"))
				{
					brothers.remove(i);
					break;
				}
			}
		}

		foreach( bro in brothers )
		{
			if (bro.getBackground().getID() == "background.brawler")
			{
				_vars.push([
					"brawler",
					bro.getName()
				]);
				return;
			}
		}

		foreach( bro in brothers )
		{
			if (bro.getBackground().isCombatBackground())
			{
				_vars.push([
					"brawler",
					bro.getName()
				]);
				return;
			}
		}

		_vars.push([
			"brawler",
			brothers[this.Math.rand(0, brothers.len() - 1)].getName()
		]);
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

