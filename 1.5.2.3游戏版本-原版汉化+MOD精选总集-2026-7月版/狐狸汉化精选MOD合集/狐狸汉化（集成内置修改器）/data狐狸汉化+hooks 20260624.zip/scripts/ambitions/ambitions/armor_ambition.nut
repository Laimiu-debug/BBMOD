this.armor_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.armor";
		this.m.Duration = 40.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们将为至少三名弟兄装备重甲，\n让他们成为对抗危险敌人的坚实壁垒。";
		this.m.UIText = "拥有3件230+耐久的盔甲和头盔";
		this.m.TooltipText = "拥有3件盔甲和3个头盔，每件装备耐久需达到230或更高。无论是购买也好，战场上缴获也罢，它们都能同样出色地保护你的弟兄。";
		this.m.SuccessText = "[img]gfx/ui/events/event_35.png[/img]随着 %companyname% 获得了更多重甲和头盔，弟兄们士气大振。%SPEECH_ON%感觉到了吗？这就叫手艺。%SPEECH_OFF%%randombrother% 说道，同时用硬木剑柄敲了敲战友那刚戴上头盔的脑袋。%SPEECH_ON%想想看，以前因为那些破烂盔甲和寒酸装备，我们错过了多少报酬丰厚的合同。%SPEECH_OFF%从现在起，后排的弟兄在进入战场时可以松一口气了，因为他们知道重装上阵的弟兄会顶在前方承受冲击。即便他们倒下了，那笨重的身躯至少也能拖慢敌人，给轻甲同伴提供快速撤退的机会。";
		this.m.SuccessButtonText = "这将有助于我们在未来的战斗中旗开得胜。";
	}

	function getArmor()
	{
		local ret = {
			Armor = 0,
			Helmet = 0
		};
		local items = this.World.Assets.getStash().getItems();

		foreach( item in items )
		{
			if (item != null)
			{
				if (item.isItemType(this.Const.Items.ItemType.Armor) && item.getArmorMax() >= 230)
				{
					++ret.Armor;
				}
				else if (item.isItemType(this.Const.Items.ItemType.Helmet) && item.getArmorMax() >= 230)
				{
					++ret.Helmet;
				}
			}
		}

		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			local item = bro.getItems().getItemAtSlot(this.Const.ItemSlot.Head);

			if (item != null)
			{
				if (item.getArmorMax() >= 230)
				{
					++ret.Helmet;
				}
			}

			item = bro.getItems().getItemAtSlot(this.Const.ItemSlot.Body);

			if (item != null)
			{
				if (item.getArmorMax() >= 230)
				{
					++ret.Armor;
				}
			}
		}

		return ret;
	}

	function onUpdateScore()
	{
		if (this.World.getTime().Days <= 40)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		local armor = this.getArmor();

		if (armor.Armor >= 3 || armor.Helmet >= 3)
		{
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		local armor = this.getArmor();

		if (armor.Armor >= 3 && armor.Helmet >= 3)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

