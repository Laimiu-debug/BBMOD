this.battle_standard_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.battle_standard";
		this.m.Duration = 99999.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们需要一柄战旗，这是独属于我们的旗帜！\n做一柄合格的战旗很费钱，所以我们要为此筹集2000克朗。";
		this.m.RewardTooltip = "你将获得一个独特的物品，它能为携带者附近的人提供额外的决心。";
		this.m.UIText = "拥有至少2000克朗";
		this.m.TooltipText = "筹集2000或更多的克朗，以便请人为战团打造战旗。你可以通过完成合同、掠夺营地和遗迹或进行贸易来赚钱。你还需要在仓库中留出足够的空间来存放这件新物品。";
		this.m.SuccessText = "[img]gfx/ui/events/event_65.png[/img]没有人喜欢吝啬鬼，尤其是一群流浪在外、嗜血成性且唯利是图的乌合之众。当你提议缩减开支以便为战旗攒钱时，并不是所有人——更准确地说，是根本没一个人——感到高兴。\n\n然而，当 %companyname% 的旗帜终于付清了账单，并第一次在清晨的微风中骄傲地猎猎作响时，没人再说这不值得了。弟兄们为他们的新旗帜感到自豪，甚至在篝火旁给它起了各种名字，虽然没一个真正流传开来。\n\n现在所有人都能清楚地看到，这不再是一伙受人雇佣的暴徒，而是一支货真价实的新兴佣兵团。谁将拥有扛起这面战旗的荣誉？";
		this.m.SuccessButtonText = "弟兄们，那是属于我们的旗帜了！";
	}

	function onUpdateScore()
	{
		if (this.World.Ambitions.getDone() < 1)
		{
			return;
		}

		this.m.Score = 10;
	}

	function onCheckSuccess()
	{
		if (this.World.Assets.getMoney() >= 2000 && this.World.Assets.getStash().hasEmptySlot())
		{
			return true;
		}

		return false;
	}

	function onReward()
	{
		local item;
		local stash = this.World.Assets.getStash();
		this.World.Assets.addMoney(-1000);
		this.m.SuccessList.push({
			id = 10,
			icon = "ui/icons/asset_money.png",
			text = "你花费了 [color=" + this.Const.UI.Color.NegativeEventValue + "]1,000[/color] 克朗"
		});
		item = this.new("scripts/items/tools/player_banner");
		item.setVariant(this.World.Assets.getBannerID());
		stash.add(item);
		this.m.SuccessList.push({
			id = 10,
			icon = "ui/items/" + item.getIcon(),
			text = "你获得了" + this.Const.Strings.getArticle(item.getName()) + item.getName()
		});
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

