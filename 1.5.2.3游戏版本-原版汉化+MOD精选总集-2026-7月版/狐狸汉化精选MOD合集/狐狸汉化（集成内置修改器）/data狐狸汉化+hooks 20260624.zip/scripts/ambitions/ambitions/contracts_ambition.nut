this.contracts_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		ContractsToComplete = 0
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.contracts";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们要把自己打造成一支可靠的佣兵团。\n让我们一次次接受考验，毋庸置疑地证明这一点！";
		this.m.UIText = "完成更多合同";
		this.m.TooltipText = "再完成8份任何形式的合同，证明自己的可靠毋庸置疑。";
		this.m.SuccessText = "[img]gfx/ui/events/event_62.png[/img]当你开始行动时，世人终于看清了你的真面目：全面武装自己的野心。谁还没点梦想？没人不想混出个人样。如果你回过头好好审视自己，你谈不上出类拔萃，也难称得上是个狠角色。但你偏偏做到了。被拒之门外。讨价还价反倒错失良机。唾沫横飞。 这世道冷酷无情，而你敢于温暖自己。你成功了。\n\n你到手的合同，未来的合同，界限渐渐模糊。胜利的浪潮开始席卷%companyname%，你完全有理由为此感到自豪。";
		this.m.SuccessButtonText = "我们正在为自己扬名。";
	}

	function getUIText()
	{
		local d = 8 - (this.m.ContractsToComplete - this.World.Contracts.getContractsFinished());
		return this.m.UIText + " (" + this.Math.min(8, d) + "/8)";
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Desert)
		{
			return;
		}

		if (this.World.Ambitions.getDone() < 1)
		{
			return;
		}

		if (this.World.Contracts.getContractsFinished() >= 15)
		{
			this.m.IsDone = true;
			return;
		}

		this.m.ContractsToComplete = this.World.Contracts.getContractsFinished() + 8;
		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Contracts.getContractsFinished() >= this.m.ContractsToComplete)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeU16(this.m.ContractsToComplete);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.ContractsToComplete = _in.readU16();
	}

});

