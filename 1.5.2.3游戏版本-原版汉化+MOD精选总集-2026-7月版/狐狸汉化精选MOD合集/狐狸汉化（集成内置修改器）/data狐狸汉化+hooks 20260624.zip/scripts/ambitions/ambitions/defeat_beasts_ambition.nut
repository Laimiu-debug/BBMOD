this.defeat_beasts_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		BeastsToDefeat = 0
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.defeat_beasts";
		this.m.Duration = 99999.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "野兽困扰着处于文明边缘的村庄。\n我们应当猎杀它们赚取钱财！";
		this.m.UIText = "击败流浪野兽群";
		this.m.TooltipText = "在战斗中击败5群流浪野兽，如恐狼或食尸鬼，通过合同或自己寻找均可。";
		this.m.SuccessText = "[img]gfx/ui/events/event_56.png[/img]解决了又一群野兽后，你思考起了祖先的本性。你打量着自己，组织有序、全副武装、游历世界、在战争和战斗方面颇有建树，然而这世上的野兽一如既往的致命。你的祖先们，他们拥有什么？没有文明的庇护，没有城市照亮黑夜、点燃勇气，没有地图勾勒出舒适的边界。然而…他们活了下来。是什么让他们做到的？如何做到的？也许，在那个时代，人类本身才是威胁，而野兽们视他为怪物。又或者在祖先们之前，人们便拥有过自己的城市，自古以来，世界上的人与动物皆处于动态平衡中。如果真是这样，那么你就不该沉湎于过去，而是应该着眼于未来的岁月…",
		this.m.SuccessButtonText = "人类和野兽都应该听说我们的大名。";
	}

	function getUIText()
	{
		local d = 5 - (this.m.BeastsToDefeat - this.World.Statistics.getFlags().getAsInt("BeastsDefeated"));
		return this.m.UIText + " (" + this.Math.min(5, d) + "/5)";
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Desert)
		{
			return;
		}

		if (this.World.Ambitions.getDone() < 1 && this.World.Assets.getOrigin().getID() != "scenario.beast_hunters")
		{
			return;
		}

		this.m.BeastsToDefeat = this.World.Statistics.getFlags().getAsInt("BeastsDefeated") + 5;
		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Statistics.getFlags().getAsInt("BeastsDefeated") >= this.m.BeastsToDefeat)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeU16(this.m.BeastsToDefeat);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.BeastsToDefeat = _in.readU16();
	}

});

