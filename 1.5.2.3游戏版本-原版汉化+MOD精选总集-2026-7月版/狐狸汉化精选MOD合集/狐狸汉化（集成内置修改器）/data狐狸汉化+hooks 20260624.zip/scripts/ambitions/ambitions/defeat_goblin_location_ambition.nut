this.defeat_goblin_location_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		Defeated = 0
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.defeat_goblin_location";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "只有最勇敢的人才敢对抗大规模的哥布林。 我们将把那些腐臭的营地付之一炬，让这消息传播出去！";
		this.m.RewardTooltip = "你将获得一件独特配饰，它能使佩戴者免疫定身。";
		this.m.UIText = "摧毁哥布林营地";
		this.m.TooltipText = "摧毁四个哥布林营地来证明战团的实力，通过合同或自己寻找均可。 你还需要在仓库中留出存放一件新物品的空间。";
		this.m.SuccessText = "[img]gfx/ui/events/event_83.png[/img]你的人零零散散地分布在战场上，经历恶战后仍喘着粗气。当你环顾四周时，%randombrother% 和 %randombrother2% 也正在废墟中搜寻贵重物品。%SPEECH_ON%我们前进，他们就后退。 我们退后，他们就袭扰。 我们放箭，他们就缩进掩体。 我们举盾，他们就用毒刃刺穿，我们冲锋，他们便四散奔逃。 他们扔的那些该死玩意，怕是要成为我们未来一段时间的噩梦。%SPEECH_OFF%%randombrother2% 用武器戳了戳哥布林的尸体，确认它死透后，单膝跪地俯身检视其装备。%SPEECH_ON%但是战斗越艰难，胜利果实就越发甜美。%SPEECH_OFF%他起身迎上 %randombrother%的目光。%SPEECH_ON%战斗越激烈，我感觉越带劲。尽管来吧。%SPEECH_OFF%他们慢慢地继续前行，去与其他人会合，在途中不时停下来寻找一些值一两枚克朗的东西，以便下次队伍到达城市时使用";
		this.m.SuccessButtonText = "胜利！";
	}

	function getUIText()
	{
		return this.m.UIText + " (" + this.m.Defeated + "/4)";
	}

	function onLocationDestroyed( _location )
	{
		if (this.World.FactionManager.getFaction(_location.getFaction()).getType() == this.Const.FactionType.Goblins)
		{
			++this.m.Defeated;
			this.World.Ambitions.updateUI();
		}
	}

	function onUpdateScore()
	{
		if (this.World.getTime().Days < 20)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		this.m.Score = 2 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (!this.World.Assets.getStash().hasEmptySlot())
		{
			return false;
		}

		if (this.m.Defeated >= 4)
		{
			return true;
		}

		return false;
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"recently_destroyed",
			this.World.Statistics.getFlags().get("LastLocationDestroyedName")
		]);
	}

	function onReward()
	{
		local item;
		local stash = this.World.Assets.getStash();
		item = this.new("scripts/items/accessory/goblin_trophy_item");
		stash.add(item);
		this.m.SuccessList.push({
			id = 10,
			icon = "ui/items/" + item.getIcon(),
			text = "你获得了" + this.Const.Strings.getArticle(item.getName()) + item.getName()
		});
	}

	function onClear()
	{
		this.m.Defeated = 0;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeU8(this.m.Defeated);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.Defeated = _in.readU8();
	}

});

