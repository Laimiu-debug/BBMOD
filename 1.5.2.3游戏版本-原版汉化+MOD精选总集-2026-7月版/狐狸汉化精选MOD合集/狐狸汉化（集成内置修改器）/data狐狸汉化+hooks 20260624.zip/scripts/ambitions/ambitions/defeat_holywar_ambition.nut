this.defeat_holywar_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.defeat_holywar";
		this.m.Duration = 99999.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "宗教动乱之火威胁着要吞噬这片土地。 让我们战团在动乱之火中变得比以往任何时候都强大，并通过赢得战争来赚取财富！";
		this.m.UIText = "结束南北战争";
		this.m.TooltipText = "选择北方贵族家族或南方城邦，与他们合作，赢得他们的圣战。 每一支被摧毁的军队，每一份合同的履行，都将加速战争的结束。";
		this.m.SuccessButtonText = "不管他们是喜欢我们还是憎恨我们，所有人都应当知晓 %companyname%之名！";
	}

	function getUIText()
	{
		local f = this.World.FactionManager.getGreaterEvil().Strength / this.Const.Factions.GreaterEvilStartStrength;
		local text;

		if (f >= 0.95)
		{
			text = "战争初始（进度5%）";
		}
		else if (f >= 0.5)
		{
			text = "战况激烈（进度5%-50%）";
		}
		else if (f >= 0.25)
		{
			text = "陷入胶着（进度50%-75%）";
		}
		else
		{
			text = "接近尾声（进度75%-100%）";
		}

		return this.m.UIText + " (" + text + ")";
	}

	function getSuccessText()
	{
		local north = 0;
		local south = 0;
		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0)
				{
					if (this.World.FactionManager.getFaction(v.getFaction()).getType() == this.Const.FactionType.NobleHouse)
					{
						north = ++north;
					}
					else
					{
						south = ++south;
					}
				}
			}
		}

		if (north >= south)
		{
			return "[img]gfx/ui/events/event_92.png[/img]{你呼吸的空气，脚下的土地，都没有丝毫改变。 然而在你身侧，北方人欢庆如潮，仿佛每个灵魂的祈愿皆已得偿所愿。 你已听闻消息，南方人已经让步，派出鸽派使者，这场圣战以北方的胜利告终。 作为交换，北方将占领圣地，并允许南方人进入，只要他们承认他们的“镀金者”是古代众神神殿中的一个。 一个年轻女孩带着一朵花向你走来。%SPEECH_ON%世人传颂着传奇的骑士与无畏的英雄，但我曾亲眼见证你的风采。 你朝这里去，好消息来了，你又朝那里去，更多的好消息来了。 你仿佛上天派来的使者，是古代诸神的右手。%SPEECH_OFF%你感谢那个女孩，她转身跑开了。%randombrother% 撅着嘴走向你。%SPEECH_ON%他们对上天派来的使者的尊敬就只值得一朵破花吗？%SPEECH_OFF%}";
		}
		else
		{
			return "[img]gfx/ui/events/event_171.png[/img]{你看，伟大的镀金者的追随者成群结队地涌向圣地，整片大地已彻底摆脱宗教战争的桎梏，而这场圣战的胜负终以南方胜利告终。 据你所知，维齐尔们强制执行了一条规定，北方人虽可朝拜圣地，但必须向管辖该区域的总督缴纳税款。 虽然和暴力复仇扯不上关系，但绝对说得上是吝啬至极了。\n\n你正在整理行囊，十几位老者沿着路走来，在路中央停下脚步。 他们自称是编撰伟大圣战纪事的史官和历史学者。显然有人向他们指出了你，但他们似乎还不太确定你是谁。 你解释道，是维齐尔雇佣了你－%SPEECH_ON%你说是雇佣的？难道说，你是逐币者？%SPEECH_OFF%其中一位老人打断你的话，他的羽毛笔戛然而止。 他摇了摇头。%SPEECH_ON%不不不，不不不，我们正在记录那些将神圣土地归还给镀金者之光的功绩。 而你只不过是一个畏首畏尾、见风使舵，阴险狡诈的逐币者。 祝你过得愉快。%SPEECH_OFF%你还没来得及反驳，他们就离开了，虽说你心里有怀疑，要是当时你有心情跟他们斗嘴，估计早教训他们了。%randombrother% 走上前问他们是谁。你耸耸肩。%SPEECH_ON%就是一帮无名小卒。%SPEECH_OFF%}";
		}
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Desert)
		{
			return;
		}

		if (!this.World.FactionManager.isHolyWar())
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		if (this.World.Assets.getBusinessReputation() < 1500)
		{
			return;
		}

		this.m.Score = 10;
	}

	function onCheckSuccess()
	{
		if (this.World.FactionManager.getGreaterEvil().Type == 0 && this.World.FactionManager.getGreaterEvil().LastType == 4)
		{
			return true;
		}

		this.World.Ambitions.updateUI();
		return false;
	}

	function onPrepareVariables( _vars )
	{
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

