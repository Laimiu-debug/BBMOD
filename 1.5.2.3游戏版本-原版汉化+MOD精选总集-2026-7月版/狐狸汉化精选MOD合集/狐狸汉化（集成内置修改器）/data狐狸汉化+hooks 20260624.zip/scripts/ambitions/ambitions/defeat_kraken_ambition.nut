this.defeat_kraken_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.defeat_kraken";
		this.m.Duration = 35.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "有传言说，沼泽地里潜伏着一只巨大的野兽。\n如果我们能找到它，杀死它，那我们就能名垂青史！";
		this.m.UIText = "击败克拉肯";
		this.m.TooltipText = "在战斗中击败一只克拉肯。你能在野外的某个地方找到它。";
		this.m.SuccessText = "[img]gfx/ui/events/event_89.png[/img]在你的梦中，它潜伏着。那是一个湿滑的球状脑袋，上面装点着睡莲和藤蔓，它的呼吸搅动着泥泞，如同汤锅中沸腾的水声。它的触手在半明半暗中扭动，像是影子的影子。就这样，它存在于无边无际的黑暗中，一个被它占据的虚无之地，漫无目的传播着恐怖。不是它出现在了你的梦里，而是你走向了它。你踏入黑暗，向前迈出一步，伸出双手，但也仅此而已。你从未真正靠近过它。有时，你的梦会是其他事物，但你知道，那头怪兽就在某个地方潜伏着。你只需打开一扇门，或是走下几步阶梯，就能再次找到它，以及它所统治的领域。你无需与你的人交谈，就可以知道他们也做着这样的梦。\n\n。世人皆知你干掉了克拉肯，但他们只是道听途说。他们认为，这只是母亲哄孩子睡觉的故事，是父亲通过讲述人类战胜恐怖的壮举来给族人壮胆。但是他们没有亲眼看到。他们接触到的是传言，而不是怪物本身，他们将%companyname%视为活着的传奇。就和所有人们口耳相传的故事一样，而如今，故事中的主角已不再是当初与你并肩作战的兄弟，而是被各地杜撰出的英雄所取代。有人说，一个普通的雇佣兵绝不可能战胜如此可怕的怪兽！是东方的骑士！是北方的国王卫队！虚荣与谎言已取代了真相。但是与你并肩作战的兄弟们知道真相，即使是垂死的真相也足以支撑你们继续干下去。\n\n它就住在那片黑暗里，而你也经常去拜访它。";
		this.m.SuccessButtonText = "还有哪位猎人能有如此壮举？";
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Unhold)
		{
			return;
		}

		if (this.World.getTime().Days <= 100)
		{
			return;
		}

		if (this.World.Ambitions.getDone() < 20)
		{
			return;
		}

		if (this.World.Flags.get("IsKrakenDefeated"))
		{
			this.m.IsDone = true;
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Flags.get("IsKrakenDefeated"))
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

