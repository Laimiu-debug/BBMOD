this.discover_locations_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		LocationsDiscovered = 0
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.discover_locations";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "伟大的探险家成为传奇人物。 进入荒野是一项危险的事业，但我们随后将讲述的故事肯定会增加我们的知名度。";
		this.m.UIText = "探索世界发现隐藏的地点";
		this.m.TooltipText = "通过自己探索世界，发现8个隐藏的地点，如废墟或敌对营地。 出发前一定要储备好食物！";
		this.m.SuccessText = "[img]gfx/ui/events/event_54.png[/img]你攥紧命运的胡须，宣布要穿越这片土地，留下作为探险家的标记。 你的人认为，不管是邪恶的巢穴还是繁荣的村庄，只要是新的地点，都会带来新的财富机会，所以他们热枕地跟随着。\n\n随后的日子里，%companyname% 饱览了无数壮丽的风景，巍峨的塔楼、险峻的峡谷尽收眼底。你们成功避开了敌人的斥候，在繁星如千点烛火的黑夜中不生火然后扎营。 绘制了桀骜不驯的河流的路线图，绕过了难以逾越的山脉的险恶边缘，%companyname% 可以坦诚宣布，他们比许多同类型的团队都走得更远。";
		this.m.SuccessButtonText = "我们绘制自己的地图。";
	}

	function getUIText()
	{
		return this.m.UIText + " (" + this.m.LocationsDiscovered + "/8)";
	}

	function onUpdateScore()
	{
		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.find_and_destroy_location").isDone())
		{
			return;
		}

		local locations = this.World.EntityManager.getLocations();
		local numDiscovered = 0;

		foreach( v in locations )
		{
			if (v.isDiscovered())
			{
				numDiscovered = ++numDiscovered;
			}
		}

		if (numDiscovered + 12 >= locations.len())
		{
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.m.LocationsDiscovered >= 8)
		{
			return true;
		}

		return false;
	}

	function onLocationDiscovered( _location )
	{
		if (_location.getTypeID() == "location.battlefield")
		{
			return;
		}

		if (this.World.Contracts.getActiveContract() == null || !this.World.Contracts.getActiveContract().isTileUsed(_location.getTile()))
		{
			this.m.LocationsDiscovered = this.Math.min(8, this.m.LocationsDiscovered + 1);
			this.World.Ambitions.updateUI();
		}
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeU8(this.m.LocationsDiscovered);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.LocationsDiscovered = _in.readU8();
	}

});

