this.have_armor_upgrades_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.have_armor_upgrades";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "平庸的护甲可不行，真正的雇佣兵装备需要更硬核的防护。\n我们应该用战利品来好好装饰我们的装备！";
		this.m.UIText = "拥有至少6件带附件的盔甲";
		this.m.TooltipText = "你需要拥有至少6件带有附加组件的护甲。你可以通过购买、掠夺，或者让制皮匠为你制作，然后将它们与你的护甲结合起来。";
		this.m.SuccessText = "[img]gfx/ui/events/event_82.png[/img]当你接掌战团时，那只是一群苟且求生的乌合之众，一群临时拼凑起来的佣兵，他们之间除了纯粹的固执和对常识的彻底蔑视外，几乎没有什么能将他们凝聚在一起。 现在你看着这些人像一个超凡脱俗的野兽一样四处走动，他们的盔甲上装饰着可怖的头皮、毛皮和骨头，这种不合时宜的征服者式的娱乐方式，使其他人知道 %companyname% 超出了大陆上的任何分类标准，无论被看作是怪物还是人类。";
		this.m.SuccessButtonText = "这对我们很有帮助。";
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Unhold)
		{
			return;
		}

		if (this.World.getTime().Days <= 20)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		local upgrades = 0;
		local items = this.World.Assets.getStash().getItems();

		foreach( item in items )
		{
			if (item != null && item.isItemType(this.Const.Items.ItemType.Armor) && item.getUpgrade() != null)
			{
				upgrades = ++upgrades;
			}
		}

		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			local item = bro.getItems().getItemAtSlot(this.Const.ItemSlot.Body);

			if (item != null && item.isItemType(this.Const.Items.ItemType.Armor) && item.getUpgrade() != null)
			{
				upgrades = ++upgrades;
			}
		}

		if (upgrades > 6)
		{
			this.m.IsDone = true;
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		local upgrades = 0;
		local items = this.World.Assets.getStash().getItems();

		foreach( item in items )
		{
			if (item != null && item.isItemType(this.Const.Items.ItemType.Armor) && item.getUpgrade() != null)
			{
				upgrades = ++upgrades;
			}
		}

		if (upgrades >= 6)
		{
			return true;
		}

		local roster = this.World.getPlayerRoster().getAll();

		foreach( bro in roster )
		{
			local item = bro.getItems().getItemAtSlot(this.Const.ItemSlot.Body);

			if (item != null && item.isItemType(this.Const.Items.ItemType.Armor) && item.getUpgrade() != null)
			{
				upgrades = ++upgrades;
			}
		}

		return upgrades >= 6;
	}

	function onPrepareVariables( _vars )
	{
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

