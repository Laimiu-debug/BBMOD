this.have_y_renown_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.have_y_renown";
		this.m.Duration = 40.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们已经在这片大陆的一些地方为人所知，但我们离成为传奇战团还差得远。 我们要进一步提高我们的声望！";
		this.m.UIText = "达到“荣耀”声望";
		this.m.TooltipText = "以“荣耀”（2750声望）闻名于世界。 你可以通过完成合同和赢得战斗来提高自己的声望。";
		this.m.SuccessText = "[img]gfx/ui/events/event_82.png[/img]穿越森林与平原，这支队伍粉碎了所有被派遣去对付的阻力。践踏敌军，击溃防线，让敌人的脑袋纷纷落地，%companyname% 发觉他们很少单独行动。 当他们行军时，乌鸦在上空盘旋；当他们吃饭时，乌鸦就放声高歌；他们完成日常工作后，乌鸦往往会饱餐一顿。\n\n所到之处，他们留下焦土与离奇的谣言，每一步踏足之处，传言愈发夸张，从挤奶女工到铁匠，乃至市长，似乎都在传颂你的丰功伟绩。 流言如同货币，在这片土地的每个角落都备受珍视。无论是宽阔的河流，还是巍峨的山峰，都无法阻挡你胜利事迹的传播，而这也让你如今能够要求更高的报酬。";
		this.m.SuccessButtonText = "所有人都应当知晓 %companyname% 的大名！";
	}

	function onUpdateScore()
	{
		if (this.World.getTime().Days < 30)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		if (this.World.Assets.getBusinessReputation() >= 2650)
		{
			this.m.IsDone = true;
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Assets.getBusinessReputation() >= 2750)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

