this.have_z_crowns_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.have_z_crowns";
		this.m.Duration = 60.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "克朗意味着权力和影响力，有多少我们都不嫌多。\n让我们收集50000克朗，在国王和贵族们间争得一席之地！";
		this.m.UIText = "拥有至少50000克朗。";
		this.m.TooltipText = "拥有至少50000克朗，跻身富人行列。你可以通过完成合同、掠夺废墟或营地、进行贸易等方式赚钱。";
		this.m.SuccessText = "[img]gfx/ui/events/event_04.png[/img]抢，抢，没错，继续抢！ 战团积累的财富足以与巨龙的财富相媲美。 最精良的铠甲与武器唾手可得。 如果你想租一艘船或一支舰队，只需打个响指就行了。 当你在城里的时候，各种各样的小摊贩摆出他们最好的商品，迫不及待地想要帮你寻找新的挥霍方式。\n\n如今你的财富足以与贵族平起平坐，不必再对他们卑躬屈膝。你可以购置爵位与领土，或是投身商人银行家，如果你厌倦了伺候这群固执任性的蠢货的话。";
		this.m.SuccessButtonText = "Excellent.";
	}

	function onUpdateScore()
	{
		if (this.World.getTime().Days < 25)
		{
			return;
		}

		if (this.World.Assets.getMoney() >= 45000)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		if (this.World.Assets.getMoney() < 10000 && !this.World.Ambitions.getAmbition("ambition.have_y_crowns").isDone())
		{
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Assets.getMoney() >= 50000)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

