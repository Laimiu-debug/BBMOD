this.make_nobles_aware_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.make_nobles_aware";
		this.m.Duration = 99999.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们需要吸引其中一个贵族家族的眼球，以获得更有利可图的工作。他们老是惹火上身，但只要给得够多，那又有什么关系呢？";
		this.m.RewardTooltip = "你将解锁由贵族签发的报酬更好的全新合同。";
		this.m.UIText = "达到“专业”声望";
		this.m.TooltipText = "以“专业”（1050声望）闻名，以吸引贵族家族的注意。 你可以通过完成合同和赢得战斗来提高自己的声望。";
		this.m.SuccessText = "[img]gfx/ui/events/event_31.png[/img]要想让人们对 %companyname% 这个名字产生兴趣，从而增加你在贵族中的前景，你驱使手下的人去完成壮举，展现无畏的勇气，并制造了大量的流血事件。 经过数次合约和多场小规模冲突后，你通过不懈的努力和长时间的工作，终于让几位贵族注意到了战团的能力。\n\n这些都是出身名门世家的人，这些贵族凭借某个早已死去多年的祖先曾征服一群手无寸铁的农民，便统治着这片土地。 正如 %highestexperience_brother% 所说，现在这些娇生惯养、近亲繁殖的纨绔子弟对你印象深刻，足以让你们参与解决他们的争端。 如果你能洗净脸庞，彬彬有礼地请求，他们应该会时不时地赐予你们一份有利可图的合同。 你可以为自己感到骄傲了！";
		this.m.SuccessButtonText = "我们要从贵族的口袋里掏钱了！";
	}

	function onUpdateScore()
	{
		if (this.World.Ambitions.getDone() < 2)
		{
			return;
		}

		if (this.World.Assets.getBusinessReputation() < 800)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.battle_standard").isDone())
		{
			return;
		}

		if (this.World.Assets.getBusinessReputation() >= 1050 && this.World.FactionManager.isGreaterEvil())
		{
			this.m.IsDone = true;
			return;
		}

		this.m.Score = 10;
	}

	function onCheckSuccess()
	{
		if (this.World.Assets.getBusinessReputation() >= 1050)
		{
			return true;
		}

		return false;
	}

	function onReward()
	{
		this.m.SuccessList.push({
			id = 10,
			icon = "ui/icons/special.png",
			text = "贵族们现在会给你合同了"
		});

		if (!this.World.Assets.getOrigin().isFixedLook())
		{
			if (this.World.Assets.getOrigin().getID() == "scenario.southern_quickstart")
			{
				this.World.Assets.updateLook(14);
			}
			else
			{
				this.World.Assets.updateLook(2);
			}

			this.m.SuccessList.push({
				id = 10,
				icon = "ui/icons/special.png",
				text = "你在世界地图上的形象已经更新了"
			});
		}
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

