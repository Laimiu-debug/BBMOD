this.raid_caravans_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		RaidsToComplete = 0
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.raid_caravans";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "那些大篷车里装满了财富，就等着我们去抢。\n就像从树上摘果子一样简单！";
		this.m.UIText = "突袭贸易或补给商队";
		this.m.TooltipText = "突袭4次沿途贸易或供应商队。如果你和他们的派别不是敌对关系，你可以通过按住Ctrl键的同时左键点击他们来强制攻击--前提是你目前没有雇佣合同。";
		this.m.SuccessText = "[img]gfx/ui/events/event_60.png[/img]脑海中响起一个死去商人的声音。%SPEECH_ON%你为什么要这么做？我们会把一切都给你的。%SPEECH_OFF%但这段记忆不是关于他，而是关于他的马车，以及他即使在生命垂危时也不愿透露的部分。自从开始洗劫商队以来，袭击商队已成为你和%companyname%的一种消遣。沉浸在洗劫带来的财富中，你的人高兴极了，而你也因为这些卑鄙行径而名声大噪。";
		this.m.SuccessButtonText = "就像从孩子手里抢糖果一样。";
	}

	function getUIText()
	{
		local d = 4 - (this.m.RaidsToComplete - this.World.Statistics.getFlags().getAsInt("CaravansRaided"));
		return this.m.UIText + " (" + this.Math.min(4, d) + "/4)";
	}

	function onUpdateScore()
	{
		if (!this.Const.DLC.Desert)
		{
			return;
		}

		if (this.World.Statistics.getFlags().getAsInt("CaravansRaided") <= 0 && this.World.Assets.getOrigin().getID() != "scenario.raiders")
		{
			return;
		}

		this.m.RaidsToComplete = this.World.Statistics.getFlags().getAsInt("CaravansRaided") + 4;
		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Statistics.getFlags().getAsInt("CaravansRaided") >= this.m.RaidsToComplete)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeU16(this.m.RaidsToComplete);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.RaidsToComplete = _in.readU16();
	}

});

