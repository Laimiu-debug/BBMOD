this.roster_of_12_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.roster_of_12";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们要把这支队伍扩充至12人！这能壮大我们的力量，从而能够承担更多高回报的任务。";
		this.m.UIText = "战团人数至少达到12人";
		this.m.TooltipText = "雇佣足够的人，让名册上的人数达到12名。 访问各地的定居点，寻找适合你需要的新兵。 充足的人员能使你接受更危险更高报酬的合同。";
		this.m.SuccessText = "[img]gfx/ui/events/event_80.png[/img]终于攒够了钱和装备，你成功组建了一支完整的十二人精锐战团。当你们再次踏上%currenttown%的主干道上时，你的部下们高声唱起了一首行军歌。一些镇民窃窃私语，抱怨这些脏兮兮的雇佣兵快要把小镇接管了，但也有不少人跟在队伍旁，和你们一同唱和。%SPEECH_ON%挺胸抬头兄弟们，给大伙看看，我们是一支货真价实的佣兵团，不是什么游手好闲的流浪汉。%SPEECH_OFF%%highestexperience_brother%宣称道。%SPEECH_ON%我们靠实力吃饭，如今人数增加，我们的身价也会水涨船高。%SPEECH_OFF%看来他说的没错。你注意到一位格外肥胖的贵族正打量着你们，仿佛已经想好了要交给你们的任务。%companyname%现在已经成为一股不可忽视的力量。或许等战士们喝起了庆功酒，你应该再到镇子里逛逛，看看有没有更好赚的合同。";
		this.m.SuccessButtonText = "我们做到了。";
	}

	function onUpdateScore()
	{
		if (this.World.Assets.getOrigin().getID() == "scenario.militia")
		{
			return;
		}

		if (this.World.Ambitions.getDone() < 1 && this.World.Assets.getOrigin().getID() != "scenario.deserters" && this.World.Assets.getOrigin().getID() != "scenario.raiders")
		{
			return;
		}

		if (this.World.getPlayerRoster().getSize() >= 12)
		{
			this.m.IsDone = true;
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.getPlayerRoster().getSize() >= 12)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

