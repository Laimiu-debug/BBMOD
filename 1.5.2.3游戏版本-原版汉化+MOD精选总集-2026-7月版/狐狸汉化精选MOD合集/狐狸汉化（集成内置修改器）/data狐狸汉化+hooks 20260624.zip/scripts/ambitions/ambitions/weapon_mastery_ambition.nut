this.weapon_mastery_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.weapon_mastery";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "想象一下，如果你的技能与你的勇敢相当，我们会留下怎样的恐怖痕迹。\n我们要训练五名武器专家，让他们充当开路先锋！";
		this.m.UIText = "每个人都有一个武器精通特技";
		this.m.TooltipText = "让你的5个人每人拥有一个武器精通特技，不管是哪一种武器。";
		this.m.SuccessText = "[img]gfx/ui/events/event_50.png[/img]为了训练兄弟们精通武器，你采取了新的训练方法。这提升了大家的士气。参训者既通过磨练技艺提高了生存几率，又赢得了同伴们的钦佩，其他人则坐在圆木上边看热闹，边把羊肉吃得满脸都是。\n\n受训者们利用一切空闲时间，用各种武器进行练习，直到他们强健的手臂变得像橡树分支般坚韧有力，锐利的眼神也变得如同大猫那般敏锐无情。。%SPEECH_ON%不仅 %weaponbrother% 不仅是我们敌人的可怕威胁，他那迅捷的步伐，让你不禁联想到舞女的身姿。%SPEECH_OFF%作出这番评论的%notweaponbrother%，最后被%weaponbrother%用训练剑狠狠收拾了一顿。";
		this.m.SuccessButtonText = "他们现在是专业人士了。";
	}

	function getUIText()
	{
		return this.m.UIText + " (" + this.Math.min(5, this.getBrosWithMastery()) + "/5)";
	}

	function getBrosWithMastery()
	{
		local brothers = this.World.getPlayerRoster().getAll();
		local count = 0;

		foreach( bro in brothers )
		{
			local p = bro.getCurrentProperties();

			if (p.IsSpecializedInBows)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInCrossbows)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInThrowing)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInSwords)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInCleavers)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInMaces)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInHammers)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInAxes)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInFlails)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInSpears)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInPolearms)
			{
				count = ++count;
			}
			else if (p.IsSpecializedInDaggers)
			{
				count = ++count;
			}
		}

		return count;
	}

	function onUpdateScore()
	{
		if (this.World.getTime().Days <= 15)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		local count = this.getBrosWithMastery();

		if (count >= 3)
		{
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		local count = this.getBrosWithMastery();

		if (count >= 5)
		{
			return true;
		}

		return false;
	}

	function onPrepareVariables( _vars )
	{
		local brothers = this.World.getPlayerRoster().getAll();
		local candidates = [];
		local not_candidates = [];

		if (brothers.len() > 2)
		{
			for( local i = 0; i < brothers.len(); i = ++i )
			{
				if (brothers[i].getSkills().hasSkill("trait.player"))
				{
					brothers.remove(i);
					break;
				}
			}
		}

		foreach( bro in brothers )
		{
			local p = bro.getCurrentProperties();

			if (p.IsSpecializedInBows)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInCrossbows)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInThrowing)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInSwords)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInCleavers)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInMaces)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInHammers)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInAxes)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInFlails)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInSpears)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInPolearms)
			{
				candidates.push(bro);
			}
			else if (p.IsSpecializedInDaggers)
			{
				candidates.push(bro);
			}
			else
			{
				not_candidates.push(bro);
			}
		}

		if (not_candidates.len() == 0)
		{
			not_candidates = brothers;
		}

		_vars.push([
			"weaponbrother",
			candidates[this.Math.rand(0, candidates.len() - 1)].getName()
		]);
		_vars.push([
			"notweaponbrother",
			not_candidates[this.Math.rand(0, not_candidates.len() - 1)].getName()
		]);
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
	}

});

