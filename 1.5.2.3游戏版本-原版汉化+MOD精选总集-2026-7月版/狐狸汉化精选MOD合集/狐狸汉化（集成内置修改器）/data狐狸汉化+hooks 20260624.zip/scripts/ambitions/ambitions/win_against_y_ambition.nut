this.win_against_y_ambition <- this.inherit("scripts/ambitions/ambition", {
	m = {
		IsFulfilled = false
	},
	function create()
	{
		this.ambition.create();
		this.m.ID = "ambition.win_against_y";
		this.m.Duration = 21.0 * this.World.getTime().SecondsPerDay;
		this.m.ButtonText = "我们获得了一些声望，但现在你可以追求真正的名望。\n让我们在战斗中击败两打强大的对手！";
		this.m.UIText = "赢得一场24个或更多敌人的战斗";
		this.m.TooltipText = "赢得一场24个或更多敌人的战斗，无论是杀死他们，还是让他们四散奔逃。 你可以把它作为合同的一部分，或者按照你自己的方式来完成。";
		this.m.SuccessText = "[img]gfx/ui/events/event_22.png[/img]战斗结束后，%lowesthp_brother% 呆坐在那里，盯着他的脚，看起来累坏了。其他人也不例外。 %SPEECH_ON%是我命中注定要打的那场仗！现在，如果我死了，我就会和我见过最勇敢、最致命的人死在一起，我为能称他们一声兄弟而自豪！%SPEECH_OFF%这在四周引起了一片疲惫的赞同声。%SPEECH_ON%乡野村夫只会谈及汗水、鲜血与泪水，但是 %companyname% 的战士们穿越火海，取得了胜利！%SPEECH_OFF%人们高呼了三次战团的名字，虽然疲惫，但斗志昂扬。\n\n接下来的日子里，但凡你们出现在有人烟的地方，便有人指指点点，窃窃私语，至于是畏惧还是钦佩，你们也无从得知。你们所向披靡的战功早已传遍四野，所到之处，众人皆已知晓你们的威名。";
		this.m.SuccessButtonText = "还有谁敢阻挡我们？";
	}

	function onUpdateScore()
	{
		if (this.World.Statistics.getFlags().getAsInt("LastEnemiesDefeatedCount") >= 24)
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.make_nobles_aware").isDone())
		{
			return;
		}

		if (!this.World.Ambitions.getAmbition("ambition.win_against_x").isDone())
		{
			return;
		}

		this.m.Score = 1 + this.Math.rand(0, 5);
	}

	function onCheckSuccess()
	{
		if (this.World.Statistics.getFlags().getAsInt("LastEnemiesDefeatedCount") >= 24 || this.m.IsFulfilled)
		{
			return true;
		}

		return false;
	}

	function onLocationDestroyed( _location )
	{
		if (this.World.Statistics.getFlags().getAsInt("LastEnemiesDefeatedCount") >= 24)
		{
			this.m.IsFulfilled = true;
		}
	}

	function onPartyDestroyed( _party )
	{
		if (this.World.Statistics.getFlags().getAsInt("LastEnemiesDefeatedCount") >= 24)
		{
			this.m.IsFulfilled = true;
		}
	}

	function onSerialize( _out )
	{
		this.ambition.onSerialize(_out);
		_out.writeBool(this.m.IsFulfilled);
	}

	function onDeserialize( _in )
	{
		this.ambition.onDeserialize(_in);
		this.m.IsFulfilled = _in.readBool();
	}

});

