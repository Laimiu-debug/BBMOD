local gt = this.getroottable();
gt.Const.FactionArchetypes <- [
	[
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Warmonger,
				this.Const.FactionTrait.ManOfThePeople
			],
			Description = "%noblehousename% 家族围绕着一个宗教教派运转。该教派教导成员对同胞心怀慈悲，但对敌人却极度狂热且冷酷无情。几代人以前，一场大规模的兽人入侵掠夺并摧毁了该家族的大部分家产，使其从未完全恢复元气。从那时起，该家族针对兽人领地发动了多次圣战与惩罚性远征，却始终无法将那些绿皮彻底荡涤干净。",
			Mottos = [
				"唯有美德堪称高贵",
				"誓死捍卫受难之人",
				"热忱与荣耀",
				"狂怒的贵族",
				"让火焰净化一切",
				"战火铸就和平",
				"希望永存",
				"光荣而勇猛",
				"我们蔑视变革与恐惧",
				"胜利高于一切",
				"黑暗中的灯塔",
				"齐心协力，众志成城"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Sheriff,
				this.Const.FactionTrait.ManOfThePeople
			],
			Description = "%noblehousename% 家族高举正义与荣誉的旗帜。得益于其理性的统治，该地区长久以来繁荣昌盛。尽管他们名声在外，似乎爱好和平，但 %noblehousename% 的骑士们都久经沙场。一旦有人威胁到他们的领土、部属或原则，其军队将发起最凶猛的反击。许多贵族嫉妒他们的财富并嘲笑他们的原则；其中尤以 %othernoblehouse% 为甚，他们对 %noblehousename% 家族怀有或明或暗的怨恨。",
			Mottos = [
				"为你自己而活",
				"友谊不容虚伪",
				"敢为睿智者",
				"勇者仁心",
				"予我以爱，必还之以花",
				"此地无暴虐无道者容身之处",
				"切莫激怒雄狮",
				"虽饱经沧桑，仍坚毅不拔",
				"心口如一",
				"时刻警惕",
				"荣耀归于长者",
				"美德源自强权",
				"泰然处之",
				"富则兼济天下，绝不独善其身"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Sheriff,
				this.Const.FactionTrait.Collector
			],
			Description = "世人皆追逐财富，但声名显赫的 %noblehousename% 家族的商人们才是达成盈利交易的个中好手。受限于祖辈的名望，他们将诚实与正直奉为家族的核心价值观。",
			Mottos = [
				"理性乃人生向导",
				"行事果决，举止温文",
				"观其行而知其人",
				"奋斗不止，无愧于心",
				"拨云见日",
				"困境中的勇气",
				"勤奋是富有之本"
			]
		}
	],
	[
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Warmonger,
				this.Const.FactionTrait.Tyrant
			],
			Description = "%noblehousename% 是一个高傲且冷酷的家族，拥有一段漫长且血腥的征服史。他们坐镇于 %factionfortressname% 要塞，用武力夺取任何他们认为理应属于自己的东西。 他们与 %othernoblehouse% 家族之间的世仇成为了他们心中怒火不熄、熔炉战火不断的永恒理由。",
			Mottos = [
				"自立自强",
				"坚忍者胜",
				"刚毅正直",
				"以此徽记之名征服",
				"名垂青史者永生",
				"绝不后退",
				"穿透箭雨与敌阵",
				"武勇与兵锋无坚不摧",
				"征服书写不朽",
				"我们厉兵秣马",
				"苍鹰志在高处"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Warmonger,
				this.Const.FactionTrait.Marauder
			],
			Description = " %noblehousename% 家族因其残忍、暴虐和贪婪而为人唾弃，与其他贵族家族鲜有往来。 众所周知，他们的队长和士兵经常从 %factionfortressname% 要塞出发，袭击商队、边远农场和小型定居点。人命在 %noblehousename% 家族的领地里一文不值，许多雇佣兵来到他们的领地希望赚笔快钱，而他们的唯一下场就是死。",
			Mottos = [
				"万物生长，终归尘土",
				"将其践踏于足下",
				"为了我，也为了我的族人",
				"猎鹰不食飞蝇",
				"行动胜于空谈",
				"天佑渡鸦",
				"渴望永无止境",
				"恶犬之子，来此受肉",
				"绝不空手而归"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Schemer,
				this.Const.FactionTrait.Tyrant
			],
			Description = "与其说 %noblehousename% 家族被人憎恨，不如说他们被人所畏惧。 无数次规模不一的起义已被血腥镇压，而 %noblehousename% 家族的走狗据传在每一个阴暗角落都有眼线，在每一面墙壁后都有耳目。 在他们祖传的 %factionfortressname% 要塞中到处都是武装警卫、警惕的战犬和规模庞大的雇佣兵团，以保护他们多疑的首领。",
			Mottos = [
				"黑暗中的利刃",
				"旧的不去，新的不来",
				"整装待发",
				"守卫永不停歇",
				"武力维系和平",
				"清白如鸽",
				"坚定不移",
				"服从",
				"以法律与武力之名",
				"如果无法反抗，那就忍受",
				"雄狮之怒，尽显尊贵"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Marauder,
				this.Const.FactionTrait.Tyrant
			],
			Description = "%noblehousename%以其奢华的生活方式和纵情享乐的派对而闻名。既然有人享受，就必须有人买单。因此，在 %noblehousename% 统治的地方，骨瘦如柴的牲畜、空空如也的粮仓和绝望的城镇居民是常见的景象。尽管其他贵族家族可能看不起这种残暴和榨取，但与此同时，他们又在焦急地等待下一次宴会的邀请。",
			Mottos = [
				"不可战胜",
				"流言蜚语止步",
				"一飞冲天",
				"持正守义",
				"施以轻蔑",
				"羊毛出在羊身上",
				"拒绝节俭",
				"富贵险中求",
				"谨记你终将一死"
			]
		}
	],
	[
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Schemer,
				this.Const.FactionTrait.Collector
			],
			Description = "俗话说商场如战场，而 %noblehousename% 家族正是对讨价还价、锱铢必较的狡诈商法登峰造极的大师。 传闻说，%noblehousename%  家族达成的许多有利可图的交易不仅基于诚信贸易，还涉及贿赂、勒索和欺诈。 该家族居住在奢华的地区首府 %factionfortressname%，尽管他们拥有无法估量的财富，却以极其吝啬而闻名。",
			Mottos = [
				"坦诚而活",
				"命运眷顾勇者",
				"世界尚不足够",
				"区分正直与实用",
				"我们的收获终将到来",
				"险中求胜"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.ManOfThePeople,
				this.Const.FactionTrait.Collector
			],
			Description = "%noblehousename% 家族声称其根源可追溯到人类首次占领这片土地、第一位国王统治全人类的时代。虽然现在他们只是众多贵族世家中的一员，但他们为自己悠久的历史感到自豪，并抱有继续书写历史的野心。随着他们的名望和资源在当下逐渐萎缩，据传他们正资助远征队，试图在沉没的城市和早已被遗忘的地方挖掘来自过去的失落宝藏。",
			Mottos = [
				"活得精彩，活出双倍人生",
				"财富属于善用之人",
				"锁闭之物方安全",
				"一如既往",
				"评估与测量",
				"狂涛巨浪，能奈我何",
				"人人为我",
				"风帆与船桨",
				"敢为天下先"
			]
		},
		{
			Traits = [
				this.Const.FactionTrait.NobleHouse,
				this.Const.FactionTrait.Marauder,
				this.Const.FactionTrait.Schemer
			],
			Description = "%noblehousename% 家族的大多数成员隐居在厚重的大门和装有铁窗的房屋后，有些人已经多年未曾露面。传闻他们的贵族血统饱受疯狂与精神错乱的困扰，但由于畏惧他们的报复，没有平民敢于说出这种主张。其他贵族家族大多避免与 %noblehousename% 家族接触，因为来访的客人受到的迎接可能是张开的双臂，也可能是飞来的弩箭。",
			Mottos = [
				"无人永生",
				"预想你的终末",
				"我们不蔑视别人，我们亦无所畏惧",
				"我们不接受评判",
				"万物皆变",
				"人不为己天诛地灭",
				"凡事皆动荡不安",
				"当心狼群"
			]
		}
	]
];
gt.Const.CityStateArchetypes <- [
	{
		Traits = [
			this.Const.FactionTrait.OrientalCityState
		],
		Description = "一个富裕而独立的城邦，主要专注于贸易和获取更多财富。",
		Mottos = [
			"和平生活，安享太平",
			"财富是我们的利箭",
			"财富是我们的利剑",
			"远处的金色塔楼",
			"礼尚往来",
			"没有付出就没有收获"
		]
	},
	{
		Traits = [
			this.Const.FactionTrait.OrientalCityState
		],
		Description = "一个致力于获取知识胜过一切的城邦——即便这意味着要进行尸检、阅读禁忌古籍，或与不属于这个世界的邪恶力量打交道。",
		Mottos = [
			"敢为睿智者",
			"智慧征服命运",
			"博览群书",
			"智慧之堡",
			"终获知识"
		]
	},
	{
		Traits = [
			this.Const.FactionTrait.OrientalCityState
		],
		Description = "一个由冷酷议会统治的城邦，一心想方设法攫取权力。许多不合时宜的死亡被传闻是  %citystatename% 的维齐尔下令进行的暗杀。",
		Mottos = [
			"草丛中的毒蛇",
			"暗影之中",
			"不择手段",
			"雄鹰不屑捕蝇"
		]
	}
];

