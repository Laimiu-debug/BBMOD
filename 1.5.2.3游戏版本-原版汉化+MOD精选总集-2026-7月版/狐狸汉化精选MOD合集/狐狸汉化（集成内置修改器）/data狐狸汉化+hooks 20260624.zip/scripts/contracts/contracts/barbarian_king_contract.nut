this.barbarian_king_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Threat = null,
		LastHelpTime = 0.0,
		IsPlayerAttacking = false,
		IsEscortUpdated = false
	},
	function create()
	{
		this.contract.create();
		local r = this.Math.rand(1, 100);

		if (r <= 70)
		{
			this.m.DifficultyMult = this.Math.rand(90, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(115, 135) * 0.01;
		}

		this.m.Type = "contract.barbarian_king";
		this.m.Name = "野蛮人国王";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 5.0;
		this.m.MakeAllSpawnsAttackableByAIOnceDiscovered = true;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		this.m.Payment.Pool = 1700 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"追捕野蛮人国王和他的大军",
					"据最新报告，他位于%region%地区，在你的%direction%"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local f = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians);
				local nearest_base = f.getNearestSettlement(this.World.State.getPlayer().getTile());
				local party = f.spawnEntity(nearest_base.getTile(), "Barbarian King", false, this.Const.World.Spawn.Barbarians, 125 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.setDescription("一个强大的野蛮部落战团，集结在野蛮人国王旗下。");
				party.getSprite("body").setBrush("figure_wildman_04");
				party.setVisibilityMult(2.0);
				this.Contract.addUnitsToEntity(party, this.Const.World.Spawn.BarbarianKing, 100);
				this.Contract.m.Destination = this.WeakTableRef(party);
				party.getLoot().Money = this.Math.rand(150, 250);
				party.getLoot().ArmorParts = this.Math.rand(10, 30);
				party.getLoot().Medicine = this.Math.rand(3, 6);
				party.getLoot().Ammo = this.Math.rand(10, 30);
				party.addToInventory("supplies/roots_and_berries_item");
				party.addToInventory("supplies/dried_fruits_item");
				party.addToInventory("supplies/pickled_mushrooms_item");
				party.getSprite("banner").setBrush(nearest_base.getBanner());
				party.setAttackableByAI(false);
				local c = party.getController();
				local patrol = this.new("scripts/ai/world/orders/patrol_order");
				patrol.setWaitTime(20.0);
				c.addOrder(patrol);
				this.Contract.m.UnitsSpawned.push(party.getID());
				this.Contract.m.LastHelpTime = this.Time.getVirtualTimeF() + this.Math.rand(10, 40);
				this.Flags.set("HelpReceived", 0);
				local r = this.Math.rand(1, 100);

				if (r <= 15)
				{
					this.Flags.set("IsAGreaterThreat", true);
					c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.BulletpointsObjectives.clear();
				this.Contract.m.BulletpointsObjectives = [
					"追捕野蛮人国王和他的大军",
					"据最新报告，他的大军位于%direction%的%terrain%，在%region%地区，靠近%nearest_town%"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onCombatWithKing.bindenv(this));
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					this.Contract.setState("Return");
				}
				else if (!this.Contract.isPlayerNear(this.Contract.m.Destination, 600) && this.Flags.get("HelpReceived") < 4 && this.Time.getVirtualTimeF() >= this.Contract.m.LastHelpTime + 70.0)
				{
					this.Contract.m.LastHelpTime = this.Time.getVirtualTimeF() + this.Math.rand(0, 30);
					this.Contract.setScreen("Directions");
					this.World.Contracts.showActiveContract();
				}
				else if (!this.Contract.isPlayerNear(this.Contract.m.Destination, 600) && this.Flags.get("HelpReceived") == 4)
				{
					this.Contract.setScreen("GiveUp");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatWithKing( _dest, _isPlayerAttacking = true )
			{
				this.Contract.m.IsPlayerAttacking = _isPlayerAttacking;

				if (!_dest.isInCombat() && !this.Flags.get("IsKingEncountered"))
				{
					this.Flags.set("IsKingEncountered", true);

					if (this.Flags.get("IsAGreaterThreat"))
					{
						this.Contract.setScreen("AGreaterThreat1");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setScreen("Approach");
						this.World.Contracts.showActiveContract();
					}
				}
				else
				{
					this.Flags.set("IsAGreaterThreat", false);
					_dest.getController().getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(true);
					local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					properties.Music = this.Const.Music.BarbarianTracks;
					this.World.Contracts.startScriptedCombat(properties, this.Contract.m.IsPlayerAttacking, true, true);
				}
			}

		});
		this.m.States.push({
			ID = "Running_GreaterThreat",
			function start()
			{
				this.Contract.m.BulletpointsObjectives.clear();
				this.Contract.m.BulletpointsObjectives = [
					"与蛮族国王一同踏上旅程，共同面对更大的威胁"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.setFaction(2);
					this.World.State.setEscortedEntity(this.Contract.m.Destination, true);
				}
			}

			function update()
			{
				if (this.Flags.get("IsContractFailed"))
				{
					if (this.Contract.m.Threat != null && !this.Contract.m.Threat.isNull())
					{
						this.Contract.m.Threat.getController().clearOrders();
					}

					if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
					{
						this.Contract.m.Destination.getController().clearOrders();
						this.Contract.m.Destination.setFaction(this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).getID());
					}

					this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
					this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "战团撕毁了一份合同");
					this.World.Contracts.finishActiveContract(true);
					return;
				}

				if (this.Contract.m.Threat == null || this.Contract.m.Threat.isNull() || !this.Contract.m.Threat.isAlive())
				{
					this.Contract.setScreen("AGreaterThreat5");
					this.World.Contracts.showActiveContract();
					return;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					if (!this.Contract.m.IsEscortUpdated)
					{
						this.World.State.setEscortedEntity(this.Contract.m.Destination, true);
						this.Contract.m.IsEscortUpdated = true;
					}

					this.World.State.setCampingAllowed(false);
					this.World.State.getPlayer().setPos(this.Contract.m.Destination.getPos());
					this.World.State.getPlayer().setVisible(false);
					this.World.Assets.setUseProvisions(false);
					this.World.getCamera().moveTo(this.World.State.getPlayer());
				}

				if (this.Contract.isPlayerAt(this.Contract.m.Threat))
				{
					this.Contract.setScreen("AGreaterThreat4");
					this.World.Contracts.showActiveContract();
				}
			}

			function end()
			{
				this.World.State.setCampingAllowed(true);
				this.World.State.setEscortedEntity(null);
				this.World.State.getPlayer().setVisible(true);
				this.World.Assets.setUseProvisions(true);
				this.World.State.resetSpeedToNormal();
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("IsContractFailed", true);
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					if (this.Flags.get("IsAGreaterThreat"))
					{
						this.Contract.setScreen("Success2");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%employer% 正用手指把玩着一顶薄薄的王冠。那玩意儿一看就是块廉价金属，但毫无疑问是从某个地方弄来的王冠。他上下打量着你，王冠在指甲盖上刮擦着，滑过去又转回来。%SPEECH_ON%我早就该预料到的。人总是渴求权力，野蛮人也不例外。%SPEECH_OFF%他任由王冠滑到指节，松垮垮地垂着。%SPEECH_ON%%direction% 方 %region% 的野蛮人正在所谓国王的麾下联合起来。一个强大又无耻的蛮子，威胁要召集一大群人，此后，嗯，我猜他肯定想向南扩张地盘。我要你到那里去，找到这个人，干掉他。%SPEECH_OFF% | %employer% 的一个仆人把你带到花园，你看见他正打理着一株番茄。他用羊剪子修剪枝叶，对着自己的手艺满意点头。他散漫地说道。%SPEECH_ON%我的斥候说，一群北方蛮子正在 %region% 地区集结军队。那些野蛮人傻子聚在一起瞎折腾也不是新鲜事，但这次不一样，他居然自立为王了。而称王的，都不满足于自己这点地盘。他们也想要别人的东西，包括我的。%SPEECH_OFF%他顿了顿，冲你点点头。%SPEECH_ON%我要你去 %region% 附近，找到这个所谓的蛮子国王，然后杀了他。这活儿不容易，但报酬绝对丰厚。%SPEECH_OFF% | %employer% 手下的副官们围在他身旁。他们对你嗤之以鼻，但 %employer% 自有决断。%SPEECH_ON%啊，佣兵，我确信你就是我要找的人。一个野蛮人在%region% 附近自立为王了，居然还弄了顶王冠，不知是骨头还是鹿角做的，关键是那王冠的象征意义。不光对他重要，对我们也一样。不能留着他。我要你去找到这个原始人，在他集结起一支大到我的手下无法处理的军队前干掉他。%SPEECH_OFF% | %employer% 端着杯麦酒招待你，自己则喝着葡萄酒。%SPEECH_ON%我把你带到这里，是因为 %region% 附近的一个原始人。他自称国王，呵呵，所有蛮子们的宗主。呵，我才不认他那狗屁王权，但我看得出这是个苗头不对的威胁。我不能放任这野蛮人统揽各个村庄，召集起一支军队。我要你找到他，杀了他。这活不简单，但相应也有丰厚的报酬。%SPEECH_OFF%你怀疑他想用麦酒灌得你放松警惕，好让你接受这个荒唐的任务。 | %employer% 手里拿着副鹿角，底部还连着顶王冠。他把鹿角往桌上一放，竖在那儿，好像还长在原来的鹿头上似的。%SPEECH_ON%有传言说一个蛮子正在 %region% 附近集结军队，还自立为王。要是他真把这帮原始人拉拢到麾下，就会形成一股不能小瞧的势力。再不管他，我们很快就要麻烦缠身了。%SPEECH_OFF%他把鹿角推倒，鹿角尖端着地，发出空洞的咔嗒声。%SPEECH_ON%所以叫你来，佣兵。我要你找到这个蛮子，在他脑子里长出不被推翻的方法之前干掉他。%SPEECH_OFF% | %employer% 坐在椅子上，抿着嘴，用拇指拨弄着一把匕首，刀尖在桌上戳出个小坑。%SPEECH_ON%我派往 %direction% 的斥候前段时间开始失踪。后来幸存者陆续回来，带回消息说有个蛮子在 %region% 附近自立为王的消息。一个野蛮人自封为这群原始人的王，需要我告诉你问题的严重性吗？%SPEECH_OFF%你说，你能想象他夜不能寐的样子。%employer% 咧嘴笑道。%SPEECH_ON%没错，所以我需要你这样身强力壮又懂规矩的雇佣兵。我要你去找的这位所谓的国王，在他带着那群蠢货在他的旗帜下行军之前干掉他。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈多少克朗？ | 这活儿可不简单啊。 | 价钱到位，什么都好说。 | 像这样的任务，报酬最好得丰厚些。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{我们可不打算硬刚一支军队。 | 这不是我们想接的活儿。 | 我不会让战团去冒险对付这样的敌人。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Directions",
			Title = "在途中…",
			Text = "{[img]gfx/ui/events/event_59.png[/img]一群难民从队伍旁边经过。有传言说那个野蛮人国王就在 %direction%  %distance% 地方。路上的许多人都来自 %nearest_town%，看样子他们可不想留在那儿，等着被野蛮人大军吞没。 | [img]gfx/ui/events/event_41.png[/img]一个商人推着空货架和队伍擦肩而过。虽然他没什么东西可卖了，但还是提到，现在路上都在传，有个野人自称是国王。他说野蛮人在你目前位置的 %direction% 一带，在 %region% 附近。他看着你们要去的方向，点了点头。%SPEECH_ON%要是你们打算往那边去，嘿，那就替我们好好教训那群原始杂种。%SPEECH_OFF% | [img]gfx/ui/events/event_94.png[/img]发现一个半裸的男人盘腿坐在路边。他说一个带着军队的原始人烧了他的农庄，强奸了女人，把所有带把儿的都杀了。%SPEECH_ON%我躲在灌木丛里，用手死死捂住嘴才活了下来。%SPEECH_OFF%那人擦了擦他的鼻子。%SPEECH_ON%我看到你们带着武器。如果你要找这个野蛮人，那我可以告诉你们，他们好像是往 %direction% 去了，就在 %terrain%  %distance% 地方，到 %region% 那边 。%SPEECH_OFF% | [img]gfx/ui/events/event_94.png[/img]你发现了一个小村落烧焦的废墟。几个幸存者还在附近徘徊，他们的身影就像自家废墟上飘起的青烟一样虚无。其中一人说，有个自称国王的家伙来过，杀光了所有能抓到的人，然后往 %direction% 去了。 | [img]gfx/ui/events/event_60.png[/img]你们路上遇到了好几辆翻倒或者烧着的货车。车上空空如也，货物全没了，只剩下车主的尸体。几个孩子正在其中一片废墟里翻找东西。你问他们这是谁干的，一个愣头愣脑的男孩开口了。%SPEECH_ON%从北方来的蛮子们，不过他们现在往 %direction% 去了。我看见他们了。我敢打赌他们在%distance% %terrain%。%SPEECH_OFF%他抠了抠他的鼻子。%SPEECH_ON%顺便说一句，他们可是杀人不眨眼的。看着跟你们差不多，不过块头更大。估计也比你们壮实。%SPEECH_OFF% | [img]gfx/ui/events/event_76.png[/img]%employer%的一名斥候在路上遇见你。他报告说，有人在 %region% 一带，就是 %direction% 的 %terrain% 附近 %distance% 地方，看见了那个野蛮人国王。你问斥候愿不愿意和你一起战斗，那人笑了。%SPEECH_ON%不了，先生，我这样很好。我到处跑跑，看看情况，然后汇报。就像是我在两个妓女之间那样的奔波。这日子挺美，可不想让你们佣兵那一套给毁了！%SPEECH_OFF%好吧，随你。 | [img]gfx/ui/events/event_132.png[/img]%randombrother%最先发现了痕迹。这里有打斗的迹象，烧焦的尸体，模糊的脚印和车辙，很明显有一支军队经过了这里。%SPEECH_ON%看来他们在战斗结束后向 %direction% 前进了，头儿。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们正在他屁股后面。",
					function getResult()
					{
						this.Flags.increment("HelpReceived", 1);
						this.Contract.getActiveState().start();
						this.World.Contracts.updateActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "GiveUp",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_45.png[/img]{现在已经毫无疑问了。由于你所遇到的种种痕迹，以及人们给你的各种消息，你终于确切地知道了野蛮人国王和他战团的具体去向。唯一剩下的就是直接面对他。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们应该加速前进。",
					function getResult()
					{
						this.Flags.increment("HelpReceived", 1);
						this.Contract.m.Destination.setVisibleInFogOfWar(true);
						this.World.getCamera().moveTo(this.Contract.m.Destination);
						this.Contract.getActiveState().start();
						this.World.Contracts.updateActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Approach",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_135.png[/img]{野蛮人国王带着他的战团出现在战场上，一群体型硕大的恶棍、咆哮的战士、怯懦的奴隶，还有尖啸的女人。这是一支由一个人组织起来的军队，这支军队就像滚雪球般席卷了整片土地，榨干了每寸资源，夺走了所有优势，现在怕是要连文明世界也一口吞下。你下令让弟兄们准备迎战。 | 野蛮人国王的战团在地面上移动着，没有丝毫训练的痕迹，甚至连队形都没有。但你知道，只要那个蛮子挥挥手，这群屠夫就会如潮水般涌来，他们确实不懂战术配合，但光靠血腥手段就足够弥补这点缺陷了。你让弟兄们准备战斗。 | 野蛮人战团如同噩梦中的景象显现，仿佛来自世界各地的冒险者从地平线涌出，他们没有制服或盔甲，而是用身上的装饰嘲讽那些被他们征服的失败者。战士胳膊上缠着婚纱绸缎，战奴身上裹着皇家颜料浸染的礼服，还有些人穿着骨头制成咔咔作响的护甲，像是他们掠劫后的剩饭。他们是恐怖的农夫，种植世界各地的村庄，收获四季不休的战争。\n\n你望着这荒诞的景象摇了摇头，随即下令准备战斗。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onCombatWithKing(this.Contract.m.Destination, this.Contract.m.IsPlayerAttacking);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{野蛮人国王死了。虽然他给自己冠上了王者的头衔，但此刻躺在尸堆里的模样，跟他的族人们没什么两样。不过是个野蛮人，一个原始人，有着稍微强健点的身体，以及一些来自征战、掠夺和蹂躏来的装备，除此之外他没有什么特别之处。你挥剑砍进他的脖颈，一脚踩住他的脸，利落地将头颅从肩膀上卸下来。%randombrother%捡起那颗沉重的头颅，随手塞进行囊。你命令弟兄们尽他们所能地搜刮战场，然后准备回去找 %employer%。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "{%companyname%取得了胜利！ | 胜利！}",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.setState("Return");
			}

		});
		this.m.Screens.push({
			ID = "AGreaterThreat1",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_136.png[/img]{你找到了野蛮人国王，但对方主动提出了谈判。野蛮人国王和一位长老跨过原野亲自迎接你。尽管觉得不妥，你还是出去见了他们。野蛮人国王开口说话，由长老翻译。%SPEECH_ON%我们不是来征服的，只为消灭‘大灾祸’而来。%SPEECH_OFF%你怀疑翻译有误，便要求他们解释得更清楚一些。国王和长老继续说道。%SPEECH_ON%死亡已经离开了这片土地，如果没有死亡，被杀者会迷失在两个世界之间，不断复活。一大群由亡灵组成的亡者军团正在行军。我们来这里不是为了你或你的领主。你如果帮助我们消灭它们，我们就会离开这片土地，不再骚扰你们的人民。我们只针对这些亡者。%SPEECH_OFF%%randombrother% 凑近你耳边低语道。%SPEECH_ON%我们可以选择加入他们，这当然没问题。但我们也可以直接现在就发动攻击。他们明显没恢复元气，而且不管他们嘴上怎么说，这些原始人一路烧杀抢掠过来是事实。头儿，奸淫掳掠是他们的天性。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会攻击他们为北方消灭这个所谓的王。",
					function getResult()
					{
						return "AGreaterThreat2";
					}

				},
				{
					Text = "我们会和他们一起向亡者进军。",
					function getResult()
					{
						return "AGreaterThreat3";
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AGreaterThreat2",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_136.png[/img]{你朝长老吐了口口水，点了点头。%SPEECH_ON%我们走过被烧的房子，被强奸的妇女，和被杀害的男人，只为了找到你们这些可怜虫，现在你想联合起来？我们不是盟友。我们不是朋友。告诉你所谓的‘国王’去向着你们的狗屁神明们祈祷去吧…%SPEECH_OFF%长老举起手来，用他们的语言与王对话。 两个人点头，转身离开。%randombrother%笑着说道。%SPEECH_ON%头儿，简短有力才是骂人的精髓。%SPEECH_OFF%你让他回到战线里，为接下来的战斗做好准备。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备战斗。",
					function getResult()
					{
						this.Flags.set("IsAGreaterThreat", false);
						this.Contract.getActiveState().onCombatWithKing(this.Contract.m.Destination, this.Contract.m.IsPlayerAttacking);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AGreaterThreat3",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_136.png[/img]{你朝那位长老点了点头。%SPEECH_ON%好吧，我们会跟你们一起，处理这个更大的威胁。%SPEECH_OFF%长老微笑着，拇指搓在一起，说了几句他们的话。野蛮人国王用拳头猛捶自己的胸口，然后用拳头在你肩膀上捶了一下，接着手在空中划出一道弧线。长老解释道。%SPEECH_ON%那我们就一起战斗，如果我们倒下，不必担心他变成不死者对付你。被杀了的话，国王会自己去找到死神，把它的镰刀放在自己的脖子上。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备进军。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				local playerTile = this.World.State.getPlayer().getTile();
				local nearest_undead = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Undead).getNearestSettlement(playerTile);
				local tile = this.Contract.getTileToSpawnLocation(playerTile, 9, 15);
				local party = this.World.FactionManager.getFaction(nearest_undead.getFaction()).spawnEntity(tile, "The Untoward", false, this.Const.World.Spawn.UndeadArmy, 260 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("banner").setBrush(nearest_undead.getBanner());
				party.setDescription("一大群行尸，向活着的人索取曾经属于他们的东西。");
				party.setSlowerAtNight(false);
				party.setUsingGlobalVision(false);
				party.setLooting(false);
				this.Contract.m.UnitsSpawned.push(party);
				this.Contract.m.Threat = this.WeakTableRef(party);
				party.setAttackableByAI(false);
				local c = party.getController();
				c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
				local wait = this.new("scripts/ai/world/orders/wait_order");
				wait.setTime(99999);
				c.addOrder(wait);
				this.Contract.m.Destination.setFaction(2);
				this.Contract.m.Destination.getSprite("selection").Visible = false;
				this.Contract.m.Destination.setOnCombatWithPlayerCallback(null);
				c = this.Contract.m.Destination.getController();
				c.clearOrders();
				local move = this.new("scripts/ai/world/orders/move_order");
				move.setDestination(party.getTile());
				c.addOrder(move);
				this.Contract.setState("Running_GreaterThreat");
			}

		});
		this.m.Screens.push({
			ID = "AGreaterThreat4",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_73.png[/img]{这些蛮子并没有说谎：一支古代军队已经被派来了。他们有着腐朽的面孔和生锈的盔甲，是一大群哀嚎着、呻吟着的怪物，哪怕光落在它们身上，也会立即消失。这无疑是一支黑暗的军队。如果是你或野蛮人单独应战，都必败无疑，但联合起来，你们还有一线生机！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备战斗。",
					function getResult()
					{
						this.World.Contracts.showCombatDialog(false, true, true);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AGreaterThreat5",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_136.png[/img]{古代死者最终被赶尽杀绝。当你的手下和蛮子们正在清理战场时，野蛮人国王和长老来到你身边。这位大块头勇士点头咕哝，长老翻译。%SPEECH_ON%他说你干得不错，真的很不错。他也希望能有像你和你的同伴们这样的人跟他并肩作战，但他也知道这不可能。我们生活在一个由许多世界组成的迷宫里，我们注定会被困在这个迷宫中，彼此迷失，偶尔能听见对方的呼喊，却永远来不及真正相识。他要我转达谢意，同时也祝你好运。%SPEECH_OFF%你问长老，一声咕哝就能表达这么多意思吗。长老笑了。%SPEECH_ON%是一声咕哝没错，但也有一生的友谊。祝你好运，剑客。%SPEECH_OFF%长老递给你一顶带角的头盔，正是你之前看见蛮族国王戴过的那顶。他没再说什么，只是拍了拍自己的胸口，又指了指天空，一切尽在不言中。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "再会，国王。",
					function getResult()
					{
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull() && this.Contract.m.Destination.isAlive())
				{
					this.Contract.m.Destination.die();
					this.Contract.m.Destination = null;
				}

				local item = this.new("scripts/items/helmets/barbarians/heavy_horned_plate_helmet");
				this.World.Assets.getStash().add(item);
				this.List.push({
					id = 10,
					icon = "ui/items/" + item.getIcon(),
					text = "你获得了" + this.Const.Strings.getArticle(item.getName()) + item.getName()
				});
			}

		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_31.png[/img]{%employer% 把野蛮人国王的脑袋从袋子里倒出来。那头颅咕噜噜滚了几圈，撞翻了一托盘酒杯，杯子散落一地，叮当作响。这蛮子死了都还是个制造混乱的家伙。%SPEECH_ON%谢了，佣兵。%SPEECH_OFF%你的雇主说道。他自顾自地点着头，把那头颅摆正，立了起来。%SPEECH_ON%真是个丑杂种，你看他那牙，全是洞！恶心死了。%SPEECH_OFF%你让他赶紧给钱，他照着约定的做了。但他一边摇头，一边龇着自己的牙，还模仿着剔牙的动作。%SPEECH_ON%这种牙怎么刷啊？用绳子吗？%SPEECH_OFF%你耸耸肩，转身出门，你才懒得告诉 %employer%，你手下的人拿到这该死的脑袋第一件事，就是把他嘴里的金子撬了出来。 | 你把野蛮人国王的脑袋丢到了 %employer% 的桌子上。他瞪了瞪脑袋，又瞪了瞪你。%SPEECH_ON%这他妈是我见过最大的头。%SPEECH_OFF%你点点头，伸手要钱，他如数给了。接着雇主开始拨弄那蛮子的脸，像是巫师想从里面偷什么秘密似的。%SPEECH_ON%我打赌，那些食人魔的传说就是这么来的，对吧？小孩看到这丑东西，想象力一发不可收拾，怪物不就这么诞生了嘛。%SPEECH_OFF%要是真这么简单就好了。 | 即使没有它庞大的身体，野蛮人国王的头颅在被展示给 %employer% 时也引起了轰动。一大群贵族和仆人哦哦啊啊着惊叹着它的大小。一个穿黑袍的人很快将你应得的钱给了你。%employer% 把头扔在空中，掂了掂分量。%SPEECH_ON%旧神啊，它真够沉的！哦 %randomname%。%SPEECH_OFF%一个仆人上前。你的雇主咧嘴一笑。%SPEECH_ON%拿根长矛来，我们要把这个恐怖的脑袋举到天顶上去。%SPEECH_OFF%对蛮子来说，这倒是个合适的归宿。 | 野蛮人国王的头刚被交给 %employer%，就成了一件玩物。贵族家的小孩在石头地板上把脑袋滚来滚去，那个蛮子的脑袋撞倒了高脚杯组成的墙壁和餐盘组成的堡垒。一条狗追着脑袋来回跑，汪汪直叫。%employer% 拍拍你的肩膀。%SPEECH_ON%干的相当不错，佣兵。我说真的。我的斥候告诉我，那是一场恶战，你当时简直跟个野蛮人没两样。不过也没办法，对吧。对付蛮子，就得用蛮子的法子。太在意文明人的身份，可无法抗衡这种野蛮！%SPEECH_OFF%其中一个孩子踢中了国王的脸，把下巴都踢断了，撞在牙齿上撞破了脚。孩子尖声求救，也许是护主心切，那条狗跨在头上，咬着脖子上的气管，把头拖来拖去。%employer% 再次笑了。%SPEECH_ON%你的钱在外面等着呢，一分不少，按说好的。%SPEECH_OFF% |  一个穿着骑士甲的人从你手中夺走了野蛮人国王的头。你立刻抽出了剑，但是 %employer% 赶紧跳到你们中间，及时避免了冲突。%SPEECH_ON%喂，没事的，佣兵。你的报酬，和说好的一样。%SPEECH_OFF%那人递给你一袋金币，可你看见他身后，脑袋被交给了一个黑袍人。你点点头，问他们打算拿脑袋干什么。%employer% 咧嘴笑道。%SPEECH_ON%我就直说了，还有场酒会等着我呢，佣兵，而且我渴极了。%SPEECH_OFF%他快步与你擦肩而过。你根本没看到什么酒，他径直跟着黑袍人走了。 | %employer% 盯着野蛮人国王的脑袋，像猫盯着不属于自己的东西一样，眼神不善。%SPEECH_ON%有点意思。我要把它做成标本，放在我的壁炉上。%SPEECH_OFF%听到他有些言语失当，你提醒雇主，那可是颗人头。%employer% 耸了耸肩。%SPEECH_ON%那又怎样？它就是个怪物。文明人和蛮子根本没法共存。把它好好处理了摆在那儿，正好时刻提醒我这个道理。你还想教训我？%SPEECH_OFF%你撇了撇嘴，让他给钱。他指了指角落。%SPEECH_ON%钱在那个袋子里。干得不错，佣兵，但别再这么跟我说话。走吧。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "杀了一个自称的野蛮人国王");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_31.png[/img]{%employer% 不情不愿地接待了你。%SPEECH_ON%你知道我的眼线遍布各地，对吧？%SPEECH_OFF%你举起空着的双手，告诉他你根本没打算撒谎，但‘野蛮人国王’不会再打扰这片土地了。你的雇主指尖轻轻敲击了几下，随即点了点头。%SPEECH_ON%难得你这么老实，不过说实话，那人和他的部众还活着，确实有点可惜。话说回来，所有情报都显示他们已经撤走了，所以不管有没有拿到那个异教徒首领的脑袋，你的活儿也算是干完了。这是你的报酬，按说好的。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "解决了一个自称是野蛮人国王的威胁");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && this.m.Destination.isAlive())
		{
			local distance = this.World.State.getPlayer().getTile().getDistanceTo(this.m.Destination.getTile());
			distance = this.Const.Strings.Distance[this.Math.min(this.Const.Strings.Distance.len() - 1, distance / 30.0 * (this.Const.Strings.Distance.len() - 1))];
			local region = this.World.State.getRegion(this.m.Destination.getTile().Region);
			local settlements = this.World.EntityManager.getSettlements();
			local nearest;
			local nearest_dist = 9999;

			foreach( s in settlements )
			{
				local d = s.getTile().getDistanceTo(this.m.Destination.getTile());

				if (d < nearest_dist)
				{
					nearest = s;
					nearest_dist = d;
				}
			}

			_vars.push([
				"region",
				region.Name
			]);
			_vars.push([
				"nearest_town",
				nearest.getName()
			]);
			_vars.push([
				"distance",
				distance
			]);
			_vars.push([
				"direction",
				this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.Destination.getTile())]
			]);
			_vars.push([
				"terrain",
				this.Const.Strings.Terrain[this.m.Destination.getTile().Type]
			]);
		}
		else
		{
			local nearest_base = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).getNearestSettlement(this.World.State.getPlayer().getTile());
			local region = this.World.State.getRegion(nearest_base.getTile().Region);
			_vars.push([
				"region",
				region.Name
			]);
			_vars.push([
				"nearest_town",
				""
			]);
			_vars.push([
				"distance",
				""
			]);
			_vars.push([
				"direction",
				this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(region.Center)]
			]);
			_vars.push([
				"terrain",
				this.Const.Strings.Terrain[region.Type]
			]);
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.World.State.setCampingAllowed(true);
			this.World.State.setEscortedEntity(null);
			this.World.State.getPlayer().setVisible(true);
			this.World.Assets.setUseProvisions(true);
			this.World.State.resetSpeedToNormal();
			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		return true;
	}

	function onIsTileUsed( _tile )
	{
		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Threat != null && !this.m.Threat.isNull())
		{
			_out.writeU32(this.m.Threat.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local obj = _in.readU32();

		if (obj != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(obj));
		}

		obj = _in.readU32();

		if (obj != 0)
		{
			this.m.Threat = this.WeakTableRef(this.World.getEntityByID(obj));
		}

		this.contract.onDeserialize(_in);
	}

});

