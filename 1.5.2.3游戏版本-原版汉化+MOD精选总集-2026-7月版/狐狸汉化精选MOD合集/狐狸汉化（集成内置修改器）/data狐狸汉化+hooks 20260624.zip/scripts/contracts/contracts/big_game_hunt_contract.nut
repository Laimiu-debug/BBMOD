this.big_game_hunt_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Size = 0,
		Dude = null
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.big_game_hunt";
		this.m.Name = "大型狩猎";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 5.0;
		this.m.MakeAllSpawnsAttackableByAIOnceDiscovered = true;
		this.m.MakeAllSpawnsResetOrdersOnceDiscovered = true;
		this.m.DifficultyMult = 1.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function setup()
	{
		local r = this.Math.rand(1, 100);

		if (r <= 40)
		{
			this.m.Size = 0;
			this.m.DifficultyMult = 0.75;
		}
		else if (r <= 75 || this.World.getTime().Days <= 30)
		{
			this.m.Size = 1;
			this.m.DifficultyMult = 1.0;
		}
		else
		{
			this.m.Size = 2;
			this.m.DifficultyMult = 1.2;
		}
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local maximumHeads;
		local priceMult = 1.0;

		if (this.m.Size == 0)
		{
			local priceMult = 1.0;
			maximumHeads = [
				15,
				20,
				25,
				30
			];
		}
		else if (this.m.Size == 1)
		{
			local priceMult = 4.0;
			maximumHeads = [
				10,
				12,
				15,
				18,
				20
			];
		}
		else
		{
			local priceMult = 8.0;
			maximumHeads = [
				8,
				10,
				12,
				15
			];
		}

		this.m.Payment.Pool = 1300 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult() * priceMult;
		this.m.Payment.Count = 1.0;
		this.m.Payment.MaxCount = maximumHeads[this.Math.rand(0, maximumHeads.len() - 1)];
		local settlements = this.World.FactionManager.getFaction(this.m.Faction).getSettlements();
		local other_settlements = this.World.EntityManager.getSettlements();
		local regions = this.World.State.getRegions();
		local candidates_first = [];
		local candidates_second = [];

		foreach( i, r in regions )
		{
			local inSettlements = 0;
			local nearSettlements = 0;

			if (r.Type == this.Const.World.TerrainType.Snow || r.Type == this.Const.World.TerrainType.Mountains || r.Type == this.Const.World.TerrainType.Desert || r.Type == this.Const.World.TerrainType.Oasis)
			{
				continue;
			}

			if (!r.Center.IsDiscovered)
			{
				continue;
			}

			if (this.m.Size == 2 && r.Type != this.Const.World.TerrainType.Steppe && r.Type != this.Const.World.TerrainType.Forest && r.Type != this.Const.World.TerrainType.LeaveForest && r.Type != this.Const.World.TerrainType.AutumnForest)
			{
				continue;
			}

			if (r.Discovered < 0.5)
			{
				this.World.State.updateRegionDiscovery(r);
			}

			if (r.Discovered < 0.5)
			{
				continue;
			}

			foreach( s in settlements )
			{
				local t = s.getTile();

				if (t.Region == i + 1)
				{
					inSettlements = ++inSettlements;
				}
				else if (t.getDistanceTo(r.Center) <= 20)
				{
					local skip = false;

					foreach( o in other_settlements )
					{
						if (o.getFaction() == this.getFaction())
						{
							continue;
						}

						local ot = o.getTile();

						if (ot.Region == i + 1 || ot.getDistanceTo(r.Center) <= 10)
						{
							skip = true;
							break;
						}
					}

					if (!skip)
					{
						nearSettlements = ++nearSettlements;
					}
				}
			}

			if (nearSettlements > 0 && inSettlements == 0)
			{
				candidates_first.push(i + 1);
			}
			else if (inSettlements > 0 && inSettlements <= 1)
			{
				candidates_second.push(i + 1);
			}
		}

		local region;

		if (candidates_first.len() != 0)
		{
			region = candidates_first[this.Math.rand(0, candidates_first.len() - 1)];
		}
		else if (candidates_second.len() != 0)
		{
			region = candidates_second[this.Math.rand(0, candidates_second.len() - 1)];
		}
		else
		{
			region = settlements[this.Math.rand(0, settlements.len() - 1)].getTile().Region;
		}

		this.m.Flags.set("Region", region);
		this.m.Flags.set("HeadsCollected", 0);
		this.m.Flags.set("StartDay", 0);
		this.m.Flags.set("LastUpdateDay", 0);
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Flags.set("StartDay", this.World.getTime().Days);
				this.Contract.m.BulletpointsObjectives.clear();

				if (this.Contract.m.Size == 0)
				{
					if (this.Const.DLC.Desert)
					{
						this.Contract.m.BulletpointsObjectives.push("猎杀恐狼、织网蛛、食尸鬼、鬣狗和大蛇");
					}
					else
					{
						this.Contract.m.BulletpointsObjectives.push("猎杀恐狼、织网蛛和食尸鬼");
					}
				}
				else if (this.Contract.m.Size == 1)
				{
					this.Contract.m.BulletpointsObjectives.push("猎杀梦魔、巨魔和女巫");
				}
				else
				{
					this.Contract.m.BulletpointsObjectives.push("猎杀树人和林德虫");
				}

				this.Contract.m.BulletpointsObjectives.push("在%worldmapregion%的%regiontype%区域附近或其它地区进行狩猎");
				this.Contract.m.BulletpointsObjectives.push("任意时刻返回%townname%以领取报酬");

				if (this.Contract.m.Size == 0)
				{
					this.Contract.setScreen("TaskSmall");
				}
				else if (this.Contract.m.Size == 1)
				{
					this.Contract.setScreen("TaskMedium");
				}
				else
				{
					this.Contract.setScreen("TaskLarge");
				}
			}

			function end()
			{
				this.Flags.set("StartDay", this.World.getTime().Days);
				local action = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Beasts).getAction("send_beast_roamers_action");
				local options;

				if (this.Contract.m.Size == 0)
				{
					options = action.m.BeastsLow;
				}
				else if (this.Contract.m.Size == 1)
				{
					options = action.m.BeastsMedium;
				}
				else
				{
					options = action.m.BeastsHigh;
				}

				local nearTile = this.World.State.getRegion(this.Flags.get("Region")).Center;

				for( local i = 0; i < 3; i = ++i )
				{
					for( local tries = 0; tries++ < 1000;  )
					{
						if (options[this.Math.rand(0, options.len() - 1)](action, nearTile))
						{
							local party = action.getFaction().getUnits()[action.getFaction().getUnits().len() - 1];
							party.setAttackableByAI(false);
							this.Contract.m.UnitsSpawned.push(party.getID());
							local wait = this.new("scripts/ai/world/orders/wait_order");
							wait.setTime(15.0);
							party.getController().addOrderInFront(wait);
							local footPrintsOrigin = this.Contract.getTileToSpawnLocation(nearTile, 4, 8);
							this.Const.World.Common.addFootprintsFromTo(footPrintsOrigin, party.getTile(), this.Const.BeastFootprints, party.getFootprintType(), party.getFootprintsSize(), 1.1);
							break;
						}
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.BulletpointsObjectives.clear();

				if (this.Contract.m.Size == 0)
				{
					if (this.Const.DLC.Desert)
					{
						this.Contract.m.BulletpointsObjectives.push("在%worldmapregion%的%regiontype%区域附近猎杀恐狼、织网蛛和食尸鬼(%killcount%/%maxcount%)");
					}
					else
					{
						this.Contract.m.BulletpointsObjectives.push("在%worldmapregion%的%regiontype%区域附近猎杀恐狼、织网蛛、食尸鬼、鬣狗和大蛇(%killcount%/%maxcount%)");
					}
				}
				else if (this.Contract.m.Size == 1)
				{
					this.Contract.m.BulletpointsObjectives.push("在%worldmapregion%的%regiontype%区域附近猎杀梦魔、巨魔和女巫(%killcount%/%maxcount%)");
				}
				else
				{
					this.Contract.m.BulletpointsObjectives.push("在%worldmapregion%的%regiontype%区域附近猎杀树人和林德虫(%killcount%/%maxcount%)");
				}

				this.Contract.m.BulletpointsObjectives.push("任意时刻返回%townname%以领取报酬");
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home) && this.Flags.get("HeadsCollected") != 0)
				{
					if (this.Contract.m.Size == 0)
					{
						this.Contract.setScreen("SuccessSmall");
					}
					else if (this.Contract.m.Size == 1)
					{
						this.Contract.setScreen("SuccessMedium");
					}
					else
					{
						this.Contract.setScreen("SuccessLarge");
					}

					this.World.Contracts.showActiveContract();
				}
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_killer != null && _killer.getFaction() != this.Const.Faction.Player && _killer.getFaction() != this.Const.Faction.PlayerAnimals)
				{
					return;
				}

				if (this.Flags.get("HeadsCollected") >= this.Contract.m.Payment.MaxCount)
				{
					return;
				}

				if (this.Contract.m.Size == 0)
				{
					if (_actor.getType() == this.Const.EntityType.Ghoul || _actor.getType() == this.Const.EntityType.Direwolf || _actor.getType() == this.Const.EntityType.Spider || _actor.getType() == this.Const.EntityType.Hyena || _actor.getType() == this.Const.EntityType.Serpent)
					{
						this.Flags.set("HeadsCollected", this.Flags.get("HeadsCollected") + 1);
					}
				}
				else if (this.Contract.m.Size == 1)
				{
					if (_actor.getType() == this.Const.EntityType.Alp || _actor.getType() == this.Const.EntityType.Unhold || _actor.getType() == this.Const.EntityType.UnholdFrost || _actor.getType() == this.Const.EntityType.UnholdBog || _actor.getType() == this.Const.EntityType.Hexe)
					{
						this.Flags.set("HeadsCollected", this.Flags.get("HeadsCollected") + 1);
					}
				}
				else if (_actor.getType() == this.Const.EntityType.Lindwurm && !this.isKindOf(_actor, "lindwurm_tail") || _actor.getType() == this.Const.EntityType.Schrat)
				{
					this.Flags.set("HeadsCollected", this.Flags.get("HeadsCollected") + 1);
				}
			}

			function onCombatVictory( _combatID )
			{
				this.start();
				this.World.State.getWorldScreen().updateContract(this.Contract);
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.start();
				this.World.State.getWorldScreen().updateContract(this.Contract);
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationPerHead);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "TaskSmall",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_63.png[/img]{你进入 %employer% 的房间。这位先生正用一根孔雀羽毛剔着手指，一边把玩着羽毛斑斓的那头，一边用尖的那头往外挑着污垢。对你的到来，他说话的语气相当漫不经心。%SPEECH_ON%我的卫兵已经报告了，说你想接狩猎野兽的活儿。我很高兴你有这意思。报酬是按头颅数算的。小型野兽，织网蛛，吃尸体玩意，这类东西对你来说想必是小菜一碟，可本地人却吓得要死不敢碰。 如果你真像人们说的那样有本事，那么你就别磨蹭了。替我把这地方清理干净。先从这片儿开始吧，据说有人在 %direction% 离这里 %distance% %worldmapregion% 地区看见了它们。%SPEECH_OFF% | %employer% 把你迎进房间。他拿过一张卷轴，那是你刚才穿过集市时镇上的传令官给你的。%SPEECH_ON%啊，原来你是来狩猎野兽的。我以为你是来搞特殊…%SPEECH_OFF%他捏了捏你的衣角，笑了笑。%SPEECH_ON%另一种消遣呢。不过嘛，反正野兽正在乡下肆虐，我很乐意付你一笔可观的报酬来收拾它们。当然，报酬是按头颅数算的，只要你手里的家伙够利索，保管你赚得盆满钵满。如果你需要一个地方开始你的狩猎，去 %direction% 离这里 %distance% %worldmapregion%地区。在那儿你能找到各式各样的八足怪物和毛茸茸的畜生。反正是能把普通农夫吓破胆的东西，不过对你这么个大人物来说，肯定都是小意思啦。%SPEECH_OFF% | 光着脚丫子跷在桌上，一群女人正给他修脚。她们从他趾缝里抠出结成块的污垢，那架势活像在给某种怪物的卵搞孵化仪式。你清了清嗓子。那男人也猛地一惊，跟着清了清喉咙。%SPEECH_ON%啊，对，是雇佣兵。喏，你要是有兴趣，我这有活给你干。%SPEECH_OFF%他漫不经心地朝你脚边扔过来一张卷轴，上面列出了需要杀死的野兽。织网蛛，小狼啥的，都不是什么吓人的东西。地图上标注的地点指向 %direction% %worldmapregion% 附近的区域。那男人打了个嗝。%SPEECH_ON%报酬将按头颅数计算，希望这很合你意。%SPEECH_OFF% | 你发现 %employer% 正拿着一截断裂的斧柄在手里把玩。手柄与本该装着斧刃的连接处明显是断裂的，标志着这把武器彻底报废了。男人把它扔在桌上，拍了拍掌心的木屑。%SPEECH_ON%有些畜生在这片土地上游荡，我需要像你这样的人把它们统统宰了。你意下如何，嗯？报酬会按头颅数计算。要开始狩猎的话，去%direction%的%worldmapregion%地区。在那有各种乱七八糟的小型野兽，造成了不小的麻烦。%SPEECH_OFF% | %employer% 将你迎入他的房间。他的桌子上满是卷轴，每个卷轴上都画着动物和野兽，甚至还可能有怪物。他正嚼着浆果，边吃边喷汁地说话。%SPEECH_ON%当地人说有肮脏的东西在作祟，可没一个能给我说清楚到底是什么麻烦。说什么像狼的怪物啊、八条腿的妖怪啊。我总不能干站着不管，所以这才请你来帮忙。去%direction%离这%distance%%worldmapregion%地区。要是看见任何野兽，就当场格杀，把它们的脑袋带回来。我会按照头皮数付钱。%SPEECH_OFF% | %employer% 正在和一群农民商议，此时与你相见。他声称有所谓的怪物把乡下搅得天翻地覆。一个农民插嘴道。%SPEECH_ON%全是些畜生。用后腿走路的狼，巨大的蜘蛛，还有臭气熏天的吃尸体的玩意。%SPEECH_OFF%贵族挥了挥手。%SPEECH_ON%行了行了，够了。佣兵，我需要你出发去把这些畜生都猎杀了。先去 %direction% 的 %worldmapregion% 地区，确保把在那儿出没的野兽都埋进土里去。不过千万记得把它们的头带回来，我将会为每个头买单。当然，前提是你对这活儿有兴趣。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈多少克朗？ | 价钱到位，什么都好说。 | 继续。 | 你子民的安全对你来说值多少钱？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这路太远了，我可不想去。 | 我们可不打算去 %worldmapregion% 做无用功。 | 这不是我们想接的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "TaskMedium",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_63.png[/img]{当你进入时，%employer%正在翻阅一本书。他抬起头，招手让你过去。%SPEECH_ON%拿一支蜡烛来。%SPEECH_OFF%你从墙上取下一个壁挂火把架，这位贵族立刻双手高举。%SPEECH_ON%我说的是蜡烛，不是该死的火把！你想干嘛？把我所有的书都烧成灰吗？就站在那儿别动。听着，这附近的人都在谈论一些我好多年没听说过的邪物。有以噩梦为食的怪物，大到胡子能塞人的巨兽，而其中最糟的，当然就是那些深知自己容颜绝色的女人了。%SPEECH_OFF%你对最后一种说法有点怀疑，但没搭话。贵族接着解释，你要在他的领土上杀死你发现的每一个怪物。在这里%direction%的%worldmapregion%区域有人看到过它们，但你可以自由追猎这些生物，无论它们躲在哪里。 | 你发现%employer%正和几个穿着黑袍的人密谈。他们招手示意你过去，你不太情愿地走上前。贵族问你是否知道如巨魔这样的怪物，或是那些以梦为食的生物。没等你回答，他就摆了摆手。%SPEECH_ON%无所谓了，我需要些武装人员去搜查%direction%的%worldmapregion%地区，看看是否有什么奇怪的东西。凡是没有心跳、不是人类的玩意儿，格杀勿论，把脑袋带回来。我会为每个脑袋付给你丰厚的报酬。当然，前提是它们真的存在。%SPEECH_OFF% | %employer%两手各掂量着一卷卷轴，眼睛却盯着桌上摊开的第三卷。最后，他把那两卷扔开，又把桌上那卷扫到一边。他看着你。%SPEECH_ON%有传言说有怪物出没。有人说巨人正在吞食牲畜和孩子。我听到有人做噩梦，为此杀死了邻居。还有一些消息传来，说这个地区有一个美丽的女人。我不知道她是否是某种邪恶生物，但一个在%direction%%worldmapregion%地区独自居住的美丽女人，这听起来就像是个大麻烦。%SPEECH_OFF%你点了点头。一个独自在陌生区域的女人，对有些人而言当然会是麻烦。贵族老爷张开双臂。%SPEECH_ON%带上你的人，去那片土地探明虚实如何？如果你真遇上什么嘶嘶作响、爬来爬去、或者根本就不是人的东西，宰了那鬼玩意儿，把它的脑袋带给我。%SPEECH_OFF% | 你看到%employer%正借着烛光埋头看书，蜡烛离书页太近，烛光摇曳，几乎将书页边缘照得发白，仿佛只有他才有资格阅读。见到你，他招手让你上前。%SPEECH_ON%我收到了%direction%%worldmapregion%地区的消息说发生了怪事。谋杀频发，鬼知道是为什么。还有些人干脆就人间蒸发了。这可不是什么好兆头。我不知道是邪教还是怪物干的，但我需要一些武装人员去那地方摆平它。如果你跟什么邪门玩意动了手，那么把它的头带给我，我会给你丰厚的报酬。%SPEECH_OFF% | 你看见%employer%正趴在梯子顶端，手忙脚乱地翻找书架最高层。他摇了摇头，招手叫你进去。%SPEECH_ON%我他妈根本不知道我在找什么。%SPEECH_OFF%你点了点头，告诉他你也束手无策。那个人爬了下来。%SPEECH_ON%真好笑，佣兵。听着，我收到了从%direction%离这%distance%%worldmapregion%地区发生混乱的消息。那地方人烟稀少，但住在那里的人都在谈论陆地上游荡着各种骇人的东西。巨人、侵扰梦境的邪灵……要什么有什么。我需要你带上你的人去干掉那些“烫手山芋”，如何？把你们发现的任何非人怪物的脑袋都带给我。每一个我都付你高价。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈多少克朗？ | 如果你能付出合适的价格。 | 继续。 | 你觉得你臣民的安全值多少？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这并不值得我去奔波劳碌。 | 我们可不打算去%worldmapregion%做无用功。 | 这不是我们想接的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "TaskLarge",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_63.png[/img]{%employer%坐在书桌后，房间里空无一人。他示意你坐下，你便坐下了。他向前倾身。%SPEECH_ON%我家族有个传说。我父亲遇见过它，我父亲的父亲也遇见过。我们不知这传说从何而起。我一直期望能在有生之年亲眼目睹这传说，而现在我觉得我见到了。就在昨晚的梦里。%SPEECH_OFF%听他说着，你不由正襟危坐，因为椅子中间破了个洞。你点点头，他继续道。%SPEECH_ON%前往%direction%的%worldmapregion%地区。我相信那些传说是真的，有一头巨大的野兽在那片土地上活动。甚至可能不止一头！无论有多少，我需要最有经验的佣兵去找到它们。把它们的脑袋带回来，你将得到丰厚的酬劳。你愿意吗？%SPEECH_OFF% | 你走进%employer%的房间。他推给你一卷卷轴，上面的文字你无法辨识。这位贵族说那上面记载的是一段传说。他张开双臂。%SPEECH_ON%我相信，这片土地上有着树一般庞大的巨兽在游荡。从这里往%direction%方向的%worldmapregion%地区。那里的农民们讲述着难以置信的巨大怪物。而我愿意相信。我想亲眼看看，所以喊你过来。去那片鬼地方，干掉任何非人的怪物，它们的脑袋摆到我脚前。%SPEECH_OFF% | %employer%将你迎入房间并直入主题。%SPEECH_ON%我需要你去%direction%的%worldmapregion%地区。我记录了许多关于庞大巨兽在那片土地上活动的传闻，我相信它们的每一句话。树那么大的蛇，和树一样大！不管它们到底是什么玩意儿，我要你去把它们干掉，把头颅带回来。或者鳞片、树枝之类的，什么都行。你带回什么，我就为它买单。有兴趣吗？%SPEECH_OFF% | %employer%递给你一本卷了书角的厚书。你心里觉得这样对待显然很稀有的书籍实在是危险的冒犯，但对此你选择了闭嘴。贵族询问你是否听说过巨人、巨龙、海怪之类的东西。你还没来得及回答，%employer%就把手指按在翻开的书页上，他的指关节敲着画中一个比橡树还高的怪物，部分原因是它长得就像一棵橡树。%SPEECH_ON%我认为它们存在。我认为它们现在就在%worldmapregion%，就在这里的%direction%。佣兵，我要你去那儿，杀死你找到的所有邪恶生物。把它们的头颅带给我。危险程度难以估量，但回报将是巨大的。你觉得自己能行吗？%SPEECH_OFF% | %employer%迎接着你，脸上带着一种仿佛要送人去送死的表情。不过他还是面带微笑，毕竟送死的不是他。%SPEECH_ON%啊，很高兴看到一个剑客。我相信你已经听说了，关于%worldmapregion%区域绝对有邪恶野兽怀孕的谣言满天飞。%SPEECH_OFF%你不确定自己会不会用这种措辞，但还是点了点头。贵族也点了点头作为回应。%SPEECH_ON%我在这个世界上信任的人不多，最近有一个人报告说，他看见一个巨大的生物，虽然他认为它有树那么高。另一个侦察兵也说，有龙一般大的巨蛇同样在那片区域游荡。不管那儿有什么，我需要你前往离此地%direction%的那片地区去，干掉任何盘踞在那儿的怪物。根据消息，这可能是你此生所做最危险的事。你准备好了吗？你的人准备好了吗？我绝不雇佣哪怕有丝毫犹豫的人。%SPEECH_OFF%}   ",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈多少克朗？ | 这可不是一件小事。 | 如果你能付出合适的价格。 | 像这样的工作最好有丰厚报酬。 | 你臣民的安全对你来说值多少钱？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{我们可不打算去%worldmapregion%做无用功。 | 这不是我们想接的活儿。 | 我不会让战团去冒险对付这样的敌人。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SuccessSmall",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回来后，将狰狞的兽头一股脑倒在%employer%的地板上。他从书桌前抬头看来。%SPEECH_ON%真是多此一举。去把钱给他，再找个仆人来收拾这烂摊子。%SPEECH_OFF% | %employer%迎接你的归来，却刻意保持着距离。他紧盯着你带的货色。%SPEECH_ON%干得漂亮，佣兵。我会让手下清点兽头，按说好的价格给你钱。%SPEECH_OFF% | 你将猎杀的成果呈给%employer%观看。他点了点头，挥手让你退下。%SPEECH_ON%费心了，但这鬼东西我一秒钟也不想多看。%randomname%，过来，把钱付给这佣兵。%SPEECH_OFF% | %employer%迎接你回来，打量着你带的货。%SPEECH_ON%简直恶心透顶。干得好！这是你的报酬，按说好的。%SPEECH_OFF% | 你向%employer%展示收集的头颅，他手指来回点着，嘴里念念有词地数着数。最后，他直起身来。%SPEECH_ON%我没功夫搞这些破事。%randomname%，对，就是你这仆人，赶紧过来清点这头颅，按颗算好的钱付给这佣兵。%SPEECH_OFF% | %employer%正啃着苹果，走过来查看你带了什么回来。他盯着你装满面目狰狞兽头的行囊，狠狠咬了一大口苹果。%SPEECH_ON%干得不错，佣兵。%SPEECH_OFF%他狼吞虎咽地嚼了几口，咕咚一声咽了下去。%SPEECH_ON%看到那边闲着的那个仆人没？他手里拿着钱袋，让他把你应得的钱结了。%SPEECH_OFF%贵族扔了啃了一半的苹果，又给自己拿了个新的。 | 你进房间时，%employer%身边带着个孩子。小家伙兴冲冲跑过来看你带了什么，随即尖叫着缩了回去。贵族点了点头。%SPEECH_ON%看来你是把我要的东西带回来了。我的仆人%randomname%会清点头颅，并付给你应得的报酬。%SPEECH_OFF% | 你把头颅拖进%employer%的房间。他挑了挑眉毛。%SPEECH_ON%你非把这些玩意儿一路拖进来看？看，你留下了一滩污渍！你为什么不去叫一个仆人来，那就是他们存在的意义。老天，这味儿比污渍还糟糕！%SPEECH_OFF%贵族冲那个拿着钱袋的人打了个响指。%SPEECH_ON%%randomname%，清点兽头，务必把钱给这佣兵。%SPEECH_OFF% | 你展开那袋头颅，把它们堆在%employer%的地板上。他站起身来。%SPEECH_ON%没弄到地毯上吧？%SPEECH_OFF%一个仆人跑过来，一脚把兽头踢开，连忙摇头。贵族点点头，慢慢坐了回去。%SPEECH_ON%好。那个谁，%randomname%，赶紧数清楚，为这些垃圾付给这个佣兵对应的钱。对了，佣兵，下次收敛点，行不？%SPEECH_OFF% | 你把一袋野兽头颅和兽皮拖进%employer%的房间。掀开盖子就要往前倒。一个仆人眼睛瞪得溜圆，猛地冲过来撞向行囊，把它扳了回去。盖子啪嗒一声合上，正好夹到他的手指，他硬生生把痛呼咽了回去。%SPEECH_ON%多谢了，佣兵，但老爷更希望我们清点时别弄得到处都是。我会算清楚总数，清点完就给你钱。%SPEECH_OFF% | %employer%端详着你的成果。%SPEECH_ON%厉害。真恶心。不是说你，是说这些畜生。我是说，你这佣兵是够邋遢的，但这些臭畜生，简直跟干净俩字八竿子打不着。%SPEECH_OFF%你听不懂那词儿啥意思，另一个也不懂。你只催他赶紧数兽头，把该给的钱结了。 | %employer%数了数那些兽头，然后向后一靠，耸了耸肩。%SPEECH_ON%我还以为它们会更吓人呢。%SPEECH_OFF%你提起，说这些东西还长在那些野兽躯干上时，对人的胆量影响可就稍微不同了。贵族又耸了耸肩。%SPEECH_ON%或许吧，但我母亲当年被刽子手砍了头，她那颗头坐在篮子里，盯着这世界的样子，可要吓人得多。%SPEECH_OFF%这话让你不知如何回应，于是你让他把欠你的钱结了。 | %employer%盯着你放在他地板上的兽头。一个拿着扫帚的仆人挨个清点，从一堆挪到另一堆。清点完毕后，仆人报上数目，贵族点了点头。%SPEECH_ON%干得好，佣兵。仆人会拿给你报酬。%SPEECH_OFF%那出身低微的仆人叹了口气，收起了扫帚。 | %employer%打开装有野兽头皮和头骨的袋子。他抿了抿嘴，嗅了嗅，又猛地将其合上。他吩咐一个仆人清点这堆残骸，然后按约定给你付钱。%SPEECH_ON%做得好，佣兵。镇民们都很感激我雇你来处理这事。%SPEECH_OFF% | %employer%盯着你收集的头骨和兽皮，吹了声口哨。%SPEECH_ON%真是够可以的了。干这种脏活儿，我本该考虑给你点额外报酬。不过我不会给，但我有过这想法，这才是最重要的，对吧。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "一场成功的狩猎。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.Assets.addMoney(this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected"));
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "狩猎野兽于" + this.World.State.getRegion(this.Flags.get("Region")).Name);
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "SuccessMedium",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回来后，将狰狞的兽头一股脑倒在%employer%的地板上。他从书桌前抬头看来。%SPEECH_ON%真是多此一举。去把钱给他，再找个仆人来收拾这烂摊子。%SPEECH_OFF% | %employer%迎接你的归来，却刻意保持着距离。他紧盯着你带的货色。%SPEECH_ON%干得漂亮，佣兵。我会让手下清点兽头，按说好的价格给你钱。%SPEECH_OFF% | 你将猎杀的成果呈给%employer%观看。他点了点头，挥手让你退下。%SPEECH_ON%费心了，但这鬼东西我一秒钟也不想多看。%randomname%，过来，把钱付给这佣兵。%SPEECH_OFF% | %employer%迎接你回来，打量着你带的货。%SPEECH_ON%简直恶心透顶。干得好！这是你的报酬，按说好的。%SPEECH_OFF% | 你向%employer%展示收集的头颅，他手指来回点着，嘴里念念有词地数着数。最后，他直起身来。%SPEECH_ON%我没功夫搞这些破事。%randomname%，对，就是你这仆人，赶紧过来清点这头颅，按颗算好的钱付给这佣兵。%SPEECH_OFF% | %employer%正啃着苹果，走过来查看你带了什么回来。他盯着你装满面目狰狞兽头的行囊，狠狠咬了一大口苹果。%SPEECH_ON%干得不错，佣兵。%SPEECH_OFF%他狼吞虎咽地嚼了几口，咕咚一声咽了下去。%SPEECH_ON%看到那边闲着的那个仆人没？他手里拿着钱袋，让他把你应得的钱结了。%SPEECH_OFF%贵族扔了啃了一半的苹果，又给自己拿了个新的。 | 你进房间时，%employer%身边带着个孩子。小家伙兴冲冲跑过来看你带了什么，随即尖叫着缩了回去。贵族点了点头。%SPEECH_ON%看来你是把我要的东西带回来了。我的仆人%randomname%会清点头颅，并付给你应得的报酬。%SPEECH_OFF% | 你把头颅拖进%employer%的房间。他挑了挑眉毛。%SPEECH_ON%你非把这些玩意儿一路拖进来看？看，你留下了一滩污渍！你为什么不去叫一个仆人来，那就是他们存在的意义。老天，这味儿比污渍还糟糕！%SPEECH_OFF%贵族冲那个拿着钱袋的人打了个响指。%SPEECH_ON%%randomname%，清点兽头，务必把钱给这佣兵。%SPEECH_OFF% | 你展开那袋头颅，把它们堆在%employer%的地板上。他站起身来。%SPEECH_ON%没弄到地毯上吧？%SPEECH_OFF%一个仆人跑过来，一脚把兽头踢开，连忙摇头。贵族点点头，慢慢坐了回去。%SPEECH_ON%好。那个谁，%randomname%，赶紧数清楚，为这些垃圾付给这个佣兵对应的钱。对了，佣兵，下次收敛点，行不？%SPEECH_OFF% | 你把一袋野兽头颅和兽皮拖进%employer%的房间。掀开盖子就要往前倒。一个仆人眼睛瞪得溜圆，猛地冲过来撞向行囊，把它扳了回去。盖子啪嗒一声合上，正好夹到他的手指，他硬生生把痛呼咽了回去。%SPEECH_ON%多谢了，佣兵，但老爷更希望我们清点时别弄得到处都是。我会算清楚总数，清点完就给你钱。%SPEECH_OFF% | %employer%端详着你的成果。%SPEECH_ON%厉害。真恶心。不是说你，是说这些畜生。我是说，你这佣兵是够邋遢的，但这些臭畜生，简直跟干净俩字八竿子打不着。%SPEECH_OFF%你听不懂那词儿啥意思，另一个也不懂。你只催他赶紧数兽头，把该给的钱结了。 | %employer%数了数那些兽头，然后向后一靠，耸了耸肩。%SPEECH_ON%我还以为它们会更吓人呢。%SPEECH_OFF%你提起，说这些东西还长在那些野兽躯干上时，对人的胆量影响可就稍微不同了。贵族又耸了耸肩。%SPEECH_ON%或许吧，但我母亲当年被刽子手砍了头，她那颗头坐在篮子里，盯着这世界的样子，可要吓人得多。%SPEECH_OFF%这话让你不知如何回应，于是你让他把欠你的钱结了。 | %employer%盯着你放在他地板上的兽头。一个拿着扫帚的仆人挨个清点，从一堆挪到另一堆。清点完毕后，仆人报上数目，贵族点了点头。%SPEECH_ON%干得好，佣兵。仆人会拿给你报酬。%SPEECH_OFF%那出身低微的仆人叹了口气，收起了扫帚。 | %employer%打开装有野兽头皮和头骨的袋子。他抿了抿嘴，嗅了嗅，又猛地将其合上。他吩咐一个仆人清点这堆残骸，然后按约定给你付钱。%SPEECH_ON%做得好，佣兵。镇民们都很感激我雇你来处理这事。%SPEECH_OFF% | %employer%盯着你收集的头骨和兽皮，吹了声口哨。%SPEECH_ON%真是够可以的了。干这种脏活儿，我本该考虑给你点额外报酬。不过我不会给，但我有过这想法，这才是最重要的，对吧。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "一场成功的狩猎。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.Assets.addMoney(this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected"));
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "狩猎野兽于" + this.World.State.getRegion(this.Flags.get("Region")).Name);
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "SuccessLarge",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你拖着猎物的残骸费力地走进%employer%的房间。他猛地后退，仿佛你驯服了那野兽还骑着它来耀武扬威似的。贵族捂着胸口，定了定神才站稳。%SPEECH_ON%旧神啊，佣兵，你要是不这么蠢，就该把这东西留在院子里，再叫我下去看。%SPEECH_OFF%你耸耸肩，问起报酬。他却问你怎么杀死的野兽。你又绕回报酬的事。贵族抿了抿嘴。%SPEECH_ON%行吧。仆人！仆人！给这个犟脾气的野兽杀手拿工钱来。%SPEECH_OFF% | 你把野兽的尸体拖到院子里，然后呼叫%employer%。他走到窗边，低头看了许久。%SPEECH_ON%真的假的？还是你在开玩笑？%SPEECH_OFF%你叹了口气，拔出剑猛地刺入一只大眼睛。只听“噗”的一声，眼球瘪了下去，黄色黏液溅了一地。贵族吹了声口哨，咂了咂舌。%SPEECH_ON%老天爷啊，真希望你没这么做！我马上派仆人给你拿报酬来！%SPEECH_OFF% | 你征用了一头驴，让它帮忙把那被杀死的怪物拖进镇里。驴子甩了甩耳朵，呆呆地盯着那歪歪扭扭、不像世间之物的行李。%employer%在他的宅邸外迎上你。他站在那具怪物残骸旁，用拇指和食指托着下巴。%SPEECH_ON%真不可思议，真难想象它活着打斗时是什么样子。%SPEECH_OFF%你点点头，告诉他外面肯定还有不少这种怪物，下次你去打猎时他也该跟着来。他摇摇头。%SPEECH_ON%我还是算了吧，佣兵。这是你的报酬，还有，你得把驴还给它的主人。%SPEECH_OFF%一个农夫一边用布擦着前额一边大步走来。%SPEECH_ON%这东西叫骡子，你要是想借这鬼东西，直说不就行了！%SPEECH_OFF% | 你把野兽的残骸切碎，然后一件件地拖进%employer%的房间。尸体越堆越高，他用布捂住了鼻子。%SPEECH_ON%看来传说都是真的。这些怪物真的存在。%SPEECH_OFF%几个仆人试着把碎块拼起来，勉强凑出个怪物的畸形模样，可手一松，肉块就又散了。贵族点点头，打了个响指。%SPEECH_ON%把钱付给他，再把我的顾问叫来。%SPEECH_OFF% | %employer%雇主的一个手下拿着雕刻刀站在一旁，准备在兽尸上凿刻，笑得又夸张又狂热。%SPEECH_ON%我家族的姓氏可以被刻在骨头上，用作斧头或剑的柄。%SPEECH_OFF%你告诉这两人，除非付钱，否则他们碰都别想碰这东西。贵族咧嘴一笑。%SPEECH_ON%没必要这么暴躁，佣兵。我已经叫仆人去拿你的报酬，还有，你要是再敢用这种语气说话，就算你是怪兽杀手还是什么别的东西，我都会割下你的舌头。%SPEECH_OFF%你手按剑柄，在心里倒数，强压着怒火。好在没等数到零，仆人就来了。 | %employer%像个孩子一样，对着这些残破的遗骸拍手叫好。%SPEECH_ON%讲述我事迹的故事将会无比伟大。我要用这些骨头来做武器的握柄，然后讲述我如何获取这些野兽脑袋的故事。%SPEECH_OFF%你点头。听起来不错。反正历史书上也不会记载你的名字。你要求他付钱。%employer%点着头，目光没有离开那些生物，打了几个响指。%SPEECH_ON%仆人！把这个人的钱给他！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "一场成功的狩猎。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.Assets.addMoney(this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected"));
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "狩猎野兽于" + this.World.State.getRegion(this.Flags.get("Region")).Name);
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		local dest = this.World.State.getRegion(this.m.Flags.get("Region")).Center;
		local distance = this.World.State.getPlayer().getTile().getDistanceTo(dest);
		distance = this.Const.Strings.Distance[this.Math.min(this.Const.Strings.Distance.len() - 1, distance / 30.0 * (this.Const.Strings.Distance.len() - 1))];
		_vars.push([
			"killcount",
			this.m.Flags.get("HeadsCollected")
		]);
		_vars.push([
			"noblehousename",
			this.World.FactionManager.getFaction(this.m.Faction).getNameOnly()
		]);
		_vars.push([
			"worldmapregion",
			this.World.State.getRegion(this.m.Flags.get("Region")).Name
		]);
		_vars.push([
			"direction",
			this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(dest)]
		]);
		_vars.push([
			"distance",
			distance
		]);
		_vars.push([
			"regiontype",
			this.Const.Strings.TerrainShort[this.World.State.getRegion(this.m.Flags.get("Region")).Type]
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		return true;
	}

	function onIsTileUsed( _tile )
	{
		return false;
	}

	function onSerialize( _out )
	{
		_out.writeU8(this.m.Size);
		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.m.Size = _in.readU8();
		this.contract.onDeserialize(_in);
	}

});

