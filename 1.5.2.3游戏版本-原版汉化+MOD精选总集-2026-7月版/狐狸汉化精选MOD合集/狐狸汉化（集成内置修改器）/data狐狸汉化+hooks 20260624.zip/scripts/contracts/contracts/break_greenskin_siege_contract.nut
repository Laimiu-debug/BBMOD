this.break_greenskin_siege_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Troops = null,
		IsPlayerAttacking = true,
		IsEscortUpdated = false
	},
	function create()
	{
		this.contract.create();
		local r = this.Math.rand(1, 100);

		if (r <= 70)
		{
			this.m.DifficultyMult = this.Math.rand(90, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(115, 135) * 0.01;
		}

		this.m.Type = "contract.break_greenskin_siege";
		this.m.Name = "解除围城";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
		this.m.MakeAllSpawnsResetOrdersOnContractEnd = false;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		this.m.Flags.set("ObjectiveName", this.m.Origin.getName());
		local nearest_orcs = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getNearestSettlement(this.m.Origin.getTile());
		this.m.Flags.set("OrcBase", nearest_orcs.getID());
		local nearest_goblins = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).getNearestSettlement(this.m.Origin.getTile());
		this.m.Flags.set("GoblinBase", nearest_goblins.getID());
		this.m.Payment.Pool = 1500 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往%objective%",
					"打破绿皮的围城"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local okLocations = 0;

				foreach( l in this.Contract.m.Origin.getAttachedLocations() )
				{
					if (l.isActive())
					{
						okLocations = ++okLocations;
					}
				}

				if (okLocations < 3)
				{
					foreach( l in this.Contract.m.Origin.getAttachedLocations() )
					{
						if (!l.isActive() && !l.isMilitary())
						{
							l.setActive(true);
							okLocations = ++okLocations;

							if (okLocations >= 3)
							{
								break;
							}
						}
					}
				}

				local faction = this.World.FactionManager.getFaction(this.Contract.getFaction());
				local party = faction.spawnEntity(this.Contract.getHome().getTile(), this.Contract.getHome().getName() + " Company", true, this.Const.World.Spawn.Noble, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("banner").setBrush(faction.getBannerSmall());
				party.setDescription("为地方领主服务的专业士兵。");
				this.Contract.m.Troops = this.WeakTableRef(party);
				party.getLoot().Money = this.Math.rand(50, 200);
				party.getLoot().ArmorParts = this.Math.rand(0, 25);
				party.getLoot().Medicine = this.Math.rand(0, 5);
				party.getLoot().Ammo = this.Math.rand(0, 30);
				local r = this.Math.rand(1, 4);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}

				local c = party.getController();
				c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
				c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
				local move = this.new("scripts/ai/world/orders/move_order");
				move.setDestination(this.Contract.getOrigin().getTile());
				c.addOrder(move);
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Origin != null && !this.Contract.m.Origin.isNull())
				{
					this.Contract.m.Origin.getSprite("selection").Visible = true;
				}

				this.World.State.setEscortedEntity(this.Contract.m.Troops, true);
			}

			function update()
			{
				if (this.Flags.get("IsContractFailed"))
				{
					this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
					this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "战团撕毁了一份合同");
					this.World.Contracts.finishActiveContract(true);
					return;
				}

				if (this.Contract.m.Troops != null && !this.Contract.m.Troops.isNull())
				{
					if (!this.Contract.m.IsEscortUpdated)
					{
						this.World.State.setEscortedEntity(this.Contract.m.Troops, true);
						this.Contract.m.IsEscortUpdated = true;
					}

					this.World.State.setCampingAllowed(false);
					this.World.State.getPlayer().setPos(this.Contract.m.Troops.getPos());
					this.World.State.getPlayer().setVisible(false);
					this.World.Assets.setUseProvisions(false);
					this.World.getCamera().moveTo(this.World.State.getPlayer());
				}

				if ((this.Contract.m.Troops == null || this.Contract.m.Troops.isNull() || !this.Contract.m.Troops.isAlive()) && !this.Flags.get("IsTroopsDeadShown"))
				{
					this.Flags.set("IsTroopsDeadShown", true);
					this.World.State.setCampingAllowed(true);
					this.World.State.setEscortedEntity(null);
					this.World.State.getPlayer().setVisible(true);
					this.World.Assets.setUseProvisions(true);
					this.World.State.resetSpeedToNormal();
					this.Contract.setScreen("TroopsHaveDied");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerNear(this.Contract.m.Origin, 1200))
				{
					if (this.Contract.m.Troops == null || this.Contract.m.Troops.isNull())
					{
						this.Contract.setScreen("ArrivingAtTheSiegeNoTroops");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.m.Troops.getController().getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(true);
						this.Contract.setScreen("ArrivingAtTheSiege");
						this.World.Contracts.showActiveContract();
					}

					this.World.State.setCampingAllowed(true);
					this.World.State.setEscortedEntity(null);
					this.World.State.getPlayer().setVisible(true);
					this.World.Assets.setUseProvisions(true);
					this.World.State.resetSpeedToNormal();
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("IsContractFailed", true);
			}

		});
		this.m.States.push({
			ID = "Running_BreakSiege",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"摧毁所有绿皮的攻城器械",
					"消灭%objective%周围的所有绿皮"
				];

				if (this.Contract.m.Origin != null && !this.Contract.m.Origin.isNull())
				{
					this.Contract.m.Origin.getSprite("selection").Visible = false;
				}

				foreach( id in this.Contract.m.UnitsSpawned )
				{
					local e = this.World.getEntityByID(id);

					if (e != null)
					{
						e.getSprite("selection").Visible = true;

						if (e.getFlags().has("SiegeEngine"))
						{
							e.setOnCombatWithPlayerCallback(this.onCombatWithSiegeEngines.bindenv(this));
						}
					}
				}
			}

			function update()
			{
				if (this.Contract.m.UnitsSpawned.len() == 0)
				{
					this.Contract.setScreen("TheAftermath");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.m.Origin == null || this.Contract.m.Origin.isNull() || !this.Contract.m.Origin.isAlive())
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatWithSiegeEngines( _dest, _isPlayerAttacking = true )
			{
				this.Contract.m.IsPlayerAttacking = _isPlayerAttacking;
				local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
				p.Music = this.Const.Music.GoblinsTracks;
				p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Edge;
				p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
				p.EnemyBanners = [
					this.World.getEntityByID(this.Flags.get("GoblinBase")).getBanner()
				];
				this.World.Contracts.startScriptedCombat(p, this.Contract.m.IsPlayerAttacking, true, true);
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];

				if (this.Contract.m.Origin != null && !this.Contract.m.Origin.isNull())
				{
					this.Contract.m.Origin.getSprite("selection").Visible = false;
				}

				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%employer% 递给你一杯酒。%SPEECH_ON%干了它。%SPEECH_OFF%你几乎能从他呼出的气息里嗅到坏消息的味道。你仰头一饮而尽，对他点了点头。他也点点头回应。%SPEECH_ON%一大群绿皮正在这一带肆虐，看样子他们想拿下 %objective%。%SPEECH_OFF%他又倒了一杯酒，一口闷下，接着又倒了一杯。%SPEECH_ON%如果他们得手，整个地区估计都得完蛋。我不知道你清不清楚十年前这帮畜生打过来时发生了什么，反正这儿没几个人想再经历一次。现在，我的探子回报说围城刚开始，那帮绿皮还没集结完毕，这意味着我们如果现在动手，就能在局势失控前打破包围！如果你感兴趣的话，看在旧神的份上，我希望你接下这活儿，赶紧把那该死的包围圈给我撕开！%SPEECH_OFF% | 护卫们围在 %employer% 身边。他们摘了头盔，满头大汗，有些人的盔甲还在微微发颤。%employer% 透过这群绝望的人看见了你，招手示意你上前。%SPEECH_ON%佣兵！有个...特别糟的消息。也许你已经听说了，但时间紧迫我就直说了：绿皮可能已经入侵了这片地区，正威胁着要拿下%objective%。他们目前正在围攻，但有消息说那些绿皮还没集结完毕。我需要你赶过去，在局面失控前，打破包围圈。%SPEECH_OFF% | %employer% 身边站着几个书记官。他们轮流低语，这位贵族老爷只是对每句话都点头示意。最后，%employer%将注意力转向你。%SPEECH_ON%佣兵，以前解过围城之困吗？ %objective% 正被绿皮围困。我们时间不多了，等他们攻破那里，这片地区说不定都要沦陷！到那时...十年前的事你应该听说过。%SPEECH_OFF%书记官们齐刷刷点头，低下了头。%employer% 继续道。%SPEECH_ON%怎么样？有兴趣活动活动筋骨吗？%SPEECH_OFF% | %employer% 面带忧色迎接你。%SPEECH_ON%我们遇上大麻烦了，佣兵，需要你出手相助！%objective%正被绿皮围困，我手头兵力不足以独自解围。但我觉得你能胜任。接不接这活？报酬绝对丰厚%SPEECH_OFF% | %employer% 双臂撑在桌沿站着，耸着肩膀，活像只盯着猎物的乌鸦。他摇了摇头。%SPEECH_ON%佣兵，我需要更多人手来对付围攻%objective%的绿皮大军。你接这活儿吗？我现在就要答案。%SPEECH_OFF% | %employer% 一见到你就站了起来。他满脸是汗，挤出个僵硬的怪笑。%SPEECH_ON%佣兵！你来得太是时候了！有消息说绿皮围困了%objective%，我需要你帮忙！接不接这活？得尽快决定。%SPEECH_OFF% | 只见 %employer% 深陷在椅子里，仿佛巴不得椅背能合起来把他永远封存。他懒洋洋地指了指桌上的地图。%SPEECH_ON%好吧，有消息说绿皮已经卷土重来，并且正在围困%objective%。我需要尽可能多的人手去那里解围。报酬少不了你的，你要加入吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{你认为拯救 %objective% 值多少钱？ | 打破围城是 %companyname% 能胜任的事。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不划算。 | 我们还有别的事儿做。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "PreparingForBattle",
			Title = "在%townname%…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你走出 %employer% 的驻地，准备召集队伍，环顾四周，骑士和士兵们正四处奔忙。其中一些人围聚在一位神父身边，静默地做着临终告解。%SPEECH_ON%他们正在天堂订位子呢。%SPEECH_OFF%%randombrother% 说着走到你身边，朝你咧了咧嘴。%SPEECH_ON%这话，太晦气了？%SPEECH_OFF% | 在 %employer% 的住所外，士兵们忙作一团。有的正往马车后厢搬扛物资，有的在打磨武器，还有几个侍从抱着大摞大摞的盔甲来回奔波。你走向自己的队员，下令做好战斗准备。%randombrother% 朝那片忙碌景象扬了扬下巴。%SPEECH_ON%看来这次我们有伴儿了？%SPEECH_OFF% | 从 %employer% 的房间到走廊挤满了士兵。你途经几个房间，里面坐着惊惶的妇孺和宁愿自己耳聋也不愿眼瞎的老人。到了外面，你得费力穿过一群抱着武器盔甲乱窜的侍从。%companyname%的成员正在等你。%SPEECH_ON%出发吧。这些人还得备战，咱们可是早就准备好了，对吧伙计们？%SPEECH_OFF% | 刚离开 %employer% 的住所，就看见 %randombrother% 正在观察着周围繁忙的战备景象：抱着武器盔甲奔走的侍从、往马车里搬扛物资的士兵、还有正在安抚新兵的神父。你吩咐这位佣兵同伴做好准备，接下来我们要跟随这些士兵出击，打破围城。 |  走到外面，你看到 %employer% 的士兵们正在整备。他们正把装备装上马车，神父在队列间穿行。妇人、孩童和老人们站在路边。%companyname% 成员们静候在原地。你走过去，向他们交代了即将执行的任务。 | 走出去后，你发现 %employer% 的士兵们正武装起来准备作战。孩子们嬉笑打闹着玩打仗游戏，笑声里全然不知真实战争的残酷。有些失去过丈夫的妇女则忧心忡忡。你穿过人群走向 %companyname%，向他们详细说明任务细节。 | %employer% 的士兵们正在备战。新兵用强装的勇气和干笑掩饰恐惧。老兵们面无表情地整理装备，仿佛在怀念未能归来的故友。而那些杀红眼的狂徒则兴奋得叫人发毛。你穿过他们走向 %companyname% 交代任务。 | 当你走出来时，发现 %employer% 的军队士兵们正准备开拔。武器堆成一座小山，士兵们正从中挑拣装备。这混乱场面显然缺乏组织。虽不是好兆头，你还是抛开疑虑，去找 %companyname% 的队员宣布这份新合同。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们出发！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "TroopsHaveDied",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]所有贵族士兵在前去解围的路上全部阵亡了。但至少死的不是你。%companyname%将继续前往%objective%。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们必须继续前进。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ArrivingAtTheSiege",
			Title = "临近%objective%…",
			Text = "[img]gfx/ui/events/event_68.png[/img]{你终于来到了围城的现场。绿皮们包围了 %objective%，只见它们的攻城器械正不断把燃烧的巨石抛向空中。半个镇子已经陷入火海，远远能看见蚂蚁般的人影正拼命奔走救火。贵族军官命令你们先去端掉那些攻城器械，随后再与大部队汇合，消灭残余的敌人。 | 眼前的 %objective% 哪还像个城镇，根本就是座熊熊燃烧的巨型篝火。你看见绿皮们的攻城器械正疯狂地倾泻着火力，天空中充斥着黑色的石弹、死牛和燃烧的木梁。贵族士兵的副官命令你去摧毁攻城器械。他和他的士兵们将攻击绿皮军队的主力，然后你们再重新汇合，彻底歼灭残敌。 | 围城战仍在激烈进行，%objective% 仍在苦苦支撑，看来你们来得正是时候，绿皮们正用它们的攻城器械疯狂破坏，不出几个钟头整座城镇怕是要从地图上消失。看着这一幕，贵族士兵的副官命令你们从侧翼包抄，摧毁那些攻城武器。他和他的士兵们将攻击绿皮军队的主力，之后你们重新汇合并消灭任何漏网之鱼。 | 还没看到战场，你就先听到了那震耳欲聋的轰击声。巨石划破长空的呼啸如同暴风肆虐，坠地时的轰鸣奏响残酷终章。终于，你爬上一座山丘，看清了 %objective% 的情况。它被绿皮野蛮人团团围住，他们的攻城器械正狰狞地运作着，抛掷出石块、死牛、成捆的人类尸体，但凡能扔的东西都被这些杂种抛进了城镇。\n\n贵族士兵的副官向你说明了作战计划：你们负责侧翼包抄，攻击攻城器械，他和他的士兵将正面冲击绿皮军队，成功之后，你们双方将重新汇合并消灭剩余的敌人。 | 你在路上遇到一位带着一群孩子的年轻女子，孩子们像严冬里挤作一团的狼崽一样紧靠着她。她一侧头上有干涸的暗红血渍，不过被她用一绺打结的头发巧妙地遮住了。她解释说，如果你们是去 %objective% 的，那你必须抓紧时间。绿皮们已经架起了攻城武器，正在疯狂轰炸。你和贵族士兵们继续前进，给那女子留下一袋面包让孩子们充饥。\n\n爬上下一座山丘，眼前的景象证实了难民的说法。贵族士兵的副官立刻下达命令。你和%companyname%负责攻击攻城器械，士兵们则直捣绿皮军队的核心。任务完成后，你们再汇合，扫清所有残余的敌人。 | 你和贵族士兵们登上了能俯瞰 %objective% 的最近山丘。镇子还在，但这鬼地方更像是一堆废墟而不是个城镇了。绿皮们已经用他们那些破烂攻城器械肯定轰了有些时候了，且丝毫没有停手的迹象。\n\n贵族军官命令你们包抄侧翼，端掉那些攻城武器。与此同时，士兵们将攻击敌人的核心部队。完成两项任务后，你们会重新汇合并摧毁残余敌人。 | 你遇到一位推着小车赶路的老人。车上躺着一个双腿被压碎的年轻人，他已经昏死过去，双手仍死死捂着粉碎的膝盖。老人说 %objective% 就在前面那座山丘后面，正被攻城武器轰炸呢，你们要是想去救援，最好动作快点。%companyname% 和士兵们继续前进，留下老人独自推车前行。\n\n那名老者没有说谎：%objective% 正在燃烧，并且在一堆绿皮蛮子们的攻城器械狂轰滥炸下正慢慢变成废墟。亲眼目睹这一幕后，贵族士兵的副官迅速制定了行动计划：%companyname% 将从侧翼攻击攻城器械，士兵们则对付绿皮大军的主力。一旦两项任务完成，你们将汇合并消灭剩余的敌人。 | 你遇到一大群野狗沿路狂奔。它们避开了你们的队伍，但你注意到它们全都夹着尾巴，低着脑袋，脚步一刻不停地匆匆掠过你们身边。\n\n翻过下一座山丘，你看到了混乱的源头：绿皮们正在用破烂的攻城机械不停地轰击 %objective%。贵族士兵的副官见状点了点头，并迅速下达了命令。%companyname% 将侧翼迂回并直接攻击攻城武器。完成任务后，你们需要绕回来与士兵们汇合，然后一并前进。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "做好战斗准备！",
					function getResult()
					{
						this.Contract.setState("Running_BreakSiege");
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.spawnSiege();
			}

		});
		this.m.Screens.push({
			ID = "ArrivingAtTheSiegeNoTroops",
			Title = "临近%objective%…",
			Text = "[img]gfx/ui/events/event_68.png[/img]{你终于看到了%objective%，它已经陷入了绝境。绿皮部落正用一排排简陋的攻城器械持续轰击着这座城镇。你命令 %companyname% 做好战斗准备：你们将从侧翼包抄敌军，直接端掉他们的攻城器械。 | 由于英勇的士兵们全部阵亡，你独自抵达了 %objective%。绿皮们还在用简陋的攻城器械不断轰击这个可怜的城镇。你认为最有效的对策就是从侧翼突袭这些绿皮蛮子并攻击他们的攻城器械。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "做好战斗准备！",
					function getResult()
					{
						this.Contract.setState("Running_BreakSiege");
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.spawnSiege();
			}

		});
		this.m.Screens.push({
			ID = "SiegeEquipmentAhead",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_68.png[/img]{绿皮兽人正在附近集结攻城器械。你必须摧毁它们，才能帮助解除围困！ | 你的士兵发现附近有几件攻城器械。绿皮兽人肯定在准备发动进攻！你需要摧毁它们以帮助解除围困！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开战！",
					function getResult()
					{
						this.Contract.getActiveState().onCombatWithSiegeEngines(null, this.Contract.m.IsPlayerAttacking);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Shaman",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_48.png[/img]{当你逼近那些围攻中的哥布林时，你注意到它们队伍里有个相当独特的轮廓。那是个萨满。你命令手下做好相应准备。 | 一个很独特的身影在哥布林中显得格外突出。你看到它正用它们那自以为能算作语言的叽里呱啦的鬼话发号施令。那恶心的东西浑身缠着怪异的植物，还戴着一条像是动物骨头做的项链。%SPEECH_ON%是个萨满。%SPEECH_OFF%%randombrother% 走到你身边说道。%SPEECH_ON%我去通知其他弟兄。%SPEECH_OFF% | %randombrother% 侦察归来。他报告说入侵的绿皮怪群里有个哥布林萨满。他似乎相当恼火。%SPEECH_ON%我挺喜欢杀几个哥布林的，但这次恐怕会很头疼。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开战！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Warlord",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_49.png[/img]{当你靠近围攻的绿皮兽人时，一眼就看到了那个几乎不可能忽略的存在：一个高大威严的兽人军阀。那肮脏家伙的盔甲闪着光，它转过身，用兽人语厉声发号施令，驱使其他绿皮兽人陷入狂暴嗜血的狂热。你赶紧让%randombrother%去通报消息，让士兵们做好准备。 | 当接近围攻的队伍时，你认出了那个高大粗野的兽人军阀轮廓。隔老远就能听到他在对手下喽喽们发号施令。这场战斗这下可就更有意思了。 | 你刚接近绿皮营地，就听见兽人军阀独特的咆哮声，他正用那恶心又响亮的语言大声吆喝。它的出现让眼下的任务变得有些不同，你把这情况告诉了弟兄们。 | %randombrother%侦察归来。他报告说绿皮兽人的营地里有个兽人军阀。虽然是坏消息，但总比蒙在鼓里冲进去被突袭强，现在抓紧准备还来得及。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开战！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "TheAftermath",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{战斗结束了，绿皮兽人从战场上溃败了。%objective% 获救了，%employer% 应该会很高兴。你踩着堆成小山的尸体，有人类的也有野兽的，招呼弟兄们准备返程。 | 战场上到处都是尸体，苍蝇已开始聚成黑压压的云团，在腐肉上嗡嗡作响。你召集手下，准备回去找 %employer% 领赏。 | %objective% 得救了！好吧，算是保住了残骸。放眼望去，地上全是士兵和绿皮的尸体，还有些没断气的在挣扎。这是一幅残酷的画面，但又如此鲜活地展现在眼前。你命令 %companyname% 准备返程，找 %employer% 领赏。 | 成堆的尸体，两三个，甚至四个尸体堆成一堆。幸存者明明躺在地面上，却像被活埋了六尺深。这是一个可怕的景象，更加令人不安的是，重伤和垂死的人们呼救声不断。在这片残肢断骸中搜寻他们，无异于在漆黑的大海里找沉浮的水手。你转身离开，去召集 %companyname% 的人。%employer% 应该很期待你们的归来。 | 战斗胜利结束，你看着手持长矛的士兵在战场上小心巡视，隔着老远给没断气的绿皮补刀。其他贵族兵都瘫坐在地上，喝水擦脸。你可没空休息，迅速集结你的人，准备返回找 %employer% 领赏。 | 鲜血把泥土泡成了烂泥地，你的靴子深深陷入泥潭。尸体遍布，面目全非，肢体被扯落并遍地散开。断掉的头颅随处可见，双目中凝结着惊恐。折断的箭矢，打碎的长矛，无人问津的剑。烂铠甲在脚下发出嘎吱声。这真是一场恶战，对所有人来说，只留下满目疮痍。\n\n成功拯救了 %objective% 之后，你慢慢召集 %companyname% 返回找 %employer% 领赏。 | 战斗结束了，贵族士兵们立刻开始砍下他们能找到的每一个绿皮的脑袋。他们将这些脑袋插在长枪上高举示众，其野蛮行径与他们刚消灭的野蛮人如出一辙。你懒得看这些戏码。%objective% 已经得救，这才是你领赏的关键原因。 %companyname% 迅速集结，准备返回找 %employer% 领取报酬。 | 战斗结束后，你小心翼翼地穿过战场。每具尸体都诉说着自己的结局。有的背后中刀，有的身首异处，还有些肚破肠流，临死前还惊恐地抓着自己的内脏。大同小异罢了，无非是换了个地点。最重要的是 %objective% 仍然屹立不倒。你召集 %companyname%，准备返回找 %employer% 领赏。 | %randombrother% 拎着个绿皮脑袋过来，却又随手丢开，仿佛那点新鲜感转瞬即逝。他双手叉腰，望着战场点了点头。%SPEECH_ON%好吧，可真是有点意思。%SPEECH_OFF%尸体堆积如山，残肢扭曲，面容痛苦，鲜血汩汩流淌的声音清晰可闻。士兵们走过时，腿脚溅起血花就像蹚过溪流。远处的 %objective% 看起来还在燃烧，但这就够了，对你来说这已经无关紧要。%companyname% 现在应该返回去找 %employer% 领赏了。 | 围攻已经被解除，尽管绿皮并非心甘情愿放弃。死去的人类和野兽遍布大地，一眼望去尽是惨状，想必也超出了任何人的想象。%randombrother% 走到你身边。抬手扯下粘在肩头的一块绿皮血肉，像甩掉湿抹布一般随手丢开。%SPEECH_ON%真是他妈的一场恶战，头儿。%SPEECH_OFF%你点点头，命令他让弟兄们做好准备。%employer% 听到 %objective% 安然无恙的消息一定会很高兴的。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.setState("Return");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你带着几名副官一同回到 %employer% 面前。你汇报了消息，雇主立刻点了点头，递给你一大袋克朗。你转身离开时，他的副官们投来几道嫉妒的目光。 | 围城被解除了，你向 %employer% 报告了这个消息。他点点头，给了你一袋克朗。%SPEECH_ON%后人会传颂你的功绩。我是说，那些还没出生的人。%SPEECH_OFF% | 你将解围的消息告知 %employer%。他站起身，与你握手。%SPEECH_ON%以旧神之名，你今日的功绩必将永世不忘！%SPEECH_OFF%但你心里却在想，这话怕是对多少早已化作枯骨的人都说过。你照旧收下报酬，把留名青史的事留给了哲学家们。 | %employer% 热情欢迎你的归来，他猛地起身，险些被脚边的猎犬绊倒。%SPEECH_ON%佣兵啊，好消息我都听说了！围困已经解除，因此你赢得了一份丰厚的奖赏！%SPEECH_OFF%他费力地将一个沉重的箱子搬到桌上。你拿起箱子，点了点克朗的数量，随即告辞离开。 | 当你进入时，%employer%正坐在书桌后。%SPEECH_ON%进来吧，‘英雄’。人们会在你的名字旁铭刻什么好呢？%SPEECH_OFF%你问他到底在说什么。%SPEECH_ON%佣兵，别装了。你的功绩，值得让那些还没出生的人都口口相传！%SPEECH_OFF%你点点头。%SPEECH_ON%好吧，是挺好的。我的钱在哪里？%SPEECH_OFF%雇主撇了撇嘴，也点点头，把袋子递过来。%SPEECH_ON%你这种人肯定身负重任吧。这件事对你来说或许微不足道，但对我们可是意义重大！%SPEECH_OFF% | 你进门时，%employer% 正低头看着脚下。书桌下藏着个人，他也没打算遮掩自己的情妇。%SPEECH_ON%欢迎回来，佣兵！你的报酬在那边角落。对，就是那儿。别偷看。%SPEECH_OFF%你拿到了报酬，朝门口走去。%employer% 喊住你，高高翘起大拇指。%SPEECH_ON%顺便说一句，干得不错。%SPEECH_OFF%你点了点头，离开了。 | 你和 %employer% 的几个副官一同走进他的房间。看到你们一行人，他站了起来，但立刻挥手示意士兵们出去。他们服从命令，慢吞吞地离开了。你摇头道。%SPEECH_ON%他们也出力了。%SPEECH_OFF%%employer% 挥手打断你。%SPEECH_ON%是啊，他们也战斗了，但他们领的是军饷。而你不同，你是按合同办事的，合同已经完成了。再说了，那些人最好别看到我付给你多少钱。%SPEECH_OFF%你收下报酬。这数目确实容易招人眼红，离开时穿过走廊，你小心地把钱藏好。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "%objective% 得救了。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "解除围城于" + this.Flags.get("ObjectiveName"));
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isGreenskinInvasion())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Failure1",
			Title = "在%objective%附近",
			Text = "[img]gfx/ui/events/event_68.png[/img]{你耽搁太久了，现在 %objective% 已经变成一片废墟。绿皮们用突袭战术攻破了城墙。闻着风里飘来的那股味儿，不用想也猜到里面的人全被杀光了。 | %companyname% 没能及时解围，现在 %objective% 为此付出了惨痛代价。他们指望着你们来救命，结果你们让所有人失望了。要说还有什么好消息的话，那就是没人活下来抱怨你的失败了。不过，你的雇主 %employer% 可就是另一回事了。这位贵族肯定会对你们的无所作为大发雷霆。 | %objective% 彻底沦陷了！兽人把恐怖的战争机器推到城墙下，摧毁了所有防御。嗜血的绿皮怪物涌进镇子，一路见人就杀，被抓走的人也不知所踪。你的雇主 %employer% 对你玩忽职守的失败行径暴跳如雷！ | 你没有及时援救 %objective% ！绿皮们砸开了大门，然后...唉，这镇子算是彻底完蛋了。考虑到 %employer% 付钱给你可是要你保住它的，结果搞成这样，他肯定不会高兴。 | 由于你拖沓不干正事，%objective% 落到了绿皮手里！愿旧神怜悯那里的居民吧。至于你的雇主 %employer%，你就别指望他对这结果还能有什么好脸色了。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "%objective%陷落了。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "没能解除围城于" + this.Flags.get("ObjectiveName"));
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
	}

	function spawnSiege()
	{
		if (this.m.Flags.get("IsSiegeSpawned"))
		{
			return;
		}

		this.m.SituationID = this.m.Origin.addSituation(this.new("scripts/entity/world/settlements/situations/besieged_situation"));
		local originTile = this.m.Origin.getTile();
		local orcBase = this.World.getEntityByID(this.m.Flags.get("OrcBase"));
		local goblinBase = this.World.getEntityByID(this.m.Flags.get("GoblinBase"));
		local numSiegeEngines;

		if (this.m.DifficultyMult >= 1.15)
		{
			numSiegeEngines = this.Math.rand(1, 2);
		}
		else
		{
			numSiegeEngines = 1;
		}

		local numOtherEnemies;

		if (this.m.DifficultyMult >= 1.25)
		{
			numOtherEnemies = this.Math.rand(2, 3);
		}
		else if (this.m.DifficultyMult >= 0.95)
		{
			numOtherEnemies = 2;
		}
		else
		{
			numOtherEnemies = 1;
		}

		for( local i = 0; i < numSiegeEngines; i = ++i )
		{
			local tile;
			local tries = 0;

			while (tries++ < 500)
			{
				local x = this.Math.rand(originTile.SquareCoords.X - 2, originTile.SquareCoords.X + 2);
				local y = this.Math.rand(originTile.SquareCoords.Y - 2, originTile.SquareCoords.Y + 2);

				if (!this.World.isValidTileSquare(x, y))
				{
					continue;
				}

				tile = this.World.getTileSquare(x, y);

				if (tile.getDistanceTo(originTile) <= 1)
				{
					continue;
				}

				if (tile.Type == this.Const.World.TerrainType.Ocean)
				{
					continue;
				}

				if (tile.IsOccupied)
				{
					continue;
				}

				break;
			}

			local party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).spawnEntity(tile, "Siege Engines", false, this.Const.World.Spawn.GreenskinHorde, this.Math.rand(100, 120) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
			this.m.UnitsSpawned.push(party.getID());
			party.setDescription("一大群绿皮和他们的攻城车。");
			local numSiegeUnits = this.Math.rand(3, 4);

			for( local j = 0; j < numSiegeUnits; j = ++j )
			{
				this.Const.World.Common.addTroop(party, {
					Type = this.Const.World.Spawn.Troops.GreenskinCatapult
				}, false);
			}

			party.updateStrength();
			party.getLoot().ArmorParts = this.Math.rand(0, 15);
			party.getLoot().Ammo = this.Math.rand(0, 10);
			party.addToInventory("supplies/strange_meat_item");
			party.getSprite("body").setBrush("figure_siege_01");
			party.getSprite("banner").setBrush(goblinBase != null ? goblinBase.getBanner() : "banner_goblins_01");
			party.getSprite("banner").Visible = false;
			party.getSprite("base").Visible = false;
			party.setAttackableByAI(false);
			party.getFlags().add("SiegeEngine");
			local c = party.getController();
			c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
			c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
			local wait = this.new("scripts/ai/world/orders/wait_order");
			wait.setTime(9000.0);
			c.addOrder(wait);
		}

		local targets = [];

		foreach( l in this.m.Origin.getAttachedLocations() )
		{
			if (l.isActive() && l.isUsable())
			{
				targets.push(l);
			}
		}

		if (targets.len() == 0)
		{
			foreach( l in this.m.Origin.getAttachedLocations() )
			{
				if (l.isUsable())
				{
					targets.push(l);
				}
			}
		}

		for( local i = 0; i < numOtherEnemies; i = ++i )
		{
			local tile;
			local tries = 0;

			while (tries++ < 500)
			{
				local x = this.Math.rand(originTile.SquareCoords.X - 4, originTile.SquareCoords.X + 4);
				local y = this.Math.rand(originTile.SquareCoords.Y - 4, originTile.SquareCoords.Y + 4);

				if (!this.World.isValidTileSquare(x, y))
				{
					continue;
				}

				tile = this.World.getTileSquare(x, y);

				if (tile.getDistanceTo(originTile) <= 1)
				{
					continue;
				}

				if (tile.Type == this.Const.World.TerrainType.Ocean)
				{
					continue;
				}

				break;
			}

			local party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).spawnEntity(tile, "Greenskin Horde", false, this.Const.World.Spawn.GreenskinHorde, this.Math.rand(90, 110) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
			this.m.UnitsSpawned.push(party.getID());
			party.setDescription("一大群迈向战争的绿皮。");
			party.getLoot().ArmorParts = this.Math.rand(0, 15);
			party.getLoot().Ammo = this.Math.rand(0, 10);
			party.addToInventory("supplies/strange_meat_item");
			party.getSprite("banner").setBrush(orcBase != null ? orcBase.getBanner() : "banner_orcs_01");
			local c = party.getController();
			local raidTarget = targets[this.Math.rand(0, targets.len() - 1)].getTile();
			c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
			local raid = this.new("scripts/ai/world/orders/raid_order");
			raid.setTime(30.0);
			raid.setTargetTile(raidTarget);
			c.addOrder(raid);
			local destroy = this.new("scripts/ai/world/orders/destroy_order");
			destroy.setTime(60.0);
			destroy.setSafetyOverride(true);
			destroy.setTargetTile(originTile);
			destroy.setTargetID(this.m.Origin.getID());
			c.addOrder(destroy);
		}

		if (this.m.Troops != null && !this.m.Troops.isNull())
		{
			local c = this.m.Troops.getController();
			c.clearOrders();
			local intercept = this.new("scripts/ai/world/orders/intercept_order");
			intercept.setTarget(this.World.getEntityByID(this.m.UnitsSpawned[this.m.UnitsSpawned.len() - 1]));
			c.addOrder(intercept);
			local guard = this.new("scripts/ai/world/orders/guard_order");
			guard.setTarget(originTile);
			guard.setTime(120.0);
		}

		this.m.Origin.spawnFireAndSmoke();
		this.m.Origin.setLastSpawnTimeToNow();
		this.m.Flags.set("IsSiegeSpawned", true);
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"objective",
			this.m.Flags.get("ObjectiveName")
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.World.State.setCampingAllowed(true);
			this.World.State.setEscortedEntity(null);
			this.World.State.getPlayer().setVisible(true);
			this.World.Assets.setUseProvisions(true);
			this.World.State.resetSpeedToNormal();

			if (!this.m.Flags.get("IsSiegeSpawned"))
			{
				this.spawnSiege();
			}

			foreach( id in this.m.UnitsSpawned )
			{
				local e = this.World.getEntityByID(id);

				if (e != null && e.isAlive())
				{
					e.setAttackableByAI(true);

					if (e.getFlags().has("SiegeEngine"))
					{
						local c = e.getController();
						c.clearOrders();
						local wait = this.new("scripts/ai/world/orders/wait_order");
						wait.setTime(120.0);
						c.addOrder(wait);
					}
				}
			}

			if (this.m.Origin != null && !this.m.Origin.isNull())
			{
				this.m.Origin.getSprite("selection").Visible = false;
			}

			if (this.m.Home != null && !this.m.Home.isNull())
			{
				this.m.Home.getSprite("selection").Visible = false;
			}
		}

		if (this.m.Origin != null && !this.m.Origin.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Origin.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(2);
			}
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isGreenskinInvasion())
		{
			return false;
		}

		local numAttachments = 0;

		foreach( l in this.m.Origin.getAttachedLocations() )
		{
			if (l.isActive() && l.isUsable())
			{
				numAttachments = ++numAttachments;
			}
		}

		if (numAttachments < 2)
		{
			return false;
		}

		return true;
	}

	function onSerialize( _out )
	{
		if (this.m.Troops != null && !this.m.Troops.isNull())
		{
			_out.writeU32(this.m.Troops.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local troops = _in.readU32();

		if (troops != 0)
		{
			this.m.Troops = this.WeakTableRef(this.World.getEntityByID(troops));
		}

		this.contract.onDeserialize(_in);
	}

});

