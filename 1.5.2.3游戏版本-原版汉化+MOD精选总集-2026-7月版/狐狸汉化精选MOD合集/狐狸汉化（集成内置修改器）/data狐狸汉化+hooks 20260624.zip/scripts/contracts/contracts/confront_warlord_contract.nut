this.confront_warlord_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Dude = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		local r = this.Math.rand(1, 100);

		if (r <= 70)
		{
			this.m.DifficultyMult = this.Math.rand(95, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(115, 135) * 0.01;
		}

		this.m.Type = "contract.confront_warlord";
		this.m.Name = "挑战兽人军阀";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		this.m.Payment.Pool = 1800 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("Score", 0);
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"摧毁各种绿皮军队和营地来诱出他们的军阀",
					"杀死兽人军阀"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Flags.set("MaxScore", 10 * this.Contract.getDifficultyMult());
				this.Flags.set("LastRandomTime", 0.0);
				local r = this.Math.rand(1, 100);

				if (r <= 10)
				{
					this.Flags.set("IsBerserkers", true);
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
			}

			function update()
			{
				if (this.Flags.get("Score") >= this.Flags.get("MaxScore"))
				{
					this.Contract.setScreen("FinalConfrontation1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("JustDefeatedGreenskins"))
				{
					this.Flags.set("JustDefeatedGreenskins", false);
					this.Contract.setScreen("MadeADent");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("LastRandomTime") + 300.0 <= this.Time.getVirtualTimeF() && this.Contract.getDistanceToNearestSettlement() >= 5 && this.Math.rand(1, 1000) <= 1)
				{
					this.Flags.set("LastRandomTime", this.Time.getVirtualTimeF());
					this.Contract.setScreen("ClosingIn");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsBerserkersDone"))
				{
					this.Flags.set("IsBerserkersDone", false);

					if (this.Math.rand(1, 100) <= 50)
					{
						this.Contract.setScreen("Berserkers3");
					}
					else
					{
						this.Contract.setScreen("Berserkers4");
					}

					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsBerserkers") && !this.TempFlags.has("IsBerserkersShown") && this.Contract.getDistanceToNearestSettlement() >= 7 && this.Math.rand(1, 1000) <= 1)
				{
					this.TempFlags.set("IsBerserkersShown", true);
					this.Contract.setScreen("Berserkers1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onLocationDestroyed( _location )
			{
				local f = this.World.FactionManager.getFaction(_location.getFaction());

				if (f.getType() == this.Const.FactionType.Orcs || f.getType() == this.Const.FactionType.Goblins)
				{
					this.Flags.set("Score", this.Flags.get("Score") + 4);
					this.Flags.set("JustDefeatedGreenskins", true);
				}
			}

			function onPartyDestroyed( _party )
			{
				local f = this.World.FactionManager.getFaction(_party.getFaction());

				if (f.getType() == this.Const.FactionType.Orcs || f.getType() == this.Const.FactionType.Goblins)
				{
					this.Flags.set("Score", this.Flags.get("Score") + 2);
					this.Flags.set("JustDefeatedGreenskins", true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Berserkers")
				{
					this.Flags.set("IsBerserkersDone", true);
					this.Flags.set("IsBerserkers", false);
					this.Flags.set("Score", this.Flags.get("Score") + 2);
				}
			}

		});
		this.m.States.push({
			ID = "Running_Warlord",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"杀死兽人军阀"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onCombatWithWarlord.bindenv(this));
				}

				this.Flags.set("IsWarlordEncountered", false);
			}

			function update()
			{
				if (this.Flags.get("IsWarlordDefeated") || this.Contract.m.Destination == null || this.Contract.m.Destination.isNull() || !this.Contract.m.Destination.isAlive())
				{
					this.Contract.setScreen("FinalConfrontation3");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatWithWarlord( _dest, _isPlayerAttacking = true )
			{
				this.Contract.m.IsPlayerAttacking = _isPlayerAttacking;

				if (!this.Flags.get("IsWarlordEncountered"))
				{
					this.Flags.set("IsWarlordEncountered", true);
					this.Contract.setScreen("FinalConfrontation2");
					this.World.Contracts.showActiveContract();
				}
				else
				{
					local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					properties.Music = this.Const.Music.OrcsTracks;
					properties.AfterDeploymentCallback = this.OnAfterDeployment.bindenv(this);
					this.World.Contracts.startScriptedCombat(properties, this.Contract.m.IsPlayerAttacking, true, true);
				}
			}

			function OnAfterDeployment()
			{
				local all = this.Tactical.Entities.getAllInstances();

				foreach( f in all )
				{
					foreach( e in f )
					{
						if (e.getType() == this.Const.EntityType.OrcWarlord)
						{
							e.getAIAgent().getProperties().BehaviorMult[this.Const.AI.Behavior.ID.Retreat] = 0.0;
							e.getFlags().add("IsFinalBoss", true);
							break;
						}
					}
				}
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_actor.getFlags().get("IsFinalBoss") == true)
				{
					this.Flags.set("IsWarlordDefeated", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{你在马厩里找到了 %employer% 。 他正轻抚着一匹马的侧腹，缓缓开口。%SPEECH_ON%知道吗？兽人光靠蛮力就能拧断这畜生的脖子。我亲眼见过，死的是我的马，脑袋被个发狂的绿皮硬生生转了个方向。%SPEECH_OFF%怀旧固然美好，但你可不是来听故事的。 你委婉地提醒这位贵族老爷该谈正事了。他倒也爽快。%SPEECH_ON%好吧。眼下跟绿皮的战事不太顺利，所以我得出结论，我们必须干掉他们的军阀。实话跟你说，那种战斗力能碾压所有绿皮的兽人根本就是噩梦。想引他现身，最好的办法就是多宰些绿皮杂种。我知道听起来是很残忍，但事成之后，我们打赢这场该死战争的机会将大大增加。%SPEECH_OFF% | %employer% 将你迎进房间时，正忧心忡忡地盯着地图。%SPEECH_ON%{我的斥候报告说这个地区有个军阀，但摸不清具体位置。 我猜，如果你出去给这些绿皮杂种制造一大堆麻烦，他或许就会出来露一手了。明白吗？ | 我们接到消息说有个兽人军阀在各地游荡。 我相信如果我们宰了它，兽人的士气就会崩溃，我们就有可能赢得这场该死的战争。 当然，当然那大块头可不会轻易露面。 你得用兽人听得懂的语言：见一个杀一个。 记住，只针对绿皮，别滥杀无辜。 | 来得正好，佣兵，有个重要任务。 我们得到消息说有一个兽人军阀在这个地区，但我们不清楚它的位置。 你去进行一场‘兽人式外交’：尽可能多的宰些绿皮蛮子，那军阀自然会找上门。只要除掉他，战局对我们就有利多了。}%SPEECH_OFF% | %employer% 被副官们围在中间，旁边还有个满脚泥泞、汗流浃背的疲惫少年。有位指挥官上前将你拉到一旁。%SPEECH_ON%我们收到了兽人军阀的消息。那孩子的家人用性命换来了这个消息。%employer% 也同意我的看法，只要大量灭杀绿皮，就能逼那军阀现身。”%SPEECH_OFF%你靠在椅背上回应。%SPEECH_ON%让我猜猜，你们想要他的脑袋？%SPEECH_OFF%指挥官耸耸肩。%SPEECH_ON%这要求不过分吧？我的领主为这个任务准备了丰厚的报酬。%SPEECH_OFF% | %employer%坐在一群筋疲力尽的狗中间，狗嘴边还沾着随鼾声轻颤的雉鸡羽毛，在呼噜声中颤动着。 贵族招手邀你进门。%SPEECH_ON%进来吧，佣兵，我刚打猎回来。巧的是，现在要派你去进行另一场狩猎。%SPEECH_OFF%你刚落座，一条猎犬抬头喷了个鼻息，又蜷回去睡了。 你询问贵族有何吩咐，他边揉着狗耳朵边解释道。%SPEECH_ON%听说有个兽人军阀在附近活动。具体位置？不清楚。但我觉得你能把他引出来，你知道该怎么做，对吧？%SPEECH_OFF%你点头回应。%SPEECH_ON%当然。不停地杀它的手下，直到它忍无可忍亲自出战。 不过，这差事可不便宜，%employer%。%SPEECH_OFF%贵族咧嘴一笑，双手摊开作出‘谈谈价钱’的姿势。 他脚边的猎犬抬起头，眼神仿佛在说‘只要继续挠耳朵，一切好商量’。 | %employer% 坐在一张长桌后面，桌上铺着比他身子还长的地图。他的文书官凑在他耳边低语几句，随后快步走到你面前。%SPEECH_ON%领主大人有个委托。我们确信有个兽人军阀正在这一带活动，自然，必须除掉这野蛮畜生。 为此我们…%SPEECH_OFF%你抬手打断他们。%SPEECH_ON%是的，我知道怎么引蛇出洞。 只要宰够多的绿皮杂种，那个暴躁的绿色大家伙自然会找上门。%SPEECH_OFF%文书官闻言露出了欣慰的笑容。%SPEECH_ON%噢，您也读过相关战术典籍？太好了！%SPEECH_OFF%你眼角微微抽搐，但没多计较，直接开始打听报酬细节。 | %employer% 在书房接待你时，正从书架抽出一本本厚册，每本书都扬起滚滚尘埃。%SPEECH_ON%来，坐。%SPEECH_OFF%你刚落座，他就捧着古籍指向插画里狰狞的兽人酋长。%SPEECH_ON%认识这家伙吧？%SPEECH_OFF%你点头。“它是一个军阀，一个兽人部队的首领，是噼啪席卷世界的旋风。” 贵族点了点头，继续说。%SPEECH_ON%我正在研究它们，因为斥候给我带来了它们的踪迹。 当然，我们无法完全追踪这个该死的东西。 它想去哪里，就去哪里，它去哪里，就破坏哪里。%SPEECH_OFF%你打断了那个贵族，直接给出一个简单的方案：只要宰了足够多的绿皮，那军阀要么觉得被挑衅，要么被激怒，总之会主动现身。%employer% 咧嘴一笑。%SPEECH_ON%瞧见没？佣兵，这就是我欣赏你的原因，你确实是内行。 当然，这事不简单，酬劳绝对配得上你的付出。%SPEECH_OFF% | %employer% 正对搬来的卷轴堆连连摇头。%SPEECH_ON%全是废话！连怎么找到它都没写！找不到怎么杀？这不明摆着吗？这么简单的算术都不懂吗！%SPEECH_OFF%书记员躲开了，一边抽着鼻子，一边盯着地板，急匆匆地走出了房间。 你问出了什么问题。%employer% 叹了口气，有个兽人军阀在附近流窜，我们无计可施。你笑着答道。%SPEECH_ON%简单，你用它们的语言说话-暴力。多宰些绿皮杂种，逼军阀亲自来找你。兽人骨子里就崇尚暴力，不过...那玩意可不好对付。%SPEECH_OFF%%employer% 向前倾身，十指交叠。%SPEECH_ON%当然不容易，但你听起来正是合适的人选。这事关乎战局走向，咱们谈谈条件吧。%SPEECH_OFF% | 你发现 %employer% 在花园踱步，盯着植物的茎秆出神。%SPEECH_ON%说来有趣，不是吗？ 我们这里有这么多绿色的东西，那些绿皮畜生也是绿色，但我打赌它们这辈子没吃过半颗蔬菜。%SPEECH_OFF%你强忍着没吐槽这蠢话，转而询问绿皮兽人的事。%employer% 点头。%SPEECH_ON%我的斥候发现了军阀的踪迹。问题是，我们不知道它在哪里，也不知道它要去哪里，斥候无法长时间跟踪它，否则他们很可能会因此丧命，这原因想必很明显。我相信干掉它能更加接近结束这场战争，但我毫无头绪，你呢？%SPEECH_OFF%你点头回应。%SPEECH_ON%是什么让你想要杀死那个军阀？是因为它在屠杀你的人民，对吧？那么是什么会让它亲自想要杀我们呢？你得尽可能多的干掉那些绿皮杂种。%SPEECH_OFF%贵族鼓掌，扔给你一个鲜红的西红柿。%SPEECH_ON%那想法不错，佣兵。我们谈正事吧！%SPEECH_OFF% | 你发现 %employer% 和他的指挥官们正围着一张地图站着。当你走进房间时，他们像一群发现兔子的鹰一样转向你。那位贵族向你致意欢迎你进入。%SPEECH_ON%佣兵，见谅我们有些紧张。我的斥候报告有兽人军阀在附近活动，但摸不清具体动向。我的指挥官们认为，如果我们尽可能多地杀死那些绿皮怪物，兽人军阀就会现身，然后我们就能把它干掉。你觉得你能胜任这个任务吗？如果可以，我们来谈笔生意。%SPEECH_OFF% | 你走进 %employer%的房间，看见他正和一群文书商量事情。那些人明显在发抖，不停捏着脖子上的串珠，坐立不安。其中一个指向你。%SPEECH_ON%也许他有个主意？%SPEECH_OFF%其他人嗤之以鼻，但你仍主动询问出了什么问题。%employer% 解释说，有个兽人军阀在境内流窜，但他们追踪不到。 你郑重其事地点点头，随即提出个简单的解决办法。%SPEECH_ON%只要尽可能多地干掉那些绿皮，那野兽骄傲的本性会驱使它出来与你战斗。 或者说，在这种情况下，是出来与……我战斗？%SPEECH_OFF%%employer% 点了点头。%SPEECH_ON%脑子转得很快啊，佣兵。我们来谈谈正事吧。%SPEECH_OFF% | %employer% 正和指挥官们站在几幅地图前。%SPEECH_ON%佣兵，我们有个棘手的任务要交给你。 我们的斥候发现一个军阀在这一带游荡，我们需要你尽可能多地干掉绿皮，把那军阀从藏身之处引出来。只要我们能拿下那个军阀的脑袋，这场该死的战争就离结束不远了。%SPEECH_OFF% | 刚走进%employer%的房间时，他就问你是否懂得狩猎兽人军阀。 你耸耸肩答道。%SPEECH_ON%它们只听暴力的语言。 所以如果你想引它现身，你必须宰杀它足够多的兽人同类。 这么说吧，这是让它现身的唯一办法。%SPEECH_OFF%贵族点头，表示理解。 将一张羊皮纸推到桌案对面。%SPEECH_ON%那么我这倒有件事要交给你。 我们已经察觉到在我们这片区域有一个兽人军阀，但一直很难追踪到它。 我要你把它引出来解决掉。 如果我们能做到这一点，我们在这场对抗那些绿色野蛮人的战争中获胜的几率将会增加十倍！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我相信你会为此付出足够代价。 | 如果报酬合适，任何活儿我们都接。 | 用叮当作响的克朗说服我。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不值得。 | 我们还有别的地方要去。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "ClosingIn",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_46.png[/img]{一堆刚被砍下的人头骨堆成的石冢。%randombrother% 盯着那张张痛苦面孔垒成的图腾，摇了摇头。%SPEECH_ON%你说他们管这叫艺术？该不会是哪只野人后退一步，还自我陶醉：‘嗯，看起来不错。’%SPEECH_OFF%你也不确定，但你衷心希望，人类不是绿皮兽人作画的画笔和画布。 | 你路过一片农场，满地都是遭宰杀的牲畜。 肠子像某种血腥的灌溉渠，在农场的垄沟间流淌。 要么是农夫误判了天气，要么这就是兽人即将逼近的明确信号。 | 满地尸体。有的被劈成两半，有些则相对安详，只是背上插着几支弩箭。 不管死状如何，都明明白白地指向一件事，绿皮即将靠近。 | 你来到一个被遗弃的绿皮营地。 地上躺着一只脑袋被砸烂的哥布林。 大概是和更强壮的兽人起了冲突。篝火上架着个形状可怖的东西在烤，你只希望它不是你所想的那样。%randombrother% 指着劈啪作响的余烬。%SPEECH_ON%火还没灭。他们没走远，头儿。%SPEECH_OFF% | 你们走近一座谷仓，门在腥风中吱呀作响，一开一合。%randombrother% 探头看了一眼，立马捂着鼻子冲了回来。%SPEECH_ON%没错，绿皮来过这儿。%SPEECH_OFF%你忍住恶心朝里瞥了一眼，随即下令全员备战，因为恶战即将到来。 | 你发现一具兽人尸体，背上还压着一只地精。把这两具尸体掀开后，底下竟是一位死去的农夫。%randombrother% 点了点头。%SPEECH_ON%好吧，他拼死抵抗了一场。可惜我们来晚了。%SPEECH_OFF%你指着泥地里一串新鲜的脚印。%SPEECH_ON%他当时寡不敌众，而剩下那帮家伙还没跑远。叫大家准备战斗。%SPEECH_OFF% | 你们看见一个男人被沉重的铁链紧紧捆住，活活勒死了。他那发紫、变形的身体在铁链晃动中叮当作响。%randombrother% 割断铁链放下尸体，死者的嘴里猛地涌出黑血，吓得他赶紧跳开。%SPEECH_ON%见鬼，这人刚死没多久！干这事的人肯定还在附近！%SPEECH_OFF%你指着泥地里的脚印告诉他，这绝对是绿皮干的，而且，他们就在附近。 | 路中央放着个用皮肉缝制的袋子，里面装满了人耳朵，鞣制得发硬，还打了孔，像是用来串钥匙链。%randombrother%  一阵干呕。你立刻通知全员，绿皮就在不远处。 毫无疑问，一场恶战即将来临！ | 你发现了一间破败小屋的残骸。炭火在焦黑的废墟中噼啪作响。%randombrother% 发现几具残缺的骸骨，半个身子都不知所踪。 看到泥地上一些深深的足迹，你立刻下令全员戒备，毫无疑问，绿皮就在附近。 | 有个男人坐在路边抽泣，盘着腿前后摇晃。你们走近时，他猛地转过头来，没有眼睛，没有鼻子，嘴唇也被割掉了。%SPEECH_ON%够了！求求你，别再这样了！%SPEECH_OFF%他喊着倒向一侧抽搐了几下，便不再动弹。%randombrother% 检查完尸体站起身摇头问。%SPEECH_ON%绿皮？%SPEECH_OFF%你指着泥地里深深的足迹，点了点头。 | 你们遇见一个女人对着一具尸体哀嚎。她浑身血污，膝下的那具尸体连脑袋都被砸扁了。你蹲到她身旁，她瞥了你一眼发出呻吟。你问这是谁干的。女人清了清沙哑的嗓子答道。%SPEECH_ON%那些绿皮畜生。高的，矮的，它们抡着棒子的时候还在笑，一下，又一下，笑声始终没停过。%SPEECH_OFF% | 一匹死马倒在路边，内脏都淌到了路上。它的肋骨间还在往下滴着新鲜的血液。%randombrother% 注意到心脏、肝脏这些好部位都不见了。你指着小径上沾血的大小脚印说道。%SPEECH_ON%是哥布林和兽人！%SPEECH_OFF%而且他们离得不远。你当即命令 %companyname% 做好战斗准备。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "小心点！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "MadeADent",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_81.png[/img]{死了这么多绿皮，看来它们的军阀迟早会找上门来。 | 你这一路，绿皮尸横遍野。 它们的军阀很快便会嗅着血腥味找来。 | 绿皮的军阀现在肯定听说了它的手下被砍倒的故事。 它一定嗅到你的气味了。 | 如果你是绿皮军阀，你可能已经准备好了去追捕那个屠杀你手下的杂种。 继续这样的杀戮，你无疑会看到你和那个野蛮人是如何想法一致的。 | 野蛮人懂得暴力，而你无疑已经在整个地区留下了血腥的‘教诲’踪迹。 只要那军阀不是太蠢，它无疑会很快向你发起进攻。 | 按最激进的估算，那兽人军阀早该暴跳如雷了，毕竟有个不知死活的人类正在肆意破坏它的计划。 你最好时刻准备迎接那野蛮畜生，或许就在下一刻。 | 随着这么多兽人和哥布林的被杀，它们的首领亲自来追杀你只是时间问题。 | 如果暴力是兽人的语言，那么你已经在这个地区写了一封真正的‘情书’了。 那军阀肯定想好好‘回信’。 | 要是暴力算兽人表达爱意的方式，那你简直是在它们军阀的院子里，向窗户扔了一大堆石头，试图引起它的注意。 只不过扔进去的不是石头，而是它手下的四肢和脑袋。 那畜生现在一定会有反应的。 | 你身后那条绿皮尸体铺成的路，迟早会吸引他们军阀的注意。 | 秃鹫正享受饕餮盛宴：你踏过的路上堆满绿皮尸体，看来用不了多久，它们的军阀就会亲自来看看你在干什么。 | 像你这样屠杀绿皮，绝对能成功引起兽人军阀的注意，而且这份‘关注’正在急速升温。 | 要是继续按计划清理这些绿皮蛮子，兽人军阀亲自登门拜访就是迟早的事。 | 过去一周你闹出的动静比兽群狂奔还响。如果你继续这样到处屠杀绿皮，它们的军阀出现只是时间问题。 | 你隐约觉得，这片地界某个角落里，有一个非常、非常疯狂的兽人军阀，正盯着一张你脸的粗糙画像。 | 你几乎能想象自己在绿皮圈子里已成了悬赏令上的主角。 一个简笔的人像画，下面标着价码。 要价是‘死活不论，但最好是死的’。麻烦在于你会一直杀到底，直到兽人军阀亲自现身，而你有种感觉，那将会很快发生。 | 现在那些绿皮一定在它们的篝火旁传颂你的‘事迹’。说有个该死的人类在屠戮它们。 用脚趾头想都知道，兽人首领听到这些传闻后，肯定会亲自来验验货 | 照这个效率杀绿皮，它们的军阀肯定会来的。 | 你现在可是在刀尖上跳舞。 杀了这么多绿皮，兽人军阀早晚会来算账。 | 你有种强烈的预感，兽人军阀很快就会找上门来。 可能跟你宰光他手下有关系吧，纯属直觉。 | 小绿皮大绿皮都宰过了，现在该会会最壮的那个：兽人军阀。 那个野蛮畜生一定在这附近徘徊着… | 既然向绿皮们宣了战，那它们的军阀迟早会出现。 | 绿皮正成片倒下。迟早会意识到这不是自然减员。 等它想明白了，绝对会加倍疯狂地追杀你。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "{胜利！ | 该死的绿皮。}",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "FinalConfrontation1",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_81.png[/img]{你听到很多来自乡下人的谣言，说有个兽人军阀正在集结兵力，朝你们这边来了。 如果这些谣言是真的，你可得做好准备。 | 最近到处都在议论，说一支兽人军队正往这片地区开拔。而且偏偏是冲你们来的。看来你们的计划奏效了！ %companyname% 该为这场恶战做准备了。 | 有消息说兽人军阀朝着你来了！ 让 %companyname% 全员戒备，他们即将迎来一场苦战！ | 路上遇到的农民都在传同一件事：有个兽人军阀正往这儿来！这恐怕不是巧合，%companyname% 最好提前做足准备。 | 眼下风声很紧，据说有支兽人军队正冲着 %companyname% 而来。 看来你的计划奏效了。 全队该为这场恶战做准备了！ | 每个碰见的乡民都在说同一桩事：一个兽人军阀已经集结了一支小部队，偏偏正好往你们这儿来。 %companyname% 应该为一场恶战做好准备！ | 有个老太太慌慌张张跑来找你，说人人都在谈论兽人军阀要打过来的事。 你不确定这是否属实，但考虑到你过去几天的所作所为，这显然太过巧合了。%companyname% 应该为战斗做好准备。 | 看来，%companyname% 得准备迎战了。一路上的每个人都在告诉你相同的事：兽人军阀带着军队正朝你们扑过来！ | 看来那些杀戮奏效了：有消息说，一个兽人军阀集结了部队正朝着你赶来，并准备亲自料理你。 %companyname% 该做好战斗准备了！ | 一个小孩朝你走来。他瞥了一眼 %companyname%的徽记，又看看你，咧嘴笑道。%SPEECH_ON%我看你们需要帮忙。%SPEECH_OFF%这话从孩子嘴里说出来有点怪。你问他为什么，他回应道。%SPEECH_ON%我父亲说，有个凶狠的大块头兽人要宰了你们。他说商队整天都在议论这事！%SPEECH_OFF%嗯，如果这消息是真的，那就意味着策略奏效了，%companyname% 该准备战斗了。 你向孩子道谢，他耸耸肩。%SPEECH_ON%我刚救了你们一命，就只得到一句谢谢？你们这些人！%SPEECH_OFF%小孩啐了一口，踢着石子走远了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们需要为此做好准备。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				local playerTile = this.World.State.getPlayer().getTile();
				local nearest_orcs = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getNearestSettlement(playerTile);
				local tile = this.Contract.getTileToSpawnLocation(playerTile, 9, 15);
				local party = this.World.FactionManager.getFaction(nearest_orcs.getFaction()).spawnEntity(tile, "Greenskin Horde", false, this.Const.World.Spawn.GreenskinHorde, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("banner").setBrush(nearest_orcs.getBanner());
				party.getSprite("body").setBrush("figure_orc_05");
				party.setDescription("由一个可怖的兽人军阀领导的一大群绿皮。");
				party.setFootprintType(this.Const.World.FootprintsType.Orcs);
				this.Contract.m.UnitsSpawned.push(party);
				local hasWarlord = false;

				foreach( t in party.getTroops() )
				{
					if (t.ID == this.Const.EntityType.OrcWarlord)
					{
						hasWarlord = true;
						break;
					}
				}

				if (!hasWarlord)
				{
					this.Const.World.Common.addTroop(party, {
						Type = this.Const.World.Spawn.Troops.OrcWarlord
					}, false);
				}

				party.getLoot().ArmorParts = this.Math.rand(0, 35);
				party.getLoot().Ammo = this.Math.rand(0, 10);
				party.addToInventory("supplies/strange_meat_item");
				party.addToInventory("supplies/strange_meat_item");
				party.addToInventory("supplies/strange_meat_item");
				party.addToInventory("supplies/strange_meat_item");
				this.Contract.m.Destination = this.WeakTableRef(party);
				party.setAttackableByAI(false);
				local c = party.getController();
				c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
				local intercept = this.new("scripts/ai/world/orders/intercept_order");
				intercept.setTarget(this.World.State.getPlayer());
				c.addOrder(intercept);
				this.Contract.setState("Running_Warlord");
			}

		});
		this.m.Screens.push({
			ID = "FinalConfrontation2",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_49.png[/img]{那个军阀是一群兽人和哥布林的首领。 他站在那群本就高大魁梧的战士中间，显得格外突出。 你命令手下列队迎战，话音刚落，军阀便咆哮起来，它的战士们便如潮水般向你们涌来！ | 乌泱泱的兽人和哥布林在你面前列阵，他们的军阀立在最前方。他走上前，将一个包裹猛掷过来。包裹在半空中散开。十几个头颅滚了出来，就像孩子玩具袋里的弹子一样。军阀高举武器，发出一声怒吼。 随着绿皮向你队伍迫近，你迅速命令 %companyname% 组成阵型。 | 站在 %companyname% 面前的是一列列的绿皮：兽人，哥布林，还有它们的军阀，那是头即使在同族中也显得格外狰狞的巨兽。 那庞然大物举起武器咆哮，惊得飞鸟离巢，走兽钻洞。\n\n当绿皮开始冲锋，你向手下喊道：“列队！记住你们是谁——%companyname%战团！” | 你和 %companyname% 终于与军阀及其率领的兽人哥布林军团正面相对。 这本该是发表战前演说的时刻，可还没等你开口，那群野蛮的畜生就发起了冲锋！ | 人类与野兽的军队终于开始对峙。  %companyname% 面是兽人与哥布林组成的军队，一头野蛮的军阀站在它们最前方。你拔出剑，军阀也举起武器。 片刻间，双方都明白，今天注定有一方会倒在这，唯有真正的战士才能直面死亡。 | 兽人军阀率领它的军队开始冲锋！ 你告诉 %companyname%的弟兄们，这正是平日艰苦训练的目的。%SPEECH_ON%除非我们想死，否则我们不会倒在这里！%SPEECH_OFF%人们怒吼着拔出刀剑，列阵而立。 | 当一群哥布林和兽人如潮水般冲过战场，一个身材高大的军阀领头时，你告诉弟兄们别怕。%SPEECH_ON%今晚咱们要不醉不归，伙计们！%SPEECH_OFF%他们拔出武器怒吼，一声震耳欲聋的咆哮回荡在战场上，那些绿皮第一次露出了短暂的惊愕神色。 | %randombrother% 向你走来，指着一支正在向你冲来的兽人和哥布林混合的小型军队，一个军阀领头。%SPEECH_ON%虽然显而易见，但我还是得说，绿皮已经来了。%SPEECH_OFF%你点点头，对你的手下大喊。%SPEECH_ON%还有谁？%SPEECH_OFF%弟兄们拔出了武器。%SPEECH_ON%我们是 %companyname%!%SPEECH_OFF% | 你和 %randombrother% 看着一个兽人军阀带着一支兽人和哥布林混合的小型军队向你们冲来。佣兵们笑了。%SPEECH_ON%瞧，他们来了。%SPEECH_OFF%你点点头，对手下们说道。%SPEECH_ON%他们冲锋是因为恐惧，因为他们毫无立足之地。但我们不同，因为我们就站在这里！%SPEECH_OFF%你将 %companyname% 的旗帜插在地上。 弟兄们发出震耳欲聋的咆哮，旗帜在风中飘扬。 | 你看着由军阀带着冲锋的绿皮。 你拔出剑，对着那些人大喊。%SPEECH_ON%今晚睡得好的人，都是砍下了野蛮人脑袋的人！谁想睡这个好觉？%SPEECH_OFF%随着弟兄们拔出武器并大喊，金属碰撞声此起彼伏。%SPEECH_ON%我们是 %companyname%!%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onCombatWithWarlord(this.Contract.m.Destination, this.Contract.m.IsPlayerAttacking);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "FinalConfrontation3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_81.png[/img]{军阀就该待在它该待的地方-死在地面上。 你看着其他绿皮纷纷逃向山林。 你的雇主，%employer%，一定会对 %companyname% 今天所做的工作非常满意。 | %companyname% 在今天取得了胜利！ 兽人军阀死在了烂泥里，他的军队也四散逃向了山林。 这是你的雇主 %employer% 最满意的结果。 | 你的雇主，%employer%，花钱买到了最好的结果：兽人军阀死了，它的野蛮的军队也逃走了。 没有了领袖，这帮畜生迟早会各自溃散自生自灭。 该回去找那位贵族老爷领赏了。 | 你们彻底剿灭了绿皮部落，宰了他们的军阀，打得它们落荒而逃。 你的雇主, %employer%, 对 %companyname% 的表现一定会非常满意。 | 兽人军阀死了，而且没了头颅，这群绿皮也会像没了头的蛇，迟早要溃散灭亡。 你的雇主，%employer%，一定会对这一消息感到非常高兴。 | 兽人军阀死了。 虽然它曾给这片土地带来无数恐惧与混乱，但此刻它躺在那儿竟意外地安详。%randombrother% 走上前，笑着说道。%SPEECH_ON%块头是大，可终究会死。我觉得人们总忘记最后这点。%SPEECH_OFF%你点点头，吩咐兄弟们准备返回 %townname%  去找 %employer% 领赏。 | 军阀就倒在你脚下，这正是他该有的归宿。 %companyname% 已经从 %employer% 那里挣到了应得的报酬。现在只剩回贵族那里，把消息告诉他。 | %employer% 大概并不相信你。他恐怕根本没想到，你，一个佣兵团长，正站在兽人军阀的尸体旁。但今天你确实站在这里，因为 %companyname% 可不是好惹的。 该回去找那位贵族老爷领赏了。 | 兽人军阀死了，它的军队四散奔逃。 你环顾四周，对弟兄们大喊。%SPEECH_ON%伙计们，要是谁想找仇家报仇，该找谁帮忙？%SPEECH_OFF%他们举起拳头高呼。%SPEECH_ON%当然是 %companyname%!%SPEECH_OFF%你笑了，继续说道。%SPEECH_ON%要是老太太想消灭阁楼里的老鼠，该找谁？%SPEECH_OFF%这次弟兄们声音低了些。%SPEECH_ON%当然是 %companyname%?%SPEECH_OFF%你咧嘴大笑，继续说。%SPEECH_ON%要是娘娘腔被墙上的蜘蛛吓破胆，该找谁？%SPEECH_OFF%%randombrother% 啐了一口。%SPEECH_ON%我们还是赶紧回 %townname% 找 %employer% 领赏吧！%SPEECH_OFF% | 你看着那些绿皮像老鼠一样四散逃跑。%randombrother% 似乎想追上去，但你拦住了他。%SPEECH_ON%让他们跑吧。%SPEECH_OFF%雇佣兵摇了摇头。%SPEECH_ON%可他们会到处宣扬！他们知道我们的名号。%SPEECH_OFF%你咧嘴大笑，拍了拍他的肩膀。%SPEECH_ON%要的就是这个效果。快点，让我们赶紧回 %townname% 找 %employer% 领赏去。%SPEECH_OFF% | 你穿过死者的坟冢，来到被斩杀的兽人军阀面前。 苍蝇已经扑到他身上了。%randombrother% 站在你身旁，低头看着那头野兽。%SPEECH_ON%它其实也没多可怕。好吧，我承认是挺吓人的，属于会让我做噩梦那种。不过总的来说也就那样。%SPEECH_OFF%你微笑着拍拍他的肩膀。%SPEECH_ON%希望有一天，你能用这个故事吓唬你的孙子。%SPEECH_OFF% | 战场已归于平静。死者们安息在他们用一生奔赴的终点。 绿皮们正仓皇逃往深山。 而 %companyname% 则在胜利中欢呼。%employer% 对这样的结局定会极为满意。 | %companyname% 依然屹立在在绿皮蛮子的尸体上。考虑到为了它能死去，许多事物都必须先消亡。 这是一个充满奇怪规则的奇异世界，但事情本就是如此。\n\n%employer% 会非常满意，并且会给你丰厚的报酬－而克朗的世界，正是你最懂行的领域。 | 你和 %randombrother% 看着兽人军阀的尸体。 苍蝇已经聚集在它的舌头上，边交配边传播瘟疫。他看着你笑了。%SPEECH_ON%你觉得自己最后也会是这结局？让一堆虫子在你该死的脸上乱搞？%SPEECH_OFF%你耸耸肩答道。%SPEECH_ON%反正离裹着毯子被家人环绕的安详死法差远了。%SPEECH_OFF%你在佣兵的胸口上拍了一下。%SPEECH_ON%行了，别扯这些了。 我们该回 %employer% 那儿领赏了。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "{%companyname%取得了胜利！ | 胜利！}",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.setState("Return");
			}

		});
		this.m.Screens.push({
			ID = "Berserkers1",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_93.png[/img]正走着，%randombrother% 突然猛地直起身子，示意大家安静。你猫着腰弓着身子挪到他边上，他拨开一丛灌木指向前方。%SPEECH_ON%瞧那边。有麻烦，天大的麻烦。%SPEECH_OFF%透过枝叶缝隙，你看见一伙兽人狂战士的营地。他们生着一小堆火，上面架着一根旋转的烤肉叉，旁边堆着几个笼子，里面关着哀鸣的猎犬。你看见一个绿皮掀开笼门，拽着条连蹬带叫的狗拖向火堆，拎着它在火焰上燎烤。\n\n 那个佣兵转头看你。%SPEECH_ON%咱们该怎么办，头儿？%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们在打仗，每一场战斗都至关重要。拿起武器！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos(), true);
						p.CombatID = "Berserkers";
						p.Music = this.Const.Music.OrcsTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.BerserkersOnly, 80 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getID());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				},
				{
					Text = "这不是我们的战斗。",
					function getResult()
					{
						return "Berserkers2";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Berserkers2",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_93.png[/img]这本来就不是你该掺和的事，从来都不是。你让手下人绕开营地，尽量不发出声响，那群狂战士可不好惹，稍有不慎就是一场恶战。 狗群的嚎叫像在背后追赶，即便你们早已离开，那声音仍像阴魂不散地缠着几个弟兄。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "保持头脑清醒，伙计们。",
					function getResult()
					{
						this.Flags.set("IsBerserkers", false);
						this.Flags.set("IsBerserkersDone", false);
						return 0;
					}

				}
			],
			function start()
			{
				local brothers = this.World.getPlayerRoster().getAll();

				foreach( bro in brothers )
				{
					if (bro.getBackground().getID() == "background.houndmaster")
					{
						bro.worsenMood(1.0, "你没有阻止战犬被兽人吃掉");

						if (bro.getMoodState() < this.Const.MoodState.Neutral)
						{
							this.List.push({
								id = 10,
								icon = this.Const.MoodStateIcon[bro.getMoodState()],
								text = bro.getName() + this.Const.MoodStateEvent[bro.getMoodState()]
							});
						}
					}
				}
			}

		});
		this.m.Screens.push({
			ID = "Berserkers3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_32.png[/img]打完了，你环顾狂战士的营地。每个笼子里都关着瘦巴巴、缩在角落的狗。打开其中一个笼子时，那狗猛地窜出来，一路呜咽吠叫着冲过山丘，眨眼就没了踪影。其他野狗大多也纷纷效仿。但剩下两只没走。你在巡视营地时，它们就一直跟在你身后。 %randombrother% 说这是战犬。%SPEECH_ON%瞧这体格，块头大又凶悍。它们的主人肯定被兽人杀了，现在嘛，倒是信得过咱们了。欢迎加入啊，小家伙们。%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "做得好，伙计们。",
					function getResult()
					{
						this.Flags.set("IsBerserkers", false);
						this.Flags.set("IsBerserkersDone", false);
						return 0;
					}

				}
			],
			function start()
			{
				local item = this.new("scripts/items/accessory/wardog_item");
				this.World.Assets.getStash().add(item);
				this.List.push({
					id = 10,
					icon = "ui/items/" + item.getIcon(),
					text = "你获得了" + item.getName()
				});
				item = this.new("scripts/items/accessory/wardog_item");
				this.World.Assets.getStash().add(item);
				this.List.push({
					id = 10,
					icon = "ui/items/" + item.getIcon(),
					text = "你获得了" + item.getName()
				});
			}

		});
		this.m.Screens.push({
			ID = "Berserkers4",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_32.png[/img]最后一个狂战士也倒下后，你们开始搜刮他们的营地。篝火堆旁散落着烧焦的狗骨头，肉被啃得精光，一堆头颅歪歪扭扭地叠着，活像某种病态的图腾。%randombrother% 挨个打开笼子， 所有猎犬刚见缝隙就窜逃而出。有个佣兵眼疾手快逮住一只，那畜生却哀嚎着瘫软下去，竟活活吓死了。 营地里再找不到什么值钱玩意，除了满心失望，就只剩成堆的兽人粪便。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们在这里还是做得很好。",
					function getResult()
					{
						this.Flags.set("IsBerserkers", false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你看见 %employer% 正和他的将领们谈话。他转身朝你微笑，张开双臂迎上来。%SPEECH_ON%干得好啊，佣兵。 说实话，我之前还真没指望你能成。 宰兽人这活儿，可真有意思。%SPEECH_OFF%你觉得这事儿压根没什么意思，但还是点了点头。 贵族取来装着 %reward_completion% 克朗的钱袋亲自递到你手中。%SPEECH_ON%这活儿干得漂亮。%SPEECH_OFF% | 你在卧室找到 %employer% ，他正和几个女人缠绵。 守卫在门口无奈地耸耸肩，脸上写着，‘是你说要放他进来的’。 贵族朝你挥挥手。%SPEECH_ON%我这儿正忙，不过听说你把那档子...呃，棘手事儿都搞定了。%SPEECH_OFF%他打了个响指，有个女人从被褥中滑出来，袅袅婷婷地踏过冰冷的石地板取来钱袋递给你。%employer% 继续说道。%SPEECH_ON%是 %reward_completion% 克朗对吧? 解决兽人军阀可不是轻松差事，这报酬够意思了。%SPEECH_OFF%递钱时那女人深深望进你眼睛。%SPEECH_ON%你杀了兽人军阀？真勇敢...%SPEECH_OFF%你点头时，这位窈窕的女士踮着脚尖旋转身子。贵族再次打响指，她便回到了床上。%SPEECH_ON%当心点儿啊，佣兵。%SPEECH_OFF% | 一名警卫将你带到菜园见 %employer%。他正修剪蔬菜，仆人提着篮子跟在身后。%SPEECH_ON%看你全须全尾地站着，我猜你成功解决了那个兽人军阀。%SPEECH_OFF%你回应道。%SPEECH_ON%确实不轻松。%SPEECH_OFF%贵族盯着泥土点点头，继续剪下一串番茄。%SPEECH_ON%那边守卫会给你报酬，我们约定的 %reward_completion% 克朗。 眼下我实在抽不开身，但你要知道我和全镇百姓都欠你个大人情。%SPEECH_OFF%不过他的‘大人情’看来就值 %reward_completion% 克朗。 | %employer% 将你迎进房间。%SPEECH_ON%这些天我的小鸟们叫个不停，说有个佣兵宰了兽人军阀，并把他的军队打得七零八落。 我心想，嘿，我想我认识那个家伙。%SPEECH_OFF%贵族咧嘴一笑，递来装着 %reward_completion% 克朗的钱袋。%SPEECH_ON%干得漂亮，佣兵。%SPEECH_OFF% | %employer% 直接拿着 %reward_completion% 克朗的钱袋向你打招呼。%SPEECH_ON%我的探子早把该报的都报了。你确实值得信赖，佣兵。%SPEECH_OFF% | 刚迈进 %employer% 的房间，就见他正侧耳听着书记员的耳语。 见到你，贵族猛地直起身。%SPEECH_ON%说曹操曹操到。现在全城都在谈论你，佣兵。 宰了兽人军阀还击溃它的军队？ 好吧，这值得我们约定好的 %reward_completion% 克朗。%SPEECH_OFF% | %employer% 正聚精会神地盯着地图。%SPEECH_ON%托你的福，我得重画部分区域了－但这是表扬。 除掉那个兽人军阀，我们才能在这片被它蹂躏过的焦土上重建家园。%SPEECH_OFF%你点点头，但委婉地提了报酬。贵族笑了。%SPEECH_ON% %reward_completion% 克朗，对吧？不过佣兵啊，你也该花点时间享受赞誉。钱又不会长腿跑掉，但现在的自豪感将来可是会褪色的。%SPEECH_OFF%你内心并不认同。这些钱很快就会融进蜂蜜酒里。 | %employer% 正在房间里踱步，将军们则几乎带着恭敬的沉默站在一旁。你问他出了什么事，他猛地坐直了身子。%SPEECH_ON%以旧神的名义起誓，我真没想到你能活下来。%SPEECH_OFF%你无视这毫无底气的夸奖，向贵族汇报了战果。他连连点头，然后取出 %reward_completion% 克朗的钱袋递过来。%SPEECH_ON%这活儿干得漂亮，佣兵。真他娘的漂亮。%SPEECH_OFF% | 你看到 %employer% 正盯着仆人劈柴。注意到你的身影，这位贵族猛地转过身来。%SPEECH_ON%啊！今晚的主角！我已经听人说了你做了很多事情。 我们正准备举办一场庆功宴－这些柴火就是晚上做饭和狂欢要用的。 本来该邀请你的，不过这是贵族的聚会，我想你懂的。%SPEECH_OFF%你耸耸肩并回应道。%SPEECH_ON%要是能把谈好的 %reward_completion% 克朗给我，我肯定能更理解的。%SPEECH_OFF%%employer% 哈哈大笑，对着守卫打了个响指，对方立刻把你的报酬送了过来。 | %employer% 正在和另一支佣兵团的队长交谈。那位队长看着弱不禁风，估计刚入行不久。贵族一见到你，马上打发走对方，热情地迎上来。%SPEECH_ON%老天，见到你可太好了，佣兵！这里的情况差点就变得棘手起来。%SPEECH_OFF%你随口说刚才那位队长看着连普通任务都够呛，更别说追杀兽人军阀了。 贵族递给你一个 %reward_completion% 克朗的钱袋，接话道。%SPEECH_ON%行啦，总之你今天立了大功。我们总算能重建那个天杀的兽人毁掉的东西，这才是重点。%SPEECH_OFF%虽然你认为手中的克朗才是最实际的，不过你决定不再纠结这个话题。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "杀死了一个著名的兽人军阀");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isGreenskinInvasion())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function onPrepareVariables( _vars )
	{
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isGreenskinInvasion())
		{
			return false;
		}

		return true;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

