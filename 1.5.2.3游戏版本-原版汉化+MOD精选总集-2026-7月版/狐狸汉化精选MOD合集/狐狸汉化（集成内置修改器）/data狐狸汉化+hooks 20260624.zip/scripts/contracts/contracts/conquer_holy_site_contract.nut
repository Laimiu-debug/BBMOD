this.conquer_holy_site_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Target = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.conquer_holy_site";
		this.m.Name = "征服圣地";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();
		local target;
		local targetIndex = 0;
		local closestDist = 9000;
		local myTile = this.m.Home.getTile();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && !this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					local d = myTile.getDistanceTo(v.getTile());

					if (d < closestDist)
					{
						target = v;
						targetIndex = i;
						closestDist = d;
					}
				}
			}
		}

		this.m.Destination = this.WeakTableRef(target);
		this.m.Destination.setVisited(true);
		local b = -1;

		do
		{
			local r = this.Math.rand(0, this.Const.PlayerBanners.len() - 1);

			if (this.World.Assets.getBanner() != this.Const.PlayerBanners[r])
			{
				b = this.Const.PlayerBanners[r];
				break;
			}
		}
		while (b < 0);

		this.m.Payment.Pool = 1350 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Flags.set("DestinationIndex", targetIndex);
		this.m.Flags.set("MercenaryPay", this.beautifyNumber(this.m.Payment.Pool * 0.5));
		this.m.Flags.set("Mercenary", this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
		this.m.Flags.set("MercenaryCompany", this.Const.Strings.MercenaryCompanyNames[this.Math.rand(0, this.Const.Strings.MercenaryCompanyNames.len() - 1)]);
		this.m.Flags.set("MercenaryBanner", b);
		this.m.Flags.set("Commander", this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
		this.m.Flags.set("EnemyID", target.getFaction());
		this.m.Flags.set("MapSeed", this.Time.getRealTime());
		this.m.Flags.set("OppositionSeed", this.Time.getRealTime());
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"从南方异教徒手中解放%holysite%",
					"摧毁或击溃附近的敌方部队"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 20)
				{
					this.Flags.set("IsAlliedArmy", true);
				}
				else if (r <= 40)
				{
					this.Flags.set("IsSallyForth", true);
				}
				else if (r <= 60)
				{
					this.Flags.set("IsMercenaries", true);
				}
				else if (r <= 80)
				{
					this.Flags.set("IsCounterAttack", true);
				}

				if (this.Contract.getDifficultyMult() >= 1.15)
				{
					this.Contract.spawnEnemy();
				}
				else if (this.Contract.getDifficultyMult() <= 0.85)
				{
					local entities = this.World.getAllEntitiesAtPos(this.Contract.m.Destination.getPos(), 1.0);

					foreach( e in entities )
					{
						if (e.isParty())
						{
							e.getController().clearOrders();
						}
					}
				}

				local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);

				foreach( c in cityStates )
				{
					c.addPlayerRelation(-99.0, "在战争选择了阵营");
				}

				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnEnterCallback(this.onDestinationAttacked.bindenv(this));
				}

				if (this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onCounterAttack.bindenv(this));
				}
			}

			function update()
			{
				if (this.Flags.get("IsFailure"))
				{
					this.Contract.setScreen("Failure");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsVictory"))
				{
					if (this.Flags.get("IsCounterAttack"))
					{
						this.Contract.setScreen("CounterAttack1");
						this.World.Contracts.showActiveContract();
					}
					else if (!this.Contract.isEnemyPartyNear(this.Contract.m.Destination, 400.0))
					{
						this.Contract.setScreen("Victory");
						this.World.Contracts.showActiveContract();
					}
				}
			}

			function onCounterAttack( _dest, _isPlayerInitiated )
			{
				if (this.Flags.get("IsCounterAttackDefend") && this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
					p.LocationTemplate.Template[0] = "tactical.southern_ruins";
					p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
					p.LocationTemplate.ShiftX = -4;
					p.CombatID = "ConquerHolySiteCounterAttack";
					p.MapSeed = this.Flags.getAsInt("MapSeed");
					p.Music = this.Const.Music.OrientalCityStateTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "ConquerHolySiteCounterAttack";
					p.Music = this.Const.Music.OrientalCityStateTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
			}

			function onDestinationAttacked( _dest )
			{
				if (this.Flags.getAsInt("OppositionSeed") != 0)
				{
					this.Math.seedRandom(this.Flags.getAsInt("OppositionSeed"));
				}

				if (this.Flags.get("IsVictory") || this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					return;
				}
				else if (this.Flags.get("IsAlliedArmy"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("AlliedArmy");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
						p.CombatID = "ConquerHolySite";
						p.MapSeed = this.Flags.getAsInt("MapSeed");
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.OrientalCityStateTracks;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 200 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner(),
							this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, true, true, true);
					}
				}
				else if (this.Flags.get("IsSallyForth"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("SallyForth");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "ConquerHolySite";
						p.Music = this.Const.Music.OrientalCityStateTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
				}
				else if (this.Flags.get("IsMercenaries"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("Mercenaries1");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
						p.CombatID = "ConquerHolySite";
						p.MapSeed = this.Flags.getAsInt("MapSeed");
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.OrientalCityStateTracks;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, (130 + (this.Flags.get("MercenariesAsAllies") ? 30 : 0)) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];

						if (this.Flags.get("MercenariesAsAllies"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
							p.AllyBanners.push(this.Flags.get("MercenaryBanner"));
						}
						else
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
							p.EnemyBanners.push(this.Flags.get("MercenaryBanner"));
						}

						this.World.Contracts.startScriptedCombat(p, true, true, true);
					}
				}
				else if (this.Flags.get("IsCounterAttack") && this.Flags.get("IsVictory"))
				{
					if (this.Flags.get("IsCounterAttackDefend"))
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
						p.LocationTemplate.ShiftX = -2;
						p.CombatID = "ConquerHolySiteCounterAttack";
						p.MapSeed = this.Flags.getAsInt("MapSeed");
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.OrientalCityStateTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "ConquerHolySiteCounterAttack";
						p.Music = this.Const.Music.OrientalCityStateTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
				}
				else if (!this.Flags.get("IsAttackDialogTriggered"))
				{
					this.Flags.set("IsAttackDialogTriggered", true);
					this.Contract.setScreen("Attacking");
					this.World.Contracts.showActiveContract();
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
					p.CombatID = "ConquerHolySite";
					p.MapSeed = this.Flags.getAsInt("MapSeed");
					p.LocationTemplate.Template[0] = "tactical.southern_ruins";
					p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
					p.Music = this.Const.Music.OrientalCityStateTracks;
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, (this.Flags.get("IsCounterAttack") ? 110 : 130) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.AllyBanners = [
						this.World.Assets.getBanner()
					];
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];
					this.World.Contracts.startScriptedCombat(p, true, true, true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "ConquerHolySiteCounterAttack")
				{
					this.Flags.set("IsCounterAttack", false);
					this.Flags.set("IsVictory", true);
				}
				else if (_combatID == "ConquerHolySite")
				{
					this.Flags.set("IsVictory", true);
					this.Flags.set("OppositionSeed", this.Time.getRealTime());
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "ConquerHolySite" || _combatID == "ConquerHolySiteCounterAttack")
				{
					this.Flags.set("IsFailure", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
					this.Contract.m.Destination.setOnEnterCallback(null);
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%employer%被一群神职人员团团围住，个个似乎都比前一个更通晓旧神的旨意与心愿。但谈话中有一条清晰的思路贯穿始终：南方人已占领了 %holysite% ，必须要夺回来。领主突然指向你。%SPEECH_ON% %companyname% 必将努力结束这场噩梦！%SPEECH_OFF%%employer% 一把推开那些神父，走近你，压低了声音。%SPEECH_ON%当然，只要价钱合适。我手下没什么多余的人手，但圣地对人民和我本人来说都至关重要。你必须去那里，驱逐那些异教徒，好让旧神不会因我们的失败而彻底抛弃我们。%SPEECH_OFF% | %employer% 房间的门猛地被推开，一列神职人员鱼贯而出。其中有两人停下脚步，狠狠瞪了你一眼，显然没一个对你出现在这里感到高兴。%employer% 朝你招手，示意你进来。%SPEECH_ON%别在意他们那副可怜又指责的眼神，佣兵。%holysite% 已被南方佬占领，这事像根硬木桩子堵得他们心里发慌。我并不是责怪他们，不过我也不能怪他们，就连我这种满腹牢骚的老顽固，心里对那片圣地也存着几分柔软。这些神父只盼着 %holysite% 能重归王室的荣光之下，但可惜我的军队已经被派去其他地方了。不过只要给足了报酬，你就能把这活儿干得妥妥当当，对吧？%SPEECH_OFF% | %SPEECH_ON%旧神无疑正在注视着这个房间。%SPEECH_OFF% %employer% 晃动着酒杯，酒浆沿着杯沿荡漾，留下紫莹莹的水痕。%SPEECH_ON% 南方佬已经占领了 %holysite%，毫无疑问，他们彻底亵渎了这个圣地。我宁愿让一条狗在圣地随便找个地方撒尿，也不愿看到那些南方杂种站在他们所谓神圣崇高的神面前。那到底是什么？“镀金者”吗？简直是一派胡言！去那儿把他们全都杀光，夺回 %holysite%，让它重归应有的神圣地位。%SPEECH_OFF% | %employer% 被发现独自待在花园里，他几乎带着一种咄咄逼人的孤独。围栏外的男男女女似乎连朝他瞥一眼都感到畏惧。但这与你无关，你径直走了进去。他正盯着一个被踢翻的蚁丘，蚂蚁们慌乱地四处奔走，忙着重建家园。这位贵族叹了口气。%SPEECH_ON%我有时会想，旧神是否也以这样的目光注视着我们。%SPEECH_OFF%你随口说道，自己其实只有被蚂蚁咬了才会注意到它们。贵族站起身来。%SPEECH_ON%你应该知道，它们对花园是有益的，佣兵。如果它们咬人，我想那也并非出于恶意，只是在做它们本就懂得去做的事罢了，正如它们知道，一旦我踢翻它们的家，就得立刻重建。同样，当我得知那些南方的蟑螂竟胆敢短暂地玷污 %holysite% 时，我便遵循旧神的意志，知道必须将他们连根拔起、彻底铲除。%SPEECH_OFF%你本以为他会把你比作一只蚂蚁，但他却只是递给你一大袋克朗，让你前往圣地，驱逐并消灭那里的占领者。%SPEECH_ON%你或许会像花园里的一只黄蜂。%SPEECH_OFF%贵族说道。你面无表情地点了点头。 | %SPEECH_ON%我对制陶可没兴趣，佣兵。所以当我形容那些南方杂种比一个夜幕下干尽龌龊勾当的皮条客还要下贱时，你就该明白，光是他们胆敢踏足圣地这件事，就已逼得我不得不走上吟游诗人的路了。%SPEECH_OFF%你心想，或许该提醒 %employer% 他想说的其实是“诗歌”（poetry），不是“陶器”（pottery），但转念一想，某种程度上，他此刻确实在“摔碎陶罐”。而且毫无疑问，他眼中的你，不过是个脚踩泥胎、不堪一击的凡夫俗子罢了。%SPEECH_ON%那些野蛮人已经占领了 %holysite%，有传言说他们甚至屠尽了所有“非信徒”。我的军队分散各处，战场遍地开花。你有空。没错，你是个贪婪的混蛋，这点我清楚。可我也知道，%companyname% 正是我们夺回圣地、把那群畜生赶出去所需要的精锐力量。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我相信你会为这样的袭击付出丰厚的报酬。 | 我们已经准备好尽自己的一份力了。 | 我们再详细谈谈报酬吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不值得。 | 这太远了。 | 我们有更要紧的事要处理。 | 别的地方更需要我们。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Attacking",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{南方人已经在 %holysite% 及其周边驻扎下来。他们利用充裕的时间构筑了坚固的防御工事，但这一切对于%companyname%来说并不是问题。你拔出剑，准备发动进攻。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "AlliedArmy",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{%holysite% 已经被扛着 %employerfaction% 旗帜的部队包围了。当你靠近时，一个男人走到一半处迎接你。他抬起手，随即又按在腰带上。%SPEECH_ON%我听说他们会派个佣兵过来，看来就是你了。是 %companyname% 对吧？我是 %employer% 的中尉，%commander%。我将和你一起清缴这些沙漠老鼠。我担心，正如你肯定担心的那样，如果我们不尽快完成这项任务，旧神将惩罚我们所有人。%SPEECH_OFF%中尉啐了一口，粗糙的手掌抹过布满胡茬的脸。%SPEECH_ON%好吧。就让旧神如实地看清我们的真面目吧，我们将以最正义的方式屠杀这些沙漠骗子。%SPEECH_OFF% | %holysite%已经被扛着 %employerfaction% 旗帜的部队包围了。领队大步上前，高声说道。%SPEECH_ON%我是 %employer% 军队的中尉 %commander%，你们是 %companyname% 吧？我来是为了与你一同前往%holysite%，或者更准确地说，你们将加入我，把那些南方渣滓从每一寸土地上连根拔起。旧神注视着我们所有人，就连你们这些佣兵也不例外，今天如果失败，我们一定会坠入万劫不复的地狱。%SPEECH_OFF%行吧。你只想确认一点，无论有没有帮手，%employer% 都得如数支付承诺给你的全部报酬。 | %holysite% 已经被扛着 %employerfaction% 旗帜的人包围了。这看起来是一群神职者和士兵的集会，带队的中尉挥舞着剑，随即迅速将其直指 %holysite%。%SPEECH_ON%那些南方舔屁股的要么自己滚，要么就让我们用钢铁之力，凭旧神之恩典，送他们下地狱。在这件事上，没有其他选择。来吧，佣兵们！%SPEECH_OFF%看来这次行动 %companyname% 会有些帮手，不过你心里清楚得很，承诺的全部赏金，一分都不能少。}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "SallyForth",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{ %holysite% 的守军获得了增援! 但值得庆幸的是，还有一线希望: 新增的援军使得他们信心大增，竟主动放弃了圣地的天然防御工事，转而向你在开阔地带发起进攻。 | 你惊讶地看到守军离开 %holysite% 穿越旷野朝你而来。一份快速侦察报告指出，他们在过去几天内得到了援军，仅凭人数优势便壮起了胆子。 一方面，他们密集的阵列确实令人略感不安；但另一方面，在平坦开阔的地形上与之交战，对你而言要容易得多。不过据你诚实判断，他们最大的错误，就是竟敢正面迎战 %companyname% 。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "那么，就来一场野战吧。",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{当 %holysite% 逐渐映入眼帘时，一名与你相貌惊人相似的男子迎面走来。他身边有一名财务官和几个佣兵。%SPEECH_ON%晚上好啊，队长。我是 %mercenary%，来自 %mercenarycompany% ，我和你一样，也是为金币而来这片土地的。我猜那位肥头大耳的贵族肯定给你和你的人签了份丰厚得响当当的合约。那这样如何，你付我 %pay% 克朗，我就帮助你完成这项任务？当然，除非你想让我把服务提供给另一方。%SPEECH_OFF% | 一群男子朝你走来，其中一人无论是走路的姿态还是体格，都莫名让你想起自己。他称自己为 %mercenary%, 是 %mercenarycompany% 的队长。 %SPEECH_ON% 我原以为 %employer% 可能会派他的职业军队来处理圣地易主的事儿。说实话，队长，当初正是我帮那些沙漠疯子占领了这座显赫的纪念碑。不过，只要给我 %pay% 克朗作为报酬，我愿意帮助你们把它抢回来。同为佣兵，我相信你能看出，这对大家都是笔划算的买卖。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [],
			function start()
			{
				if (this.World.Assets.getMoney() > this.Flags.get("MercenaryPay"))
				{
					this.Options.push({
						Text = "你被雇佣了!",
						function getResult()
						{
							return "Mercenaries2";
						}

					});
				}
				else
				{
					this.Options.push({
						Text = "恐怕我们没有那么多的钱。",
						function getResult()
						{
							return "Mercenaries3";
						}

					});
				}

				this.Options.push({
					Text = "自己找工作去，%mercenary%。我们不需要帮助。",
					function getResult()
					{
						return "Mercenaries3";
					}

				});
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{那名队长咧嘴一笑，重重拍了拍你的肩膀。%SPEECH_ON%啊哈，就是这样！就是这股子高贵的佣兵精神！嗯，作为 %companyname% 的指挥官，让我们暂时一起前往战场，也暂时一同战斗吧！%SPEECH_OFF% | 协议达成后，那支佣兵团的队长便紧挨着你站了过来，几乎近得有些不舒服，而且他呼出的气息显然不太好闻。%SPEECH_ON%你知道吗，像我们这样的人，伙计们，朋友们，我们是好朋友，对吧？像我们这样的好兄弟，就得互相照应。这场仗嘛，我们就一起战斗。%SPEECH_OFF%他点点头，又给了你肩膀一拳。 %SPEECH_ON%打完这一仗嘛，希望以后还能再做朋友，懂我意思吧? %SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Flags.set("MercenariesAsAllies", true);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.World.Assets.addMoney(-this.Flags.get("MercenaryPay"));
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你花了 [color=" + this.Const.UI.Color.NegativeEventValue + "]" + this.Flags.get("MercenaryPay") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{%SPEECH_START% 真遗憾啊。%SPEECH_OFF%%mercenary% 说着，迅速退回了 %mercenarycompany% 的队列中。他一边后退，一边直接融入了守卫 %holysite% 的南方士兵阵线。他双臂张开，像在逆流中游泳般挥动着。%SPEECH_ON%真是他妈的遗憾！好吧，%companyname%的队长，接下来我们看看哪边雇到了更好的佣兵？%SPEECH_OFF%那名佣兵拔出了武器，%holysite% 后面的南方士兵也纷纷亮出兵刃。你自然也抽出了自己的武器。战斗时刻到了。 | %SPEECH_ON%好吧，好吧，我明白了。不过我本来就没抱太大指望。毕竟，我也只是个卖命的佣兵。而现在......%SPEECH_OFF%他一边说着，一边缓缓退向自己的队伍，而他的队伍则与保卫 %holysite% 的北方士兵汇合。%SPEECH_ON%眼下，南方人出价更高。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们将在战场上再见。开始进攻！",
					function getResult()
					{
						this.Flags.set("MercenariesAsAllies", false);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_164.png[/img]{战斗虽然结束了，但远处一道金色闪光却吸引了你的目光。你凝视着地平线，一支南方军队赫然出现，他们耀眼的装束显然是故意要引人注目。这是反攻！ | 当你将剑归鞘时， %randombrother% 突然高声喊道。他指向地平线，一列南方士兵正朝这边逼近，盔甲熠熠生辉，步态自信。步伐趾高气扬。这些反攻者就是要让你看见他们，而且毫无疑问，他们志在必得...}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们将坚守圣地进行防御！",
					function getResult()
					{
						return "CounterAttack2";
					}

				},
				{
					Text = "我们去开阔地迎战他们！",
					function getResult()
					{
						return "CounterAttack3";
					}

				},
				{
					Text = "我们撑不住另一场战斗了，撤退！",
					function getResult()
					{
						return "Failure";
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_164.png[/img]{南方人的进攻一直持续着。%SPEECH_ON%蟑螂永远都不会消失(俗语, 指问题不会消失)。%SPEECH_OFF%你看到%randombrother%摇了摇头。他抬起靴子，用脚趾弹掉一只虫子。他把脚放下，向着攻击者点点头。%SPEECH_ON%别担心，队长，我们会让%holysite%的防御处于最佳状态来对付那些野蛮的混蛋们。%SPEECH_OFF% | 你命令士兵们保卫这个地点。%SPEECH_ON%在%holysite%作战，真是一个令人兴奋的时刻。%SPEECH_OFF%%randombrother%说道。你点了点头，告诉他你希望这段经历总有一天会成为他的回忆。他笑了笑，问怎么可能会忘记。另一个雇佣兵插话说有一种可以让他忘记的方法，但是你打断了他，并告诉士兵要专注于手头任务。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "集合！",
					function getResult()
					{
						this.Flags.set("IsCounterAttackDefend", true);
						this.Flags.set("IsVictory", false);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onCounterAttack.bindenv(this.Contract.getActiveState()));
						this.Contract.m.Target = this.WeakTableRef(party);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_164.png[/img]{防御看起来不如从前那般坚固了。你命令 %companyname% 列阵出战，任何残破的工事都不会阻碍你的指挥。南方中尉向你问好。%SPEECH_ON%你用血亵渎了 %holysite%，为此，镀金者亲自把你们引到这片战场上，让你们像个真正的男人一样战死。你还有何话可说？%SPEECH_OFF%你拔出了剑。%SPEECH_ON%流的又不是我的血。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "冲锋！",
					function getResult()
					{
						this.Flags.set("IsCounterAttackDefend", false);
						this.Flags.set("IsVictory", false);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onCounterAttack.bindenv(this.Contract.getActiveState()));
						this.Contract.m.Target = this.WeakTableRef(party);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{当你收起武器，命令部队从死者身上搜刮能带走的一切时，一种奇怪的感觉油然而生，这并非 %holysite% 第一次见证如此血腥的屠杀。不过也好，如果注定有人要在祖先的足迹上倒下，你很高兴那个人不是自己，就在你动身前往 %employer% 之际，一队北方士兵恰好赶来接管这片圣地。 | 敌人已经被击溃，%holysite% 也已经收复。一群信徒缓缓涌入，他们从尸体旁经过，只为在最神圣的地方俯首叩拜，没有人向你们道谢。不过这也不重要，那是 %employer% 该做的事。在你离开的路上，一队北方士兵与你擦肩而过，每个战士都对你投以轻蔑和嘲弄的目光。 | 战斗结束后，一小群信徒开始聚集在 %holysite% 的角落里。你甚至不知道这些人是从哪里冒出来的。他们不理会你们，你们也懒得理他们。现在唯一重要的是。 %employer% 那里正有一大笔克朗等着你凯旋。北方士兵一出现，你便立刻动身离开了。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.m.Destination.setFaction(this.Contract.getFaction());
						this.Contract.m.Destination.setBanner(this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner());
						this.updateAchievement("NewManagement", 1, 1);
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.spawnAlly();
			}

		});
		this.m.Screens.push({
			ID = "Failure",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{%holysite% 已经落入南方人手中。一名佣兵摇了摇头。%SPEECH_ON%唉，我猜他们现在不是在那儿寻欢作乐，就是在那儿拉屎撒尿。%SPEECH_OFF%确实如此。既然圣地已经丢失，除非你有兴趣去看另一种‘神圣奇观’，否则再也没理由回 %employer% 那里了。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "灾难！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "未能征服一个圣地");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Success",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%townname% 的修道院里挤满了比你见过的还要多的农民。%employer%站在台阶外，他用手拍了拍你的肩膀向你致意。%SPEECH_ON%欢迎回来，佣兵。你或许是个只认赏金的小混蛋，但你身上带着旧神的怒火。%holysite% 现在回到了它真正的主人手中。%SPEECH_OFF%贵族打了个响指，几个身材圆润的修士摇摇摆摆地走过来，扛着装满 %reward% 克朗的箱子。%employer% 转身走上台阶。%SPEECH_ON%我会在众人面前为你美言几句，你叫什么来着？啊，我明白了，你肯定希望功劳归于整个佣兵团。那我就感谢整个 %companyname% 好了。%SPEECH_OFF% | %employer% 正低头研究他的作战地图。%SPEECH_ON%这有点好笑，我派自己的人去，迎接我的总是失败，但当旧神降下怒火时，我雇了个佣兵，却换来了胜利。既然 %holysite% 再次回到我们的掌控中，希望能激励我的手下像 %companyname% 那样战斗。为了 %reward% 克朗，你把那些南方杂碎赶回了他们沙漠的地狱，也鼓舞了整场战事。我差点要说亏待你了，雇佣兵。只是差点而已。%SPEECH_OFF% | %SPEECH_ON%斥候一回来，第一件事就是跑去修道院。所以我才知道你成功了。我也罚了他们每人一天的地牢禁闭，谁让他们擅离职守来找我。%SPEECH_OFF% %employer% 坐在一个看起来很奇怪的软垫上，也许是他在与南方人的战争中不知从哪弄来的。他晃动着高脚杯里的酒液。%SPEECH_ON%你的%reward% 克朗已经在外面备好了。我得问一句，你在下面的时候，有没有听到什么？也许是关于旧神的低语？又或者是关于那个被称为‘镀金者’的家伙的传言？%SPEECH_OFF%你摇了摇头。贵族耸了耸肩。%SPEECH_ON%真遗憾。人们不禁要好奇，究竟怎样才能让神明再次降临呢。%SPEECH_OFF%你告诉他，如果能把那 %reward% 克朗花在正途上，或许是个不错的开始。这位贵族得意地微笑着，答应了你的请求。 | 你发现 %employer% 身边跟着一位年轻的、皮肤黝黑的女子，明显来自南方。他上下打量着她。%SPEECH_ON%旧神把这个送给了我，就像我相信他们把你送到我身边一样。%SPEECH_OFF%他一时语塞，清了清嗓子。%SPEECH_ON%我是说，当然，是以另一种方式。你在%holysite%的胜利鼓舞了士气，驱散了笼罩在我们头顶的失败阴霾。修士们重新聚拢了信众，只要我们足够勤勉，就能向旧神证明我们的价值。%SPEECH_OFF%他推开那女子想要站起来，但软垫太深了，可能也太舒服了。他最终还是坐着没动。%SPEECH_ON%你的%reward% 克朗克朗就在大厅里。去叫个仆人来，把她带到修道院去做祷告吧。%SPEECH_OFF% | 你在镇上的一个神庙里找到了 %employer%，他正站在一尊旧神雕像的下方。%SPEECH_ON%我已经听说了你的功绩。全镇都欢欣鼓舞，整个地区都洋溢着喜悦。不过他们当然不会提起你，他们会把功劳全算在我头上。%SPEECH_OFF%这位贵族看起来对自己相当满意。他转过身，拍了拍你的肩膀。%SPEECH_ON%希望那些南方杂种没给你添太多麻烦。我的副官会把你的 %reward% 克朗送来。对了，你觉得%holysite%值得去看看吗？我还从没去过，其实，也不太想去。无论在哪里，我都会被神明祝福。%SPEECH_OFF%你抿了抿嘴，看着贵族转身离去。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "征服了一个圣地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isHolyWar())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function spawnAlly()
	{
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y + 4; y <= o.Y + 6; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.getFaction());
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			if (s.isMilitary())
			{
				candidates.push(s);
			}
		}

		local party = f.spawnEntity(tiles[0].Tile, candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly() + " Company", true, this.Const.World.Spawn.Noble, 170 * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("效忠于地方领主的职业士兵。");
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 5);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r == 1)
		{
			party.addToInventory("supplies/bread_item");
		}
		else if (r == 2)
		{
			party.addToInventory("supplies/roots_and_berries_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dried_fruits_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/ground_grains_item");
		}

		local c = party.getController();
		local occupy = this.new("scripts/ai/world/orders/occupy_order");
		occupy.setTarget(this.m.Destination);
		occupy.setTime(10.0);
		c.addOrder(occupy);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(240.0);
		c.addOrder(guard);
		return party;
	}

	function spawnEnemy()
	{
		local cityState = this.World.FactionManager.getFaction(this.getFaction());
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y - 4; y <= o.Y - 3; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.m.Flags.get("EnemyID"));
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			candidates.push(s);
		}

		local party = f.spawnEntity(tiles[0].Tile, "Regiment of " + candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly(), true, this.Const.World.Spawn.Southern, this.Math.rand(100, 140) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("忠于城邦的应征士兵。");
		party.setAttackableByAI(false);
		party.setAlwaysAttackPlayer(true);
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 5);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r <= 2)
		{
			party.addToInventory("supplies/rice_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dates_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/dried_lamb_item");
		}

		local c = party.getController();
		local attack = this.new("scripts/ai/world/orders/attack_zone_order");
		attack.setTargetTile(this.m.Destination.getTile());
		c.addOrder(attack);
		local move = this.new("scripts/ai/world/orders/move_order");
		move.setDestination(this.m.Destination.getTile());
		c.addOrder(move);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(999.0);
		c.addOrder(guard);
		return party;
	}

	function onPrepareVariables( _vars )
	{
		local illustrations = [
			"event_152",
			"event_154",
			"event_151"
		];
		_vars.push([
			"illustration",
			illustrations[this.m.Flags.get("DestinationIndex")]
		]);
		_vars.push([
			"holysite",
			this.m.Flags.get("DestinationName")
		]);
		_vars.push([
			"pay",
			this.m.Flags.get("MercenaryPay")
		]);
		_vars.push([
			"employerfaction",
			this.World.FactionManager.getFaction(this.m.Faction).getName()
		]);
		_vars.push([
			"mercenary",
			this.m.Flags.get("Mercenary")
		]);
		_vars.push([
			"mercenarycompany",
			this.m.Flags.get("MercenaryCompany")
		]);
		_vars.push([
			"commander",
			this.m.Flags.get("Commander")
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnEnterCallback(null);
			}

			if (this.m.Target != null && !this.m.Target.isNull())
			{
				this.m.Target.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isHolyWar())
		{
			return false;
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();

		foreach( v in locations )
		{
			foreach( s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && !this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					return true;
				}
			}
		}

		return false;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Target != null && !this.m.Target.isNull())
		{
			_out.writeU32(this.m.Target.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local target = _in.readU32();

		if (target != 0)
		{
			this.m.Target = this.WeakTableRef(this.World.getEntityByID(target));
		}

		this.contract.onDeserialize(_in);
	}

});

