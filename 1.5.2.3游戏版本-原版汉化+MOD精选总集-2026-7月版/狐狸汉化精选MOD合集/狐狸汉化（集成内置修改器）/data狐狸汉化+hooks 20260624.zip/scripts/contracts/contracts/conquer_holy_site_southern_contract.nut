this.conquer_holy_site_southern_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Target = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.conquer_holy_site_southern";
		this.m.Name = "征服圣地";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();
		local target;
		local targetIndex = 0;
		local closestDist = 9000;
		local myTile = this.m.Home.getTile();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && !this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					local d = myTile.getDistanceTo(v.getTile());

					if (d < closestDist)
					{
						target = v;
						targetIndex = i;
						closestDist = d;
					}
				}
			}
		}

		this.m.Destination = this.WeakTableRef(target);
		this.m.Destination.setVisited(true);
		local b = -1;

		do
		{
			local r = this.Math.rand(0, this.Const.PlayerBanners.len() - 1);

			if (this.World.Assets.getBanner() != this.Const.PlayerBanners[r])
			{
				b = this.Const.PlayerBanners[r];
				break;
			}
		}
		while (b < 0);

		this.m.Payment.Pool = 1300 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Flags.set("DestinationIndex", targetIndex);
		this.m.Flags.set("MercenaryPay", this.beautifyNumber(this.m.Payment.Pool * 0.5));
		this.m.Flags.set("Mercenary", this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
		this.m.Flags.set("MercenaryCompany", this.Const.Strings.MercenaryCompanyNames[this.Math.rand(0, this.Const.Strings.MercenaryCompanyNames.len() - 1)]);
		this.m.Flags.set("MercenaryBanner", b);
		this.m.Flags.set("Commander", this.Const.Strings.SouthernNames[this.Math.rand(0, this.Const.Strings.SouthernNames.len() - 1)]);
		this.m.Flags.set("EnemyID", target.getFaction());
		this.m.Flags.set("MapSeed", this.Time.getRealTime());
		this.m.Flags.set("OppositionSeed", this.Time.getRealTime());
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"从北方异教徒手中夺回 %holysite%",
					"歼灭或击溃附近的敌方部队"
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 20)
				{
					this.Flags.set("IsAlliedArmy", true);
				}
				else if (r <= 40)
				{
					this.Flags.set("IsSallyForth", true);
				}
				else if (r <= 60)
				{
					this.Flags.set("IsMercenaries", true);
				}
				else if (r <= 80)
				{
					this.Flags.set("IsCounterAttack", true);
				}

				if (this.Contract.getDifficultyMult() >= 1.15)
				{
					this.Contract.spawnEnemy();
				}
				else if (this.Contract.getDifficultyMult() <= 0.85)
				{
					local entities = this.World.getAllEntitiesAtPos(this.Contract.m.Destination.getPos(), 1.0);

					foreach( e in entities )
					{
						if (e.isParty())
						{
							e.getController().clearOrders();
						}
					}
				}

				local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);

				foreach( n in nobles )
				{
					if (n.getFlags().get("IsHolyWarParticipant"))
					{
						n.addPlayerRelation(-99.0, "在战争选择了阵营");
					}
				}

				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnEnterCallback(this.onDestinationAttacked.bindenv(this));
				}

				if (this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onCounterAttack.bindenv(this));
				}
			}

			function update()
			{
				if (this.Flags.get("IsFailure"))
				{
					this.Contract.setScreen("Failure");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsVictory"))
				{
					if (this.Flags.get("IsCounterAttack"))
					{
						this.Contract.setScreen("CounterAttack1");
						this.World.Contracts.showActiveContract();
					}
					else if (!this.Contract.isEnemyPartyNear(this.Contract.m.Destination, 400.0))
					{
						this.Contract.setScreen("Victory");
						this.World.Contracts.showActiveContract();
					}
				}
			}

			function onCounterAttack( _dest, _isPlayerInitiated )
			{
				if (this.Flags.get("IsCounterAttackDefend") && this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
					p.LocationTemplate.Template[0] = "tactical.southern_ruins";
					p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
					p.LocationTemplate.ShiftX = -4;
					p.CombatID = "ConquerHolySiteCounterAttack";
					p.MapSeed = this.Flags.getAsInt("MapSeed");
					p.Music = this.Const.Music.NobleTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "ConquerHolySiteCounterAttack";
					p.Music = this.Const.Music.NobleTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
			}

			function onDestinationAttacked( _dest )
			{
				if (this.Flags.getAsInt("OppositionSeed") != 0)
				{
					this.Math.seedRandom(this.Flags.getAsInt("OppositionSeed"));
				}

				if (this.Flags.get("IsVictory") || this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					return;
				}
				else if (this.Flags.get("IsAlliedArmy"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("AlliedArmy");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
						p.CombatID = "ConquerHolySite";
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.NobleTracks;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 200 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner(),
							this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, true, true, true);
					}
				}
				else if (this.Flags.get("IsSallyForth"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("SallyForth");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "ConquerHolySite";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
				}
				else if (this.Flags.get("IsMercenaries"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("Mercenaries1");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
						p.CombatID = "ConquerHolySite";
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.NobleTracks;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, (130 + (this.Flags.get("MercenariesAsAllies") ? 30 : 0)) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];

						if (this.Flags.get("MercenariesAsAllies"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
							p.AllyBanners.push(this.Flags.get("MercenaryBanner"));
						}
						else
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
							p.EnemyBanners.push(this.Flags.get("MercenaryBanner"));
						}

						this.World.Contracts.startScriptedCombat(p, true, true, true);
					}
				}
				else if (this.Flags.get("IsCounterAttack") && this.Flags.get("IsVictory"))
				{
					if (this.Flags.get("IsCounterAttackDefend"))
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
						p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
						p.LocationTemplate.ShiftX = -2;
						p.CombatID = "ConquerHolySiteCounterAttack";
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "ConquerHolySiteCounterAttack";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
				}
				else if (!this.Flags.get("IsAttackDialogTriggered"))
				{
					this.Flags.set("IsAttackDialogTriggered", true);
					this.Contract.setScreen("Attacking");
					this.World.Contracts.showActiveContract();
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Flags.get("EnemyID");
					p.CombatID = "ConquerHolySite";
					p.LocationTemplate.Template[0] = "tactical.southern_ruins";
					p.LocationTemplate.Fortification = this.Const.Tactical.FortificationType.Walls;
					p.Music = this.Const.Music.NobleTracks;
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, (this.Flags.get("IsCounterAttack") ? 110 : 130) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.AllyBanners = [
						this.World.Assets.getBanner()
					];
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];
					this.World.Contracts.startScriptedCombat(p, true, true, true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "ConquerHolySiteCounterAttack")
				{
					this.Flags.set("IsCounterAttack", false);
					this.Flags.set("IsVictory", true);
				}
				else if (_combatID == "ConquerHolySite")
				{
					this.Flags.set("IsVictory", true);
					this.Flags.set("OppositionSeed", this.Time.getRealTime());
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "ConquerHolySite" || _combatID == "ConquerHolySiteCounterAttack")
				{
					this.Flags.set("IsFailure", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
					this.Contract.m.Destination.setOnEnterCallback(null);
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_162.png[/img]{你发现 %employer% 正埋首于一堆卷轴之后。他正埋头苦写，而周围那些圣职人员也同样忙碌，时刻准备在他最后一笔落下时立刻抢走卷轴。这位书写要务的大人物终于抬起了头。%SPEECH_ON%那些北方老鼠竟然敢擅闯 %holysite%，这件事非同小可。我尽量克制我的情绪，毕竟这不是镀金者的行事风格，我们不会让愤怒玷污理性。总之，这些野蛮人的存在，是对理性的冒犯。%SPEECH_OFF%维齐尔蘸了蘸羽毛笔，一边继续书写，一边说道。%SPEECH_ON%然而，狗儿如果吠叫，鸟儿便会飞走。我需要一条狗，逐币者，而且是一条带獠牙的狗。带上你的队伍前往圣地，铲除那些堕落者。如果我们达成共识，那么等你凯旋归来的时候，除了镀金者的光辉，还有 %reward% 克朗在等着你。%SPEECH_OFF% | %employer%以一种令人惊讶的热情欢迎了你。%SPEECH_ON%我就知道镀金者会为我带来一位举足轻重的人物，一个拥有强大力量与担当的人。一个逐币者，当然，更是位战士！%SPEECH_OFF%还没等你询问事情的具体性质，维齐尔便举起一只金制高脚杯，杯子的一半边缘被切开，像月亮的轮廓一样。%SPEECH_ON%我们的圣地 %holysite% 被野蛮的北方人夺走了。我们的世界正受到黑暗的威胁，为了抵御阴影，我们必须努力获得祝福。我领地里的士兵虽然众多，但在镀金者目光照耀下的土地辽阔无边，我需要像你这样的士兵来帮助我们夺回 %holysite%。因为这片土地是镀金者至高无上的领地，而镀金者恩泽万物：任务完成之后，我会给你 %reward% 克朗。我们达成协议吗？%SPEECH_OFF% | 这是罕见的一幕，你发现 %employer% 俯伏在一尊形如太阳、闪闪发光的徽章之下，显得卑微而虔诚。他先是对自己低声细语了几句然后起身，又低语了一番，接着一根一根地擦拭指尖，最后转身面向你。%SPEECH_ON%当我的部队在其他地方取得有利进展时，%holysite%却处于无人防守的状态。为了赢得这场战争，我不慎留下了一个破绽，让野蛮的北方人占据了这个地方。我请求与你面对面交谈，给予一些外部援助。镀金者会为我们所有人铺就镀金之路，逐币者，你也不例外。通过我的手，只要你夺回 %holysite%，你将获得 %reward% 克朗！%SPEECH_OFF% | 一只金色酒杯摔碎在大理石地板上，葡萄酒四处飞溅。维齐尔冲着你大喊，愤怒与急切交织在一起。%SPEECH_ON%终于有人能帮上忙了！%SPEECH_OFF%他挥手赶走了几名助手，甚至还有几位看起来像是他副官的人。%SPEECH_ON%逐币者，%holysite%已经被北方的蠢货征服了。一想到他们在那里烧杀抢掠，我就痛哭流涕。%reward% 克朗，这就是你将得到的奖励。这对你来说这是一笔巨款，但毕竟有这样一句话，但人们常说，对某些人来说，镀金者之路或许比对其他人更实在一些。%SPEECH_OFF% | %employer% 被一群身穿丝绸的男人包围着。一人提着一个罩着兜帽的笼子，里面装着萤火虫，暗淡的虫光忽明忽暗。另一人则提着一个笼子，里面有一只死鸟的残骸，全身皮肉已被剔尽只剩骨架，唯独剩下两根羽毛，似乎复刻了它曾经双翼的全部形态。看到你来了，维齐尔从这些人中间走出来，就像一个人从神庙不可移动的石柱间穿过一样。%SPEECH_ON%逐币者，你来了！我的斥候报告说，我们在对抗北方狗的战争中失利了。%holysite% 已经被占领了，而且根据镀金者的低语，我必须让它重回我们手中。不仅是为了我的领地，更是为了让祂的崇高蒙上最微弱的阴影。如果你完成任务，你将得到 %reward% 克朗，一份沉重的任务对应一笔丰厚的报酬，没错！%SPEECH_OFF% | 平时总是锦衣玉食、身边围着一群挥霍无度的熟人的 %employer%，此刻却跪在地上，穿着相当朴素的衣服。他戴着一顶头饰，黑色的绳索缠绕在他的头顶。这位平日沉默寡言的维齐尔平静地对你说道。%SPEECH_ON%北方的异教徒从我们的土地上夺走了 %holysite%。我不怪他们的行为，因为他们不知道自己在做什么。愿镀金者见证我的过错。但失败并不意味着投降。我需要你前往那片圣地，并将其归还给我们的领域。为此，你的金库中将多出 %reward% 克朗。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我相信你会为这样的袭击付出丰厚的报酬。 | 我们已经准备好尽自己的一份力了。 | 我们再详细谈谈报酬吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不值得。 | 这太远了。 | 我们有更要紧的事情要处理。 | 别的地方更需要我们。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Attacking",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{正如维齐尔所料，北方人已经占据了 %holysite% 及其周边地区。大多数信徒早已逃走，只剩下 %companyname% 和敌对势力在此对峙。你拔出剑，命令弟兄们发起攻击。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "AlliedArmy",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{当你接近 %holysite% 时，一名男子仿佛从地底凭空升起。你吃了一惊，拔出武器，但这人却表示自己是 %employer% 的一名伪装过的指挥官。 %SPEECH_ON%别紧张，逐币者，你很快就会拿到你的钱。维齐尔的信鸽已经告诉我的队伍你要来了，我必须说，你稍微迟到了一点。我知道这并不是你的战争, 但好吧, 我想现在也不是责备的时候. 让我们为镀金者夺回这片圣地吧，愿祂的光辉永远照耀我们前行的道路！%SPEECH_OFF% | 当 %holysite% 进入视野时，一名男子看似从地面浮现。他问你是否就是 %companyname% 的指挥官，而你那一瞬间的停顿似乎已经给了他答案，他立刻开口说道 %SPEECH_ON%是的，当然你是。我是 %commander% ，%employer%的副官。维齐尔的信鸽已经告诉我说你会来。你或许是在追逐金钱，逐币者，但如果今天我们取得胜利，镀金者必将照耀你明天的道路！%SPEECH_OFF%}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "SallyForth",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{ %holysite% 的守军得到了增援！值得庆幸的是，事情因此出现了一丝转机: 这批额外的援军给了他们信心，让他们敢于离开圣地的天然屏障，在开阔地带向你发起挑战。 | 当你看到守军离开 %holysite% 踏上开阔平原时，感到有些惊讶。一份快速侦察报告显示，他们在过去几天里确实得到了增援，仅凭人数上的优势就变得有恃无恐。一方面，他们严整的阵列确实让人心里有些不安，但另一方面，在势均力敌的平地上迎战他们会容易得多。不过依你诚恳的判断，他们敢于面对 %companyname% 将是一个致命错误。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "那么，就来一场野战吧。",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{当 %holysite% 逐渐映入眼帘时，一名与你相貌惊人相似的男子迎面走来。他身边有一名财务官和几个佣兵。%SPEECH_ON%晚上好啊，队长。我是 %mercenary% 的雇佣兵，来自 %mercenarycompany%，我和你一样，也是为金币而来这片土地的。我打赌维齐尔给了你和你的手下一份丰厚的合同，但如果你愿意付给我 %pay% 克朗，我就帮助你完成这项小任务？%SPEECH_OFF%. | 一群男子朝你走来，其中一人无论是走路的姿态还是体格，都莫名让你想起自己。他自称为%mercenary%，是%mercenarycompany%的队长。%SPEECH_ON%我以为维齐尔会派专业军队来处理圣地易手的事儿。实话告诉你吧，队长，当初正是我帮北方人夺下了这著名的纪念碑。不过，只要给我 %pay% 克朗作为报酬，我愿意帮助你们把它抢回来。同为佣兵，我相信你能看出，这对大家都是笔划算的买卖。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [],
			function start()
			{
				if (this.World.Assets.getMoney() > this.Flags.get("MercenaryPay"))
				{
					this.Options.push({
						Text = "你被雇佣了!",
						function getResult()
						{
							return "Mercenaries2";
						}

					});
				}
				else
				{
					this.Options.push({
						Text = "恐怕我们没有那么多的钱。",
						function getResult()
						{
							return "Mercenaries3";
						}

					});
				}

				this.Options.push({
					Text = "自己找工作去，%mercenary%。我们不需要帮助。",
					function getResult()
					{
						return "Mercenaries3";
					}

				});
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{那名队长咧嘴一笑，重重拍了拍你的肩膀。%SPEECH_ON%啊哈，就是这样！就是这股子高贵的佣兵精神！嗯，作为 %companyname% 的指挥官，啊哈，就是这样！就是这股子高贵的佣兵精神！%SPEECH_OFF% | 协议达成后，那支佣兵团的队长便紧挨着你站了过来，几乎近得有些不舒服，而且他呼出的气息显然不太好闻。%SPEECH_ON%你知道吗，像我们这样的人，伙计们，朋友们，我们是好朋友，对吧？像我们这样的好兄弟，就得互相照应。这场仗嘛，我们就一起战斗。%SPEECH_OFF%他点点头，又给了你肩膀一拳。%SPEECH_ON%打完这一仗嘛，希望以后还能再做朋友，懂我意思吧。 %SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "开始进攻！",
					function getResult()
					{
						this.Flags.set("MercenariesAsAllies", true);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.World.Assets.addMoney(-this.Flags.get("MercenaryPay"));
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你花费了 [color=" + this.Const.UI.Color.NegativeEventValue + "]" + this.Flags.get("MercenaryPay") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_134.png[/img]{%SPEECH_START% 真遗憾啊。%SPEECH_OFF% %mercenary% 说着，迅速退回了 %mercenarycompany% 的队列中。他一边后退，一边直接融入了守卫 %holysite% 的北方士兵阵线。他双臂张开，像在逆流中游泳般挥动着。%SPEECH_ON%真是他妈的遗憾！好吧， %companyname% 的队长，接下来我们看看哪边雇到了更好的佣兵？%SPEECH_OFF%那名佣兵拔出了武器，他身边的北方士兵们也纷纷亮出兵刃，你也跟着拔出武器。战斗时刻到了。 | %SPEECH_ON%好吧，好吧，我明白了。不过我本来就没抱太大指望。毕竟，我也只是个卖命的佣兵。而现在......%SPEECH_OFF%他一边说着，一边缓缓退向自己的队伍，而他的队伍则与守卫 %holysite% 的北方士兵队列中。%SPEECH_ON%眼下看来，出价最高的是北方人。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们将在战场上再见。开始进攻！",
					function getResult()
					{
						this.Flags.set("MercenariesAsAllies", false);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{战斗虽然结束了，但远处一道金色闪光却吸引了你的目光。你凝视着地平线，一支北方军队赫然出现，他们耀眼的装束显然是故意要引人注目。这是反攻！ | 当你将剑归鞘时，一支箭矢呼啸着从头顶飞过，闷响一声扎进了沙地里。你循声望去，只见一名年轻而紧张的弓箭手正被扇了一记耳光，在那人身边，赫然是一整支北方人的部队！这是反击！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们将坚守圣地进行防御！",
					function getResult()
					{
						return "CounterAttack2";
					}

				},
				{
					Text = "我们去开阔地迎战他们！",
					function getResult()
					{
						return "CounterAttack3";
					}

				},
				{
					Text = "我们撑不住另一场战斗了，撤退！",
					function getResult()
					{
						return "Failure";
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{%SPEECH_START%不过是更多的北方佬罢了。%SPEECH_OFF%%randombrother% 说道。你点点头，回应道。%SPEECH_ON%就当是给镀金者的火焰添些柴火吧。%SPEECH_OFF%那名佣兵嘟囔说，镀金者对黄金的兴趣恐怕比火焰更大，但你让他闭嘴，并叫他准备好应对即将到来的战斗。%holysite% 本身的防御工事在这里会很管用。 | 你命令弟兄们在 %holysite% 内部进行防御。%randombrother% 环顾了一下四周。%SPEECH_ON%你说，你有没有想过，那些注视着这一切的神明会不会感到有点恼火？你知道吗？就好像我们在打翻他们的锅碗瓢盆一样？%SPEECH_OFF%你一巴掌拍在他的后脑勺上，叫他集中注意力。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "集合！",
					function getResult()
					{
						this.Flags.set("IsCounterAttackDefend", true);
						this.Flags.set("IsVictory", false);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onCounterAttack.bindenv(this.Contract.getActiveState()));
						this.Contract.m.Target = this.WeakTableRef(party);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "CounterAttack3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你率领 %companyname% 进入战场。那名北方军的中尉挥手冲你一笑，说道。%SPEECH_ON%出来啦？怎么，祈祷累了？%SPEECH_OFF%你转过头啐了一口，回敬道。%SPEECH_ON%我们快没地方埋你们的尸体了。%SPEECH_OFF%中尉的笑容瞬间凝固，随即下令发起冲锋。战斗开始！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "冲锋！",
					function getResult()
					{
						this.Flags.set("IsCounterAttackDefend", false);
						this.Flags.set("IsVictory", false);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onCounterAttack.bindenv(this.Contract.getActiveState()));
						this.Contract.m.Target = this.WeakTableRef(party);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{当你收起武器，命令部队从死者身上搜刮能带走的一切时，一种奇怪的感觉油然而生，这并非 %holysite% 第一次见证如此血腥的屠杀。不过也好，如果注定有人要在祖先的足迹上倒下，你很高兴那个人不是自己。几名南方士兵赶来接管了这片圣地，有他们在，你可以放心回去了，你知道 %employer% 会欢迎你带去的消息。 | 敌人已经被击溃，%holysite% 也已经收复。南方士兵慢慢地修复防线，一群信徒缓缓涌入，他们从尸体旁经过，只为在最神圣的地方俯首叩拜，没有人向你们道谢，不过这也不重要，那是 %employer% 该做的事 | 战斗结束后，一小群信徒开始聚集在 %holysite% 的角落里。你甚至不知道这些人是从哪里冒出来的。他们不理会你们，你们也懒得理他们。现在唯一重要的是， %employer% 那里正有一大笔克朗等着你凯旋。当你们离开时，几名南方士兵接替了岗位，嘴里同样没有吐出半句感谢的话。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.m.Destination.setFaction(this.Contract.getFaction());
						this.Contract.m.Destination.setBanner(this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner());
						this.updateAchievement("NewManagement", 1, 1);
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.spawnAlly();
			}

		});
		this.m.Screens.push({
			ID = "Failure",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你没能保护好 %holysite%，让北方人攻破了。没有理由再逗留下去了，而回去找 %employer% 的唯一理由，恐怕就是你想把自己的脑袋摆在维齐尔镶金的盘子里了。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "灾难！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "未能征服一个圣地");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Success",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%employer% 正坐在一个金色圆球状物体的光芒之下，那是一块巨大的金属，像太阳一样被链条悬挂在天花板上。这东西肯定是在你离开期间才竖起来的。当你走上前去时，一名神职人员拦住了你，并摇了摇头。他用手在空中画了一个圈，然后指尖轻触你的头顶。微笑着，他热情地指引你走向房间的另一侧，那里 %reward% 克朗正整齐地堆放在木托盘里。\n\n 那人鞠了一躬，双手指向那个金色圆球，手掌弯曲仿佛托举着那个构造物本身，随后他似乎将这种庄严神圣的气息引导到了你的酬劳上，硬币在光芒下噼啪作响。虽然这只是某种把戏，但薪水是真的，于是你拿了钱便离开了。 | 当你进入 %employer% 的房间时，几名卫兵向你鞠躬并短暂地俯伏在地，随后站起身来。远处，维齐尔静静地坐在王座上，身边簇拥着身穿丝绸的圣职人员。看来今天你是没法接近他了，不过一群年轻男孩会一次一个地为你端来装满硬币的托盘，直到凑够 %reward% 克朗为止。维齐尔点点头，翻转了一下手掌。你收下报酬，随即离去。 | 你走进宏伟的大厅，发现 %employer% 似乎被一团金色的迷雾所迷惑。他站在一个旋转平台上——在地板下几乎看不见的奴隶的帮助下，平台转得相当粗犷——手腕上还系着布条。他的妃嫔站在一旁，嘴里含着某种金色液体，然后将其喷出，形成嘴唇飞溅的雾气。仔细一看，这并非你刚进来时以为的那般辉煌盛况。。在你想靠近进一步观察之前，一名身穿宗教长袍的壮汉拦住了你，把你引到房间后方的一张桌子旁。桌上摆满了装有克朗的托盘，这些就是你 %reward% 克朗的报酬。拿到报酬后，你被匆匆送出了房间。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "征服了一个圣地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isHolyWar())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function spawnAlly()
	{
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y + 4; y <= o.Y + 6; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.getFaction());
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			candidates.push(s);
		}

		local party = f.spawnEntity(tiles[0].Tile, "Regiment of " + candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly(), true, this.Const.World.Spawn.Southern, 170 * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("忠于城邦的应征士兵。");
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 5);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r <= 2)
		{
			party.addToInventory("supplies/rice_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dates_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/dried_lamb_item");
		}

		local c = party.getController();
		local occupy = this.new("scripts/ai/world/orders/occupy_order");
		occupy.setTarget(this.m.Destination);
		occupy.setTime(10.0);
		c.addOrder(occupy);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(240.0);
		c.addOrder(guard);
		return party;
	}

	function spawnEnemy()
	{
		local cityState = this.World.FactionManager.getFaction(this.getFaction());
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y - 4; y <= o.Y - 3; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.m.Flags.get("EnemyID"));
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			if (s.isMilitary())
			{
				candidates.push(s);
			}
		}

		local party = f.spawnEntity(tiles[0].Tile, candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly() + " Company", true, this.Const.World.Spawn.Noble, this.Math.rand(100, 140) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("为地方领主服务的专业士兵。");
		party.setAttackableByAI(false);
		party.setAlwaysAttackPlayer(true);
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 5);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r == 1)
		{
			party.addToInventory("supplies/bread_item");
		}
		else if (r == 2)
		{
			party.addToInventory("supplies/roots_and_berries_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dried_fruits_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/ground_grains_item");
		}

		local c = party.getController();
		local attack = this.new("scripts/ai/world/orders/attack_zone_order");
		attack.setTargetTile(this.m.Destination.getTile());
		c.addOrder(attack);
		local move = this.new("scripts/ai/world/orders/move_order");
		move.setDestination(this.m.Destination.getTile());
		c.addOrder(move);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(999.0);
		c.addOrder(guard);
		return party;
	}

	function onPrepareVariables( _vars )
	{
		local illustrations = [
			"event_152",
			"event_154",
			"event_151"
		];
		_vars.push([
			"illustration",
			illustrations[this.m.Flags.get("DestinationIndex")]
		]);
		_vars.push([
			"holysite",
			this.m.Flags.get("DestinationName")
		]);
		_vars.push([
			"pay",
			this.m.Flags.get("MercenaryPay")
		]);
		_vars.push([
			"employerfaction",
			this.World.FactionManager.getFaction(this.m.Faction).getName()
		]);
		_vars.push([
			"mercenary",
			this.m.Flags.get("Mercenary")
		]);
		_vars.push([
			"mercenarycompany",
			this.m.Flags.get("MercenaryCompany")
		]);
		_vars.push([
			"commander",
			this.m.Flags.get("Commander")
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnEnterCallback(null);
			}

			if (this.m.Target != null && !this.m.Target.isNull())
			{
				this.m.Target.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isHolyWar())
		{
			return false;
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();

		foreach( v in locations )
		{
			foreach( s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && !this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					return true;
				}
			}
		}

		return false;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Target != null && !this.m.Target.isNull())
		{
			_out.writeU32(this.m.Target.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local target = _in.readU32();

		if (target != 0)
		{
			this.m.Target = this.WeakTableRef(this.World.getEntityByID(target));
		}

		this.contract.onDeserialize(_in);
	}

});

