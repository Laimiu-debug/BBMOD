this.decisive_battle_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Warcamp = null,
		WarcampTile = null,
		Dude = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		local r = this.Math.rand(1, 100);

		if (r <= 70)
		{
			this.m.DifficultyMult = this.Math.rand(95, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(115, 135) * 0.01;
		}

		this.m.Type = "contract.decisive_battle";
		this.m.Name = "决战";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		if (this.m.WarcampTile == null)
		{
			local settlements = this.World.EntityManager.getSettlements();
			local lowest_distance = 99999;
			local best_settlement;
			local myTile = this.m.Home.getTile();

			foreach( s in settlements )
			{
				if (this.World.FactionManager.isAllied(this.getFaction(), s.getFaction()))
				{
					continue;
				}

				local d = s.getTile().getDistanceTo(myTile);

				if (d < lowest_distance)
				{
					lowest_distance = d;
					best_settlement = s;
				}
			}

			this.m.WarcampTile = myTile.getTileBetweenThisAnd(best_settlement.getTile());
			this.m.Flags.set("EnemyNobleHouse", best_settlement.getOwner().getID());
		}

		this.m.Flags.set("CommanderName", this.Const.Strings.KnightNames[this.Math.rand(0, this.Const.Strings.KnightNames.len() - 1)]);
		this.m.Payment.Pool = 1600 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("RequisitionCost", this.beautifyNumber(this.m.Payment.Pool * 0.25));
		this.m.Flags.set("Bribe", this.beautifyNumber(this.m.Payment.Pool * 0.35));
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往军营并向 %commander% 报到",
					"协助军队对抗 %feudfamily%"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).addPlayerRelation(-99.0, "在战争选择了阵营");

				if (this.Contract.m.WarcampTile == null)
				{
					local settlements = this.World.EntityManager.getSettlements();
					local lowest_distance = 99999;
					local best_settlement;
					local myTile = this.Contract.m.Home.getTile();

					foreach( s in settlements )
					{
						if (this.World.FactionManager.isAllied(this.Contract.getFaction(), s.getFaction()))
						{
							continue;
						}

						local d = s.getTile().getDistanceTo(myTile);

						if (d < lowest_distance)
						{
							lowest_distance = d;
							best_settlement = s;
						}
					}

					this.Contract.m.WarcampTile = myTile.getTileBetweenThisAnd(best_settlement.getTile());
				}

				local tile = this.Contract.getTileToSpawnLocation(this.Contract.m.WarcampTile, 1, 12, [
					this.Const.World.TerrainType.Shore,
					this.Const.World.TerrainType.Ocean,
					this.Const.World.TerrainType.Mountains,
					this.Const.World.TerrainType.Forest,
					this.Const.World.TerrainType.LeaveForest,
					this.Const.World.TerrainType.SnowyForest,
					this.Const.World.TerrainType.AutumnForest,
					this.Const.World.TerrainType.Swamp
				], false, false, true);
				tile.clear();
				this.Contract.m.WarcampTile = tile;
				this.Contract.m.Warcamp = this.WeakTableRef(this.World.spawnLocation("scripts/entity/world/locations/noble_camp_location", tile.Coords));
				this.Contract.m.Warcamp.onSpawned();
				this.Contract.m.Warcamp.getSprite("banner").setBrush(this.World.FactionManager.getFaction(this.Contract.getFaction()).getBannerSmall());
				this.Contract.m.Warcamp.setFaction(this.Contract.getFaction());
				this.Contract.m.Warcamp.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Warcamp.getTile().Pos, 500.0);
				local r = this.Math.rand(1, 100);

				if (r <= 40)
				{
					this.Flags.set("IsScoutsSighted", true);
				}
				else
				{
					this.Flags.set("IsRequisitionSupplies", true);
					r = this.Math.rand(1, 100);

					if (r <= 33)
					{
						this.Flags.set("IsAmbush", true);
					}
					else if (r <= 66)
					{
						this.Flags.set("IsUnrulyFarmers", true);
					}
					else
					{
						this.Flags.set("IsCooperativeFarmers", true);
					}
				}

				r = this.Math.rand(1, 100);

				if (r <= 40)
				{
					if (this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getSettlements().len() >= 2)
					{
						this.Flags.set("IsInterceptSupplies", true);
						local myTile = this.Contract.m.Warcamp.getTile();
						local settlements = this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getSettlements();
						local lowest_distance = 99999;
						local highest_distance = 0;
						local best_start;
						local best_dest;

						foreach( s in settlements )
						{
							if (s.isIsolated())
							{
								continue;
							}

							local d = s.getTile().getDistanceTo(myTile);

							if (d < lowest_distance)
							{
								lowest_distance = d;
								best_dest = s;
							}

							if (d > highest_distance)
							{
								highest_distance = d;
								best_start = s;
							}
						}

						this.Flags.set("InterceptSuppliesStart", best_start.getID());
						this.Flags.set("InterceptSuppliesDest", best_dest.getID());
					}
				}
				else if (r <= 80)
				{
					this.Flags.set("IsDeserters", true);
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往军营并向 %commander% 报到"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Warcamp) && !this.Flags.get("IsWarcampDay1Shown"))
				{
					this.Flags.set("IsWarcampDay1Shown", true);
					this.Contract.setScreen("WarcampDay1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Running_WaitForNextDay",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"在军营里待命，等候调遣"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Warcamp))
				{
					if (this.World.getTime().Days > this.Flags.get("LastDay"))
					{
						if (this.Flags.get("NextDay") == 2)
						{
							this.Contract.setScreen("WarcampDay2");
						}
						else
						{
							this.Contract.setScreen("WarcampDay3");
						}

						this.World.Contracts.showActiveContract();
					}
				}
			}

		});
		this.m.States.push({
			ID = "Running_Scouts",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"拦截 %feudfamily% 的斥候，他们最后出现在军营的 %direction%",
					"不留活口"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onCombatWithScouts.bindenv(this));
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsScoutsFailed"))
					{
						this.Contract.setScreen("ScoutsEscaped");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setScreen("ScoutsCaught");
						this.World.Contracts.showActiveContract();
					}
				}
				else if (this.Flags.get("IsScoutsRetreat"))
				{
					this.Flags.set("IsScoutsRetreat", false);
					this.Contract.m.Destination.die();
					this.Contract.m.Destination = null;
					this.Contract.setScreen("ScoutsEscaped");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatWithScouts( _dest, _isPlayerAttacking = true )
			{
				local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
				properties.CombatID = "Scouts";
				properties.Music = this.Const.Music.NobleTracks;
				properties.EnemyBanners = [
					this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getBannerSmall()
				];
				this.World.Contracts.startScriptedCombat(properties, _isPlayerAttacking, true, true);
			}

			function onActorRetreated( _actor, _combatID )
			{
				if (_combatID == "Scouts")
				{
					this.Flags.set("IsScoutsFailed", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Scouts")
				{
					this.Flags.set("IsScoutsRetreat", true);
				}
			}

		});
		this.m.States.push({
			ID = "Running_ReturnAfterScouts",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回军营"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Warcamp) && !this.Flags.get("IsReportAfterScoutsShown"))
				{
					this.Flags.set("IsReportAfterScoutsShown", true);
					this.Contract.setScreen("WarcampDay1End");
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Running_Requisition",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往军营%direction%的%objective%处征用补给。"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Destination) && !this.TempFlags.get("IsReportAfterRequisitionShown"))
				{
					this.TempFlags.set("IsReportAfterRequisitionShown", true);
					this.Contract.setScreen("RequisitionSupplies2");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsRequisitionRetreat") && !this.Flags.get("IsRequisitionCombatDone"))
				{
					this.Flags.set("IsRequisitionCombatDone", true);
					this.Contract.setScreen("BeatenByFarmers");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsRequisitionVictory") && !this.Flags.get("IsRequisitionCombatDone"))
				{
					this.Flags.set("IsRequisitionCombatDone", true);
					this.Contract.setScreen("PoorFarmers");
					this.World.Contracts.showActiveContract();
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Ambush" || _combatID == "TakeItByForce")
				{
					this.Flags.set("IsRequisitionRetreat", true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Ambush" || _combatID == "TakeItByForce")
				{
					this.Flags.set("IsRequisitionVictory", true);
				}
			}

		});
		this.m.States.push({
			ID = "Running_ReturnAfterRequisition",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回军营"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = true;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Warcamp))
				{
					if (this.Flags.get("IsInterceptSupplies") || this.Flags.get("IsDeserters"))
					{
						this.Contract.setScreen("WarcampDay1End");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setScreen("WarcampDay2End");
						this.World.Contracts.showActiveContract();
					}
				}
			}

		});
		this.m.States.push({
			ID = "Running_InterceptSupplies",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"拦截从%supply_start% 运往 %supply_dest% 的补给。"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setVisibleInFogOfWar(true);
				}
			}

			function update()
			{
				if (this.Flags.get("IsInterceptSuppliesSuccess"))
				{
					this.Contract.setScreen("SuppliesIntercepted");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.m.Destination == null || this.Contract.m.Destination != null && this.Contract.m.Destination.isNull())
				{
					this.Flags.set("IsInterceptSuppliesFailure", true);
					this.Contract.setScreen("SuppliesReachedEnemy");
					this.World.Contracts.showActiveContract();
				}
			}

			function onPartyDestroyed( _party )
			{
				if (_party.getFlags().has("ContractSupplies"))
				{
					this.Flags.set("IsInterceptSuppliesSuccess", true);
				}
			}

		});
		this.m.States.push({
			ID = "Running_ReturnAfterIntercept",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回军营"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = true;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Warcamp))
				{
					this.Contract.setScreen("WarcampDay2End");
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Running_Deserters",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"追踪脚印，接近逃兵",
					"设法劝说他们归队，否则格杀勿论"
				];

				if (this.Contract.m.Warcamp != null && !this.Contract.m.Warcamp.isNull())
				{
					this.Contract.m.Warcamp.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Flags.get("IsDesertersFailed"))
				{
					if (this.Contract.m.Destination != null)
					{
						this.Contract.m.Destination.die();
						this.Contract.m.Destination = null;
					}

					this.Contract.setState("Running_ReturnAfterIntercept");
				}
				else if (this.Contract.m.Destination == null || this.Contract.m.Destination != null && this.Contract.m.Destination.isNull())
				{
					this.Contract.setScreen("DesertersAftermath");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerNear(this.Contract.m.Destination, this.Const.World.CombatSettings.CombatPlayerDistance / 2) && !this.TempFlags.get("IsDeserterApproachShown"))
				{
					this.TempFlags.set("IsDeserterApproachShown", true);
					this.Contract.setScreen("Deserters2");
					this.World.Contracts.showActiveContract();
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Deserters")
				{
					this.Flags.set("IsDesertersFailed", true);
				}
			}

		});
		this.m.States.push({
			ID = "Running_FinalBattle",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"为 %noblehouse% 赢得这场战斗的胜利"
				];
			}

			function update()
			{
				if (this.Flags.get("IsFinalBattleLost") && !this.Flags.get("IsFinalBattleLostShown"))
				{
					this.Flags.set("IsFinalBattleLostShown", true);
					this.Contract.m.Warcamp.die();
					this.Contract.m.Warcamp = null;
					this.Contract.setScreen("BattleLost");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsFinalBattleWon") && !this.Flags.get("IsFinalBattleWonShown"))
				{
					this.Flags.set("IsFinalBattleWonShown", true);
					this.Contract.m.Warcamp.die();
					this.Contract.m.Warcamp = null;
					this.Contract.setScreen("BattleWon");
					this.World.Contracts.showActiveContract();
				}
				else if (!this.TempFlags.get("IsFinalBattleStarted"))
				{
					this.TempFlags.set("IsFinalBattleStarted", true);
					local tile = this.Contract.getTileToSpawnLocation(this.Contract.m.Warcamp.getTile(), 3, 12, [
						this.Const.World.TerrainType.Shore,
						this.Const.World.TerrainType.Ocean,
						this.Const.World.TerrainType.Mountains,
						this.Const.World.TerrainType.Forest,
						this.Const.World.TerrainType.LeaveForest,
						this.Const.World.TerrainType.SnowyForest,
						this.Const.World.TerrainType.AutumnForest,
						this.Const.World.TerrainType.Swamp,
						this.Const.World.TerrainType.Hills
					], false);
					this.World.State.getPlayer().setPos(tile.Pos);
					this.World.getCamera().moveToPos(this.World.State.getPlayer().getPos());
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "FinalBattle";
					p.Music = this.Const.Music.NobleTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.Entities = [];
					p.AllyBanners = [
						this.World.Assets.getBanner(),
						this.World.FactionManager.getFaction(this.Contract.getFaction()).getBannerSmall()
					];
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getBannerSmall()
					];
					local allyStrength = 90;

					if (this.Flags.get("IsRequisitionFailure"))
					{
						allyStrength = allyStrength - 20;
					}

					if (this.Flags.get("IsDesertersFailed"))
					{
						allyStrength = allyStrength - 20;
					}

					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, allyStrength * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
					p.Entities.push({
						ID = this.Const.EntityType.Knight,
						Variant = 0,
						Row = 2,
						Script = "scripts/entity/tactical/humans/knight",
						Faction = this.Contract.getFaction(),
						Callback = this.Contract.onCommanderPlaced.bindenv(this.Contract)
					});
					local enemyStrength = 150;

					if (this.Flags.get("IsScoutsFailed"))
					{
						enemyStrength = enemyStrength + 25;
					}

					if (this.Flags.get("IsInterceptSuppliesFailure"))
					{
						enemyStrength = enemyStrength + 25;
					}

					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, enemyStrength * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyNobleHouse"));
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 60 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyNobleHouse"));
					p.Entities.push({
						ID = this.Const.EntityType.Knight,
						Variant = this.Const.DLC.Wildmen && this.Contract.getDifficultyMult() >= 1.15 ? 1 : 0,
						Name = this.Const.Strings.KnightNames[this.Math.rand(0, this.Const.Strings.KnightNames.len() - 1)],
						Row = 2,
						Script = "scripts/entity/tactical/humans/knight",
						Faction = this.Flags.get("EnemyNobleHouse"),
						Callback = null
					});
					this.Contract.setState("Running_FinalBattle");
					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "FinalBattle")
				{
					this.Flags.set("IsFinalBattleLost", true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "FinalBattle")
				{
					this.Flags.set("IsFinalBattleWon", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName() + "领取你的报酬。"
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%employer% 热情地欢迎你入内。尽管他身披铠甲，但身边的指挥官们似乎正极力劝阻他亲自上阵。不过，这位领主依然热情地迎接了你，并迅速说明了他对你的需求。%SPEECH_ON%这场愚蠢的战争即将画上句号。我的主力部队正在 %direction% 集结，你需要前往那里，与 %commander% 会面，他会向你说明如何利用你的能力。如果你能助我们扭转战局，佣兵，你将获得丰厚的报酬。%SPEECH_OFF% | 你走进 %employer% 的房间，看见他正把一面 %feudfamily% 的旗帜喂给几条狗，这些杂种狗熟练而凶狠地撕扯着它。%employer% 抬起头看向你。%SPEECH_ON%啊，佣兵。很高兴你终于来了。我需要你去 %direction% 找 %commander%。该死的战争到了最后阶段，我相信像你这样的人能加速它的终结。除了告诉你这些战争通常会以最壮观的方式结束外，我无法多说什么。当然，你的报酬也会同样壮观。%SPEECH_OFF% | 你走进 %employer% 的房间，发现他被一群将军包围着。他们正俯视着一张地图，上面布满了严阵以待的敌对兵力标记。这位贵族看向了你。%SPEECH_ON%啊，佣兵。我需要你去这里。%SPEECH_OFF%他把一根棍子戳在地图上。%SPEECH_ON%去见 %commander%。我们准备一劳永逸地结束这场战争，而你的帮助至关重要。%SPEECH_OFF%你点了点头，但没有立刻离开。那人挑了挑眉毛，竖起一根手指。%SPEECH_ON%哦对了，你的帮助是有偿的！这一点毋庸置疑。%SPEECH_OFF% | 你无法进入%employer% 的房间。相反，他的一名指挥官在外面拦住了你，手里拿着地图和一份合同。他解释说一场大战即将到来，他们需要你的帮助。如果你选择接受，就去找 %direction% 的 %commander%，并在那里等候进一步指示。 | %employer% 房间外的一名守卫拦住了你。他盯着你身上 %companyname% 的徽记，然后直接对你说道。%SPEECH_ON%我奉命把这个交给你。%SPEECH_OFF%他把一卷羊皮纸拍在你胸口。指令表明一场决定战争走向的大战即将到来，如果你选择帮忙，你就需要前往 %commander% 的营地听候进一步的指示。你询问是应该和他还是 %employer% 讨价还价。守卫艰难地咽了口唾沫，一滴汗珠顺着脸颊滑落。%SPEECH_ON%如果你一定要讨价还价，你可以试着和我谈。%SPEECH_OFF% | %employer% 迎接了你，并带你来到他的私人驯犬师那里。当他在一排狗面前走过时，它们乖巧地坐着。他随手抚摸着它们的头顶，动作随意而充满掌控感。%SPEECH_ON%%commander% 正率领我的军队驻扎在 %direction%，他向我报告说那儿可能会有一场大战。%SPEECH_OFF%贵族停下脚步转向你。%SPEECH_ON%他认为这可能会结束与 %feudfamily% 的战争，所以我希望你去那里帮忙，不惜一切代价结束这场可怕的冲突。%SPEECH_OFF% | 你在满是将军的房间里见到了 %employer%。他的指挥官们怀疑地盯着你，但那人却邀请你到角落里私下交谈。%SPEECH_ON%别介意他们。长话短说，我有一支由 %commander% 领导的军队，就在这里的 %direction%。我需要你去见他，听候进一步指示。我的指挥官们认为决战可能很快就会到来，我们需要一切能得到的帮助。如果这场战斗真的结束了这场战争，你会得到相应的奖赏。%SPEECH_OFF% | 一名守卫让你进入了 %employer% 的房间，在那里你发现那人身陷争吵不休的将军们的包围圈。他们互相大喊大叫，撞翻了地图上的战争筹码，把原本精心策划的作战计划搞得一团糟。%employer% 站起身来亲自接待你。%SPEECH_ON%别管那些噪音。大家之所以焦躁不安，是因为我们很可能正处于结束与 %feudfamily% 的该死的战争的边缘。%commander% 和我的大部分军队正在 %direction% 休整。他召集了一切能召集的援军，包括雇佣兵。如果你去那里并帮我们结束这场狗屎战争，佣兵，你将会得到重赏。%SPEECH_OFF% | %employer% 带你来到猪圈旁。在那里，你看到猪群正在啃食一具尸体。附近，几只山羊正在咀嚼 %feudfamily% 的旗帜。%employer% 转过头，咧嘴一笑。%SPEECH_ON%间谍，你知道这些东西是怎么回事。不管怎样，%commander% 已经向我汇报说，他认为与 %feudfamily% 的最终决战可能迫在眉睫。他请求尽可能多的援助，我也打算派过去。如果你去那里，见他，并按他要求的去做，你会得到极其丰厚的报酬。%SPEECH_OFF% | 你见到了 %employer% 的一名守卫，他把你带到了领主本人面前。他躲在一间狭小的隔间里，远离世间的纷扰。烛光摇曳，他正翻阅着一本书。他甚至没有抬头看你就开口说道。%SPEECH_ON%你好，佣兵。我的前线指挥官 %commander% 派信使告诉我，%feudfamily% 的军队正在集结。他认为我们有机会一劳永逸地结束这场战争。%SPEECH_OFF%那位贵族舔了舔拇指，慢慢翻过一页书，继续说道。%SPEECH_ON%我希望你去加入他。当然，你的报酬会根据你的贡献来定，我猜那一定不会少。%SPEECH_OFF% | %employer% 的一名守卫带你来到一座塔楼顶端，在那里你见到了领主本人。他看着你说。%SPEECH_ON%风景不错，是吧？%SPEECH_OFF%你环顾四周。大地延展开来，人们变成了微小的虫子在上面奔忙。一辆驴车在塔下颠簸驶过，进入 %townname% 做生意。你耸了耸肩。%employer%点点头。%SPEECH_ON%我以为你会欣赏这样的景色，但我猜一个忙于生意的人脑子里不会想这些。而亲爱的佣兵，现在正是生意繁忙的时候。我的一名指挥官报告说，%feudfamily% 的军队正在集结。他认为我们有可能通过一场盛大的决战彻底结束这场战争。你明白吗？%SPEECH_OFF%你点了点头。他接着说。%SPEECH_ON%如果一切顺利，你会得到与服务相匹配的报酬。我不知道你以前是否帮人结束过战争，但许多人都愿意付出天价来换取这样的服务。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "一场伟大的战斗，你说呢？",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{我不会让 %companyname% 接受他人的指挥。 | 我只能婉拒了。 | 别的地方更需要我们。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "WarcampDay1",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{你抵达了营地，那里与其说是军营，不如说更像是一座帐篷之城，你找到了 %commander%。他把你迎进自己的帐篷。那里面与其说是住处，不如说更像是一座地图之城，他正在审视着自己军队的位置，以及他推测 %feudfamily% 军队可能出现的地方。%SPEECH_ON%欢迎，佣兵。你来得正是时候。%SPEECH_OFF% | %commander% 的战地军营里满是无聊的士兵。他们要么在搅动炖锅，要么在玩纸牌游戏。最刺激的娱乐项目就是一场甲虫和蠕虫之间的决斗，但似乎两边都没什么兴趣。%commander% 亲自欢迎了你，并带你走进他的帐篷，那里挂满了地图和各种规划用具。 | 你走进 %commander% 的帐篷，发现一群人的兴致并不高。其中一人喊道。%SPEECH_ON%你们不是我们要的妓女啊。%SPEECH_OFF%士兵们哄堂大笑。%randombrother% 大声回敬。%SPEECH_ON%你妈先伺候过我们。%SPEECH_OFF%不出所料，双方开始拔剑相向。%commander% 亲自介入，阻止了一场流血冲突的发生。他把你带进帐篷。%SPEECH_ON%很高兴你能来，但是如果你想让我们赢得这场该死的战争，你的人最好少给我惹麻烦。%SPEECH_OFF% | 你来到 %commander% 的营地，发现士兵们正在举办甲虫赛跑。他们为甲虫加油助威，但在跑到一半由稻草铺成的赛道上，甲虫们突然掉头互相撕咬起来。士兵们的欢呼声反而变得更大了。%commander% 在人群中找到了你，并把你带到他的帐篷里。%SPEECH_ON%很高兴你来了，佣兵。我现在就有事要交给你做。%SPEECH_OFF% | 抵达 %commander% 的战地军营时，你发现士兵们正在为一个骑着驴、衣衫不整的女人喝彩。那位女士和那头驴随后进入了一顶帐篷，帐篷很快就被涌进去的男人撑得鼓了起来。%randombrother% 问能不能去。你说你也去，所以当然可以。就在这时，%commander% 抓住了你，把你带到了他的指挥帐篷。%SPEECH_ON%相信我，你不会想看那个的。%SPEECH_OFF%你并不相信他。 | %commander% 的战地军营已经把土地变成了泥潭。他们砍光了附近所有的树木，在原地搭建起歪歪斜斜、做工粗糙的小棚屋。帐篷一直延伸到视线尽头，沿途篝火点点，如同白昼天空中的繁星。 你在挂满地图、副官们正等待命令的帐篷里见到了 %commander%。 | 战地军营里充满了叮当作响的声音。铁匠在修理装备，厨师在炖煮着他们声称是食物的可怕玩意儿，士兵们则在为帐篷钉桩子。你在帐篷里见到了 %commander%。虽然隔绝了外面的金属噪音，但取而代之的是他下属们激烈的争吵声。他摇了摇头。%SPEECH_ON%当大战临近时，大家都会紧张。别介意他们的争吵。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "你需要 %companyname% 做什么？",
					function getResult()
					{
						if (this.Flags.get("IsScoutsSighted"))
						{
							return "ScoutsSighted";
						}
						else
						{
							return "RequisitionSupplies1";
						}
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "WarcampDay1End",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{你返回战地军营，命令弟兄们好好休息。谁也不知道明天等待你们的将会是什么。 | %commander% 的任务已经完成了，但明天肯定还会有更多的事情。趁现在赶紧休息吧！ | 战地军营和你离开时一样。你不确定这究竟是好是坏。明天还有更多的烂摊子要处理，于是你命令 %companyname% 的成员抓紧休息。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "好好休息，我们很快就会再次被召唤。",
					function getResult()
					{
						this.Flags.set("LastDay", this.World.getTime().Days);
						this.Flags.set("NextDay", 2);
						this.Contract.setState("Running_WaitForNextDay");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ScoutsSighted",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_54.png[/img]%commander% 向你说明了当前的情况。%SPEECH_ON%{我们的斥候发现了敌方的斥候。不幸的是，我没给我的人配备武器，所以他们请求支援。敌人就在我们 %direction%。把他们全部杀光，%feudfamily% 就会对我们的动向一无所知。 | 我的几个向导在离这里不远的 %direction% 发现了一些 %feudfamily% 的斥候。他们正在到处寻找我们的主力部队，但只要你们去把他们全杀了，他们就找不到。明白了吗？？ | 有人在 %direction% 发现了 %feudfamily% 的斥候。我需要你去把他们全部干掉，赶在他们找到我们或汇报过去几天打探到的情报之前。 | 战争中，情报就是一切。我最近得到消息 %feudfamily% 的斥候正在%direction% 不远的地方游荡。如果我能掌握他们的情况，同时破坏他们对我们的了解，那么我们在接下来的战斗中就将获得巨大的优势。}%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "战团马上出发。",
					function getResult()
					{
						this.Contract.setState("Running_Scouts");
						return 0;
					}

				}
			],
			function start()
			{
				local playerTile = this.Contract.m.Warcamp.getTile();
				local tile = this.Contract.getTileToSpawnLocation(playerTile, 5, 8);
				local party = this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).spawnEntity(tile, "Scouts", false, this.Const.World.Spawn.Noble, 60 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("banner").setBrush(this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getBannerSmall());
				party.setDescription("为地方领主服务的职业士兵。");
				party.setFootprintType(this.Const.World.FootprintsType.Nobles);
				this.Contract.m.UnitsSpawned.push(party);
				party.getLoot().Money = this.Math.rand(50, 100);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 20);
				local r = this.Math.rand(1, 6);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}
				else if (r == 5)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				this.Contract.m.Destination = this.WeakTableRef(party);
				party.setAttackableByAI(false);
				party.setFootprintSizeOverride(0.75);
				local c = party.getController();
				c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
				local roam = this.new("scripts/ai/world/orders/roam_order");
				roam.setPivot(this.Contract.m.Warcamp);
				roam.setMinRange(4);
				roam.setMaxRange(9);
				roam.setAllTerrainAvailable();
				roam.setTerrain(this.Const.World.TerrainType.Ocean, false);
				roam.setTerrain(this.Const.World.TerrainType.Shore, false);
				roam.setTerrain(this.Const.World.TerrainType.Mountains, false);
				c.addOrder(roam);
			}

		});
		this.m.Screens.push({
			ID = "ScoutsEscaped",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{不幸的是，有一些斥候成功逃走了。他们收集到的所有情报现在都落入了 %feudfamily% 手中。 | 全该死！有部分斥候成功逃走了，毫无疑问他们会把这些情报带回 %feudfamily%。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "该死的！",
					function getResult()
					{
						this.Contract.setState("Running_ReturnAfterScouts");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ScoutsCaught",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{所有的斥候都死了。他们掌握的所有情报都随他们一同消亡了。这对即将到来的战斗将是一个巨大的利好。 | 斥候已经全部被歼灭，他们打探到的一切都没了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.setState("Running_ReturnAfterScouts");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "RequisitionSupplies1",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{%commander% 叹了口气，开始说道。%SPEECH_ON%我不想浪费你的才能，佣兵，但我需要有人出去为军队征用粮食。我们的补给快耗尽了，现在急需一切能获得的帮助。%SPEECH_OFF%嘿，既然拿了钱，这就不算侮辱你。 | %commander% 往嘴唇后塞了片干叶子，双臂抱在胸前。%SPEECH_ON%该死，我知道你是来打仗的。我知道你是来杀人的，而且为此能得到丰厚的报酬。但眼下，我的军队得吃饭，为了让他们吃上饭，我需要有人去把粮食弄回来。%SPEECH_OFF%他走到一张地图前，指着上面。%SPEECH_ON%我需要你去见见这些农民，把他们的粮食装车运回来。他们会等着你，应该不会有任何问题。就当是大战前轻松的一天，好吗？%SPEECH_OFF% | %commander% 指着铺在地图上的一卷羊皮纸。上面列着数字，数字越往下越少。%SPEECH_ON%我们的口粮供应已经所剩无几。我们通常通过找 %direction% 的农民征粮。我需要你去那里再取一些回来。他们会等着你，应该不会有问题。%SPEECH_OFF% | 低头看着一个盘子，上面放着一块干面包。旁边的盘子里有块肉，只吃了一半，剩下的正被苍蝇叮咬。角落里一条养得肥壮的狗正摇着尾巴。%commander% 走到一张地图旁边。%SPEECH_ON%我们的存粮快见底了。如果我的人饿着肚子，他们就不会战斗，如果不战斗我们就输了！%SPEECH_OFF% 你点了点头，这个道理显而易见。他继续说道。%SPEECH_ON%这段时间我们一直从%direction%的农民那里获取食物。我需要你去那里照做。我的一名守卫会给你一份清单。农民们不敢反抗，他们知道后果是什么。%SPEECH_OFF% | 你看到帐篷角落里有个勤奋的男人。他正用一支干羽毛笔划过卷轴，一边摇头。突然，他站起身，把那页纸递给 %commander%。指挥官点了点头，然后看向你。%SPEECH_ON%这对某些雇佣兵来说可能有点掉价，但我需要 %companyname% 去 %direction% 的农场征用他们手里的食物。这不是我们军队第一次向这些农民提要求。上次我们去的时候，他们试图反抗，但后来……他们吸取了教训。我的文书会写下我们需要的一切。就当是去集市上逛街购物吧。%SPEECH_OFF% 指挥官嘲弄地咧嘴一笑。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "战团将在一小时内出发。",
					function getResult()
					{
						this.Contract.setState("Running_Requisition");
						return 0;
					}

				}
			],
			function start()
			{
				local settlements = this.World.EntityManager.getSettlements();
				local lowest_distance = 99999;
				local best_location;
				local myTile = this.Contract.m.Warcamp.getTile();

				foreach( s in settlements )
				{
					foreach( l in s.getAttachedLocations() )
					{
						if (l.getTypeID() == "attached_location.wheat_fields" || l.getTypeID() == "attached_location.pig_farm")
						{
							local d = myTile.getDistanceTo(l.getTile());

							if (d < lowest_distance)
							{
								lowest_distance = d;
								best_location = l;
							}
						}
					}
				}

				best_location.setActive(true);
				this.Contract.m.Destination = this.WeakTableRef(best_location);
			}

		});
		this.m.Screens.push({
			ID = "RequisitionSupplies2",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_72.png[/img]{农舍已近在眼前。一片庄稼的海洋在你面前延展，当风掠过时，田地如波浪般起伏。%randombrother% 将手伸进一片麦田里。%randombrother2% 一拳打在他的肩膀上。%SPEECH_ON%你想把虫子带回家吗？把手拿出来。%SPEECH_OFF%那名佣兵揉了揉肩膀，随即回敬了一拳。%SPEECH_ON%去你妈的，我想把手放哪就放哪，不信就去问问你妈。%SPEECH_OFF%拳头迅速升级为混战，这田园诗般的景象瞬间破灭。 | 远处便是农舍。成片的庄稼在清脆的风中摇曳，发出如平静海浪般的沙沙声。农场工人挥舞着镰刀收割，一群帮手则用干草叉将割下的作物装车。驴子在后面拉着板车穿过崎岖不平的地形。 | 农场点缀在群山之间，土壤肥沃得让人不会因为地理障碍而放弃耕种。每一块田地都长满了庄稼，工人们穿行其间，镰刀和干草叉随着他们的一举一动闪闪发光。在远处，你看到农场主们聚在一起站着。他们看起来怒气冲冲，但很少有人敢在 %companyname% 面前一直保持愤怒。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们去拿这次来要的东西吧。",
					function getResult()
					{
						if (this.Flags.get("IsAmbush"))
						{
							return "Ambush";
						}
						else if (this.Flags.get("IsUnrulyFarmers"))
						{
							return "UnrulyFarmers";
						}
						else
						{
							return "CooperativeFarmers";
						}
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Ambush",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_10.png[/img]{当你靠近农民时，两侧突然传来一声大喊，随即跳出一队全副武装的男人。这是一个埋伏！ | 逼近农舍时，那些装满食物的板车开始向后倒退。随着它们挪开，慢慢显露出一支全副武装的队伍。农民们迅速逃离了现场。%randombrother% 拔出了武器。%SPEECH_ON% 这是个埋伏！ %SPEECH_OFF% | 你走向那些运粮车。农民们纷纷闪到一旁，%randombrother% 走上前一把掀开了其中一辆马车上的帆布，里面空空如也。突然，一支箭‘砰’地一声射在马车侧面。农民们趴下身子四散奔逃，而全副武装的人则从两侧涌出。这是一个埋伏！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "Ambush";
						p.Music = this.Const.Music.CivilianTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Center;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
						local n = 0;

						do
						{
							n = this.Math.rand(1, this.Const.PlayerBanners.len());
						}
						while (n == this.World.Assets.getBannerID());

						p.Entities = [];
						p.EnemyBanners = [
							this.Const.PlayerBanners[n - 1],
							"banner_noble_11"
						];
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 100 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Const.Faction.Enemy);
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsArmed, 40 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Const.Faction.Enemy);
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "UnrulyFarmers",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_43.png[/img]你走到农民们面前，结果他们却要反抗。他们的首领双臂抱在胸前，摇了摇头。%SPEECH_ON%{听着，我的人已经把车装好了。我是愿意各退一步的，你知道吗？因为我们也有家人要养活，也有债要还，跟其他人一样。要不这样，你们给我们 %cost% 克朗，我们就当这事没发生过，回去跟 %commander% 也好交代。 | 你们是佣兵，对吧？那你们应该比谁都明白钱的重要性。我们只是普通的农民，又不是钱庄老板。我们只希望得到一点对我们劳动的补偿。你们给我们 %cost% 克朗，粮食就归你们。虽然这协议让我们亏了本，但我认为这很公平。 | 你穿着花里胡哨的衣服大摇大摆地过来，以为能恐吓我们就范？依我看 %commander% 已经拿得够多了，也是时候让他像其他人一样为食物付账了！所以，就这么办。我会以 %cost% 克朗的价格把粮食卖给你。我觉得对于我们提供的东西来说，这个价格非常公道。}%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "你搞清楚自己的身份，农夫。你是想逼我们动手抢吗？",
					function getResult()
					{
						return "TakeItByForce";
					}

				},
				{
					Text = "我懂。 你会得到你的 %cost% 克朗，而我们则拿走补给。",
					function getResult()
					{
						return "PayCompensation";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BeatenByFarmers",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_22.png[/img]埋伏太强了！你带着还能站着的人撤退。%commander% 的部队现在不得不进一步缩减口粮配给，而 %companyname% 在此战败的消息无疑会迅速传开。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "该死的！",
					function getResult()
					{
						this.Flags.set("IsRequisitionFailure", true);
						this.Contract.setState("Running_ReturnAfterRequisition");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "PoorFarmers",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_60.png[/img]{农民们和他们雇佣的佣兵都被击倒了。一名农场工人肠子都流出来了，他在地上向后蹬踹着，乞求怜悯。你摇了摇头。%SPEECH_ON%你们全完了，孩子，现在这样就是对你的仁慈。%SPEECH_OFF%刀刃轻易地划过他的喉咙。他发出咯咯声，但很快就断气了。你命令手下收集粮食，准备返回 %commander% 那里。 | 农民及其雇佣的伏兵已经被杀得一干二净。你下令手下收拢补给物资。%commander% 和他的部下看到你们归来应该会很高兴。 | 有些食物上沾了血，但稍微用水擦洗一下就能弄干净。%commander% 的手下会感激你们在这里的付出。 | %randombrother% 抓起一个装死的农民，一刀割开了他的喉咙。那人发出咯咯声，挣脱了佣兵的抓握。他踉跄着扑向其中一辆马车，在粮食上喷了一身血。你大喊道。%SPEECH_ON%该死，把他弄下来！%SPEECH_OFF%那个农民很快就被处理掉了，但那批货无疑算是毁了。你摇了摇头。%SPEECH_ON%把这些盖个毯子。也许没人会注意到。%SPEECH_OFF% | 拿到这些粮食比预想的要麻烦一点，但现在它们都在你们手中了。你将这片农庄的所有权赐给了一个穿着羊毛袋当鞋的可怜农场帮工，并对他说道？%SPEECH_ON%别忘了你主人在这里遭遇了什么，因为同样的事绝对也会发生在你身上，听明白了吗？%SPEECH_OFF%那孩子迅速点了点头。你命令 %companyname% 准备返回 %commander% 那里。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "一群傻子。",
					function getResult()
					{
						this.Flags.set("RequisitionSuccess", true);
						this.Contract.setState("Running_ReturnAfterRequisition");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "CooperativeFarmers",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{农民们热情地迎接了你。%SPEECH_ON%让我猜猜，是 %commander% 派你们来的吧？%SPEECH_OFF% 你点了点头。那农民吐了口唾沫，也点了点头。%SPEECH_ON%行吧。你们在这里不会有任何麻烦。伙计们，帮他们把货装上路。%SPEECH_OFF% 农场工人走出来帮助你的手下搬运补给物资，并准备启程返回 %commander% 那里。 | 你见到了农民的头领。他握了握你的手。%SPEECH_ON% %commander% 的信鸽告诉我，他会派佣兵来，但你们这身行头看起来比任何我见过的佣兵团都要强上一筹。我的小伙子们会帮你们装车，这样你们就能尽快上路了。%SPEECH_OFF% | 当你走近时，农民们已经开始往马车上装货了。他们的首领走上前说道。%SPEECH_ON%我对做这事可不高兴，但我宁愿待在这些田地里，也不想坐在某个战地营里等死，况且那场战争我根本不在乎。我的人会帮你们装车，你们好赶紧离开。等你见到 %commander% 的时候，请替我说句好话，行吗？我想继续种地。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我相信 %noblehouse% 会很感激你的。",
					function getResult()
					{
						this.Flags.set("RequisitionSuccess", true);
						this.Contract.setState("Running_ReturnAfterRequisition");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "TakeItByForce",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_43.png[/img]{你拔出了剑。农民们纷纷后退，一阵抓起干草叉的叮当声在他们中间响起。他们的首领吐了口唾沫，用袖子抹了抹嘴。%SPEECH_ON%该死，你想在这儿动手？那我们就奉陪到底。%SPEECH_OFF% | 你摇了摇头。%SPEECH_ON%没得谈。交出粮食，否则就尝尝我们的厉害。%SPEECH_OFF%那农民挥舞着干草叉。他的手下开始慢慢拿起武器。他点了点头。%SPEECH_ON%我们是农民，混蛋。早在很久很久以前，天谴就已经选择了我们。%SPEECH_OFF% | 你来这里可不是为了谈条件的。%SPEECH_ON%不会有任何补偿的。%commander%派我们来是为了……%SPEECH_OFF%那农民大笑着打断了你。%SPEECH_ON%指挥官派来了几条哈巴狗。那我告诉你吧，小狗狗，让我们看看你的手下是不是只会叫唤不会咬人。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "别废话，赶紧的。",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "TakeItByForce";
						p.Music = this.Const.Music.CivilianTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.Entities = [];
						p.EnemyBanners = [
							"banner_noble_11"
						];
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Peasants, 80 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Const.Faction.Enemy);
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "PayCompensation",
			Title = "在农场…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{你认为，仅仅因为这些贫穷的农民想要活下去而流血是毫无理由的。交出克朗时，你警告那名农民，以后做这种交易要小心点。%SPEECH_ON%并不是每个人都像我这样好心，愿意和你们谈条件。%SPEECH_OFF%那农民转过头，露出了一道从头皮延伸到肩膀的长疤。%SPEECH_ON%我很清楚。感谢你的体谅，佣兵。%SPEECH_OFF% | 你杀农民只有在有人为此付钱的时候才会动手。而 %commander% 并没有。你同意了农民们的条件。他们的首领握了握你的手。%SPEECH_ON%谢谢你，佣兵。很少见到愿意退让一步的人。我本来以为你是个粗人，但显然你很有头脑。%SPEECH_OFF% | 你大老远跑来不是为了屠杀这些可怜的农民的。你同意了那人的条件。他感谢你没有大老远跑来屠杀他们。然而，%randombrother% 却小声嘀咕说他大老远跑来可不是为了……你大声让他闭嘴，并开始装车。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "让我们快点回到军营去吧。",
					function getResult()
					{
						this.Flags.set("RequisitionSuccess", true);
						this.Contract.setState("Running_ReturnAfterRequisition");
						return 0;
					}

				}
			],
			function start()
			{
				this.World.Assets.addMoney(-this.Flags.get("RequisitionCost"));
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你花费了 [color=" + this.Const.UI.Color.NegativeEventValue + "]" + this.Flags.get("RequisitionCost") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "WarcampDay2",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{早上的阳光溜进你的帐篷，直直地照在你的眼睛上，仿佛特意提醒你：又得忍受新的一天了。 | 你起身穿上靴子，顺手拍死几只以为这里是过夜好地方的蜘蛛。 | 帐篷外，一只公鸡正大声地向所有人宣告它是一只多么讨厌的动物。你极不情愿地爬了起来。 | 你又醒来了，迎接新的一天。太棒了。 | 你睡得像个死人，醒来也像具尸体。透进帐篷的阳光太过刺眼，让你没法再睡回去，而帐门帘又离得太远，懒得去关。见鬼去吧，还是起来算了。 | 早晨。那个不可避免的时刻，伴随着新一天的光辉，成千上万的悔恨如约而至。}\n一个男孩站在你的帐篷外，手里拿着一卷羊皮纸。他展开信件，费力地试图辨认上面的文字并读出来。%SPEECH_ON%{你的...指挥官...要求见你。 | %commander% 想见你，快去吧。 | 先生，这张纸让我告诉你，你...应该...去见指挥官。后面还有很多内容，但如果我试着读完，我们得耗上一整天。 | 是这样的，我其实真的不识字，但我猜指挥官想见您。 | 让我看看，这封信...我知道这是封信...这是字母“I”，我觉得剩下的句子应该都是些我看不懂的鬼东西。听着，直接去见指挥官吧，我觉得这就是他想要的。}%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候去拜访一下指挥官了…",
					function getResult()
					{
						if (this.Flags.get("IsInterceptSupplies"))
						{
							return "InterceptSupplies";
						}
						else
						{
							return "Deserters1";
						}
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "InterceptSupplies",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]你在帐篷中见到了 %commander%。他看起来相当兴奋，身旁站着一个精明且神秘的小个子男人。指挥官急切地说道。%SPEECH_ON%{据我手下的探子报告说，有一批装备正运往 %feudfamily% 的军队。如果我们能拦截并摧毁它，他们未来的战斗力就会大打折扣！ | 你好，佣兵。我的探子告诉我，%feudfamily% 有一批急需的装备正在运往他们的营地。我需要你去把它毁了。 | 间谍难道不是最棒的吗？看看这个小个子男人。他告诉我，先生，%feudfamily% 有一大批物资即将到来。武器、盔甲、食物等等。我说，我正好有个人可以利用这个消息：就是你！去找这批货，把它们全部销毁。 | 你知道吗，很多时候仗还没打就已经赢了。我这个小探子告诉我，%feudfamily% 有一批武器和盔甲要运过来。如果你能搞定它，他们的军队在开阔地带作战的准备就会差得多。 | 你知道吗，我曾经不费一兵一卒就赢得了一场战斗。我设法拦截了一批物资，让我的敌人完全没有准备好战斗，所以他们投降了。我这个小探子告诉我，%feudfamily% 也有一批同样的装备正在运来。我确信这不会结束战争，但如果你能去把它搞定，那将是一个巨大的帮助。 | 你知道的，一支没有装备的军队根本算不上军队。%feudfamily% 的军队补给已经所剩无几了。事实上，他们迟迟没有进攻的原因就是他们在等更多的武器和盔甲到达！好了，我这个小探子发现了那批物资。我要你去把它毁了。 | 我得到了一个极好的消息，佣兵。%feudfamily% 正在等待武器和盔甲的到来——而且我们确切知道是从哪里来的。我只需要你去做一件显而易见的事：摧毁那批物资，在敌人还不知道发生了什么之前就重创他。}%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "战团马上出发。",
					function getResult()
					{
						this.Contract.setState("Running_InterceptSupplies");
						return 0;
					}

				}
			],
			function start()
			{
				local startTile = this.World.getEntityByID(this.Flags.get("InterceptSuppliesStart")).getTile();
				local destTile = this.World.getEntityByID(this.Flags.get("InterceptSuppliesDest")).getTile();
				local enemyFaction = this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse"));
				local party = enemyFaction.spawnEntity(startTile, "Supply Caravan", false, this.Const.World.Spawn.NobleCaravan, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("base").Visible = false;
				party.getSprite("banner").setBrush(this.World.FactionManager.getFaction(this.Flags.get("EnemyNobleHouse")).getBannerSmall());
				party.setMirrored(true);
				party.setVisibleInFogOfWar(true);
				party.setImportant(true);
				party.setDiscovered(true);
				party.setDescription("一支由武装护卫押运，负责在各定居点之间运输给养、补给和装备的车队。");
				party.setFootprintType(this.Const.World.FootprintsType.Caravan);
				party.getFlags().set("IsCaravan", true);
				party.setAttackableByAI(false);
				party.getFlags().add("ContractSupplies");
				this.Contract.m.Destination = this.WeakTableRef(party);
				this.Contract.m.UnitsSpawned.push(party);
				party.getLoot().Money = this.Math.rand(50, 100);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 20);
				local r = this.Math.rand(1, 6);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}
				else if (r == 5)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				local c = party.getController();
				c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
				c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
				local move = this.new("scripts/ai/world/orders/move_order");
				move.setDestination(destTile);
				move.setRoadsOnly(true);
				local despawn = this.new("scripts/ai/world/orders/despawn_order");
				c.addOrder(move);
				c.addOrder(despawn);
			}

		});
		this.m.Screens.push({
			ID = "SuppliesReachedEnemy",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{你没能摧毁那支商队。显然，所有的物资都已经送到了 %feudfamily% 的军队手里，这会让接下来几天的战斗变得困难得多。 | 那支商队没有被摧毁。你可以确信，%feudfamily% 的军队在即将到来的大战中将会接近满编状态。 | 唉，该死。那支商队没毁掉。现在。%feudfamily% 的军队将会为接下来的战斗做好充分的准备。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们应该回营地了…",
					function getResult()
					{
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SuppliesIntercepted",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_60.png[/img]{你原本打算从商队那里尽可能地劫掠一番，但守卫们在物资被抢走之前就将它全部烧毁了。虽然很遗憾，但重要的是 %feudfamily% 的军队没能得到这些装备。 | 你摧毁了商队的大部分物资，而剩下的则是守卫们为了防止落入敌人手中而自行销毁的。%commander% 对这一结果会非常满意。 | 这场战斗非常激烈，但你还是成功消灭了所有的商队护卫。不幸的是，这支队伍似乎采取了焦土政策，在被俘获前设法烧毁了每一辆马车，他们知道绝不能让这些装备落入敌人手中。尽管如此，%commander% 还是会非常高兴。 | 总的来说，商队守卫进行了顽强的抵抗，但 %companyname% 还是将他们全数消灭。至少你这样认为：战斗中，有一名守卫设法溜走并实施了焦土战术，点燃了所有的马车。显然，如果 %feudfamily% 得不到这些装备，那谁也别想得到。这很烦人，但也很明智。尽管如此，%commander% 和他的部下还是会欣然接受这个消息。 | 商队已被彻底摧毁。你原本希望能俘获马车并将装备据为己有，但其中一名守卫还是成功将所有车辆点燃了，毫无疑问是为了防止物资落入敌人手中。不管怎样，%feudfamily% 的军队肯定因此被削弱了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "即将到来的战斗中，又少了一个麻烦。",
					function getResult()
					{
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Deserters1",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{你刚钻进%commander% 的帐篷，一支蜡烛就擦着你的脸飞了过去。烛芯滋滋作响地落入泥泞中，紧接着一张桌子也翻滚着飞出，上面的地图散落一地。只见 %commander% 脸红脖子粗地站在一片狼藉的尽头，双手叉腰，大口喘着粗气平复情绪。他向你解释道。%SPEECH_ON%逃兵！他们竟然跑了！就在我人生最重要战役的前夕，我连这群该死的手下都留不住吗？听着，我不能让这支军队就这样分崩离析。你必须去把那些逃兵找回来，带回到我面前。如果他们拒绝回来……那就把他们都杀了！有个哨兵说看到他们往 %direction% 去了。快去！%SPEECH_OFF% | 就在你准备进入 %commander% 的帐篷时，一个人影突然从里面飞了出来。%commander% 随即冲出帐篷，一把将那人按进泥里。他揪住对方的衣领，像提布娃娃一样把他拎了起来，吼道。%SPEECH_ON%他们去哪儿了？我以旧神之名发誓，如果你敢不说实话，我就让你求生不得求死不能！%SPEECH_OFF%那个男人大喊大叫指着一个方向。%SPEECH_ON%那边，他们往 %direction% 走走了，我发誓！%SPEECH_OFF%%commander% 扔下那人，卫兵迅速将他拖走。指挥官站直身子，用手捋了一把头发，对你说道。%SPEECH_ON%佣兵，我的几个手下觉得逃跑是最佳选择。去把他们找回来，带回来给我。明白吗？%SPEECH_OFF%你点了点头，但追问如果那些人拒绝回来怎么办。指挥官耸了耸肩。%SPEECH_ON%当然是把他们全杀了。%SPEECH_OFF% | 你走进 %commander%的帐篷，发现他正从一名坐着的人身边退开。指挥官手里拿着一把钳子，钳口间夹着一颗白森森的牙齿。你注意到那个坐着的人已经昏了过去，脑袋耷拉着，嘴角流着血。%commander% 把钳子扔在桌上，用沾满鲜血的手搓了搓头发。%SPEECH_ON%	的几个手下叛逃了。我不能冒这个险让军队在这个节骨眼上散伙，马上就要打仗了。我这位朋友，当他还清醒的时候，告诉我，他的同伙们觉得往 %direction% 跑是最好的选择。去吧，佣兵，把那些逃兵带回来给我。%SPEECH_OFF%在你离开前，你问如果逃兵拒绝回来该怎么办。指挥官狠狠地瞪了你一眼。%SPEECH_ON%你觉得呢？杀了他们！%SPEECH_OFF% | 你发现 %commander% 正对着地图沉思。他的指关节用力到发白，死死扣在桌面上，桌腿发出不堪重负的呻吟和摇晃。他抬起头，眼中闪过一道难以置信的怒火。%SPEECH_ON%我的几个手下觉得有必要逃离我的军队，哨兵告诉我他们往 %direction% 跑了。去，抓他们回来。%SPEECH_OFF%你问他是否要抓活的。他点了点头。%SPEECH_ON%我希望他们毫发无伤地回来，这样我才能更好地提醒他们抛弃军队意味着什么。当然，如果他们坚决不从，那我就要他们死。这也是个很好的警示，不是吗？%SPEECH_OFF% | %commander% 把一名副官绑在帐篷柱子上。他手里拿着一根长棍，不停地抽打副官的胸口和双腿。那人惨叫着身体旋转，后背又挨了一顿揍。当副官转回正面时，他那张发紫的脸正喷着鼻息，眼看就要昏厥。\n\n%commander% 扔下棍子，开始从手指里挑出木刺。%SPEECH_ON%很高兴你来了，佣兵。我的几个手下叛逃了，我需要你去找到他们。把他们活着带回来，如果他们拒绝就全杀了。我这位朋友说他们往 %direction% 跑了。希望他说的是真的。 %SPEECH_OFF%你也希望他说的是真的。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "战团将在一小时内出发。",
					function getResult()
					{
						this.Contract.setState("Running_Deserters");
						return 0;
					}

				}
			],
			function start()
			{
				local playerTile = this.World.State.getPlayer().getTile();
				local tile = this.Contract.getTileToSpawnLocation(playerTile, 5, 10, [
					this.Const.World.TerrainType.Shore,
					this.Const.World.TerrainType.Mountains
				]);
				local party = this.World.FactionManager.getFaction(this.Contract.getFaction()).spawnEntity(tile, "Deserters", false, this.Const.World.Spawn.Noble, 80 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
				party.getSprite("banner").setBrush("banner_deserters");
				party.setFootprintType(this.Const.World.FootprintsType.Nobles);
				party.setAttackableByAI(false);
				party.getController().getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
				party.setFootprintSizeOverride(0.75);
				this.Const.World.Common.addFootprintsFromTo(playerTile, party.getTile(), this.Const.GenericFootprints, this.Const.World.FootprintsType.Nobles, 0.75);
				this.Contract.m.Destination = this.WeakTableRef(party);
				party.getLoot().Money = this.Math.rand(50, 100);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 20);
				local r = this.Math.rand(1, 6);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}
				else if (r == 5)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				local c = party.getController();
				local wait = this.new("scripts/ai/world/orders/wait_order");
				wait.setTime(9000.0);
				c.addOrder(wait);
			}

		});
		this.m.Screens.push({
			ID = "Deserters2",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{你发现逃兵们正围坐在一簇只有余烬的营火旁，而其中一人正拼命用尘土盖灭余烬。看到你，他停了下来。其余的逃兵顺着他的目光看去，随后猛地跳了起来。%SPEECH_ON%我们才不会回去，你可以告诉，让他 %commander% 去死。%SPEECH_OFF% | 当你闯入时，逃兵们正在互相争吵。其中一个男人往后一跳。%SPEECH_ON%是 %commander% 派你来的，对吧？那你回去告诉他去死。%SPEECH_OFF%另一个男人挥舞着拳头%SPEECH_ON%没错，我们才不会回去呢！%SPEECH_OFF%他们无疑是一群乌合之众。 | %randombrother% 指出一群站在路牌旁的男人。他们互相争吵的声音太大，以至于没听见你靠近。你吹了一声响亮的口哨，这同时让他们安静下来并转过身。其中一人后退一步。%SPEECH_ON%那个该死的指挥官派佣兵追我们？%SPEECH_OFF%你点点头，并解释说他们应该跟你回去。另一个逃兵摇了摇头%SPEECH_ON%回去？你可以滚了？我们不回去，你就这样去告诉指挥官。%SPEECH_OFF% | 发现逃兵们正在分享一个羊毛袋里的食物。看到你，他们停顿了一下，其中一人试图把嘴里的食物一口吞下去。他被噎住了。其他人一动不动。那个被噎的人慌乱地寻求帮助，脸涨得发紫。他的双腿在羊毛袋上乱蹬，把食物踢得到处都是。你点点头。%SPEECH_ON%帮一下你的同伴吧。%SPEECH_OFF%逃兵们迅速跑向那个被噎的人，把食物从他喉咙里弄了出来。他大口喘着气。你开始解释 %commander% 让你做什么，但其中一个逃兵打断了你。%SPEECH_ON%不，我们不会回去。这场战争毫无意义，我们不想参与。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "这就是你想成为的人吗？连自己的家园都不敢保卫的懦夫？",
					function getResult()
					{
						return this.Math.rand(1, 100) <= 50 ? "DesertersAcceptMotivation" : "DesertersRefuseMotivation";
					}

				},
				{
					Text = "你的选择很简单。 为你的领主而战，或者死在这里。",
					function getResult()
					{
						return this.Math.rand(1, 100) <= 50 ? "DesertersAcceptThreats" : "DesertersRefuseThreats";
					}

				},
				{
					Text = "明人不说暗话。 如果你回来的话，你们会得到 %bribe% 克朗。",
					function getResult()
					{
						return "DesertersAcceptBribe";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "DesertersAcceptBribe",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{你拿出一个袋子，放进了 %bribe% 克朗。%SPEECH_ON%我会亲自付钱，让你们跟我回战地军营。别搞错了。%commander% 对你们非常愤怒，但他需要每一个能用的人。如果你们在即将到来的战斗中为他效力，我毫不怀疑他会宽恕你们这次犯下的小错。%SPEECH_OFF% | 你给了这些逃兵 %bribe% 克朗。逃兵们相互看了看，然后对你说。%SPEECH_ON%当指挥官要把我们全绞死的时候，钱还有什么用？%SPEECH_OFF%你点点头回答。%SPEECH_ON%问得好，但 %commander% 不是傻子。为了即将到来的战斗，他需要集结所有能召集到的人手。只要在战场上证明自己，你们这次闹剧就会被忘得一干二净。%SPEECH_OFF%}{逃兵们权衡了一番选择，最终同意跟你回去。 | 逃兵们聚在一起商量，达成了某种协议。散开后，他们的头领走上前来。%SPEECH_ON%尽管有人反对，但我们同意跟你回军营。希望我不会因此后悔。%SPEECH_OFF% | 经过短暂的商议，逃兵们进行了投票。虽然不是全票通过，但他们达成了协议：他们将和你一起回 %commander% 那里。 | 逃兵们争论着下一步该怎么办。最后，不可避免地进行了一场投票。不出所料，结果是平局。于是这些人同意抛硬币决定：正面就回军营，反面就离开。头领抛起硬币，所有人都盯着它在空中翻转、闪烁。硬币落地，是正面。看到这一幕，他们每个人都叹了口气，仿佛命运和运气替他们卸下了本不该由他们自己做出选择的巨大负担。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "这对即将到来的战斗会有帮助。",
					function getResult()
					{
						this.Contract.m.Destination.die();
						this.Contract.m.Destination = null;
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			],
			function start()
			{
				this.World.Assets.addMoney(-this.Flags.get("Bribe"));
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你花费了 [color=" + this.Const.UI.Color.NegativeEventValue + "]" + this.Flags.get("Bribe") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "DesertersAcceptThreats",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{%bigdog% 走上前来，轻松地将一把武器甩到肩上。他点了点头。%SPEECH_ON%你们害怕 %commander%，我理解。你们了解他，知道他的脾气，也知道他能干出什么事。问题是......%SPEECH_OFF%这名佣兵咧嘴一笑，狡黠的笑容映照在刀刃的寒光中。%SPEECH_ON%你们了解我吗？%SPEECH_OFF% | 当逃兵们看起来正准备离开时，%bigdog% 突然吹了一声响亮的口哨。%SPEECH_ON%嘿，你们这群废物，我的头儿给你们下了命令。%SPEECH_OFF%其中一个逃兵嗤之以鼻。%SPEECH_ON%是吗？他又不是我们该死的指挥官，你把那命令塞回去吧。%SPEECH_OFF%%bigdog%拔出一把巨大的刀，‘哐’地一声插在地上，双手合十撑在剑柄上。%SPEECH_ON%你害怕 %commander%，这很正常。但如果你要继续当个混账小子，我们倒要看看，你究竟该真正害怕哪一个指挥官。%SPEECH_OFF% | 逃兵们转身想要离开。 %bigdog%拔出一把巨刃，在盔甲上重重一磕。逃兵们缓缓转回身。%bigdog% 微笑着问道。%SPEECH_ON%你们有人尿过裤子吗?%SPEECH_OFF%一个逃兵摇了摇头。%SPEECH_ON%嘿，伙计，别说这种废话了。%SPEECH_OFF%%bigdog% 抢过他的刀，将刀尖指向逃兵。%SPEECH_ON%哦？你想让我闭嘴？再敢这样跟我说话，很快这里就没任何人能说话了。%SPEECH_OFF%}{逃兵们权衡了一番利弊，最终同意跟你回去。 | 逃兵们聚在一起商量，达成了某种协议。散开后，他们的头领走上前来。%SPEECH_ON%尽管有人反对，但我们同意跟你回军营。希望我不会因此后悔。%SPEECH_OFF% | 经过短暂的商议，逃兵们进行了投票。虽然不是全票通过，但他们达成了协议：他们将和你一起回 %commander% 那里。 | 逃兵们争论着下一步该怎么办。最后，不可避免地进行了一场投票。不出所料，结果是平局。于是这些人同意抛硬币决定：正面就回军营，反面就离开。头领抛起硬币，所有人都盯着它在空中翻转、闪烁。硬币落地，是正面。看到这一幕，他们每个人都叹了口气，仿佛命运和运气替他们卸下了本不该由他们自己做出选择的巨大负担。}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "你做了正确的决定。",
					function getResult()
					{
						this.Contract.m.Destination.die();
						this.Contract.m.Destination = null;
						this.Contract.m.Dude = null;
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			],
			function start()
			{
				local brothers = this.World.getPlayerRoster().getAll();
				local candidates = [];

				foreach( bro in brothers )
				{
					if (bro.getSkills().hasSkill("trait.player"))
					{
						continue;
					}

					if (bro.getSkills().hasSkill("trait.bloodthirsty") || bro.getSkills().hasSkill("trait.brute") || bro.getBackground().getID() == "background.raider" || bro.getBackground().getID() == "background.sellsword" || bro.getBackground().getID() == "background.hedge_knight" || bro.getBackground().getID() == "background.brawler")
					{
						candidates.push(bro);
					}
				}

				if (candidates.len() == 0)
				{
					candidates = brothers;
				}

				this.Contract.m.Dude = candidates[this.Math.rand(0, candidates.len() - 1)];
				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "DesertersAcceptMotivation",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{当逃兵们转身准备离开时，%motivator% 走上前来清了清嗓子。%SPEECH_ON%所以，事情就要这么定了是吗？你们打算像一群软蛋一样逃避责任？我理解你们的感受。我知道你们觉得这场战争毫无意义，不值得为那些高高在上、根本不懂你们疾苦的贵族拼命。这很公平。但几年后的某一天，当你坐在摇椅上逗弄孙子时，他会问你关于战争的事。而你，将不得不对那个小男孩撒谎。%SPEECH_OFF% | %motivator% 将手指放在唇边，吹了一声尖锐的口哨。逃兵们转过身，他开始说道。%SPEECH_ON%所以就是这样吗？你们真的要故意背负这样的罪名吗？当那一天来临时，你们要怎么告诉你们的后代？说你们是一群抛弃战友、让他们替自己去死的无用逃兵？别搞错了，你的缺席会导致本不该死去的人丧命！你的不在场会造成无法估量的后果！%SPEECH_OFF% | %motivator% 冲着逃兵们喊道。%SPEECH_ON%好吧，现在你们走了。扔下旗帜，结束这场战役。但如果 %feudfamily% 赢得了这场战争，会发生什么？%SPEECH_OFF%其中一个逃兵耸了耸肩。%SPEECH_ON%他们不认识我。我会回家种地。%SPEECH_OFF%%motivator% 笑着摇了摇头。%SPEECH_ON%是吗？当那些外乡人来到你的农场时你怎么办？当他们看到你的妻子？看到你的孩子？你到底知不知道这场战争是为了什么？你这个蠢货，到时候根本就没有家可以让你回去！%SPEECH_OFF%}{逃兵们权衡了一番利弊，最终同意跟你回去。 | 逃兵们聚在一起商量，达成了某种协议。散开后，他们的头领走上前来。%SPEECH_ON%尽管有人反对，但我们同意跟你回军营。希望我不会因此后悔。%SPEECH_OFF% | 经过短暂的商议，逃兵们进行了投票。虽然不是全票通过，但他们达成了协议：他们将和你一起回 %commander% 那里。 | 逃兵们争论着下一步该怎么办。最后，不可避免地进行了一场投票。不出所料，结果是平局。于是这些人同意抛硬币决定：正面就回军营，反面就离开。头领抛起硬币，所有人都盯着它在空中翻转、闪烁。硬币落地，是正面。看到这一幕，他们每个人都叹了口气，仿佛命运和运气替他们卸下了本不该由他们自己做出选择的巨大负担。}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "你做了正确的决定。",
					function getResult()
					{
						this.Contract.m.Destination.die();
						this.Contract.m.Destination = null;
						this.Contract.m.Dude = null;
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			],
			function start()
			{
				local brothers = this.World.getPlayerRoster().getAll();
				local highest_bravery = 0;
				local best;

				foreach( bro in brothers )
				{
					if (bro.getCurrentProperties().getBravery() > highest_bravery)
					{
						best = bro;
					}
				}

				this.Contract.m.Dude = best;
				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "DesertersRefuseThreats",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{%bigdog% 走上前来，轻松地将一把武器甩到肩上。他点了点头。%SPEECH_ON%你们害怕 %commander%，我理解。你们了解他，知道他的脾气，也知道他能干出什么事。问题是......%SPEECH_OFF%这名佣兵咧嘴一笑，狡黠的笑容映照在刀刃的寒光中。%SPEECH_ON%你们了解我吗？%SPEECH_OFF% | 当逃兵们看起来正准备离开时，%bigdog% 突然吹了一声响亮的口哨。%SPEECH_ON%嘿，你们这群废物，我的头儿给你们下了命令。%SPEECH_OFF%其中一个逃兵嗤之以鼻。%SPEECH_ON%是吗？他又不是我们该死的指挥官，你把那命令塞回去吧。%SPEECH_OFF%%bigdog%拔出一把巨大的刀，‘哐’地一声插在地上，双手合十撑在剑柄上。%SPEECH_ON%你害怕 %commander%，这很正常。但如果你要继续当个混账小子，我们倒要看看，你究竟该真正害怕哪一个指挥官。%SPEECH_OFF% | 逃兵们转身想要离开。 %bigdog%拔出一把巨刃，在盔甲上重重一磕。逃兵们缓缓转回身。%bigdog% 微笑着问道。%SPEECH_ON%你们有人尿过裤子吗?%SPEECH_OFF%一个逃兵摇了摇头。%SPEECH_ON%嘿，伙计，别说这种废话了。%SPEECH_OFF%%bigdog% 抢过他的刀，将刀尖指向逃兵。%SPEECH_ON%哦？你想让我闭嘴？再敢这样跟我说话，很快这里就没任何人能说话了。%SPEECH_OFF%}{逃兵们内部无法达成一致，于是进行了投票。继续逃跑的选项获得了多数票。他们的头领向你告知了这个民主的结果，并祝你一路顺风。%commander% 听到这个消息一定会大发雷霆，但你拔出剑，告诉他们只有另一条路可走。头领转过身，拔出他的刀并点头说道。%SPEECH_ON%好吧，我就猜到你大老远跑来不只是为了听我们说再见。全体准备战斗。%SPEECH_OFF% | %commander% 可能会对此很不满，但逃兵们拒绝回头。他们认为没有理由重新跳回火坑。你祝他们的头领好运。他感谢你，但当你拔出武器、其余 %companyname% 的成员紧随其后时，他迅速沉默了。头领叹了口气。%SPEECH_ON%是啊，我就知道事情会这样。%SPEECH_OFF%你点点头说道。%SPEECH_ON%没什么私人恩怨。我不在乎你们做什么，但这笔生意必须有个了结。%SPEECH_OFF% | 逃兵们无法做出决定，于是求助于运气：头领掏出一枚硬币抛向空中。正面就回军营，反面就继续离开。硬币落地，是反面。逃兵们集体松了一口气。 他们的头领拍了拍你的肩膀。%SPEECH_ON%命运已经决定了我们的归宿.%SPEECH_OFF% 你点点头，拔出剑，身后的队员们也纷纷效仿。%SPEECH_ON%记住这一点，因为我们要杀光你们所有人。%SPEECH_OFF% 头领露出一丝苦笑，拔出剑。%SPEECH_ON%没关系。与其回到那个磨盘里去，我们宁愿死在通往自由的门槛上。%SPEECH_OFF% | 头领礼貌地拒绝了回去。%SPEECH_ON%佣兵，我们不是轻率地选择这条路的。我们不会回去。%SPEECH_OFF%你下令 %companyname% 拔出武器。逃兵头领叹了口气，但理解地点点头。%SPEECH_ON%我想这就是命吧。我们早就讨论过这种可能，我们宁愿死在自己想去的地方，也不愿死在某个狗娘养的命令下。现在，这个世界就是我们的一切。%SPEECH_OFF%你耸了耸肩回道。%SPEECH_ON%对我们来说，这只是笔生意而已。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "让我们赶紧把事情了解了吧……",
					function getResult()
					{
						this.Contract.m.Dude = null;
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos(), true);
						p.CombatID = "Deserters";
						p.Music = this.Const.Music.CivilianTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.TemporaryEnemies = [
							this.Contract.getFaction()
						];
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							"banner_deserters"
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			],
			function start()
			{
				local brothers = this.World.getPlayerRoster().getAll();
				local candidates = [];

				foreach( bro in brothers )
				{
					if (bro.getSkills().hasSkill("trait.player"))
					{
						continue;
					}

					if (bro.getSkills().hasSkill("trait.bloodthirsty") || bro.getSkills().hasSkill("trait.brute") || bro.getBackground().getID() == "background.raider" || bro.getBackground().getID() == "background.sellsword" || bro.getBackground().getID() == "background.hedge_knight" || bro.getBackground().getID() == "background.brawler")
					{
						candidates.push(bro);
					}
				}

				if (candidates.len() == 0)
				{
					candidates = brothers;
				}

				this.Contract.m.Dude = candidates[this.Math.rand(0, candidates.len() - 1)];
				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "DesertersRefuseMotivation",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_88.png[/img]{当逃兵们转身准备离开时，%motivator% 走上前来清了清嗓子。%SPEECH_ON%所以，事情就要这么定了是吗？你们打算像一群软蛋一样逃避责任？我理解你们的感受。我知道你们觉得这场战争毫无意义，不值得为那些高高在上、根本不懂你们疾苦的贵族拼命。这很公平。但几年后的某一天，当你坐在摇椅上逗弄孙子时，他会问你关于战争的事。而你，将不得不对那个小男孩撒谎。%SPEECH_OFF% | %motivator% 将手指放在唇边，吹了一声尖锐的口哨。逃兵们转过身，他开始说道。%SPEECH_ON%所以就是这样吗？你们真的要故意背负这样的罪名吗？当那一天来临时，你们要怎么告诉你们的后代？说你们是一群抛弃战友、让他们替自己去死的无用逃兵？别搞错了，你的缺席会导致本不该死去的人丧命！你的不在场会造成无法估量的后果！%SPEECH_OFF% | %motivator% 冲着逃兵们喊道。%SPEECH_ON%好吧，现在你们走了。扔下旗帜，结束这场战役。但如果 %feudfamily% 赢得了这场战争，会发生什么？%SPEECH_OFF%其中一个逃兵耸了耸肩。%SPEECH_ON%他们不认识我。我会回家种地。%SPEECH_OFF%%motivator% 笑着摇了摇头。%SPEECH_ON%是吗？当那些外乡人来到你的农场时你怎么办？当他们看到你的妻子？看到你的孩子？你到底知不知道这场战争是为了什么？你这个蠢货，到时候根本就没有家可以让你回去！%SPEECH_OFF%}{逃兵们无法做出决定，于是通过投票，选择继续逃跑。他们的领袖告诉您这个民主的结果并给您告别。%commander%不会高兴，但您取出剑告诉逃兵只有另一条路可走。领袖转身，拔出剑点头示意。%SPEECH_ON%逃兵们内部无法达成一致，于是进行了投票。继续逃跑的选项获得了多数票。他们的头领向你告知了这个民主的结果，并祝你一路顺风。%commander% 听到这个消息一定会大发雷霆，但你拔出剑，告诉他们只有另一条路可走。头领转过身，拔出他的刀并点头说道。%SPEECH_ON%好吧，我就猜到你大老远跑来不只是为了听我们说再见。全体准备战斗。%SPEECH_OFF% | %commander% 可能会对此很不满，但逃兵们拒绝回头。他们认为没有理由重新跳回火坑。你祝他们的头领好运。他感谢你，但当你拔出武器、其余 %companyname% 的成员紧随其后时，他迅速沉默了。头领叹了口气。%SPEECH_ON%是啊，我就知道事情会这样。%SPEECH_OFF%你点点头说道。%SPEECH_ON%没什么私人恩怨。我不在乎你们做什么，但这笔生意必须有个了结。%SPEECH_OFF% | 逃兵们无法做出决定，于是求助于运气：头领掏出一枚硬币抛向空中。正面就回军营，反面就继续离开。硬币落地，是反面。逃兵们集体松了一口气。 他们的头领拍了拍你的肩膀。%SPEECH_ON%命运已经决定了我们的归宿.%SPEECH_OFF% 你点点头，拔出剑，身后的队员们也纷纷效仿。%SPEECH_ON%记住这一点，因为我们要杀光你们所有人。%SPEECH_OFF% 头领露出一丝苦笑，拔出剑。%SPEECH_ON%没关系。与其回到那个磨盘里去，我们宁愿死在通往自由的门槛上。%SPEECH_OFF% | 头领礼貌地拒绝了回去。%SPEECH_ON%佣兵，我们不是轻率地选择这条路的。我们不会回去。%SPEECH_OFF%你下令 %companyname% 拔出武器。逃兵头领叹了口气，但理解地点点头。%SPEECH_ON%我想这就是命吧。我们早就讨论过这种可能，我们宁愿死在自己想去的地方，也不愿死在某个狗娘养的命令下。现在，这个世界就是我们的一切。%SPEECH_OFF%你耸了耸肩回道。%SPEECH_ON%对我们来说，这只是笔生意而已。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "让我们赶紧把事情了解了吧……",
					function getResult()
					{
						this.Contract.m.Dude = null;
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos(), true);
						p.CombatID = "Deserters";
						p.Music = this.Const.Music.CivilianTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.TemporaryEnemies = [
							this.Contract.getFaction()
						];
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];
						p.EnemyBanners = [
							"banner_deserters"
						];
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			],
			function start()
			{
				local brothers = this.World.getPlayerRoster().getAll();
				local highest_bravery = 0;
				local best;

				foreach( bro in brothers )
				{
					if (bro.getCurrentProperties().getBravery() > highest_bravery)
					{
						best = bro;
					}
				}

				this.Contract.m.Dude = best;
				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "DesertersAftermath",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{%randombrother% 在一具尸体的罩袍上擦拭着他的刀刃。%SPEECH_ON%真可惜他们以这种方式死去。他们本可以活下来的。他们是有选择的。%SPEECH_OFF%你耸了耸肩，回答道。%SPEECH_ON%他们四面楚歌，死亡环绕。他们只是选择了让我们来做那个刽子手而已。%SPEECH_OFF% | 周围的逃兵都已经死了。其中一个正沿着地面爬行，试图拉开自己与 %commander% 军队之间的距离。你蹲在他身边，手里拿着匕首准备送他最后一程。他却对你笑了。%SPEECH_ON%没必要弄脏你的匕首，佣兵。给我点时间就好。这便是我所拥有的一切，呃啊。%SPEECH_OFF%一口鲜血从他嘴角涌出。他的眼神凝固，直勾勾地盯着前方，随后缓缓倒在地上。你站起身，命令队伍准备离开。 | 最后一个逃兵靠在一块岩石上，双手无力地垂在身体两侧，掌心向上翻着，像个忙于乞讨却生意兴隆的乞丐。鲜血顺着他胸口和双腿流下，在地上汇成一滩。他直愣愣地盯着那滩血。%SPEECH_ON%我没事的，谢谢你的关心，佣兵。%SPEECH_OFF%你告诉他你根本没问什么。他看着你，一脸真诚的困惑。%SPEECH_ON%你没问？哦，那没事了。%SPEECH_OFF%片刻之后，他歪倒在一边，脸上保持着那种僵硬的表情。 | 喜欢这种注定毁灭的人生所带来的荒诞感。当所有的选择和自由都被剥夺后，面对如此残酷的命运，除了大笑还能做什么呢？每一个逃兵死去时，脸上都带着一种镇定自若的表情。 | 最后一个活着的逃兵被发现正望着天空，他徒劳地在空中挥舞着一只手。%SPEECH_ON%该死，我就想看一眼。%SPEECH_OFF%你问他想看什么。他笑了，一声爽朗的大笑很快被一阵剧痛打断。%SPEECH_ON%一只鸟。看，那儿有一只。它是那么大，那么美。%SPEECH_OFF%他指着天空，你也抬头望去。一只秃鹫正在头顶盘旋。当你再低下头时，那人已经断气了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "这很不幸，但这事非做不可。",
					function getResult()
					{
						this.Contract.setState("Running_ReturnAfterIntercept");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "WarcampDay2End",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_96.png[/img]{%commander% 指挥官通知你，明天就是决战的日子。你回到帐篷里，好好享受这来之不易的休息。 | 你找到 %commander% 汇报了情况。他显得非常沉静，思绪完全被即将到来的大战所占据。一天结束，你决定上床休息，静待黎明。 | 你向 %commander% 报到，但他几乎毫无反应。他简直住在那些战图上了。%SPEECH_ON%明天见，佣兵。今晚好好睡一觉，因为你明天会很需要它。%SPEECH_OFF% | %commander% 允许你进入他的帐篷，但似乎忽略了你的汇报。相反，他正专注于地图，并继续与副官们讨论明天的作战计划。你决定回去好好睡一觉。 | %commander% 点头示意听到了你的汇报，但其他方面显然没怎么注意你。桌上铺满了各种作战地图，他的目光全神贯注在上面。你很理解：明天是关键的大战，他有更重要的事情要考虑。你决定今晚早点休息。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "今晚好好休息，明天决战就要开始了！",
					function getResult()
					{
						this.Flags.set("LastDay", this.World.getTime().Days);
						this.Flags.set("NextDay", 3);
						this.Contract.setState("Running_WaitForNextDay");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "WarcampDay3",
			Title = "在军营…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{%commander% 在集结的士兵面前走动。一些士兵面带倦容无所事事，整夜没合眼。另一些人则仍在紧张地发抖。他们的指挥官向他们喊话。%SPEECH_ON%你们害怕吗？感到恐惧吗？这很正常。如果你们一点都不怕，我反而会担心。%SPEECH_OFF%零星的笑声让气氛轻松了一些。他继续说道。%SPEECH_ON%但现在，我要求你们不要为自己担惊受怕，而是要为同胞、为家人的性命感到担忧！我们今天就是为了他们而战！让我们把自身的安危留到明天再去考虑，因为今天我们要做真正的男人！%SPEECH_OFF%笑声随即变成了雷鸣般的欢呼。 | %commander% 让他的部下在他面前集合。步兵、弓箭手、预备队，所有人都伫立在凛冽的寒风中。指挥官审视着他们。%SPEECH_ON%我知道你们在想什么：‘我为什么要为这个可怜的家伙卖命？如果他那么高尚，怎么没见他骑着高头大马来主持公道呢？’%SPEECH_OFF%士兵们笑了，缓解了一些紧张情绪。%commander% 接着说。%SPEECH_ON%好吧，不管是不是个丑家伙，我最喜欢的就是痛快地打一架！而那就是我会在的地方，兄弟们！我会和你们并肩作战，直到力竭，战斗到最后一刻，因为这才是战士该做的事！%SPEECH_OFF%士兵们举起手臂欢呼。他们的指挥官转过身，把剑高高举起。%SPEECH_ON%现在，跟我来！我们要让 %feudfamily% 知道什么叫真正的男人！%SPEECH_OFF% | %commander% 的乌合之众为了这场大战聚集在一起。他在战线前来回踱步，开始发表演说。%SPEECH_ON%你们有些人看起来都没睡醒。怎么，紧张了？我也是！一整晚都没合眼。%SPEECH_OFF%这让一些士兵放松了下来。无论是肉体还是精神上，知道自己并不孤单总是件好事。他继续说道。%SPEECH_ON%但我醒着是为了今天，为了这场战斗。我绝不会错过它。所以擦亮你们的眼睛吧，伙计们！今天我们要让那些 %feudfamily% 的混蛋知道，他们本该乖乖待在床上的。%SPEECH_OFF% | %commander% 正在对整装待发的部下训话。你一个字也没听进去。相反，你正在为即将到来的战斗整备自己的队伍。 | 你看着 %commander% 走向他的士兵，用激励的话语鼓舞士气。其中很多话你以前都听过。事实上，这些台词是不是来自某个古老的卷轴？来自一位励志演说家，他的激情被一代代传承下来？%randombrother% 走上前来，笑着说：%SPEECH_ON%我知道他只是在空谈，但我还是忍不住想做几个俯卧撑。%SPEECH_OFF%你笑着让他去队伍里站好。他开玩笑地回了一句。%SPEECH_ON%会有演讲环节吗？%SPEECH_OFF%那人笑着转身离开时，你推了他一把。 | %commander% 在战线前来回巡视。他走到一个男孩面前，那孩子吓得浑身发抖，盔甲都在哗啦作响。%SPEECH_ON%小子，你知道吗？你让我想起了当年的自己。你以为我没经历过你现在的处境？呵，放轻松点，因为总有一天，你也可能会像我一样。%SPEECH_OFF%男孩抬起头，眼中闪烁着新的光芒。他稳住身形，坚定地点了点头。指挥官提高嗓门，厉声命令部下准备迎接人生中最关键的一战。 | %commander% 在人群中穿梭，大喊着这场战斗将是他们一生中最重要的时刻。你对此并不确定，但可以肯定的是，这对他们中的许多人来说将是最后的时刻。不过，战争的残酷并不是最好的动员方式，所以你默不作声。 | 当 %commander% 用一套关于贵族世家之战宏大意义的浮夸演讲来激励部下时，你正系紧自己的靴带。这套说辞极具说服力。必须如此，毕竟如果一群从战斗中毫无所得的人要去送死的话。 | %commander% 走到士兵们面前。他身着华丽的战袍，在这群灰头土脸的士兵中显得鹤立鸡群。他解释说，他们必须赢得这场战斗，因为输掉它就等于输掉了整场战争。你觉得他只是在胡扯以激起士兵们的投入感。见鬼，如果不是某个沽名钓誉的指挥官从政治氛围中解读出某种神圣意义，你才不会为了那些娇生惯养的贵族去死。但话说回来，这种态度也正是你成为雇佣兵的原因。 | 战争真是一件可怕的事情。该如何向一个人兜售它呢？%commander% 尽其所能，在面对士兵时高谈阔论各种话题。首先，他说这是光荣之举。接着，他表示这里士兵众多，毫无疑问增加了别人替你去死的概率。人多力量大！接着他论证说，输掉这场战斗可能意味着失去他们的妻子、孩子和国家。最后一个理由似乎最管用，士兵们怒吼着爆发出能量。透过这群欢呼的人群，你很容易就能辨认出那些清醒的怀疑者和混乱的放纵者。 | %commander% 用深沉有力的语调对部下讲话。%SPEECH_ON%啊，你们中有些人看起来很兴奋，迫不及待想屠杀 %feudfamily% 的人了，是吧？我懂那种感觉。%SPEECH_OFF%一阵紧张的笑声响起。指挥官继续说道。%SPEECH_ON%记住你们的家人，兄弟们，因为他们今天肯定指望着我们！%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "兄弟们，向前看，还有一场战斗要打赢！",
					function getResult()
					{
						this.Contract.setState("Running_FinalBattle");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BattleLost",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_86.png[/img]{尸横遍野。%commander% 的身影矗立在尸堆之上，他的铠甲闪烁着微光，却包裹着一具血肉模糊的残躯。%employer% 得知此地战败的消息后，无疑会深感悲痛，但事已至此，我们无能为力。 | 战役已经输了！%commander% 的部下几乎全军覆没，只剩下零星幸存者，而指挥官本人也已阵亡。秃鹫已经在头顶盘旋，%feudfamily% 的人正稳步搜查成堆的尸体，处决任何装死的士兵。你迅速集结了 %companyname% 的剩余人马准备撤退。%employer% 看到这里的惨状无疑会感到惊骇，但眼下我们也只能如此了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "不是每一场战斗都能赢…",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "输掉了一场重要的战斗");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BattleWon",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_87.png[/img]{你们胜利了！好吧，是你和 %commander% 的部下共同的功劳。赢下这场仗才是最重要的。你踩着堆积如山的尸体，准备回去见你的雇主。 | 尸体堆积如山，足有五层之高。秃鹫在尸堆上啄食着碎肉。伤员们在地上乞求着救助。在旁观者看来，这里似乎根本没有什么赢家。然而，%commander%却带着灿烂的笑容走了过来。%SPEECH_ON%{干得好，佣兵！你应该赶紧回去找你的雇主，告诉他这里发生的一切。 | 哟，这不是那个佣兵吗？我还以为你没能活下来。你应该赶紧回去告诉你的雇主这里的情况。}%SPEECH_OFF% | 一个伤员在你脚边哀嚎乞怜。你分不清他是 %commander% 的人还是敌人。突然，一支矛头猛地刺入，刺穿了他的头颅，让他永远地斜着眼睛望向一边。你转头看去，凶手正双手搭在长矛顶端，脸上带着一副完成任务的表情。他冲你竖起一根手指。%SPEECH_ON%你就是那个佣兵，对吧？%commander% 让我告诉你，你该回你雇主那儿去了。这说法没毛病吧？%SPEECH_OFF%你点了点头。尸堆中传来一声呻吟。那人拔起长矛，换到另一只手提着。%SPEECH_ON%好了，继续干活！%SPEECH_OFF% | 战斗结束后，你看到 %commander% 在咆哮着，扯下自己的盔甲和衬衣。他炫耀着自己的伤口，用力绷紧肌肉让伤口裂开，就像刚切开的水果渗出汁液一样。他命令手下也这样做，让他们转过身来好让他看到他们的背。%SPEECH_ON%你看，像我们这样的好战士，伤口都在这儿、这儿，还有这儿……%SPEECH_OFF%他指着自己身体正面的每一处地方，然后指向自己的后背。%SPEECH_ON%但这里，没有一个人在这里受伤！因为我们是向前战死的，绝不后退一步！是不是这样？%SPEECH_OFF%士兵们欢呼起来，尽管有些人摇摇欲坠，鲜血从伤口不断渗出。你无视了这些花哨的表演，集结了 %companyname% 的人。你的雇主听到这里的战果肯定会很高兴，这才是你真正关心的事。 | %commander% 在战斗后迎接了你。他浑身浴血，仿佛刚砍下某人的脑袋，站在喷涌的血柱下洗了个澡。当他咧嘴一笑时，那一排牙齿显得格外惨白。%SPEECH_ON%这才是我所说的战斗。%SPEECH_OFF%你问他如果输了是否还会这么说。他大笑起来。%SPEECH_ON%哦？你是个怀疑论者吗？不，我压根就没打算输，就算输了，我也绝不会活着看到自己的失败。%SPEECH_OFF%你点点头，回应道。%SPEECH_ON%很少有人能有幸活到亲眼见证自己最惨痛的失败。和你并肩作战很愉快，指挥官，但我现在必须回去找我的雇主了。%SPEECH_OFF%指挥官点点头，转过身大喊着让人给他拿条毛巾来。 | 你发现 %commander% 蹲在一个受伤的敌军士兵身上。他正用匕首在那可怜人的胸口来回滑动，在盔甲上刮擦出刺耳的声音。指挥官看着你。%SPEECH_ON%你觉得呢，佣兵？我该让他活下去吗？%SPEECH_OFF%那个俘虏死死盯着你，猛地向前探头，拼命眨眼。你猜这是在说‘是’。你耸了耸肩。%SPEECH_ON%这不归我管。听着，和你作战很痛快，但我现在得回去找我的雇主了。%SPEECH_OFF%%commander% 点了点头。%SPEECH_ON%那就后会有期了。%SPEECH_OFF%当你离开时，指挥官还蹲在后面陪着他的俘虏，刀刃来回晃动，发出叮当的声响，来回，来回，来回。 | 你发现 %commander% 把匕首捅进一个伤员的侧腹。倒下的敌人因剧痛而抽搐，但很快便没了动静，几分钟内就软绵绵地瘫倒在地。随着指挥官拔出刀，一股鲜血随之涌出，他顺手在裤腿上擦了擦刀刃。%SPEECH_ON%直击心脏，又快又利索。还有什么死法能让男人奢求更多呢。%SPEECH_OFF%你点点头，告诉指挥官你要回去找雇主领薪水了。 | 你看到 %commander% 和一队士兵在战场上闲逛，凡是发现的伤员，无论是敌是友，他们都会补刀处决。%randombrother% 问我们是否应该向指挥官报告。你摇了摇头。%SPEECH_ON%不用。我们直接去见雇主。这鬼地方爱怎样怎样，我们回去领钱。%SPEECH_OFF% | 战场上到处都是尸体和求死不得的人。%commander% 的部下正在收容伤员，并处决发现的敌人。指挥官本人走过来拍了拍你的肩膀，溅起的一滴血点落在了你的脸颊上。%SPEECH_ON%干得漂亮，佣兵。我不确定你的人能不能守住阵线，但你确实做到了。我相信你的雇主见到你会非常高兴。%SPEECH_OFF% | 你四处找寻 %companyname% 的人。%commander% 走了过来，手里拿着一块布擦拭着剑，浓稠的血被抹了下来。%SPEECH_ON%这就要走了？%SPEECH_OFF%你点了点头。%SPEECH_ON%是你家雇主付钱雇我们，所以我们自然要回去找他。%SPEECH_OFF%指挥官把他的武器插回剑鞘里，点了点头。%SPEECH_ON%有道理，和你一起作战很愉快，佣兵。真遗憾不能把你招进我的队伍。看来你们这群家伙还得继续为金币奔波啊，是吧？%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						local faction = this.World.FactionManager.getFaction(this.Contract.getFaction());
						local settlements = faction.getSettlements();
						local origin = settlements[this.Math.rand(0, settlements.len() - 1)];
						local party = faction.spawnEntity(this.World.State.getPlayer().getTile(), origin.getName() + " Company", true, this.Const.World.Spawn.Noble, 150);
						party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + faction.getBannerString());
						party.setDescription("为地方领主服务的职业士兵。");
						this.Contract.setState("Return");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你发现 %employer% 已经喝得烂醉如泥，他透过杯沿盯着你，在把酒喝下去之前先把话含在嘴里咕哝了一遍。%SPEECH_ON%啊，该死，你回来了。%SPEECH_OFF%随着他吞咽的动作，杯子放了下来。你迅速汇报了胜利的消息。那人笑了，虽然醉得太厉害，看起来几乎有些困惑。%SPEECH_ON%那么一切都结束了。胜利是我的。这就是我想要的。我希望没太多人为了满足我的愿望而送命。%SPEECH_OFF%他突然爆发出一阵大笑。随后，他的一个卫兵递给你一个帆布袋，把你请出了房间。 | %employer% 拿着一个小包迎接了你。%SPEECH_ON%{胜利属于我们。谢谢你，佣兵。 | 外面干得真不错，佣兵。胜利归于我们，这其中也有你的一份功劳。这是给你的 %reward_completion% 克朗。 | 你说多少来着，%reward_completion% 克朗？为了击溃那支军队，让我们离结束这场战争更近一步，这点代价太划算了。 | 我的探子告诉我你在外面表现不错，佣兵。当然，他们还告诉我，%feudfamily% 的军队正在撤退。我还能奢求什么呢？按照约定，这是给你的 %reward_completion% 克朗。}%SPEECH_OFF% | 你看到 %employer% 正向他的指挥官们大声下达命令。看到你，他迅速指向你的方向。%SPEECH_ON%看看这个家伙！他是一个能成事的人。卫兵！给他 %reward_completion% 克朗。要是我能付钱给你们这些懒狗，让他们干出一半像他这样的成绩就好了！%SPEECH_OFF% | 你发现 %employer% 在他的花园里给一群女人讲笑话。你闯入她们的圈子，浑身血污，满身泥泞。女人们惊叫一声退开了。%employer% 却大笑起来。%SPEECH_ON%啊，佣兵你回来了！你真是个讨女人喜欢的家伙。真希望能把你介绍给这些漂亮的女士中的一位，但是我担心她们的父亲会把你阉了。%SPEECH_OFF%其中一位女士把手滑过自己的胸口。%SPEECH_ON%如果他愿意，可以碰我。%SPEECH_OFF%%employer%再次大笑。%SPEECH_ON%哦，天哪，难道你惹的麻烦还不够多吗？走吧，女士们，去告诉我的一名守卫，拿一个装有 %reward_completion% 克朗的皮包来。%SPEECH_OFF% | 你发现 %employer% 正在试图训练他的猫握手。%SPEECH_ON%看看这个小畜生。它甚至不敢看我的眼睛！当我喂它时，它表现得好像这是我理所应当做的。如果我想的话，我可以把这个小东西从该死的窗户扔出去！%SPEECH_OFF%你回应道。%SPEECH_ON%它会四脚着地的。%SPEECH_OFF%贵族点了点头。%SPEECH_ON%这才是最该死的地方。%SPEECH_OFF%你的雇主捡起那只有弹性的猫，并将它扔出了窗外。他拍了拍手，然后交给你一个装有 %reward_completion% 克朗的小包。%SPEECH_ON%如果我看起来有点心不在焉，请原谅。你在那里干得很好，%feudfamily% 的军队正在撤退，这些日子我实在不能要求更多了。%SPEECH_OFF% | 你发现 %employer% 正在对他的一个指挥官进行即兴审判。你不确定是为了什么，但那名指挥官高昂着头，一脸倔强。结束后，他被粗暴地推搡着带了出去。%employer%向你招手。%SPEECH_ON%{谢谢你，佣兵。胜利属于我们，我不确定没有你的帮助是否能成功。当然，这是说好的 %reward_completion% 克朗报酬。 | 那家伙违抗了我的命令，事实如此。然而你，表现堪称典范！这是说好的！你将获得 %reward_completion% 克朗。 | 那个人不肯为我打仗。他说他不会拔剑对付为敌军效力的亲兄弟。简直是胡扯。你干得很好，佣兵。这是承诺给你的 %reward_completion% 克朗的报酬。}%SPEECH_OFF% | 你回到 %employer% 身边，他正站在一排指挥官中间。%SPEECH_ON%{谢谢你，佣兵。现在胜利属于我们了。这是说好的 %reward_completion% 克朗报酬。 | 战争还在继续，但因为你，它或许快要结束了。这是你应得的 %reward_completion% 克朗，佣兵。}%SPEECH_OFF% | %employer% 的一名卫兵拦住你不让你靠近。他拿着装着 %reward_completion% 克朗的袋子，很快就交给了你。%SPEECH_ON%我的领主告诉我，你在战场上表现不错。%SPEECH_OFF%卫兵尴尬地环顾四周。%SPEECH_ON%那个……那就是我该说的全部了。%SPEECH_OFF% | %employer% 欢迎你进入他的作战室，里面的指挥官已经被清空。%SPEECH_ON%见到你真好，佣兵。想必你也知道，%feudfamily% 的军队已经在撤退了。谁也不知道如果没有你我们能不能做到。这是按约定给你的 %reward_completion% 克朗。%SPEECH_OFF% | %employer% 正在喂一只高大、看起来很蠢的鸟。你从未见过这么大块头的鸟，所以保持了距离。那位觉得有趣的贵族一边让那畜生从他手里啄食，一边说道。%SPEECH_ON%别害怕，佣兵。跟你说一声，我已经听说了你的事迹。%feudfamily% 的军队在撤退，所以我们离结束这场该死的战争越来越近了。那边那个拿着皮包的守卫，那里有你的 %reward_completion% 克朗的报酬。%SPEECH_OFF%你离开时，那只鸟扑腾着翅膀尖叫了一声。 | 你发现 %employer% 正待在一个人工池塘边。他正用温柔的手势捞起青蛙。那些黏糊糊的小东西扭动着跳开了。%SPEECH_ON%胜利属于我们。我会说，这份工作干得很出色，佣兵。我给了你一个巨大的机会，而你真的……抓住了。%SPEECH_OFF%你肯定露出了明显的厌恶表情，因为那位贵族迅速站起身，用手在裤子上擦了擦。 %SPEECH_ON%该死，这笑话有那么烂吗？好吧，那边的守卫有你的酬劳，%reward_completion%克朗。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "赢得了一场重要的战斗");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isCivilWar())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function onCommanderPlaced( _entity, _tag )
	{
		_entity.setName(this.m.Flags.get("CommanderName"));
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"noblehouse",
			this.World.FactionManager.getFaction(this.getFaction()).getName()
		]);
		_vars.push([
			"feudfamily",
			this.World.FactionManager.getFaction(this.m.Flags.get("EnemyNobleHouse")).getName()
		]);
		_vars.push([
			"commander",
			this.m.Flags.get("CommanderName")
		]);
		_vars.push([
			"objective",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.m.Destination.getName()
		]);
		_vars.push([
			"cost",
			this.m.Flags.get("RequisitionCost")
		]);
		_vars.push([
			"bribe",
			this.m.Flags.get("Bribe")
		]);

		if (this.m.Flags.get("IsInterceptSupplies"))
		{
			_vars.push([
				"supply_start",
				this.World.getEntityByID(this.m.Flags.get("InterceptSuppliesStart")).getName()
			]);
			_vars.push([
				"supply_dest",
				this.World.getEntityByID(this.m.Flags.get("InterceptSuppliesDest")).getName()
			]);
		}

		if (this.m.Dude != null)
		{
			_vars.push([
				"bigdog",
				this.m.Dude.getName()
			]);
			_vars.push([
				"motivator",
				this.m.Dude.getName()
			]);
		}

		if (this.m.Destination == null)
		{
			_vars.push([
				"direction",
				this.m.WarcampTile == null ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.WarcampTile)]
			]);
		}
		else
		{
			_vars.push([
				"direction",
				this.m.Destination == null || this.m.Destination.isNull() ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.Destination.getTile())]
			]);
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			if (this.m.Warcamp != null && !this.m.Warcamp.isNull())
			{
				this.m.Warcamp.die();
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isCivilWar())
		{
			return false;
		}

		return true;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Warcamp != null && !this.m.Warcamp.isNull())
		{
			_out.writeU32(this.m.Warcamp.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local warcamp = _in.readU32();

		if (warcamp != 0)
		{
			this.m.Warcamp = this.WeakTableRef(this.World.getEntityByID(warcamp));
		}

		this.contract.onDeserialize(_in);
	}

});

