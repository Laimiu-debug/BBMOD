this.defend_holy_site_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Target = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.defend_holy_site";
		this.m.Name = "保卫圣地";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();
		local target;
		local targetIndex = 0;
		local closestDist = 9000;
		local myTile = this.m.Home.getTile();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					local d = myTile.getDistanceTo(v.getTile());

					if (d < closestDist)
					{
						target = v;
						targetIndex = i;
						closestDist = d;
					}
				}
			}
		}

		this.m.Destination = this.WeakTableRef(target);
		this.m.Destination.setVisited(true);
		this.m.Payment.Pool = 1250 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);
		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Flags.set("DestinationIndex", targetIndex);
		this.m.Flags.set("EnemyID", cityStates[this.Math.rand(0, cityStates.len() - 1)].getID());
		this.m.Flags.set("MapSeed", this.Time.getRealTime());
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往 %holysite%，抵御南方异教徒的进攻"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 25)
				{
					this.Flags.set("IsQuartermaster", true);
				}

				local r = this.Math.rand(1, 100);

				if (r <= 30)
				{
					this.Flags.set("IsSallyForth", true);
				}
				else if (r <= 60)
				{
					this.Flags.set("IsAlliedSoldiers", true);
				}

				local cityStates = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.OrientalCityState);

				foreach( c in cityStates )
				{
					c.addPlayerRelation(-99.0, "在战争选择了阵营");
				}

				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);

				if (this.Contract.getDifficultyMult() >= 0.95)
				{
					local cityState = cityStates[this.Math.rand(0, cityStates.len() - 1)];
					local party = cityState.spawnEntity(this.Contract.m.Destination.getTile(), "Regiment of " + cityState.getNameOnly(), true, this.Const.World.Spawn.Southern, this.Math.rand(100, 150) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
					party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + cityState.getBannerString());
					party.setDescription("忠于城邦的应征士兵。");
					party.getLoot().Money = this.Math.rand(50, 200);
					party.getLoot().ArmorParts = this.Math.rand(0, 25);
					party.getLoot().Medicine = this.Math.rand(0, 3);
					party.getLoot().Ammo = this.Math.rand(0, 30);
					local r = this.Math.rand(1, 4);

					if (r <= 2)
					{
						party.addToInventory("supplies/rice_item");
					}
					else if (r == 3)
					{
						party.addToInventory("supplies/dates_item");
					}
					else if (r == 4)
					{
						party.addToInventory("supplies/dried_lamb_item");
					}

					local c = party.getController();
					local roam = this.new("scripts/ai/world/orders/roam_order");
					roam.setAllTerrainAvailable();
					roam.setTerrain(this.Const.World.TerrainType.Ocean, false);
					roam.setTerrain(this.Const.World.TerrainType.Shore, false);
					roam.setTerrain(this.Const.World.TerrainType.Mountains, false);
					roam.setPivot(this.Contract.m.Destination);
					roam.setMinRange(4);
					roam.setMaxRange(8);
					roam.setTime(300.0);
				}

				local entities = this.World.getAllEntitiesAtPos(this.Contract.m.Destination.getPos(), 1.0);

				foreach( e in entities )
				{
					if (e.isParty())
					{
						e.getController().clearOrders();
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Flags.get("IsQuartermaster") && this.Contract.isPlayerAt(this.Contract.m.Home) && this.World.Assets.getStash().getNumberOfEmptySlots() >= 3)
				{
					this.Contract.setScreen("Quartermaster");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					this.Contract.setScreen("Approaching" + this.Flags.get("DestinationIndex"));
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Running_Defend",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"保卫%holysite%，抵御南方异教徒的侵犯",
					"摧毁或击溃附近的敌方部队",
					"不要走得太远"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}

				if (this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Flags.get("IsFailure") || !this.Contract.isPlayerNear(this.Contract.m.Destination, 700) || !this.World.FactionManager.isAllied(this.Contract.getFaction(), this.Contract.m.Destination.getFaction()))
				{
					this.Contract.setScreen("Failure");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsSallyForthNextWave"))
				{
					this.Contract.setScreen("SallyForth3");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsVictory"))
				{
					if (!this.Contract.isEnemyPartyNear(this.Contract.m.Destination, 400.0))
					{
						this.Contract.setScreen("Victory");
						this.World.Contracts.showActiveContract();
					}
				}
				else if (!this.Flags.get("IsTargetDiscovered") && this.Contract.m.Target != null && !this.Contract.m.Target.isNull() && this.Contract.m.Target.isDiscovered())
				{
					this.Flags.set("IsTargetDiscovered", true);
					this.Contract.setScreen("TheEnemyAttacks");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsArrived") && this.Flags.get("AttackTime") > 0 && this.Time.getVirtualTimeF() >= this.Flags.get("AttackTime"))
				{
					if (this.Flags.get("IsSallyForth"))
					{
						this.Contract.setScreen("SallyForth1");
						this.World.Contracts.showActiveContract();
					}
					else if (this.Flags.get("IsAlliedSoldiers"))
					{
						this.Contract.setScreen("AlliedSoldiers1");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Flags.set("AttackTime", 0.0);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onDestinationAttacked.bindenv(this));
						this.Contract.m.Target = this.WeakTableRef(party);
					}
				}
			}

			function onDestinationAttacked( _dest, _isPlayerInitiated = false )
			{
				if (this.Flags.get("IsSallyForthNextWave"))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "DefendHolySite";
					p.Music = this.Const.Music.OrientalCityStateTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.Entities = [];
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];

					if (this.Flags.get("IsLocalsRecruited"))
					{
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsArmed, 10, this.Contract.getFaction());
						p.AllyBanners.push("banner_noble_11");
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else if (this.Flags.get("IsSallyForth"))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "DefendHolySite";
					p.Music = this.Const.Music.OrientalCityStateTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.Entities = [];
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, (this.Flags.get("IsEnemyReinforcements") ? 130 : 100) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];

					if (this.Flags.get("IsLocalsRecruited"))
					{
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsArmed, 50, this.Contract.getFaction());
						p.AllyBanners.push("banner_noble_11");
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
					p.CombatID = "DefendHolySite";

					if (this.Contract.isPlayerAt(this.Contract.m.Destination))
					{
						p.MapSeed = this.Flags.getAsInt("MapSeed");
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Flags.get("IsPalisadeBuilt") ? this.Const.Tactical.FortificationType.WallsAndPalisade : this.Const.Tactical.FortificationType.Walls;
						p.LocationTemplate.CutDownTrees = true;
						p.LocationTemplate.ShiftX = -2;
						p.Music = this.Const.Music.OrientalCityStateTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];

						if (this.Flags.get("IsAlliedReinforcements"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
							p.AllyBanners.push(this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner());
						}

						if (this.Flags.get("IsLocalsRecruited"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsArmed, 50, this.Contract.getFaction());
							p.AllyBanners.push("banner_noble_11");
						}
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "DefendHolySite")
				{
					if (this.Flags.get("IsSallyForthNextWave"))
					{
						this.Flags.set("IsSallyForthNextWave", false);
						this.Flags.set("IsSallyForth", false);
						this.Flags.set("IsVictory", true);
					}
					else if (this.Flags.get("IsSallyForth"))
					{
						this.Flags.set("IsSallyForthNextWave", true);
					}
					else
					{
						this.Flags.set("IsVictory", true);
					}
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "DefendHolySite")
				{
					this.Flags.set("IsFailure", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%SPEECH_START%沙丘符文杂种。%SPEECH_OFF%这是你进入 %employer% 房间时听到的第一句话。他很不情愿地挥手示意你进去。%SPEECH_ON%与南方的战争仍在继续，但他们却打破了不成文的协议：他们正在进攻 %holysite%，而我没有能力保护它。我不想纠结于这片土地的重要性，但如果我放任不管，公众肯定会阉了我。既然我非常喜欢我的蛋蛋，我将拿出 %reward% 克朗，让你去那里保卫 %holysite%。%SPEECH_OFF% | 你发现 %employer%正试图在聚集的农民面前为自己辩解。看来，南方士兵正在逼近%holysite%。%SPEECH_ON%我们有不成文的规矩，这些神圣的土地，它们，它们…它们是神圣的！%SPEECH_OFF%看到你，这位贵族清理出一条路，宣布你们是他一周前召唤来的勇敢的战士。然而，当他靠近时，他压低声音说道。%SPEECH_ON%这些白痴不需要知道你们是雇佣兵。听着，南方佬这次可把我坑惨了。这些野蛮人真的要对 %holysite% 下手了，我需要你们去那里阻止他们。%reward% 克朗应该足够完成这项任务了，没错吧？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{%companyname% 可以帮你处理这个。 | 防御南方敌人这活儿，最好给足报酬。 | 我很感兴趣，说下去。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不值得。 | 别的地方更需要我们。 | 我不会为了对抗南方的战争机器而拿整个团队去冒险。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Approaching1",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{巨大的破火山口已经基本清空了它那些忠诚而好奇的住客。哪怕只有一丁点战争的迹象，就已将信徒们驱散回各自修道院的庇护所中。毕竟，在接下来的几个小时里，这里终会分出个胜负。某种程度的狂热劲头，或许会诱使获胜的那一方在正义的名义下放纵过度……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Approaching0",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{神谕之地已经不是你记忆中的模样了：许多虔诚的信徒已然离去，而战争的鼓点已逼近这座古老寺庙的门槛。不过，这一切都无关紧要。你此行并非来此寻求神启或解开梦境，你只为给你的敌人制造噩梦而来。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Approaching2",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{具有讽刺意味的是，这座栖身于半毁山脉之下的平顶城市，此刻却透出了一种怪诞的荒废感。少数信徒在此徘徊，其余的人则早已在宗教纷争波及他们的帐篷营地与精神领地之前离去。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Preparation1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你认为自己已经利用 %holysite% 所能提供的地形，构筑起了一个勉强够用的防御阵地。 剩下的时间不多了，至少可以让 %companyname% 去完成一项至关重要的任务。问题只在于，究竟做些什么才最符合这支队伍的利益。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "建起木栅栏来加固防守！",
					function getResult()
					{
						return "Preparation2";
					}

				},
				{
					Text = "搜查这片区域，看看有没有对我们有用的东西！",
					function getResult()
					{
						return "Preparation3";
					}

				},
				{
					Text = "招募一些忠实信徒，协助我们防守！",
					function getResult()
					{
						return "Preparation4";
					}

				}
			],
			function start()
			{
				this.Contract.setState("Running_Defend");
			}

		});
		this.m.Screens.push({
			ID = "Preparation2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你悄悄洗劫了这座圣地，这件事你绝不会向任何人透露，又翻遍了信徒们遗弃的物品，好不容易拼凑出足够的木材，加固了环绕 %holysite%一角的一段城墙。在你看来，这里是敌人最可能攻入的突破口，自然也是你最需要死守的地方。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsPalisadeBuilt", true);
			}

		});
		this.m.Screens.push({
			ID = "Preparation3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你派手下搜遍了整个区域，寻找可用于战斗的物资。众人窃取了大量物品，并将其堆成小山。等把 %holysite% 彻底搜刮一空后，你和弟兄们花了几分钟时间，琢磨着哪些东西最派得上用场……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				for( local i = 0; i < 2; i = ++i )
				{
					local r = this.Math.rand(1, 12);
					local item;

					switch(r)
					{
					case 1:
						item = this.new("scripts/items/weapons/oriental/saif");
						break;

					case 2:
						item = this.new("scripts/items/tools/throwing_net");
						break;

					case 3:
						item = this.new("scripts/items/weapons/oriental/polemace");
						break;

					case 4:
						item = this.new("scripts/items/weapons/ancient/broken_ancient_sword");
						break;

					case 5:
						item = this.new("scripts/items/armor/ancient/ancient_mail");
						break;

					case 6:
						item = this.new("scripts/items/supplies/ammo_item");
						break;

					case 7:
						item = this.new("scripts/items/supplies/armor_parts_item");
						break;

					case 8:
						item = this.new("scripts/items/shields/ancient/tower_shield");
						break;

					case 9:
						item = this.new("scripts/items/loot/ancient_gold_coins_item");
						break;

					case 10:
						item = this.new("scripts/items/loot/silver_bowl_item");
						break;

					case 11:
						item = this.new("scripts/items/weapons/wooden_stick");
						break;

					case 12:
						item = this.new("scripts/items/helmets/oriental/spiked_skull_cap_with_mail");
						break;
					}

					if (item.getConditionMax() > 1)
					{
						item.setCondition(this.Math.max(1, item.getConditionMax() * this.Math.rand(10, 50) * 0.01));
					}

					this.World.Assets.getStash().add(item);
					this.List.push({
						id = 10,
						icon = "ui/items/" + item.getIcon(),
						text = "你获得了" + item.getName()
					});
				}

				local amount = this.Math.rand(10, 30);
				this.World.Assets.addArmorParts(amount);
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_supplies.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]+" + amount + "[/color] 工具和补给"
				});
			}

		});
		this.m.Screens.push({
			ID = "Preparation4",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{在 %holysite% 周围仍留下的少数忠实信徒，必然是最狂热和最虔诚的。 因为你在这里代表北方，既然你代表北方来到这里，就让手下挑选几个看起来身强力壮的旧神狂信者，让他们为自己的神明而战。这算是现成的便利征兵手段了，这些人很快便武装起来，并接受了极其简短的训练。你只希望他们在即将到来的实战中真能派上用场。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsLocalsRecruited", true);
			}

		});
		this.m.Screens.push({
			ID = "TheEnemyAttacks",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{南方人出现在地平线上。他们的盔甲在远处也闪闪发光，称他们为‘镀金者追随者’再贴切不过了。%randombrother% 吐了口唾沫，抬头打量着他们。%SPEECH_ON% 那群家伙看起来可太体面了，哪像一群将死之人。你有没有想过，如果我们把自己打扮得像个精灵，再带着小恶魔般的自信冲出去，那些南方人会不会直接就撤了？ %SPEECH_OFF%听罢，你微微一笑，拔剑出鞘，率领弟兄们投入战斗。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "列阵！",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Quartermaster",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_158.png[/img]{离开 %townname% 时，你遇到一个人正从一辆马车后方举起 %employerfaction% 的旗帜。他自称是你雇主的军需官，并表示有一些物资可以提供给你。 %SPEECH_ON%我这里有几条战犬、一些渔网和投掷用的长矛。不过我接到的指示是只能分给你其中一样，毕竟这附近还有很多作战人员急需补给。 %SPEECH_OFF%}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "我们会带上战犬。",
					function getResult()
					{
						for( local i = 0; i < 3; i = ++i )
						{
							local item = this.new("scripts/items/accessory/wardog_item");
							this.World.Assets.getStash().add(item);
						}

						return 0;
					}

				},
				{
					Text = "我们会拿这些网。",
					function getResult()
					{
						for( local i = 0; i < 4; i = ++i )
						{
							local item = this.new("scripts/items/tools/throwing_net");
							this.World.Assets.getStash().add(item);
						}

						return 0;
					}

				},
				{
					Text = "我们会拿投矛。",
					function getResult()
					{
						if (this.Const.DLC.Wildmen)
						{
							for( local i = 0; i < 4; i = ++i )
							{
								local item = this.new("scripts/items/weapons/throwing_spear");
								this.World.Assets.getStash().add(item);
							}
						}
						else
						{
							for( local i = 0; i < 4; i = ++i )
							{
								local item = this.new("scripts/items/weapons/javelin");
								this.World.Assets.getStash().add(item);
							}
						}

						return 0;
					}

				},
				{
					Text = "我们手头的东西已经够用了，把这些留给其他人吧。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsQuartermaster", false);
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "SallyForth1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{南方人出现了，但他们并未集结全力而来，而且来的也不一定全是侦察兵。看来他们在行军时没怎么保持队形，而是散开了阵势推进。 如果你现在立刻出击进攻，很有机会打他们个措手不及。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们必须抓住这个机会。立刻准备出击，整队迎敌！",
					function getResult()
					{
						return this.Math.rand(1, 100) <= 50 ? "SallyForth2" : "SallyForth4";
					}

				},
				{
					Text = "我们在这里有易守难攻的优势，按兵不动。",
					function getResult()
					{
						return "SallyForth5";
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_50.png[/img]{%SPEECH_START%好主意。%SPEECH_OFF%%randombrother% 附和着你的命令。于是，%companyname% 全速开拔，赶在南方人集结全部兵力之前截击他们。你穿过田野，转眼间便已抵达。他们仍在卸载装备和器材，一看到你，几个营地随从立刻惊慌失措地逃命。其余士兵则匆忙拿起武器。\n\n从尖锐的嗓音判断，现场唯一的指挥官显然没受过这种场面的训练，他扯着嗓子发号施令，几近破音，而士兵们则试图勉强组成某种阵型。不再浪费时间，你径直冲入混战之中！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "冲锋！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_90.png[/img]{你解决了最后一名士兵，他们脸上惊讶的表情依然凝固着。%SPEECH_ON%头儿，剩下的人来了。%SPEECH_OFF%%randombrother% 从对地平线的匆匆一瞥后返回说道。 你点了点头，下令弟兄们准备迎战。这一次，南方人保持着整齐的阵型推进，尽管在看到你以及散落在脚边的尸体时，阵型短暂地动摇了一下。他们的旗帜升上天空，南方人的士气瞬间重振，带着愤怒与力量冲锋而来。“为镀金者而战！”的呼喊声在空中回荡。你将剑锋直指前方。%SPEECH_ON%虽然他们的信仰令人钦佩，但这里不会有神明找到他们，只有 %companyname% 在此等候，而我们只有一种祷词可以献上。%SPEECH_OFF%随着战斗一触即发，人们发出震耳欲聋的怒吼。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "集合！整队！准备迎敌！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth4",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{%SPEECH_START%好主意。%SPEECH_OFF%%randombrother% 附和着你的命令。于是，%companyname% 全速开拔，赶在南方人集结全部兵力之前截击他们。你穿过田野，转眼间便已抵达。他们仍在卸载装备和器材，一看到你，几个营地随从立刻惊慌失措地逃命。其余士兵则匆忙拿起武器。 就在你以为胜券在握之时，另一支援军突然从侧翼杀到。%SPEECH_ON%镀金者只垂青于那些配得上祂光辉的人，逐币者！%SPEECH_OFF% 那名南方指挥官嘲弄地大喊道。由于己方防御阵地距离太远，而敌人却又近在咫尺，此刻的出路只有一条。你高举长剑，率领众人准备冲锋。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们要杀出一条血路！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsEnemyReinforcements", true);
			}

		});
		this.m.Screens.push({
			ID = "SallyForth5",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你认为坚守阵地是上策。这么做或许会错失良机，但至少是目前最稳妥的选择。%SPEECH_ON%早该主动出击的。我们这次错失了什么，头儿。%SPEECH_OFF%回头一看，只见 %randombrother% 耸了耸肩说道。 你警告他管好自己的嘴，否则他待会儿就会缺点什么。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "全员准备！他们很快就会发起总攻。",
					function getResult()
					{
						this.Flags.set("IsSallyForth", false);
						this.Flags.set("AttackTime", 1.0);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{就在你严阵以待南方人之时，一队北方士兵赶到了。他们的中尉拍了拍头盔致意。%SPEECH_ON%当他们命令我往这个方向来支援一支佣兵团时，我说这命令他们可以塞回自己的屁眼里。但你知道是什么说服了我吗？是知道那是 %companyname%。你们有这个名声，而我手下的人也正好能腾出来帮你们打这一仗。%SPEECH_OFF%从他们的装备来看，把他们当作掩护部队，用来引开一部分正在逼近的敌军或许是最佳用法。当然，或者也可以选择将他们直接编入你的队伍，在你原本就最强的战线上进一步充实兵力。.}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "我需要你和你的人迂回到炮兵侧翼，中尉。",
					function getResult()
					{
						this.Flags.set("IsEnemyLuredAway", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers2";
					}

				},
				{
					Text = "我需要你和你的人去引开一部分步兵，中尉。",
					function getResult()
					{
						this.Flags.set("IsEnemyLuredAway", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers2";
					}

				},
				{
					Text = "我需要你和你的人并肩作战，中尉。",
					function getResult()
					{
						this.Flags.set("IsAlliedReinforcements", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers3";
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
				this.Flags.set("IsAlliedSoldiers", false);
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你掏出单筒望远镜，观察着前方的战场。北方部队排成楔形阵势冲锋，随后两翼散开，向不同方向跑去。这看似一场自杀式冲锋，但令你惊讶的是，他们成了诱人的诱饵，让南方人完全无法抗拒。看到镀金者的信徒们根本顾不上正主，反而分散兵力去追击佯攻的部队。%SPEECH_ON%简直妙极了，头儿。%SPEECH_OFF%%randombrother%说。}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "非常好。",
					function getResult()
					{
						this.Flags.set("IsAlliedSoldiers", false);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你还是希望这些士兵留下来助战。中尉点了点头。%SPEECH_ON%是，长官。呃，队长，请问怎么称呼？%SPEECH_OFF%你无视了他的问题，转头吩咐 %randombrother% 安排这支北方部队协助防御。%SPEECH_ON%务必让他们熟悉阵地，但别太熟悉了。%SPEECH_OFF%那佣兵凑近你，压低声音说道。%SPEECH_ON%啊，要是他们是奸细，我们可不能透露太多细节，对吧头儿？%SPEECH_OFF%你也凑近他，低声回应道。%SPEECH_ON%不。把他们安排在我们最薄弱的防线上。希望他们全都在前线送了命，那样他们的装备就归我们了。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "现在我们接着等吧。",
					function getResult()
					{
						this.Flags.set("IsAlliedSoldiers", false);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_168.png[/img]{最后一名南方士兵抬头望着你。%SPEECH_ON%凭着镀金者的光辉，我已经准备就绪。%SPEECH_OFF%你拔出佩剑。%SPEECH_ON%既然此刻站在这里的是我，而你即将倒下，那道光辉对你又有什么用？%SPEECH_OFF%没等他回应，你便挥剑刺穿了他的脖颈。随后你命令佣兵们搜刮尸体，并准备返回 %employer% 复命。 | 你发现最后那名南方士兵倚坐在一块岩石旁，手臂搭在石头顶上，仿佛那是他的好朋友。他吐了口血，点了点头。%SPEECH_ON%或许我的道路并不像我想的那样金光闪闪。%SPEECH_OFF%你回以点头，告诉他很快就能亲自去问镀金者了。%SPEECH_ON%我也会替你问候祂的。%SPEECH_OFF%他回答道。你被这句话噎了一下，随即一剑贯穿了他的胸膛。剩下的尸体还需要搜刮一番。%employer% 见到你们应该会很高兴。 | 战斗结束，战场上尸横遍野。你站在最后一个尚有气息的南方人面前，他越过你的肩膀凝视着天空。当你问他是否觉得他的‘镀金者’正在注视时，那人笑了。%SPEECH_ON%祂正看着我们俩。%SPEECH_OFF%你点点头，结束了他最后的生命。紧接着一声响亮的口哨，你唤回了 %companyname% 的注意力。你的命令很简单：捡走所有值钱的东西，然后整队返回 %employer%。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.spawnAlly();
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Failure",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{南方人已经在 %holysite% 上空升起了他们的旗帜。%SPEECH_ON%我想这下全完了。%SPEECH_OFF%%randombrother% 说道。如果他所谓的‘完了’是指没必要去找 %employer% 讨论解除合约了，那么没错，确实全完了。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "灾难！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能保卫圣地");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Success",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%我猜那些南方杂种在你收拾他们的时候肯定哭爹喊娘了吧。%SPEECH_OFF%没等你回答，%employer% 就咬下半块鸡胸肉。但他根本停不下来，嘴里塞满了食物，还没嚼几下就喷得到处都是。%SPEECH_ON%你知道吗，我本来都快怀疑旧神们了。但现在，有了这事儿，我看得出来祂们的道路是正确的，祂们的神性至高无上。 %SPEECH_OFF%他咽下嘴里的东西，把剩下的鸡往盘子里一摔。%SPEECH_ON%给这佣兵付钱。 %SPEECH_OFF% | 你发现 %employer% 正和几个修士、他们的院长，以及一些看起来绝不像是已婚妇女的女人在一起。这位贵族笑得合不拢嘴。 %SPEECH_ON%关于你们的事迹几天前就传到我们这儿了。旧神们为你的部下举杯致敬啊，佣兵。我相信你肯定让那些南方人尝尽了他们应得的地狱滋味，现在他们毫无疑问正待在那儿呢。这是你的酬劳，一分不少。%SPEECH_OFF% 几个女人朝你走来，但很快就被拉了回去。 %SPEECH_ON%女士们，女士们，注意点体统。佣兵。%SPEECH_OFF%%employer% 指向一口装着 %reward% 克朗的箱子。 | 你在一座修道院里找到了 %employer%。他正独自一人在祭坛前祈祷。结束之后，他没有回头便开了口。%SPEECH_ON%我相信昨晚老神们与我对话了。祂说你会带着好消息回来，而事实的确如此。因为我们现在是私下谈话，我告诉你一件事。那些在沙漠里到处跑的‘镀金者’，我觉得他们是真心实意的一群人。我认为无论他们在哪儿祈祷，此刻他们都在那里祈祷。你根本就没有动摇他们的信仰，总有一天我们还得再去那儿。%SPEECH_OFF% 这位贵族站起身转过身来。%SPEECH_ON%失败只会让信徒更加坚定。我已经吃了亏，现在轮到他们了。当你拿这笔任务的酬金时，记得祈祷一下，希望这是你为此拿的最后一笔钱。%SPEECH_OFF% 你当然不会这么做，但觉得在这种掏心掏肺的时刻说实话很不合适。不过，拿着吧, 这袋子里装着 %reward% 克朗。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "保卫圣地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isHolyWar())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function spawnAlly()
	{
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y + 4; y <= o.Y + 6; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.getFaction());
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			this.logInfo("姓名：" + s.getName());

			if (s.isMilitary())
			{
				candidates.push(s);
			}
		}

		local party = f.spawnEntity(tiles[0].Tile, candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly() + " Company", true, this.Const.World.Spawn.Noble, this.Math.rand(100, 150) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("为地方领主服务的专业士兵。");
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 3);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r == 1)
		{
			party.addToInventory("supplies/bread_item");
		}
		else if (r == 2)
		{
			party.addToInventory("supplies/roots_and_berries_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dried_fruits_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/ground_grains_item");
		}

		local c = party.getController();
		local move = this.new("scripts/ai/world/orders/move_order");
		move.setDestination(this.m.Destination.getTile());
		c.addOrder(move);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(240.0);
		c.addOrder(guard);
		return party;
	}

	function spawnEnemy()
	{
		local cityState = this.World.FactionManager.getFaction(this.getFaction());
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y - 4; y <= o.Y - 3; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.m.Flags.get("EnemyID"));
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			candidates.push(s);
		}

		local party = f.spawnEntity(tiles[0].Tile, "Regiment of " + candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly(), true, this.Const.World.Spawn.Southern, (this.m.Flags.get("IsEnemyLuredAway") ? 130 : 160) * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("忠于城邦的应征士兵。");
		party.setAttackableByAI(false);
		party.setAlwaysAttackPlayer(true);
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 3);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r <= 2)
		{
			party.addToInventory("supplies/rice_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dates_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/dried_lamb_item");
		}

		local c = party.getController();
		local attack = this.new("scripts/ai/world/orders/attack_zone_order");
		attack.setTargetTile(this.m.Destination.getTile());
		c.addOrder(attack);
		local occupy = this.new("scripts/ai/world/orders/occupy_order");
		occupy.setTarget(this.m.Destination);
		occupy.setTime(10.0);
		occupy.setSafetyOverride(true);
		c.addOrder(occupy);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(999.0);
		c.addOrder(guard);
		return party;
	}

	function onPrepareVariables( _vars )
	{
		local illustrations = [
			"event_152",
			"event_154",
			"event_151"
		];
		_vars.push([
			"illustration",
			illustrations[this.m.Flags.get("DestinationIndex")]
		]);
		_vars.push([
			"holysite",
			this.m.Flags.get("DestinationName")
		]);
		_vars.push([
			"employerfaction",
			this.World.FactionManager.getFaction(this.m.Faction).getName()
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
			}

			if (this.m.Target != null && !this.m.Target.isNull())
			{
				this.m.Target.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isHolyWar())
		{
			return false;
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					return true;
				}
			}
		}

		return false;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Target != null && !this.m.Target.isNull())
		{
			_out.writeU32(this.m.Target.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local target = _in.readU32();

		if (target != 0)
		{
			this.m.Target = this.WeakTableRef(this.World.getEntityByID(target));
		}

		this.contract.onDeserialize(_in);
	}

});

