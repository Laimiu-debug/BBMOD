this.defend_holy_site_southern_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Target = null,
		IsPlayerAttacking = false
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.defend_holy_site_southern";
		this.m.Name = "保卫圣地";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();
		local target;
		local targetIndex = 0;
		local closestDist = 9000;
		local myTile = this.m.Home.getTile();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					local d = myTile.getDistanceTo(v.getTile());

					if (d < closestDist)
					{
						target = v;
						targetIndex = i;
						closestDist = d;
					}
				}
			}
		}

		this.m.Destination = this.WeakTableRef(target);
		this.m.Destination.setVisited(true);
		this.m.Payment.Pool = 1200 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}

		local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
		local houses = [];

		foreach( n in nobles )
		{
			if (n.getFlags().get("IsHolyWarParticipant"))
			{
				houses.push(n);
			}
		}

		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Flags.set("DestinationIndex", targetIndex);
		this.m.Flags.set("EnemyID", houses[this.Math.rand(0, houses.len() - 1)].getID());
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往 %holysite%，保卫它，抵御北方的异教者"
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 25)
				{
					this.Flags.set("IsAlchemist", true);
				}

				local r = this.Math.rand(1, 100);

				if (r <= 30)
				{
					this.Flags.set("IsSallyForth", true);
				}
				else if (r <= 60)
				{
					this.Flags.set("IsAlliedSoldiers", true);
				}

				local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
				local houses = [];

				foreach( n in nobles )
				{
					if (n.getFlags().get("IsHolyWarParticipant"))
					{
						n.addPlayerRelation(-99.0, "在战争选择了阵营");
						houses.push(n);
					}
				}

				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);

				if (this.Contract.getDifficultyMult() >= 0.95)
				{
					local f = houses[this.Math.rand(0, houses.len() - 1)];
					local candidates = [];

					foreach( s in f.getSettlements() )
					{
						if (s.isMilitary())
						{
							candidates.push(s);
						}
					}

					local party = f.spawnEntity(this.Contract.m.Destination.getTile(), candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly() + " Company", true, this.Const.World.Spawn.Noble, this.Math.rand(100, 150) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getMinibossModifier());
					party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
					party.setDescription("为地方领主服务的职业士兵。");
					party.getLoot().Money = this.Math.rand(50, 200);
					party.getLoot().ArmorParts = this.Math.rand(0, 25);
					party.getLoot().Medicine = this.Math.rand(0, 3);
					party.getLoot().Ammo = this.Math.rand(0, 30);
					local r = this.Math.rand(1, 4);

					if (r == 1)
					{
						party.addToInventory("supplies/bread_item");
					}
					else if (r == 2)
					{
						party.addToInventory("supplies/roots_and_berries_item");
					}
					else if (r == 3)
					{
						party.addToInventory("supplies/dried_fruits_item");
					}
					else if (r == 4)
					{
						party.addToInventory("supplies/ground_grains_item");
					}

					local c = party.getController();
					local roam = this.new("scripts/ai/world/orders/roam_order");
					roam.setAllTerrainAvailable();
					roam.setTerrain(this.Const.World.TerrainType.Ocean, false);
					roam.setTerrain(this.Const.World.TerrainType.Shore, false);
					roam.setTerrain(this.Const.World.TerrainType.Mountains, false);
					roam.setPivot(this.Contract.m.Destination);
					roam.setMinRange(4);
					roam.setMaxRange(8);
					roam.setTime(300.0);
				}

				local entities = this.World.getAllEntitiesAtPos(this.Contract.m.Destination.getPos(), 1.0);

				foreach( e in entities )
				{
					if (e.isParty())
					{
						e.getController().clearOrders();
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Flags.get("IsAlchemist") && this.Contract.isPlayerAt(this.Contract.m.Home) && this.World.Assets.getStash().getNumberOfEmptySlots() >= 2)
				{
					this.Contract.setScreen("Alchemist1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					this.Contract.setScreen("Approaching" + this.Flags.get("DestinationIndex"));
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Running_Defend",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"保卫 %holysite%，抵御南方异教徒的侵犯",
					"摧毁或击溃附近的敌方部队",
					"不要走得太远"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}

				if (this.Contract.m.Target != null && !this.Contract.m.Target.isNull())
				{
					this.Contract.m.Target.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Flags.get("IsFailure") || !this.Contract.isPlayerNear(this.Contract.m.Destination, 700) || !this.World.FactionManager.isAllied(this.Contract.getFaction(), this.Contract.m.Destination.getFaction()))
				{
					this.Contract.setScreen("Failure");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsSallyForthNextWave"))
				{
					this.Contract.setScreen("SallyForth3");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsVictory"))
				{
					if (!this.Contract.isEnemyPartyNear(this.Contract.m.Destination, 400.0))
					{
						this.Contract.setScreen("Victory");
						this.World.Contracts.showActiveContract();
					}
				}
				else if (!this.Flags.get("IsTargetDiscovered") && this.Contract.m.Target != null && !this.Contract.m.Target.isNull() && this.Contract.m.Target.isDiscovered())
				{
					this.Flags.set("IsTargetDiscovered", true);
					this.Contract.setScreen("TheEnemyAttacks");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsArrived") && this.Flags.get("AttackTime") > 0 && this.Time.getVirtualTimeF() >= this.Flags.get("AttackTime"))
				{
					if (this.Flags.get("IsSallyForth"))
					{
						this.Contract.setScreen("SallyForth1");
						this.World.Contracts.showActiveContract();
					}
					else if (this.Flags.get("IsAlliedSoldiers"))
					{
						this.Contract.setScreen("AlliedSoldiers1");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Flags.set("AttackTime", 0.0);
						local party = this.Contract.spawnEnemy();
						party.setOnCombatWithPlayerCallback(this.Contract.getActiveState().onDestinationAttacked.bindenv(this));
						this.Contract.m.Target = this.WeakTableRef(party);
					}
				}
			}

			function onDestinationAttacked( _dest, _isPlayerInitiated = false )
			{
				if (this.Flags.get("IsSallyForthNextWave"))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "DefendHolySite";
					p.Music = this.Const.Music.NobleTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.Entities = [];
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];

					if (this.Flags.get("IsLocalsRecruited"))
					{
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsSouthern, 10, this.Contract.getFaction());
						p.AllyBanners.push("banner_noble_11");
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else if (this.Flags.get("IsSallyForth"))
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "DefendHolySite";
					p.Music = this.Const.Music.NobleTracks;
					p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
					p.Entities = [];
					this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, (this.Flags.get("IsEnemyReinforcements") ? 130 : 100) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Flags.get("EnemyID"));
					p.EnemyBanners = [
						this.World.FactionManager.getFaction(this.Flags.get("EnemyID")).getPartyBanner()
					];

					if (this.Flags.get("IsLocalsRecruited"))
					{
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsSouthern, 50, this.Contract.getFaction());
						p.AllyBanners.push("banner_noble_11");
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.LocationTemplate = clone this.Const.Tactical.LocationTemplate;
					p.LocationTemplate.OwnedByFaction = this.Const.Faction.Player;
					p.CombatID = "DefendHolySite";

					if (this.Contract.isPlayerAt(this.Contract.m.Destination))
					{
						p.LocationTemplate.Template[0] = "tactical.southern_ruins";
						p.LocationTemplate.Fortification = this.Flags.get("IsPalisadeBuilt") ? this.Const.Tactical.FortificationType.WallsAndPalisade : this.Const.Tactical.FortificationType.Walls;
						p.LocationTemplate.CutDownTrees = true;
						p.LocationTemplate.ShiftX = -4;
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.LineForward;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.LineBack;
						p.AllyBanners = [
							this.World.Assets.getBanner()
						];

						if (this.Flags.get("IsAlliedReinforcements"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Southern, 50 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
							p.AllyBanners.push(this.World.FactionManager.getFaction(this.Contract.getFaction()).getPartyBanner());
						}

						if (this.Flags.get("IsLocalsRecruited"))
						{
							this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.PeasantsSouthern, 50, this.Contract.getFaction());
							p.AllyBanners.push("banner_noble_11");
						}
					}

					this.World.Contracts.startScriptedCombat(p, false, true, true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "DefendHolySite")
				{
					if (this.Flags.get("IsSallyForthNextWave"))
					{
						this.Flags.set("IsSallyForthNextWave", false);
						this.Flags.set("IsSallyForth", false);
						this.Flags.set("IsVictory", true);
					}
					else if (this.Flags.get("IsSallyForth"))
					{
						this.Flags.set("IsSallyForthNextWave", true);
					}
					else
					{
						this.Flags.set("IsVictory", true);
					}
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "DefendHolySite")
				{
					this.Flags.set("IsFailure", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "{[img]gfx/ui/events/event_163.png[/img]%employer% 不见踪影。取而代之的是一个身着神职人员服饰的男人，旁边站着一位中将。他们声称，一支北方士兵的队伍正逼近 %holysite%，意图将其完全占为己有。由于城邦的士兵都派往别处，他们将不得不依靠你尽快赶往那里并加以防御。他们强硬的语气中带着一丝焦虑，这无疑使得这可能成为一笔能让你腰包鼓鼓的买卖。 | [img]gfx/ui/events/event_162.png[/img]你被推入 %employer% 的房间，维齐尔向你点头并鼓掌。%SPEECH_ON%终于，小逐币者来了，准备为我们大家做一番大事。来，看看这张地图。你看到我的士兵在哪里了吗？ 你看到 %holysite% 在哪里了吗？ 就在那儿，那些北方老鼠…… 他们离圣地很近，而我的人离得很远。 然而，你就在这里，真的很近，不是吗？ 这是 %reward% 克朗，我要你前往 %holysite% 并保卫它。%SPEECH_OFF%维齐尔带着温暖的微笑凝视着你，仿佛这根本不是在提问，而是一个用黄金压得沉甸甸的请求，几乎等同于命令。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{%companyname% 可以帮你处理这个。 | 防御北方敌人这活儿，最好给足报酬。 | 我很感兴趣，说下去。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不值得。 | 别的地方更需要我们。 | 我不原意让战团冒险与北方大军正面对抗。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Approaching1",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{巨大的破火山口已经基本清空了它那些忠诚而好奇的住客。哪怕只有一丁点战争的迹象，就已将信徒们驱散回各自修道院的庇护所中。毕竟，在接下来的几个小时里，这里终会分出个胜负。某种程度的狂热劲头，或许会诱使获胜的那一方在正义的名义下放纵过度……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Approaching0",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{神谕之地已经不是你记忆中的模样了：许多虔诚的信徒已然离去，而战争的鼓点已逼近这座古老寺庙的门槛。不过，这一切都无关紧要。你此行并非来此寻求神启或解开梦境，你只为给你的敌人制造噩梦而来。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Approaching2",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{具有讽刺意味的是，这座栖身于半毁山脉之下的平顶城市，此刻却透出了一种怪诞的荒废感。少数信徒在此徘徊，其余的人则早已在宗教纷争波及他们的帐篷营地与精神领地之前离去。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会在这里扎营。",
					function getResult()
					{
						return "Preparation1";
					}

				}
			],
			function start()
			{
				this.Flags.set("IsArrived", true);
			}

		});
		this.m.Screens.push({
			ID = "Preparation1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你认为自己已经利用 %holysite% 所能提供的地形，构筑起了一个勉强够用的防御阵地。 剩下的时间不多了，至少可以让 %companyname% 去完成一项至关重要的任务。问题只在于，究竟做些什么才最符合这支队伍的利益。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "建起木栅栏来加固防守！",
					function getResult()
					{
						return "Preparation2";
					}

				},
				{
					Text = "搜查这片区域，看看有没有对我们有用的东西！",
					function getResult()
					{
						return "Preparation3";
					}

				},
				{
					Text = "招募一些忠实信徒，协助我们防守！",
					function getResult()
					{
						return "Preparation4";
					}

				}
			],
			function start()
			{
				this.Contract.setState("Running_Defend");
			}

		});
		this.m.Screens.push({
			ID = "Preparation2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你悄悄洗劫了这座圣地，这件事你绝不会向任何人透露，又翻遍了信徒们遗弃的物品，好不容易拼凑出足够的木材，加固了环绕 %holysite%一角的一段城墙。在你看来，这里是敌人最可能攻入的突破口，自然也是你最需要死守的地方。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsPalisadeBuilt", true);
			}

		});
		this.m.Screens.push({
			ID = "Preparation3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你派手下搜遍了整个区域，寻找可用于战斗的物资。众人窃取了大量物品，并将其堆成小山。等把 %holysite% 彻底搜刮一空后，你和弟兄们花了几分钟时间，琢磨着哪些东西最派得上用场……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				for( local i = 0; i < 3; i = ++i )
				{
					local r = this.Math.rand(1, 12);
					local item;

					switch(r)
					{
					case 1:
						item = this.new("scripts/items/weapons/oriental/saif");
						break;

					case 2:
						item = this.new("scripts/items/tools/throwing_net");
						break;

					case 3:
						item = this.new("scripts/items/weapons/oriental/polemace");
						break;

					case 4:
						item = this.new("scripts/items/weapons/ancient/broken_ancient_sword");
						break;

					case 5:
						item = this.new("scripts/items/armor/ancient/ancient_mail");
						break;

					case 6:
						item = this.new("scripts/items/supplies/ammo_item");
						break;

					case 7:
						item = this.new("scripts/items/supplies/armor_parts_item");
						break;

					case 8:
						item = this.new("scripts/items/shields/ancient/tower_shield");
						break;

					case 9:
						item = this.new("scripts/items/loot/ancient_gold_coins_item");
						break;

					case 10:
						item = this.new("scripts/items/loot/silver_bowl_item");
						break;

					case 11:
						item = this.new("scripts/items/weapons/wooden_stick");
						break;

					case 12:
						item = this.new("scripts/items/helmets/oriental/spiked_skull_cap_with_mail");
						break;
					}

					if (item.getConditionMax() > 1)
					{
						item.setCondition(this.Math.max(1, item.getConditionMax() * this.Math.rand(10, 50) * 0.01));
					}

					this.World.Assets.getStash().add(item);
					this.List.push({
						id = 10,
						icon = "ui/items/" + item.getIcon(),
						text = "你获得了" + item.getName()
					});
				}
			}

		});
		this.m.Screens.push({
			ID = "Preparation4",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{仍在 %holysite% 周围仍留下的少数忠实信徒，必然是最狂热和最虔诚的。既然你代表南方来到此地，便让手下挑选了几名‘镀金者’的追随者，要求他们为自己的神明而战。这无疑是现成的征兵手段，他们很快便武装起来，并接受了最简短的训练。你只能寄希望于他们在即将到来的真正战斗中能派上点用场。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "现在我们等着。",
					function getResult()
					{
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsLocalsRecruited", true);
			}

		});
		this.m.Screens.push({
			ID = "TheEnemyAttacks",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{北方的军队已经到了。或者说，是他们残存的部队。身着重甲，携带重武器，长途跋涉让他们的队伍有些削弱，但看起来依然是一场相当严峻的挑战。 你转头看向 %randombrother%，只见他耸了耸肩。%SPEECH_ON%{除了眼前的景色不同，这也不过是另一场战斗罢了，不是吗？ | 我知道大家都会聊些这个那个的宗教屁话，但坦白说，对我来说，这不过又是一场战斗而已。而我爱死这个了。}%SPEECH_OFF%你点点头，拔出佩剑，命令弟兄们准备迎战。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "列阵！",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Alchemist1",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_163.png[/img]{一名男子在 %townname% 的城门口走近了你。从他胸前那些五颜六色、花里胡哨的弹药带和护身符来看，他应该是个炼金术士。他自称是维齐尔派来的。%SPEECH_ON%我手头的材料有点紧缺，不过还是足够制作一些特定的东西的，当然，具体做什么还得听您的吩咐。%SPEECH_OFF%他向你介绍，他的炼金产物主要有这几种：火油罐、闪光弹和烟雾弹。}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "我们要火油罐。",
					function getResult()
					{
						this.Flags.set("IsFirepot", true);
						return "Alchemist2";
					}

				},
				{
					Text = "我们要闪光罐。",
					function getResult()
					{
						this.Flags.set("IsFlashpot", true);
						return "Alchemist2";
					}

				},
				{
					Text = "我们要烟雾罐。",
					function getResult()
					{
						this.Flags.set("IsSmokepot", true);
						return "Alchemist2";
					}

				},
				{
					Text = "我们已经有了我们所需的一切了。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsAlchemist", false);
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "Alchemist2",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_163.png[/img]{炼金术士动作很快，将一大堆粉末状的原料倒进碗里，又捣碎混入了一些你根本认不出来的材料。整个过程出人意料地短暂，你也不确定这是因为他的技艺太高超，还是这整件事根本就是个骗局。但不管怎样，他还是如约把那些罐子交给了你。%SPEECH_ON%愿镀金者照亮你的道路，愿你的剑将和平带到 %holysite%。%SPEECH_OFF%}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "这些应该会派上用场。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();

				for( local i = 0; i < 2; i = ++i )
				{
					local item;

					if (this.Flags.get("IsFirepot"))
					{
						item = this.new("scripts/items/tools/fire_bomb_item");
					}
					else if (this.Flags.get("IsFlashpot"))
					{
						item = this.new("scripts/items/tools/daze_bomb_item");
					}
					else if (this.Flags.get("IsSmokepot"))
					{
						item = this.new("scripts/items/tools/smoke_bomb_item");
					}

					this.World.Assets.getStash().add(item);
					this.List.push({
						id = 10,
						icon = "ui/items/" + item.getIcon(),
						text = "你获得了一个 " + item.getName()
					});
				}
			}

		});
		this.m.Screens.push({
			ID = "SallyForth1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{北方人出现了，但他们并未集结全力而来，而且来的也不一定全是侦察兵。看来他们在行军时没怎么保持队形，而是散开了阵势推进。 如果你现在立刻出击进攻，很有机会打他们个措手不及。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们必须抓住这个机会。立刻准备出击，整队迎敌！",
					function getResult()
					{
						return this.Math.rand(1, 100) <= 50 ? "SallyForth2" : "SallyForth4";
					}

				},
				{
					Text = "我们在这里有易守难攻的优势，按兵不动。",
					function getResult()
					{
						return "SallyForth5";
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_156.png[/img]{%SPEECH_START%好主意。%SPEECH_OFF%%randombrother% 附和着你的命令。于是，%companyname% 全速开拔，赶在北方人集结全部兵力之前截击他们。 你穿过田野，转眼间便已抵达。他们仍在卸载装备和器材，一看到你，几个营地随从立刻惊慌失措地逃命。其余士兵则匆忙拿起武器。 从尖锐的嗓音判断，现场唯一的指挥官显然没受过这种场面的训练，他扯着嗓子发号施令，几近破音，而士兵们则试图勉强组成某种阵型。不再浪费时间，你径直冲入混战之中！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "冲锋！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_90.png[/img]{你解决了最后一名士兵，他们脸上惊讶的表情依然凝固着。%SPEECH_ON%头儿，剩下的人来了。%SPEECH_OFF%%randombrother% 从对地平线的匆匆一瞥后返回说道。 你点了点头，下令弟兄们准备迎战。 这一次，南方人保持着整齐的阵型推进，尽管在看到你以及散落在脚边的尸体时，阵型短暂地动摇了一下。他们的旗帜升上天空，北方人的士气瞬间重振，带着愤怒与力量冲锋而来。 你低头看向 %randombrother%，顺手拂去他肩上的一块碎肉。当他回过头时，你只是微微一笑。%SPEECH_ON%好戏开场了，你也该打扮得体面些。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "集合！整队！准备迎敌！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "SallyForth4",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_78.png[/img]{%SPEECH_START%好主意。%SPEECH_OFF%%randombrother% 附和着你的命令。于是，%companyname% 全速开拔，赶在南方人集结全部兵力之前截击他们。 你穿过田野，转眼间便已抵达。他们仍在卸载装备和器材，一看到你，几个营地随从立刻惊慌失措地逃命。其余士兵则匆忙拿起武器。 就在你以为胜券在握之时，另一支援军突然从侧翼杀到。%SPEECH_ON%该死，这几乎是他们的全部人马了！%SPEECH_OFF%%randombrother% 说道。由于己方防御阵地距离太远，而敌人却又近在咫尺，此刻的出路只有一条。你高举长剑，率领众人准备冲锋。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们要杀出一条血路！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				this.Flags.set("IsEnemyReinforcements", true);
			}

		});
		this.m.Screens.push({
			ID = "SallyForth5",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{你认为坚守阵地是上策。这么做或许会错失良机，但至少是目前最稳妥的选择。%SPEECH_ON%早该主动出击的。我们这次错失了什么，头儿。%SPEECH_OFF%回头一看，只见 %randombrother% 耸了耸肩说道。 你警告他管好自己的嘴，否则他待会儿就会缺点什么。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "全员准备！他们很快就会发起总攻。",
					function getResult()
					{
						this.Flags.set("IsSallyForth", false);
						this.Flags.set("AttackTime", 1.0);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers1",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{当你们正等待北方人到来时，一小队南方士兵差点对你们发动了突袭。幸运的是，他们是友军，并主动提出效劳。%SPEECH_ON%镀金者告诉我们你们应该在这里，虽然你是逐币者，但为了祂的荣耀，我们愿意服从你的指挥来保卫此地。%SPEECH_OFF%从他们的装备来看，把他们当作掩护部队，用来引开一部分正在逼近的敌军或许是最佳用法。不过，也许现在最好的办法是暂时将他们整编进 %companyname%，在你原本就最强的战线上进一步充实兵力。}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "我需要你和你的人去侧翼包抄他们的弩手，中尉。",
					function getResult()
					{
						this.Flags.set("IsEnemyLuredAway", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers2";
					}

				},
				{
					Text = "我需要你和你的人去引开一部分步兵，中尉。",
					function getResult()
					{
						this.Flags.set("IsEnemyLuredAway", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers2";
					}

				},
				{
					Text = "我需要你和你的人并肩作战，中尉。",
					function getResult()
					{
						this.Flags.set("IsAlliedReinforcements", true);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return "AlliedSoldiers3";
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
				this.Flags.set("IsAlliedSoldiers", false);
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers2",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{你掏出单筒望远镜，观察着前方的战场。南方士兵像蚂蚁一样散开，与北方人交上了火。令你惊讶的是，佯攻竟然奏效了。你咧嘴一笑，看着北方部队分兵追击，阵型因此变得松散。}",
			Image = "",
			Banner = "",
			List = [],
			Options = [
				{
					Text = "非常好。",
					function getResult()
					{
						this.Flags.set("IsAlliedSoldiers", false);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "AlliedSoldiers3",
			Title = "在 %holysite%",
			Text = "[img]gfx/ui/events/event_164.png[/img]{你更希望这些士兵留下来跟着你。中尉点了点头。%SPEECH_ON%镀金者派我们来帮助你，不管你怎么想，祂也同样信任你。%SPEECH_OFF%行吧，随便。你指了个方向，他们便带着令人厌烦的宗教式顺从立刻执行，一路上还喋喋不休地念叨着什么金光、圣光之类的东西。}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "现在我们接着等吧。",
					function getResult()
					{
						this.Flags.set("IsAlliedSoldiers", false);
						this.Flags.set("AttackTime", this.Time.getVirtualTimeF() + this.Math.rand(5, 10));
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.getFaction()).getUIBanner();
			}

		});
		this.m.Screens.push({
			ID = "Victory",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_87.png[/img]{最后一名活着的北方人倒在地上，胸前带着伤口，鲜血染红了地面。他的眼神变得悠远，呼吸平缓，仿佛已预感到大势已去。你拔出剑，但他却抬手示意。不是为了求饶，而是想再留片刻。%SPEECH_ON%不必了。我自己能感觉到。它走了。一切都走了。真不知道我当初为什么那么在乎。%SPEECH_OFF%他身子一软，手从胸口滑落。%randombrother% 用脚踢了踢尸体，随后开始搜刮。你收剑入鞘，命令士兵们准备启程返回维齐尔那里。 | 你的手下正忙着处理最后几个幸存者。这活儿很简单，不过是用利刃快速补上一两下刺穿尸体。有些尸体被刺时还会抽搐一下，但你知道他们已经死透了。你搞不懂为什么尸体还会动，仿佛那个曾经的人把恐惧留在了躯壳里。其他的则毫无反应。有个试图藏起来的士兵突然尖叫了一声，但很快就被制伏了。战场上尸横遍野，你让 %companyname% 去搜刮所有能用的东西，然后准备返回维齐尔那里。 | 最后一名北方人将自己逼进了两块巨石的夹缝中，双手向两侧张开，像个蜘蛛一样缩回了隐秘的洞穴。%SPEECH_ON%旧神不会怜悯你们的。%SPEECH_OFF%上方一道黑影一闪而过，紧接着那黑影的实体砸了下来，砸碎了那人的脑袋。他倒在地上的身体不断抽搐，嘴里发出咯咯的声响。%randombrother% 站在两块巨石的顶端俯视着。%SPEECH_ON%这下是最后一个了。我们该去搜刮点装备，然后回去找那个，呃，那个装腔作势的，维齐…维兹…子爵？%SPEECH_OFF%是维齐尔。不过，差不多吧。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "胜利！",
					function getResult()
					{
						this.Contract.spawnAlly();
						this.Contract.setState("Return");
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Failure",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/%illustration%.png[/img]{好吧，%holysite% 现在已经落入北方人手中了。鉴于你对自己的脑袋格外珍惜，并且希望它能一直待在脖子上，你认为暂时还是别回去找维齐尔了。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "灾难！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能保卫圣地");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Success",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%employer% 躲在一个远离他宫殿的偏僻小修道院里。在这里找到他实在有些出人意料，他脚边只围着一小群贫穷的追随者，正聆听着他的教诲。维齐尔瞥了你一眼，随即在讲话中途朝另一个人点了点头。片刻后，一个留胡子的男人佩着两把剑向你走来。他上下打量了你一番，然后侧身让开，露出两名抬着一个箱子的仆人。%SPEECH_ON%维齐尔向你致谢，逐币者。愿你永远走在镀金之路上。%SPEECH_OFF%当然，钱一到手，你立刻就被请了出去。大门在你身后关上时，维齐尔连个点头或挥手的表示都没有。 | 你被带过一条长长的走廊，进入一间空荡荡的屋子。一时间，你怀疑自己是不是要在这里被出卖。但背叛很少会发生在不希望弄出乱子的地方。当你盯着干净的石质地板时，%employer% 从另一侧走了进来。他站在几英尺开外，空旷的房间让他的声音产生了回响。%SPEECH_ON%据说你们浴血奋战，而那些北方人，在战场上证明了他们只是一群会叫的狗罢了。我猜后半句是句谎话，只是为了取悦我。但我是个思想家，也是个现实主义者。我想象你发现敌人的决心相当顽强，就像他们也会如此评价我们一样。你会得到我们约定好的报酬，逐币者。%SPEECH_OFF%一群人突然鱼贯而入，站在维齐尔身后，你再次怀疑他们是否另有所图。让你松了一口气的是，他们带来了装满硬币的钱袋。当你再回头看向门口时，%employer% 已经不见了，片刻后他的仆人们也跟着不见了。 | %employer% 将你迎进一个房间，里面除了他，还有几位精选的宗教人士。这些朴素的修道院长们依次走到你面前，向你短暂地鞠了一躬。维齐尔没有参与其中，但他打了个响指，仆人们便拖过来一个装满皇冠的大箱子。最后，这些教士们转身面向维齐尔，以同样的队列向他鞠躬，甚至还亲吻了他的脚和一枚戒指，这些可不在你的待遇清单上。%employer% 开口了。%SPEECH_ON%我们的道路一直金光闪耀，逐币者。 镀金者竟将如此重任托付于我，让我雇佣你，一个本会被许多人忽视的卑微佣兵，来为我保全 %holysite%。我真是受宠若惊。真的。%SPEECH_OFF%你拿走了金子就走，最后看到的画面是那些穿着长袍的人们排着队回来领第二轮赏赐。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "保卫圣地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isHolyWar())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCriticalContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function spawnAlly()
	{
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y - 6; y <= o.Y - 3; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.getFaction());
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			candidates.push(s);
		}

		local party = f.spawnEntity(tiles[0].Tile, "Regiment of " + candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly(), true, this.Const.World.Spawn.Southern, this.Math.rand(100, 150) * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("忠于城邦的应征士兵。");
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 3);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r <= 2)
		{
			party.addToInventory("supplies/rice_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dates_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/dried_lamb_item");
		}

		local c = party.getController();
		local move = this.new("scripts/ai/world/orders/move_order");
		move.setDestination(this.m.Destination.getTile());
		c.addOrder(move);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(240.0);
		c.addOrder(guard);
		return party;
	}

	function spawnEnemy()
	{
		local cityState = this.World.FactionManager.getFaction(this.getFaction());
		local o = this.m.Destination.getTile().SquareCoords;
		local tiles = [];

		for( local x = o.X - 4; x < o.X + 4; x = ++x )
		{
			for( local y = o.Y + 4; y <= o.Y + 6; y = ++y )
			{
				if (!this.World.isValidTileSquare(x, y))
				{
				}
				else
				{
					local tile = this.World.getTileSquare(x, y);

					if (tile.Type == this.Const.World.TerrainType.Ocean)
					{
					}
					else
					{
						local s = this.Math.rand(0, 3);

						if (tile.Type == this.Const.World.TerrainType.Mountains)
						{
							s = s - 10;
						}

						if (tile.HasRoad)
						{
							s = s + 10;
						}

						tiles.push({
							Tile = tile,
							Score = s
						});
					}
				}
			}
		}

		if (tiles.len() == 0)
		{
			tiles.push({
				Tile = this.m.Destination.getTile(),
				Score = 0
			});
		}

		tiles.sort(function ( _a, _b )
		{
			if (_a.Score > _b.Score)
			{
				return -1;
			}
			else if (_a.Score < _b.Score)
			{
				return 1;
			}

			return 0;
		});
		local f = this.World.FactionManager.getFaction(this.m.Flags.get("EnemyID"));
		local candidates = [];

		foreach( s in f.getSettlements() )
		{
			if (s.isMilitary())
			{
				candidates.push(s);
			}
		}

		local party = f.spawnEntity(tiles[0].Tile, candidates[this.Math.rand(0, candidates.len() - 1)].getNameOnly() + " Company", true, this.Const.World.Spawn.Noble, (this.m.Flags.get("IsEnemyLuredAway") ? 130 : 160) * this.getDifficultyMult() * this.getScaledDifficultyMult(), this.getMinibossModifier());
		party.getSprite("body").setBrush(party.getSprite("body").getBrush().Name + "_" + f.getBannerString());
		party.setDescription("为地方领主服务的专业士兵。");
		party.setAttackableByAI(false);
		party.setAlwaysAttackPlayer(true);
		party.getLoot().Money = this.Math.rand(50, 200);
		party.getLoot().ArmorParts = this.Math.rand(0, 25);
		party.getLoot().Medicine = this.Math.rand(0, 3);
		party.getLoot().Ammo = this.Math.rand(0, 30);
		local r = this.Math.rand(1, 4);

		if (r == 1)
		{
			party.addToInventory("supplies/bread_item");
		}
		else if (r == 2)
		{
			party.addToInventory("supplies/roots_and_berries_item");
		}
		else if (r == 3)
		{
			party.addToInventory("supplies/dried_fruits_item");
		}
		else if (r == 4)
		{
			party.addToInventory("supplies/ground_grains_item");
		}

		local c = party.getController();
		local attack = this.new("scripts/ai/world/orders/attack_zone_order");
		attack.setTargetTile(this.m.Destination.getTile());
		c.addOrder(attack);
		local occupy = this.new("scripts/ai/world/orders/occupy_order");
		occupy.setTarget(this.m.Destination);
		occupy.setTime(10.0);
		occupy.setSafetyOverride(true);
		c.addOrder(occupy);
		local guard = this.new("scripts/ai/world/orders/guard_order");
		guard.setTarget(this.m.Destination.getTile());
		guard.setTime(999.0);
		c.addOrder(guard);
		return party;
	}

	function onPrepareVariables( _vars )
	{
		local illustrations = [
			"event_152",
			"event_154",
			"event_151"
		];
		_vars.push([
			"illustration",
			illustrations[this.m.Flags.get("DestinationIndex")]
		]);
		_vars.push([
			"holysite",
			this.m.Flags.get("DestinationName")
		]);
		_vars.push([
			"employerfaction",
			this.World.FactionManager.getFaction(this.m.Faction).getName()
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
			}

			if (this.m.Target != null && !this.m.Target.isNull())
			{
				this.m.Target.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (!this.World.FactionManager.isHolyWar())
		{
			return false;
		}

		local sites = [
			"location.holy_site.oracle",
			"location.holy_site.meteorite",
			"location.holy_site.vulcano"
		];
		local locations = this.World.EntityManager.getLocations();

		foreach( v in locations )
		{
			foreach( i, s in sites )
			{
				if (v.getTypeID() == s && v.getFaction() != 0 && this.World.FactionManager.isAllied(this.getFaction(), v.getFaction()))
				{
					return true;
				}
			}
		}

		return false;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Target != null && !this.m.Target.isNull())
		{
			_out.writeU32(this.m.Target.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local target = _in.readU32();

		if (target != 0)
		{
			this.m.Target = this.WeakTableRef(this.World.getEntityByID(target));
		}

		this.contract.onDeserialize(_in);
	}

});

