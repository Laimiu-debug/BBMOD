this.defend_settlement_bandits_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Reward = 0,
		Kidnapper = null,
		Militia = null
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.defend_settlement_bandits";
		this.m.Name = "保卫城镇";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 5.0;
		this.m.MakeAllSpawnsResetOrdersOnContractEnd = false;
		this.m.MakeAllSpawnsAttackableByAIOnceDiscovered = true;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		this.m.Payment.Pool = 700 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"保卫 %townname% 及其郊区免受掠夺"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local nearestBandits = this.Contract.getNearestLocationTo(this.Contract.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getSettlements());
				local nearestZombies = this.Contract.getNearestLocationTo(this.Contract.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Zombies).getSettlements());

				if (nearestZombies.getTile().getDistanceTo(this.Contract.m.Home.getTile()) <= 20 && nearestBandits.getTile().getDistanceTo(this.Contract.m.Home.getTile()) > 20)
				{
					this.Flags.set("IsUndead", true);
				}
				else
				{
					local r = this.Math.rand(1, 100);

					if (r <= 20)
					{
						this.Flags.set("IsKidnapping", true);
					}
					else if (r <= 40)
					{
						if (this.Contract.getDifficultyMult() >= 0.95)
						{
							this.Flags.set("IsMilitia", true);
						}
					}
					else if (r <= 50 || this.World.FactionManager.isUndeadScourge() && r <= 70)
					{
						if (nearestZombies.getTile().getDistanceTo(this.Contract.m.Home.getTile()) <= 20)
						{
							this.Flags.set("IsUndead", true);
						}
					}
				}

				local number = 1;

				if (this.Contract.getDifficultyMult() >= 0.95)
				{
					number = number + this.Math.rand(0, 1);
				}

				if (this.Contract.getDifficultyMult() >= 1.1)
				{
					number = number + 1;
				}

				local locations = this.Contract.m.Home.getAttachedLocations();
				local targets = [];

				foreach( l in locations )
				{
					if (l.isActive() && !l.isMilitary() && l.isUsable())
					{
						targets.push(l);
					}
				}

				number = this.Math.min(number, targets.len());
				this.Flags.set("ActiveLocations", targets.len());

				for( local i = 0; i != number; i = ++i )
				{
					local party;

					if (this.Flags.get("IsUndead"))
					{
						party = this.Contract.spawnEnemyPartyAtBase(this.Const.FactionType.Zombies, this.Math.rand(80, 110) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}
					else
					{
						party = this.Contract.spawnEnemyPartyAtBase(this.Const.FactionType.Bandits, this.Math.rand(80, 110) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}

					party.setAttackableByAI(false);
					local c = party.getController();
					c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
					c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
					local t = this.Math.rand(0, targets.len() - 1);

					if (i > 0)
					{
						local wait = this.new("scripts/ai/world/orders/wait_order");
						wait.setTime(4.0 * i);
						c.addOrder(wait);
					}

					local move = this.new("scripts/ai/world/orders/move_order");
					move.setDestination(targets[t].getTile());
					c.addOrder(move);
					local raid = this.new("scripts/ai/world/orders/raid_order");
					raid.setTime(40.0);
					raid.setTargetTile(targets[t].getTile());
					c.addOrder(raid);
					targets.remove(t);
				}

				this.Contract.m.Home.setLastSpawnTimeToNow();
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.Home.getSprite("selection").Visible = true;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(false);
			}

			function update()
			{
				if (this.Contract.m.UnitsSpawned.len() == 0 || this.Flags.get("IsEnemyHereDialogShown"))
				{
					local isEnemyGone = true;

					foreach( id in this.Contract.m.UnitsSpawned )
					{
						local p = this.World.getEntityByID(id);

						if (p != null && p.isAlive() && p.getDistanceTo(this.Contract.m.Home) <= 1200.0)
						{
							isEnemyGone = false;
							break;
						}
					}

					if (isEnemyGone)
					{
						if (this.Flags.get("HadCombat"))
						{
							this.Contract.setScreen("ItsOver");
							this.World.Contracts.showActiveContract();
						}

						this.Contract.setState("Return");
						return;
					}
				}

				if (!this.Flags.get("IsEnemyHereDialogShown"))
				{
					local isEnemyHere = false;

					foreach( id in this.Contract.m.UnitsSpawned )
					{
						local p = this.World.getEntityByID(id);

						if (p != null && p.isAlive() && p.getDistanceTo(this.Contract.m.Home) <= 700.0)
						{
							isEnemyHere = true;
							break;
						}
					}

					if (isEnemyHere)
					{
						this.Flags.set("IsEnemyHereDialogShown", true);

						foreach( id in this.Contract.m.UnitsSpawned )
						{
							local p = this.World.getEntityByID(id);

							if (p != null && p.isAlive())
							{
							}
						}

						if (this.Flags.get("IsUndead"))
						{
							this.Contract.setScreen("UndeadAttack");
						}
						else
						{
							this.Contract.setScreen("DefaultAttack");
						}

						this.World.Contracts.showActiveContract();
					}
				}
				else if (this.Flags.get("IsKidnapping") && !this.Flags.get("IsKidnappingInProgress") && this.Contract.m.UnitsSpawned.len() == 1)
				{
					local p = this.World.getEntityByID(this.Contract.m.UnitsSpawned[0]);

					if (p != null && p.isAlive() && !p.isHiddenToPlayer() && !p.getController().hasOrders())
					{
						local c = p.getController();
						c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(true);
						c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(true);
						this.Contract.m.Kidnapper = this.WeakTableRef(p);
						this.Flags.set("IsKidnappingInProgress", true);
						this.Flags.set("KidnappingTooLate", this.Time.getVirtualTimeF() + 60.0);
						this.Contract.setScreen("Kidnapping1");
						this.World.Contracts.showActiveContract();
						this.Contract.setState("Kidnapping");
					}
				}

				if (this.Flags.get("IsMilitia") && !this.Flags.get("IsMilitiaDialogShown"))
				{
					this.Flags.set("IsMilitiaDialogShown", true);
					this.Contract.setScreen("Militia1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

			function onCombatVictory( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

		});
		this.m.States.push({
			ID = "Kidnapping",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"营救被劫走的俘虏",
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = false;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(false);

				if (this.Contract.m.Kidnapper != null && !this.Contract.m.Kidnapper.isNull())
				{
					this.Contract.m.Kidnapper.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.m.Kidnapper == null || this.Contract.m.Kidnapper.isNull() || !this.Contract.m.Kidnapper.isAlive())
				{
					if (this.Time.getVirtualTimeF() - this.World.Events.getLastBattleTime() <= 5.0)
					{
						this.Flags.set("IsKidnapping", false);
						this.Contract.setScreen("Kidnapping2");
					}
					else
					{
						this.Contract.setScreen("Kidnapping3");
					}

					this.World.Contracts.showActiveContract();
					this.Contract.setState("Return");
				}
				else if (this.Contract.m.Kidnapper.isHiddenToPlayer() && this.Time.getVirtualTimeF() > this.Flags.get("KidnappingTooLate"))
				{
					this.Contract.setScreen("Kidnapping3");
					this.World.Contracts.showActiveContract();
					this.Contract.setState("Return");
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

			function onCombatVictory( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(true);

				if (this.Contract.m.Kidnapper != null && !this.Contract.m.Kidnapper.isNull())
				{
					this.Contract.m.Kidnapper.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					local locations = this.Contract.m.Home.getAttachedLocations();
					local numLocations = 0;

					foreach( l in locations )
					{
						if (l.isActive() && !l.isMilitary() && l.isUsable())
						{
							numLocations = ++numLocations;
						}
					}

					if (numLocations == 0 || this.Flags.get("ActiveLocations") - numLocations >= 2)
					{
						if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
						{
							this.Contract.setScreen("Failure2");
						}
						else
						{
							this.Contract.setScreen("Failure1");
						}
					}
					else if (this.Flags.get("ActiveLocations") - numLocations >= 1)
					{
						if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
						{
							this.Contract.setScreen("Success4");
						}
						else
						{
							this.Contract.setScreen("Success2");
						}
					}
					else if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
					{
						this.Contract.setScreen("Success3");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_20.png[/img]{%employer% 正望着窗外，朝你招手示意过去。%SPEECH_ON%看看那些人。%SPEECH_OFF%楼下是一群乱成一团的平民，正在哭哭啼啼。%SPEECH_ON%强盗在这片区域游荡有一阵子了，人们都觉得他们正准备大举进攻。%SPEECH_OFF%他猛地拉上窗帘，走去点亮一支蜡烛。他对着烛火说话，呼吸间让火焰不停摇曳。%SPEECH_ON%我们需要你来保护，佣兵。如果你能挡住这些强盗，报酬绝对丰厚。有兴趣吗？%SPEECH_OFF% | 几个农民在议事厅外徘徊，你能听到他们喊叫的声音，透着一股不安。%employer% 倒了一杯酒，手微微颤抖地抿了一口。%SPEECH_ON%我跟你直说吧，佣兵。我们收到了大量报告，说强盗马上要攻打这个镇子。如果你想知道详情，这些情报可都是伴随着死去的女人和孩子的尸体一起送来的。显然，我们没理由怀疑这些报告的严重性。所以，问题来了，你肯帮我们吗？ %SPEECH_OFF% | %employer% 正盯着桌上的几份文件。你坐下身，问他到底想干什么。%SPEECH_ON%你好，佣兵。我们有个麻烦，我觉得你会……很擅长处理。%SPEECH_OFF%你让他有话直说，他便直奔主题。%SPEECH_ON%强盗把城外的一些房屋和棚屋烧了。消息说，他们正在准备一次更大规模、更猛烈的进攻。我需要你留下来阻止他们。你觉得你能搞定这个任务吗？%SPEECH_OFF% | %employer% 背对着你，盯着书架发呆。他声音低沉地说道。%SPEECH_ON%可惜没几个人能读懂这些书。也许如果他们能读懂，我们的麻烦就没了。或者，也许只会变得更糟。%SPEECH_OFF%他摇了摇头，转过身来。%SPEECH_ON%我们有一帮强盗马上要来袭击了。我需要你，佣兵，去阻止他们。我的书反正肯定挡不住。我保证价钱会很合适，你有兴趣吗？%SPEECH_OFF% | %employer% 手里捏着两张纸，上面画着人像。%SPEECH_ON%前几天抓到这两个，绞死了，烧成灰了。%SPEECH_OFF%你耸了耸肩。%SPEECH_ON%恭喜？%SPEECH_OFF%这人一点没觉得好笑。%SPEECH_ON%现在我们得到消息，他们那帮强盗同伙要来报复我们了！没错，我们需要你帮忙打退他们。有兴趣吗？%SPEECH_OFF% | 你走进 %employer% 的房间里，在他身边坐下，摸着木椅的扶手。是上好的橡木，一棵曾经的树，坐起来很舒服。%SPEECH_ON%很高兴你觉得舒服，佣兵，但我可糟透了。我们收到了无数警告，说一大群强盗正要攻打镇子。我们缺守卫，但不缺乏克朗。显然，这就是你的用武之地了。有兴趣吗？%SPEECH_OFF% | %employer% 把一个杯子狠狠砸向墙壁。杯子碎裂飞溅，酒渍溅到了你的脸颊上。%SPEECH_ON%流浪汉！强盗！掠夺者！没完没了！%SPEECH_OFF%他心不在焉地递给你一张餐巾。%SPEECH_ON%现在我又得到消息，说这帮暴徒正准备大规模进攻，要把这镇子烧成平地！不过，我也给他们准备了点惊喜：就是你。怎么样，佣兵？你愿意帮我们防守吗？%SPEECH_OFF% | 几个悲伤的妇女在 %employer% 房间外哭喊着，声音清晰可闻。他转向你。%SPEECH_ON%听见了吗？这就是强盗来了之后的下场。他们抢劫、强奸、杀人。%SPEECH_OFF%你点点头。毕竟，这就是强盗的行事作风。%SPEECH_ON%现在乡下的农民说，这帮恶棍正在准备对我们的村庄发动大规模突袭。你必须帮帮我们，佣兵。呵呵，我当然说‘必须’。其实我的意思是，我们会付钱请你帮我们……%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{%townname% 准备出多少钱来买他们的平安？ | 这对你来说应该值不少克朗，对吧?}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{恐怕你们只能靠自己了。 | 我们有更要紧的事要处理。 | 祝你们好运，但我们不会掺和这件事。}",
					function getResult()
					{
						if (this.Math.rand(1, 100) <= 60)
						{
							this.World.Contracts.removeContract(this.Contract);
							return 0;
						}
						else
						{
							return "Plea";
						}
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Plea",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_43.png[/img]{当你拒绝了 %employer% ，正往外面走时，发现外面围了一大群农民。每个人都拿着些奇奇怪怪的东西——那是平民能凑出来的全部家当了：有鸡、廉价的项链、破衣服、生锈的铁匠工具，林林总总，五花八门。其中一个人走上前来，两只胳膊底下各夹着一只鸡。。%SPEECH_ON%求求你了！你不能走！你得帮帮我们啊！%SPEECH_OFF%%randombrother% 嘲笑起来，但你不得不承认，这些穷苦百姓确实知道怎么触动人心。也许……你真该留下来帮帮他们？ | 当你离开 %employer%时，只见一个女人站在外面，身后跟着一群在她腿边乱窜的孩子，怀里还有一个正在吃奶的婴儿。%SPEECH_ON%佣兵，求求你，你不能就这样丢下我们！这镇子需要你！孩子们需要你！%SPEECH_OFF%她顿了顿，然后掀开了另一边的衣襟，露出一个极具诱惑意味的挑逗。%SPEECH_ON%我需要你......%SPEECH_OFF%你抬起一只手，既是为了制止她，也是为了擦去突然冒出来的冷汗。也许帮帮这对……呃，可怜人，也不是什么坏事？ | 当你准备离开 %townname% 时，一只小狗跑过来对着你狂吠，还舔你的靴子。一个更小的孩子紧追其后，几乎抓着狗尾巴不放。小孩扑倒在狗身上，紧紧搂住它毛茸茸的身体。%SPEECH_ON%哦，{马利 | 耶拉 | 乔乔}，我好爱你啊！%SPEECH_OFF%脑海中突然闪过强盗屠杀手无寸铁的孩子和宠物的画面。你本有更重要的事要做，而不是扮演警长和警察对付一帮普通强盗。但看着狗不停地舔着男孩的脸，孩子笑得那么开心。%SPEECH_ON%哈哈！我们会永远永远活下去，对不对？永远永远！%SPEECH_OFF%该死。 | 当你离开 %employer% 的住所时，一个男人走向你。%SPEECH_ON%先生，我听说您拒绝了那位大人的提议。真遗憾，我只想说这句话。我本以为这世上还有不少好人，看来是我看走眼了。祝您一路顺风，也希望您在旅途中能为我们祈祷。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = false,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{该死，我们不能就这样看着这些人去送死。 | 好吧，好吧，我们不会离开 %townname%。但至少得谈谈报酬吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{我相信你们能挺过去的。让开。 | 我不想为了救几个饥肠辘辘的农民，拿 %companyname% 的弟兄们去冒险。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "UndeadAttack",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_29.png[/img]{正在站岗时，一个疯疯癫癫的农民朝你狂奔过来。他张着大嘴，上气不接下气，双手撑着膝盖，差点把胃里的东西都喷出来：%SPEECH_ON%亡……亡灵来了！%SPEECH_OFF%你越过他向远处眺望，果然看见一大群面色惨白的生物正摇摇晃晃地走来。 | 这里没有强盗，只有亡灵！当你正等着那帮恶棍和无赖冲进镇子时，却看到一大群摇摇晃晃的怪物朝这边过来了。虽然目标变了，但合同可没变——准备战斗！ | 镇上的教堂响起了刺耳的警报声。你一边盯着地平线，一边听着钟声。那钟声一直响个不停。一个当地人跑到你身边，数着钟声。%SPEECH_ON%一下……两下……三下……四下…… %SPEECH_OFF%他开始冒汗了。当钟声敲响最后一下的时候，他的眼睛猛地瞪大。%SPEECH_ON%这……不可能。%SPEECH_OFF%你问他怕成这样到底在怕什么。他一边后退一边喊道。%SPEECH_ON%死人又在地上行走了！%SPEECH_OFF%太棒了，就在你刚觉得这单生意挺轻松的时候……。 | 呻吟着，哀嚎着，亡灵蹒跚着进入了你的视野。这里没有强盗——也许这些肮脏的家伙已经被它们吃了——但合同没有作废：保护镇子！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "DefaultAttack",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_07.png[/img]强盗就在眼前了！准备战斗，保护城镇！",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ItsOver",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_22.png[/img]{战斗结束了，弟兄们在难得的喘息间闲散下来。%employer% 此刻正在镇上等着你。 | 战斗结束了，你放眼望去，战场上尸横遍野。这是一幅令人毛骨悚然的景象，但不知为何却让你感到一阵莫名的亢奋。眼前这座由死尸堆成的骇人山丘，反而时刻提醒着你，你还没向这个可怕的世界屈服，你体内仍有着生命力。像 %employer% 那样的人真该亲自来看看，但他不会来，那就只能由你去见他了。 | 残肢断臂散落在战场上，几乎无法分辨出属于谁。黑色的秃鹫在头顶盘旋，人字形阴影的光环在死者身上荡漾，鸟儿们等待着哀悼者离开。%randombrother% 来到你的身边，问他们是否应该开始返回 %employer% 那儿了。你离开了战场，点了点头。 | 死亡造就了一种别样的残垣断壁。仿佛僵硬与永恒的失去才是他们的自然状态，而他们的整个生命不过是意外的短暂插曲，最终走向了终结。%randombrother% 走过来问你是否还好。老实说，你也不确定，只是回答说，是时候去见 %employer% 了。 | 扭曲畸形的尸体散布在地上，因为战斗让死者无法决定自己以何种方式终结。无头的尸体看起来最安详，因为在战斗中，没有人或野兽有时间真正砍掉脖子，这只发生在最快和最锋利的刀刃挥舞中。你的一部分希望以这种瞬间的结局结束，但另一部分希望你有机会和敌人同归于尽。\n\n%randombrother% 来到你身边，询问指示。你转过身，告诉 %companyname% 的弟兄们准备好回去见 %employer%。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们回市政厅！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ItsOverDidNothing",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_30.png[/img]空气中弥漫着浓烟，以及木材燃烧、家园焚毁时刺鼻的焦味。%townname% 的人们将全部希望都押在了雇佣 %companyname% 上，这无疑是一个致命的错误。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "事情没按计划发展……",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Militia1",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]{在准备保卫 %townname% 时，当地的民兵队已经来到你身边。他们服从你的指挥，只请求你将他们派往最需要的地方。 | 看来民兵队已经加入战斗了！虽然是一群乌合之众，但终究还是能派上用场的。现在的问题是，该把他们派去哪儿？ | %townname% 的民兵已经投入战斗！尽管这是一群装备简陋、杂乱无章的士兵，但他们保卫家园的意愿十分强烈。他们听从你的指挥，并相信你会将他们派往最需要的地方。 | 你并不是孤军奋战！%townname% 的民兵已经加入了你们。他们热切希望参战，并询问你将他们派往哪里他们可以发挥最大的作用。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "列队集合，现在你们归我指挥。",
					function getResult()
					{
						return "Militia2";
					}

				},
				{
					Text = "去保卫 %townname% 的市政厅。",
					function getResult()
					{
						local home = this.Contract.m.Home;
						local party = this.World.FactionManager.getFaction(this.Contract.getFaction()).spawnEntity(home.getTile(), home.getName() + " Militia", false, this.Const.World.Spawn.Militia, home.getResources() * 0.7, this.Contract.getMinibossModifier());
						party.getSprite("banner").setBrush(home.getBanner());
						party.setDescription("勇敢的人们用生命保卫自己的家园。他们有农民、工匠、手艺人，但没一个是真正的士兵。");
						party.setFootprintType(this.Const.World.FootprintsType.Militia);
						this.Contract.m.Militia = this.WeakTableRef(party);
						local c = party.getController();
						local guard = this.new("scripts/ai/world/orders/guard_order");
						guard.setTarget(home.getTile());
						guard.setTime(300.0);
						local despawn = this.new("scripts/ai/world/orders/despawn_order");
						c.addOrder(guard);
						c.addOrder(despawn);
						return 0;
					}

				},
				{
					Text = "去保卫 %townname% 的郊区。",
					function getResult()
					{
						local home = this.Contract.m.Home;
						local party = this.World.FactionManager.getFaction(this.Contract.getFaction()).spawnEntity(home.getTile(), home.getName() + " Militia", false, this.Const.World.Spawn.Militia, home.getResources() * 0.7, this.Contract.getMinibossModifier());
						party.getSprite("banner").setBrush(home.getBanner());
						party.setDescription("勇敢的人们用生命保卫自己的家园。他们有农民、工匠、手艺人，但没一个是真正的士兵。");
						party.setFootprintType(this.Const.World.FootprintsType.Militia);
						this.Contract.m.Militia = this.WeakTableRef(party);
						local c = party.getController();
						local locations = home.getAttachedLocations();
						local targets = [];

						foreach( l in locations )
						{
							if (l.isActive() && !l.isMilitary() && l.isUsable())
							{
								targets.push(l);
							}
						}

						local guard = this.new("scripts/ai/world/orders/guard_order");
						guard.setTarget(targets[this.Math.rand(0, targets.len() - 1)].getTile());
						guard.setTime(300.0);
						local despawn = this.new("scripts/ai/world/orders/despawn_order");
						c.addOrder(guard);
						c.addOrder(despawn);
						return 0;
					}

				},
				{
					Text = "去躲起来，别挡路。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Militia2",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]既然你决定要指挥当地人，他们便前来询问该如何武装自己以迎接即将到来的战斗。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿上弓箭，你们在后方负责射击。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest_ranged");
							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				},
				{
					Text = "拿上剑和盾，你们去前线肉搏。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest");
							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				},
				{
					Text = "想用什么装备随你们便。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia;

							if (this.Math.rand(0, 1) == 0)
							{
								militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest");
							}
							else
							{
								militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest_ranged");
							}

							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "MilitiaVolunteer",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]{战斗结束后，一位曾参与防守的民兵亲自来到你面前，深深地鞠了一躬，并献上他的剑。%SPEECH_ON%大人，我为 %townname% 效力的日子已经结束了，但 %companyname% 的英勇表现真是令人惊叹。如果大人允许的话，我非常希望能与您和您的部下并肩作战。%SPEECH_OFF% | 随着战斗的结束，来自 %townname% 的一名民兵表示，他很乐意加入 %companyname% 效力。一方面是因为他非常钦佩这支雇佣兵队伍的战斗力，另一方面则是因为被征召入伍保卫城镇，既不赚钱又太伤身体。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "欢迎加入 %companyname%！",
					function getResult()
					{
						return 0;
					}

				},
				{
					Text = "这里不适合你。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping1",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_30.png[/img]{就在你们警惕地搜寻强盗行踪时，一个农民跑过来告诉你们，一伙暴徒刚刚袭击了附近，还抓走了一批人质。你难以置信地摇摇头，他们是怎么悄无声息地溜进来干这种事的？那平民也跟着摇头。 %SPEECH_ON%我以为你们是来帮我们的。为什么你们什么都没做？%SPEECH_OFF% 你问强盗们走远了吗？那农民摇了摇头。看来你们还有机会把人追回来。 | 一个衣衫褴褛、扛着断了齿的干草叉的男人朝着你们的队伍狂奔而来。他扑倒在你脚边哀嚎。%SPEECH_ON%强盗发起袭击了！你们当时在哪？他们杀了人……烧了房子……还……还抓了好多人！求求你们，去救救他们吧！%SPEECH_OFF% 你看了一眼 %randombrother% 并点了点头。%SPEECH_ON%召集弟兄们，准备行动。我们必须在那帮畜生彻底逃走前追上他们。%SPEECH_OFF% | 你们眼睛紧盯着地平线，搜寻着流浪汉或盗贼的任何踪迹。突然，%randombrother% 带着一个女人来到你面前。她讲述了一个故事：暴徒已经发动了袭击，杀死了大量平民，没杀的就抓走了。那名佣兵点了点头。%SPEECH_ON%看来他们是从我们眼皮子底下溜过去的，头儿。%SPEECH_OFF%你现在只有一个选择了，去把那些人带回来！ | 你们驻扎在靠近 %townname% 的地方，本以为这次任务会轻而易举，但一个疯疯癫癫的平民突然出现，情况显然不妙。那平民解释说，劫掠者已经袭击了郊区。他们杀了所有能看见的人，然后掳走了几个男人、女人和孩子。这个男人要么是喝醉了，要么是受了惊吓，说话含糊不清地恳求着。%SPEECH_ON%求求你们……把他们救回来，好吗？%SPEECH_OFF% | 在警戒时，一群愤怒的农民涌上道路，带着暴民般的怒火朝你们冲来。%SPEECH_ON%我以为我们花钱雇你们是为了保护我们！你们当时在哪！%SPEECH_OFF%他们浑身是血，有的还衣衫不整。一个女人袒露着胸部，因为太过愤怒而根本不在乎失态。你询问他们到底发生了什么事。一名将拐杖紧紧抱在胸前的男人解释说，袭击者和暴徒已经发动了攻击，去往了附近的一个小村庄。他们见人就杀，等杀戮欲望得到满足后，便尽可能多地抓走了俘虏。\n\n你点了点头。%SPEECH_ON%我们会把他们带回来的。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "让我们去找到他们！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{收起佩剑，你命令 %randombrother% 去解救那些被囚禁的俘虏。一群茫然无措的农民被从皮质的牵绳、锁链以及狗笼中解放出来。他们感谢你及时赶到，也感谢你施加给那些强盗的暴力惩戒。 | 强盗们被屠戮殆尽。你派弟兄们四散开来，去营救每一个能找到的平民。人们聚在一起，相拥哭泣，为能从这场可怕的噩梦中幸存下来而欣喜若狂。 | 在杀光了周围的最后一个强盗后，你吩咐队伍去解救流浪汉们抓走的人质。每个人都依次来到你面前，有的亲吻你的手，有的亲吻你的脚。而你只是告诉他们赶紧回 %townname% 去，你自己随后也会回去。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "看来这下结束了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping3",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_53.png[/img]{不幸的是，那些强盗带着人质跑了。愿诸神保佑那些可怜的灵魂。 | 你没能救出那些可怜的农民。现在只有天知道他们会遭遇什么。 | 遗憾的是，掠夺者带着他们的人类货物逃跑了。那些可怜的人现在只能听天由命了。那些可怜的家伙现在只能自求多福了。然而，你听过的那些传闻告诉你，他们的下场绝对不会好到哪里去。 | 强盗们成功逃走了，囚犯们就在他们身边。你不知道那些人接下来会遭遇什么，但你知道肯定不是什么好事。是沦为奴隶？遭受酷刑？还是直接被杀？你不确定这其中哪一种才是最糟糕的结局。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "{%townname% 的人肯定不会喜欢这个消息…… | 只希望那些人的死能痛快点……}",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回到 %employer% 面前，脸上带着理所应当的得意神情。%SPEECH_ON%任务完成了。%SPEECH_OFF%他点了点头，倾斜手中的酒杯，却并不一定是要敬酒。%SPEECH_ON%是的。镇上的人们永远感激你的帮助。他们也……在金钱上表达了感激。%SPEECH_OFF%那人朝房间的角落示意了一下。你看到那里有一个装满克朗的袋子。%SPEECH_ON%%reward% 克朗，正如我们约定的那样。再次感谢，佣兵。%SPEECH_OFF% | %employer% 端着一杯酒欢迎你的归来。%SPEECH_ON%喝一杯吧，佣兵，你挣来的。%SPEECH_OFF%这酒尝起来……很特别。如果傲慢能成为一种味道的话，那就是这种了。你的雇主绕过桌子，欢快地坐了下来。%SPEECH_ON%你成功地保护了小镇，正如你所承诺的，我对此印象非常深刻。！%SPEECH_OFF%他点点头，把酒杯朝向一个木箱子%SPEECH_ON%印象深刻。%SPEECH_OFF%你打开箱子，发现里面装满了克朗。 | %employer% 欢迎你进入他的房间。%SPEECH_ON%我从窗户里看到了，你知道吗？全看到了。嗯，大部分吧。精彩的部分，我想是的。%SPEECH_OFF%你挑了挑眉。%SPEECH_ON%哦，别用那种眼神看我。我享受我看到的东西，这没什么不对。我们还活着，对吧？我们这些好人。%SPEECH_OFF%另一只眉毛也挑了起来。%SPEECH_ON%嗯……不管怎么说，这是你的报酬。%SPEECH_OFF%那人递过来一个装有 %reward% 克朗的箱子。 | 当你回到 %employer% 那里时，发现他的房间几乎已经收拾好了，一切都准备好要搬走。你略带幽默地表示了关切。%SPEECH_ON%准备去哪儿啊？%SPEECH_OFF%那人安稳地坐回椅子上。%SPEECH_ON%我曾对你有过疑虑，佣兵。这能怪我吗？不管怎么说，你不必怀疑我付钱的能力。%SPEECH_OFF%他挥了挥手，指向桌子角落。那里有一个口袋，里面塞满了克朗。%SPEECH_ON%和约定的一样，%reward% 克朗。%SPEECH_OFF% | 你进入房间后，%employer% 从椅子上站了起来。他鞠了一躬，有些难以置信，但也很真诚。他朝窗外点头，那里传来农民们欢欣的嘈杂声。%SPEECH_ON%听到了吗？你赢得了这一切，佣兵。这里的人现在都喜欢你。%SPEECH_OFF%你点了点头，但普通人的喜欢并不是你来这里的原因。%SPEECH_ON%我还赢得了什么？%SPEECH_OFF%，%employer% 笑了。%SPEECH_ON%直奔主题的人。我打赌这就是你的……优势所在。当然，你也赢得了这个。%SPEECH_OFF%他把一个木箱子拖到桌上并打开。金黄的克朗温暖了你的心。 | 当你进入时，%employer% 正盯着窗外。他几乎处于一种梦幻状态，低头用手托着下巴。你打断了他的思绪。%SPEECH_ON%在想我吗？%SPEECH_OFF%那人轻笑一声，假装捂住胸口。%SPEECH_ON%你真是我梦中情人啊，佣兵。%SPEECH_OFF%他穿过房间，从书架上取下一个箱子，放在桌上打开。一堆金黄的克朗在你面前闪耀。%employer% 咧嘴一笑。%SPEECH_ON%现在谁在做梦？%SPEECH_OFF% | 当你进入时，%employer% 正坐在桌旁。%SPEECH_ON%我看到了很多。杀戮，死亡。%SPEECH_OFF%你坐了下来。%SPEECH_ON%希望你享受这场表演。不过，观看可不是免费的。%SPEECH_OFF%那人点点头，拿起一个钱袋递了过来。%SPEECH_ON%我愿意为再次表演付钱，但我不确定 %townname% 是否想让这件事再次发生。%SPEECH_OFF% }",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{%companyname%会好好利用这个的。 | 辛苦工作的报酬。}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "成功抵御了强盗对城镇的袭击");
						this.World.Contracts.finishActiveContract();

						if (this.Flags.get("IsUndead") && this.World.FactionManager.isUndeadScourge())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{你回到 %employer% 面前，他指着窗外欢迎你的归来。%SPEECH_ON%看见了吗？就在那边远处。%SPEECH_OFF%你走到他身边。他问道。%SPEECH_ON%你看到了什么？%SPEECH_OFF%地平线上有浓烟。你告诉他你看到的就是这个。%SPEECH_ON%对，烟。但我雇你不是让你放烟的，明白吗？当然……好在镇子大部分还完好无损……%SPEECH_OFF%他把一个钱袋扔到你怀里。%SPEECH_ON%干得不错，佣兵。只是……还不够好。%SPEECH_OFF% | 你回到 %employer% 那里时。他看起来既高兴又难过，介于醉酒和清醒之间。这不是你想看到的表情。%SPEECH_ON%你干得不错，佣兵。有消息说你把那些土匪彻底打趴下了。但也有消息说他们烧毁了我们镇外的一些地方。%SPEECH_OFF%你点了点头。对于无法掩盖的事实，没必要撒谎。%SPEECH_ON%你会拿到报酬，但你得明白，重建那些区域需要钱。显然，这笔钱得从你口袋里出……%SPEECH_OFF% | 当你回来的时候，%employer% 正瘫坐在椅子上。%SPEECH_ON%%townname% 的大多数人很高兴，但还有几个不高兴。你能猜到是哪些吗？%SPEECH_OFF%强盗确实摧毁了镇外的一些地方，但这是个反问句。%SPEECH_ON%我需要钱来帮助重建那些被强盗染指的地区。我相信你能理解，这就是为什么你的酬劳会减少……%SPEECH_OFF%你耸了耸肩。该怎么样就怎么样吧。 | %employer% 正站在书架旁。他拿起一本书，一个转身，顺手就把它摊开在桌上。%SPEECH_ON%这里有账目。我敢肯定你读不懂，但我告诉你上面写着什么：强盗摧毁了镇子的一部分，现在我需要钱来重建。不幸的是，我手头没有那么多钱来办这事。我相信你能理解这个困境。%SPEECH_OFF%你点点头，直言不讳地说。%SPEECH_ON%这钱从我的报酬里扣。%SPEECH_OFF%那人点点头，摊开一只手划过桌面，示意你注意角落里的一个钱袋。争论报酬没有意义。你拿起钱袋，转身离开。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor, "成功抵御了强盗对城镇的袭击");
						this.World.Contracts.finishActiveContract();

						if (this.Flags.get("IsUndead") && this.World.FactionManager.isUndeadScourge())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success3",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回到 %employer% 面前，脸上带着理所应当的得意神情。%SPEECH_ON%任务完成了。%SPEECH_OFF%他点了点头，倾斜手中的酒杯，却并不一定是要敬酒。%SPEECH_ON%是的。镇上的人们永远感激你的帮助。他们也……在金钱上表达了感激。%SPEECH_OFF%那人朝房间的角落示意了一下。你看到那里有一个装满克朗的袋子。%SPEECH_ON%%reward% 克朗，正如我们约定的那样。再次感谢，佣兵。呃，那些农民的事真是遗憾……。%SPEECH_OFF% | %employer% 端着一杯酒欢迎你的归来。%SPEECH_ON%喝一杯吧，佣兵，你挣来的。%SPEECH_OFF%这酒尝起来……很特别。如果傲慢能成为一种味道的话，那就是这种了。你的雇主绕过桌子，欢快地坐了下来。%SPEECH_ON%你成功地保护了小镇，正如你所承诺的，我对此印象非常深刻。%SPEECH_OFF%他点点头，把酒杯朝向一个木箱子。%SPEECH_ON%印象深刻。%SPEECH_OFF%你打开箱子，发现里面装满了克朗。%SPEECH_ON%那些被绑走的农民真是遗憾。我已经相应地做了调整……%SPEECH_OFF% | %employer% 欢迎你进入他的房间。%SPEECH_ON%我从窗户里看到了，你知道吗？全看到了。嗯，大部分吧。精彩的部分，我想是的。%SPEECH_OFF%你挑了挑眉。%SPEECH_ON%哦，别用那种眼神看我。我享受我看到的东西，这没什么不对。我们还活着，对吧？我们这些好人。%SPEECH_OFF%另一只眉毛也挑了起来。%SPEECH_ON%嗯……不管怎么说，这是你的报酬，按照约定的数量。我听说有几名农民被绑走了。我做了一些扣除。那笔钱将用于资助幸存者。%SPEECH_OFF%那人递过来一个装有 %reward% 克朗的箱子。 | 当你回到 %employer% 那里时，发现他的房间几乎已经收拾好了，一切都准备好要搬走。你略带幽默地表示了关切。%SPEECH_ON%准备去哪儿啊？%SPEECH_OFF%那人安稳地坐回椅子上。%SPEECH_ON%我曾对你有过疑虑，佣兵。这能怪我吗？不管怎么说，你不必怀疑我付钱的能力。%SPEECH_OFF%他挥了挥手，指向桌子角落。那里有一个口袋，里面塞满了克朗。%SPEECH_ON%比约定的少一些克朗。你知道那些被土匪掳走的农民会发生什么吧？没错，我扣你报酬是有原因的。%SPEECH_OFF% | 你进入房间后，%employer% 从椅子上站了起来。他鞠了一躬，有些难以置信，但也很真诚。他朝窗外点头，那里传来农民们欢欣的嘈杂声。%SPEECH_ON%听到了吗？你赢得了这一切，佣兵。这里的人现在都喜欢你。%SPEECH_OFF%你点了点头，但普通人的喜欢并不是你来这里的原因。%SPEECH_ON%我还赢得了什么？%SPEECH_OFF%%employer% 笑了。%SPEECH_ON%直奔主题的人。我打赌这就是你的……优势所在。当然，你也赢得了这个。嗯，稍微少了一点。关于那些你让土匪掳走的农民，这事儿可不太好听，是吧？%SPEECH_OFF%他把一个木箱子拖到桌上并打开。金黄的克朗温暖了你的心。 | 当你进入时，%employer% 正盯着窗外。他几乎处于一种梦幻状态，低头用手托着下巴。你打断了他的思绪。%SPEECH_ON%在想我吗？%SPEECH_OFF%那人轻笑一声，假装捂住胸口。%SPEECH_ON%你真是我梦中情人啊，佣兵。%SPEECH_OFF%他穿过房间，从书架上取下一个箱子，放在桌上打开。一堆金黄的克朗在你面前闪耀。%employer%咧嘴一笑，但笑容转瞬即逝。%SPEECH_ON%比你预期的要少一点吧？那些被强盗掳走的农民的幸存家属会得到少的那部分。我相信你能理解。%SPEECH_OFF% | 当你进入时，%employer% 正坐在桌旁。%SPEECH_ON%我看到了很多。杀戮，死亡。%SPEECH_OFF%你坐了下来。%SPEECH_ON%希望你享受这场表演。不过，观看可不是免费的。%SPEECH_OFF%这个人点了点头，拿了一个小包递给你。%SPEECH_ON%我愿意为再次表演付钱，但我不确定 %townname% 是否想让这件事再次发生。当然，那些被强盗掳走的可怜人也不想要他们所遭遇的。%SPEECH_OFF%你看了一眼袋子，发现里面的克朗比预期要少。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor, "成功抵御了强盗对城镇的袭击");
						this.World.Contracts.finishActiveContract();

						if (this.Flags.get("IsUndead") && this.World.FactionManager.isUndeadScourge())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success4",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{你回到 %employer% 面前，他指着窗外欢迎你的归来。%SPEECH_ON%看见了吗？就在那边远处。%SPEECH_OFF%你走到他身边。他问道。%SPEECH_ON%你看到了什么？%SPEECH_OFF%地平线上有浓烟。你告诉他你看到的就是这个。%SPEECH_OFF%对，烟。但我雇你不是让你放烟的，明白吗？当然……好在镇子大部分还完好无损……%SPEECH_OFF%他把一个钱袋扔到你怀里。%SPEECH_ON%干得不错，佣兵。只是……还不够好。还有那些可怜农民……那些该死的强盗把他们掳走了，真是遗憾。%SPEECH_OFF% | 你回到 %employer% 那里时，他看起来既高兴又难过，介于醉酒和清醒之间。这不是你想看到的表情。%SPEECH_ON%你干得不错，佣兵。有消息说你把那些土匪彻底打趴下了。但也有消息说他们烧毁了我们镇外的一些地方。%SPEECH_OFF%你点了点头。对于无法掩盖的事实，没必要撒谎。%SPEECH_ON%你会拿到报酬，但你得明白，重建那些区域需要钱。还有那些被强盗掳走的可怜人怎么办？他们的家人也需要帮助。显然，这笔钱得从你口袋里出……%SPEECH_OFF% | 当你回来的时候，%employer% 正瘫坐在椅子上。%SPEECH_ON%%townname% 的大多数人很高兴，但还有几个不高兴。你能猜到是哪些吗？%SPEECH_OFF%强盗确实摧毁了镇外的一些地方，但这是个反问句。%SPEECH_ON%我需要钱来帮助重建那些被强盗染指的地区。我也需要钱来帮助那些你没能救下的农民的幸存者。我相信你能理解，这就是为什么你的酬劳会减少……%SPEECH_OFF%你耸耸肩。该怎么样就怎么样吧。 | %employer% 正站在书架旁。他拿起一本书，一个转身，顺手就把它摊开在桌上。%SPEECH_ON%这里有账目。我敢肯定你读不懂，但我告诉你上面写着什么：强盗摧毁了镇子的一部分，现在我需要钱来重建。不幸的是，我手头没有那么多钱来办这事。我相信你能理解这个困境。%SPEECH_OFF%你点点头，直言不讳地说。%SPEECH_ON%这钱从我的报酬里扣。还有那些让你放跑的农民？他们有家人，有幸存者。他们也会分走我们约定好的一部分。%SPEECH_OFF%那人点点头，摊开一只手划过桌面，示意你注意角落里的一个钱袋。争论报酬没有意义。你拿起钱袋，转身离开。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(0);
						this.World.Contracts.finishActiveContract();

						if (this.Flags.get("IsUndead") && this.World.FactionManager.isUndeadScourge())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Failure1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{当你走进 %employer% 的房间时，他示意你关上门。就在门锁咔哒一声合上的瞬间，他对你劈头盖脸就是一顿臭骂，满口脏话之多，多到你根本记不住他说了些什么。等他稍微平复了一下情绪，他的声音和用词才恢复到了某种正常的水平。%SPEECH_ON%我们的郊区被彻底毁了。我到底花钱雇你来干什么的？给我滚出去！%SPEECH_OFF% | %employer% 正猛灌葡萄酒。窗外传来农民们愤怒的喧哗声。%SPEECH_ON%听见了吗？要是我付你钱，他们就要了我的命。你只有一份差事，一份差事！保护这个镇子。而你却搞砸了。所以你现在只能做一件事，而且是免费的：立刻给我滚！%SPEECH_OFF% | %employer% 双手合十放在桌子上。%SPEECH_ON%你到底在期待什么？我真惊讶你居然还有脸回来找我。半个镇子都在燃烧，另一半已经化成灰烬。我雇你不是来制造浓烟和废墟的，佣兵。快滚！%SPEECH_OFF% | 当你回到 %employer% 身边时，他正拿着一杯啤酒。他的手在颤抖，脸色涨红。%SPEECH_ON%我现在全靠意志力强忍着，才没把这酒泼到你脸上！%SPEECH_OFF%为了以防万一，那人仰头一大口把酒全灌了下去。他把杯子往桌上重重一摔。%SPEECH_ON%这个镇子指望你来保护他们。结果呢？强盗冲进郊区就他妈像在旅游一样！我才不做让强盗玩得开心的生意，佣兵。给我滚他妈的远点！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{该死的农民！ | 我们本该要求预付更多报酬的…… | 该死的！}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "未能成功抵御强盗对城镇的袭击。");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Failure2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{当你走进 %employer% 的房间时，他示意你关上门。就在门锁咔哒一声合上的瞬间，他对你劈头盖脸就是一顿臭骂，满口脏话之多，多到你根本记不住他说了些什么。等他稍微平复了一下情绪，他的声音和用词才恢复到了某种正常的水平。%SPEECH_ON%我们的郊区被彻底毁了。甚至有人被掳走，旧神才知道他们会落得什么下场！我到底花钱雇你来干什么的？给我滚出去。%SPEECH_OFF% | %employer% 正猛灌葡萄酒。窗外传来农民们愤怒的喧哗声。%SPEECH_ON%听见了吗？要是我付你钱，他们就要了我的命。你只有一份差事，一份差事！保护这个镇子。而你却搞砸了。该死，你甚至没能救下那些被绑架的可怜农民！所以你现在只能做一件事，而且是免费的：立刻给我滚。%SPEECH_OFF% | %employer% 双手在办公桌上交握。%SPEECH_ON%你到底在期待什么？我真惊讶你居然还有脸回来找我。半个镇子都在燃烧，另一半已经化成灰烬。幸存者告诉我，他们甚至有家人被绑架了！你知道那些被掳走的人会遭遇什么吗？我雇你不是来制造浓烟和废墟的，佣兵。快滚。%SPEECH_OFF% | 当你回到 %employer% 的时候，他正拿着一杯啤酒。他的手在颤抖，脸色涨红。%SPEECH_ON%我现在全靠意志力强忍着，才没把这酒泼到你脸上。%SPEECH_OFF%为了以防万一，那人仰头一大口把酒全灌了下去。他把杯子往桌上重重一摔。%SPEECH_ON%这个镇子指望你来保护他们。结果呢？强盗冲进郊区就他妈像在旅游一样！我才不做让强盗玩得开心的生意，佣兵。给我滚他妈的远点。%SPEECH_OFF% | 当你踏入房间时，%employer% 笑了起来。%SPEECH_ON%郊区被毁了。%townname% 的民众一片哗然，至少那些还活着的人是愤怒的。还有更糟的？你竟然让几个居民被这些怪物掳走了！%SPEECH_OFF%那人摇摇头，手指指向门口。%SPEECH_ON%我不知道你指望我会付你什么钱，但绝不是为了这种结果。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{该死的农民！ | 我们本该要求预付更多报酬的…… | 该死的！}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "未能成功抵御强盗对城镇的袭击。");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"reward",
			this.m.Reward
		]);
	}

	function onHomeSet()
	{
		if (this.m.SituationID == 0)
		{
			local s = this.new("scripts/entity/world/settlements/situations/raided_situation");
			s.setValidForDays(4);
			this.m.SituationID = this.m.Home.addSituation(s);
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.World.FactionManager.getFaction(this.getFaction()).setActive(true);
			this.m.Home.getSprite("selection").Visible = false;

			if (this.m.Kidnapper != null && !this.m.Kidnapper.isNull())
			{
				this.m.Kidnapper.getSprite("selection").Visible = false;
			}

			if (this.m.Militia != null && !this.m.Militia.isNull())
			{
				this.m.Militia.getController().clearOrders();
			}

			this.World.getGuestRoster().clear();
		}
	}

	function onIsValid()
	{
		local nearestBandits = this.getNearestLocationTo(this.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getSettlements());
		local nearestZombies = this.getNearestLocationTo(this.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Zombies).getSettlements());

		if (nearestZombies.getTile().getDistanceTo(this.m.Home.getTile()) > 20 && nearestBandits.getTile().getDistanceTo(this.m.Home.getTile()) > 20)
		{
			return false;
		}

		local locations = this.m.Home.getAttachedLocations();

		foreach( l in locations )
		{
			if (l.isUsable() && l.isActive() && !l.isMilitary())
			{
				return true;
			}
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.m.Flags.set("KidnapperID", this.m.Kidnapper != null && !this.m.Kidnapper.isNull() ? this.m.Kidnapper.getID() : 0);
		this.m.Flags.set("MilitiaID", this.m.Militia != null && !this.m.Militia.isNull() ? this.m.Militia.getID() : 0);
		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.contract.onDeserialize(_in);
		this.m.Kidnapper = this.WeakTableRef(this.World.getEntityByID(this.m.Flags.get("KidnapperID")));
		this.m.Militia = this.WeakTableRef(this.World.getEntityByID(this.m.Flags.get("MilitiaID")));
	}

});

