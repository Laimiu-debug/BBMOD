this.defend_settlement_greenskins_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Reward = 0,
		Kidnapper = null,
		Militia = null
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.defend_settlement_greenskins";
		this.m.Name = "保卫城镇";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 5.0;
		this.m.MakeAllSpawnsResetOrdersOnContractEnd = false;
		this.m.MakeAllSpawnsAttackableByAIOnceDiscovered = true;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		this.m.Payment.Pool = 900 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"保卫 %townname% 及其郊区免受掠夺"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);
				local nearestOrcs = this.Contract.getNearestLocationTo(this.Contract.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getSettlements());
				local nearestGoblins = this.Contract.getNearestLocationTo(this.Contract.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).getSettlements());

				if (nearestOrcs.getTile().getDistanceTo(this.Contract.m.Home.getTile()) + this.Math.rand(0, 6) <= nearestGoblins.getTile().getDistanceTo(this.Contract.m.Home.getTile()) + this.Math.rand(0, 6))
				{
					this.Flags.set("IsOrcs", true);
				}
				else
				{
					this.Flags.set("IsGoblins", true);
				}

				if (this.Math.rand(1, 100) <= 25 && this.Contract.getDifficultyMult() >= 0.95)
				{
					this.Flags.set("IsMilitia", true);
				}

				local number = 1;

				if (this.Contract.getDifficultyMult() >= 0.95)
				{
					number = number + this.Math.rand(0, 1);
				}

				if (this.Contract.getDifficultyMult() >= 1.1)
				{
					number = number + 1;
				}

				local locations = this.Contract.m.Home.getAttachedLocations();
				local targets = [];

				foreach( l in locations )
				{
					if (l.isActive() && !l.isMilitary() && l.isUsable())
					{
						targets.push(l);
					}
				}

				number = this.Math.min(number, targets.len());
				this.Flags.set("ActiveLocations", targets.len());

				for( local i = 0; i != number; i = ++i )
				{
					local party;

					if (this.Flags.get("IsGoblins"))
					{
						party = this.Contract.spawnEnemyPartyAtBase(this.Const.FactionType.Goblins, this.Math.rand(80, 110) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}
					else
					{
						party = this.Contract.spawnEnemyPartyAtBase(this.Const.FactionType.Orcs, this.Math.rand(80, 110) * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}

					party.setAttackableByAI(false);
					local c = party.getController();
					c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
					c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
					local t = this.Math.rand(0, targets.len() - 1);

					if (i > 0)
					{
						local wait = this.new("scripts/ai/world/orders/wait_order");
						wait.setTime(4.0 * i);
						c.addOrder(wait);
					}

					local move = this.new("scripts/ai/world/orders/move_order");
					move.setDestination(targets[t].getTile());
					c.addOrder(move);
					local raid = this.new("scripts/ai/world/orders/raid_order");
					raid.setTime(40.0);
					raid.setTargetTile(targets[t].getTile());
					c.addOrder(raid);
					targets.remove(t);
				}

				this.Contract.m.Home.setLastSpawnTimeToNow();
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.Home.getSprite("selection").Visible = true;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(false);
			}

			function update()
			{
				if (this.Contract.m.UnitsSpawned.len() == 0 || this.Flags.get("IsEnemyHereDialogShown"))
				{
					local isEnemyGone = true;

					foreach( id in this.Contract.m.UnitsSpawned )
					{
						local p = this.World.getEntityByID(id);

						if (p != null && p.isAlive() && p.getDistanceTo(this.Contract.m.Home) <= 1200.0)
						{
							isEnemyGone = false;
							break;
						}
					}

					if (isEnemyGone)
					{
						if (this.Flags.get("HadCombat"))
						{
							this.Contract.setScreen("ItsOver");
							this.World.Contracts.showActiveContract();
						}

						this.Contract.setState("Return");
						return;
					}
				}

				if (!this.Flags.get("IsEnemyHereDialogShown"))
				{
					local isEnemyHere = false;

					foreach( id in this.Contract.m.UnitsSpawned )
					{
						local p = this.World.getEntityByID(id);

						if (p != null && p.isAlive() && p.getDistanceTo(this.Contract.m.Home) <= 700.0)
						{
							isEnemyHere = true;
							break;
						}
					}

					if (isEnemyHere)
					{
						this.Flags.set("IsEnemyHereDialogShown", true);

						foreach( id in this.Contract.m.UnitsSpawned )
						{
							local p = this.World.getEntityByID(id);

							if (p != null && p.isAlive())
							{
							}
						}

						if (this.Flags.get("IsGoblins"))
						{
							this.Contract.setScreen("GoblinsAttack");
						}
						else
						{
							this.Contract.setScreen("OrcsAttack");
						}

						this.World.Contracts.showActiveContract();
					}
				}
				else if (this.Flags.get("IsKidnapping") && !this.Flags.get("IsKidnappingInProgress") && this.Contract.m.UnitsSpawned.len() == 1)
				{
					local p = this.World.getEntityByID(this.Contract.m.UnitsSpawned[0]);

					if (p != null && p.isAlive() && !p.isHiddenToPlayer() && !p.getController().hasOrders())
					{
						local c = p.getController();
						c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(true);
						c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(true);
						this.Contract.m.Kidnapper = this.WeakTableRef(p);
						this.Flags.set("IsKidnappingInProgress", true);
						this.Flags.set("KidnappingTooLate", this.Time.getVirtualTimeF() + 60.0);
						this.Contract.setScreen("Kidnapping1");
						this.World.Contracts.showActiveContract();
						this.Contract.setState("Kidnapping");
					}
				}

				if (this.Flags.get("IsMilitia") && !this.Flags.get("IsMilitiaDialogShown"))
				{
					this.Flags.set("IsMilitiaDialogShown", true);
					this.Contract.setScreen("Militia1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

			function onCombatVictory( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

		});
		this.m.States.push({
			ID = "Kidnapping",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"营救被劫走的俘虏",
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = false;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(false);

				if (this.Contract.m.Kidnapper != null && !this.Contract.m.Kidnapper.isNull())
				{
					this.Contract.m.Kidnapper.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.m.Kidnapper == null || this.Contract.m.Kidnapper.isNull() || !this.Contract.m.Kidnapper.isAlive())
				{
					if (this.Time.getVirtualTimeF() - this.World.Events.getLastBattleTime() <= 5.0)
					{
						this.Flags.set("IsKidnapping", false);
						this.Contract.setScreen("Kidnapping2");
					}
					else
					{
						this.Contract.setScreen("Kidnapping3");
					}

					this.World.Contracts.showActiveContract();
					this.Contract.setState("Return");
				}
				else if (this.Contract.m.Kidnapper.isHiddenToPlayer() && this.Time.getVirtualTimeF() > this.Flags.get("KidnappingTooLate"))
				{
					this.Contract.setScreen("Kidnapping3");
					this.World.Contracts.showActiveContract();
					this.Contract.setState("Return");
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

			function onCombatVictory( _combatID )
			{
				this.Flags.set("HadCombat", true);
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
				this.World.FactionManager.getFaction(this.Contract.getFaction()).setActive(true);

				if (this.Contract.m.Kidnapper != null && !this.Contract.m.Kidnapper.isNull())
				{
					this.Contract.m.Kidnapper.getSprite("selection").Visible = false;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					local locations = this.Contract.m.Home.getAttachedLocations();
					local numLocations = 0;

					foreach( l in locations )
					{
						if (l.isActive() && !l.isMilitary() && l.isUsable())
						{
							numLocations = ++numLocations;
						}
					}

					if (numLocations == 0 || this.Flags.get("ActiveLocations") - numLocations >= 2)
					{
						if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
						{
							this.Contract.setScreen("Failure2");
						}
						else
						{
							this.Contract.setScreen("Failure1");
						}
					}
					else if (this.Flags.get("ActiveLocations") - numLocations >= 1)
					{
						if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
						{
							this.Contract.setScreen("Success4");
						}
						else
						{
							this.Contract.setScreen("Success2");
						}
					}
					else if (this.Flags.get("IsKidnapping") && this.Flags.get("IsKidnappingInProgress"))
					{
						this.Contract.setScreen("Success3");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_20.png[/img]{当你见到 %employer% 时，他满头大汗，正用一块绣工精美的布擦拭。但这似乎根本挡不住汗水的流淌。%SPEECH_ON%佣兵，见到你真是太好了！求你了，请进来说话。%SPEECH_OFF%你小心翼翼地走进房间坐下，目光短暂扫视，确保门后或靠墙的书架旁没有藏人。%employer% 将一张地图推到你面前。%SPEECH_ON%看到那些绿色标记了吗？那是斥候追踪到的绿皮动向。有时候他们会口头汇报，有时候则完全没了音讯。那些斥候就……就像凭空消失了。不过，不用想也能猜到他们究竟遭遇了什么，对吧？%SPEECH_OFF%你问他想要什么。他猛拍地图，拳头正落在 %townname% 的位置上。%SPEECH_ON%你看不出来吗？它们正朝这边来，我需要你帮忙防守！%SPEECH_OFF% | 当你找到 %employer% 时，他正紧张地啃着指甲。他的指甲已被啃得所剩无几，指尖全是皮肉和血丝。%SPEECH_ON%谢谢你来了，佣兵。我直说了吧，绿皮要来了。%SPEECH_OFF%你用手比划着高度，问他是什么样的绿皮，是这么高的，还是大概这么高的。%employer% 耸了耸肩。%SPEECH_ON%我也不知道。我的斥候在不断失踪，而逃难来的村民也不是什么可靠的目击证人。你只需要知道我们需要你的帮助，因为那些绿皮正朝这里来。%SPEECH_OFF% | 你找到 %employer% 时，他喝得醉醺醺的，深陷在椅子里。手指着桌上一本打开的书。%SPEECH_ON%你听说过“众名之战”吗？大约十年前，当兽人涌入人类的土地，而人类集结军队，对它们说：不。%SPEECH_OFF%你点点头，对那场战役和它终结的战争了如指掌。那人继续说道。%SPEECH_ON%不幸的是，我们有理由相信它们要卷土重来了。绿皮，不知道什么种类的，也不知道多高或长什么样子，但它们确实正朝这里来。%SPEECH_OFF%他仰头喝光了杯中酒，那样子仿佛这是断头台前喝的最后一口。%SPEECH_ON%你愿意留下来保护我们吗？当然，价钱好商量。我还没忘你的身份。%SPEECH_OFF% | 当你进入时，%employer% 正站在窗边。%SPEECH_ON%你听到了吗？%SPEECH_OFF%街上一片喧嚣，人们麻木地哀嚎与惊恐的哭泣交织在一起。%SPEECH_ON% 那就是绿皮来临时的声音。%SPEECH_OFF%那人关上窗户，转向你。%SPEECH_ON%我知道这要求很多，但我们有钱，所以还是直说吧。你愿意帮忙保护 %townname% 吗？%SPEECH_OFF% | 你找到 %employer% 时，他正被一群人围住。%SPEECH_ON%大家冷静点！都冷静点！%SPEECH_OFF%有人扔了一颗洋葱，不偏不倚地砸在他头上，带着辛辣气味的蔬菜汁液溅了他一脸。另一个人迅速爬过去捡起来咬了一口。%employer% 在人群中指出了你。%SPEECH_ON%佣兵！你来了真是太好了！%SPEECH_OFF%他奋力挤过人群，凑到你耳边大喊，因为不喊根本听不见。%SPEECH_ON%我们有钱！我们有你需要的一切！帮帮我们，保护小镇免遭绿皮的袭击！%SPEECH_OFF% | %employer% 的员工们正在房间里翻箱倒柜，收集卷轴和书籍，然后匆匆忙忙地离开，不知要去何方。他自己则只是坐在椅子上，偶尔喝一口杯中的酒，同时看着一张地图。他对你招手示意。%SPEECH_ON%坐吧，别管我的员工。%SPEECH_OFF%你照做了，但周围的一片慌乱实在难以忽视。%employer% 靠回椅背，十指交叉放在肚子上。%SPEECH_ON%我想你已经注意到这里情况不太对劲了吧。那是因为有人发现了一大群绿皮，它们正朝这边来，一路烧杀抢掠。显然，我希望你能帮忙防守 %townname%，不然我们所有人都会变成某个书记员脚注里的历史人物，明白吗？%SPEECH_OFF% | 你进入 %employer% 的住所，发现地板上全是泥，壁炉里的火也烧得噼啪作响，冒着水汽。他的几个员工正抱着卷轴匆匆忙忙地跑来跑去，纸张堆得几乎遮住了他们的头。你看到 %employer% 站在一片混乱中，只是指挥员工做这做那。你走上前，他只是点了点头。%SPEECH_ON%绿皮要来了。什么种类？我不知道。但我只知道如果不能防守小镇会发生什么，所以我们正在做点准备工作，明白吗？%SPEECH_OFF%你同样点了点头，然后问他还有什么要求。%SPEECH_ON%当然是帮我们打这些绿皮。这对你来说显然是一笔不菲的收入。%SPEECH_OFF% | 一些农民来到了 %employer% 的住所。他们怀里抱着一大堆东西，每走一步都散落一地，急于逃离，连捡都不捡。 %employer% 从窗户看到你，示意你从侧门进来。你悄悄溜进去时，他只是瘫坐在椅子上，给你倒了杯酒。%SPEECH_ON%绿皮要来了，而且我不认为手头的人手足以防守 %townname%。 显然，我愿意雇佣并支付你的服务费，以保护 %townname%，免受这绿色威胁的侵害。%SPEECH_OFF% | 一个男人站在 %employer% 的住所外，身上披着两块画着图案的木板。每块木板上都写着某个预言家的末日言论。你无视了那人，走进了屋子。%employer% 站在那里，笑着摇头。%SPEECH_ON%外面那个家伙说得没错。我的侦察兵已经报告说这片区域有绿皮出没一段时间了。我早该听他们的，因为我的侦察兵已经整整一周没传来任何消息了，推测是因为那些绿皮抓住了他们。现在，普通民众都跑来给我讲外面发生的恐怖故事，说一大群可怕的生物正朝这边涌来。%SPEECH_OFF%他转向你，咧嘴一笑，那笑容里透着一股疯狂。%SPEECH_ON%那么，不如你我做个交易，让那个末日预言家闭嘴如何？你愿意帮忙保护 %townname%吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{%townname%准备出多少钱来买他们的平安？ | 这应该对你来说值不少克朗，对吧？ | 对抗绿皮族可不便宜。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{恐怕你们只能靠自己了。 | 恐怕这对 %companyname% 来说不值得。 | 祝你们好运，但我们不会掺和这件事。}",
					function getResult()
					{
						if (this.Math.rand(1, 100) <= 60)
						{
							this.World.Contracts.removeContract(this.Contract);
							return 0;
						}
						else
						{
							return "Plea";
						}
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Plea",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_43.png[/img]{在拒绝了 %employer% 并离开后，你遇到了一个男人，他一边大笑一边摇头。 %SPEECH_ON%嘿，听着，绿皮可不是往那个方向去的，除非……这本来就是你的计划，你这个没用的懦夫。 %SPEECH_OFF%你拔出佩剑，让剑刃在剑鞘上划出悠长刺耳的摩擦声。那人却笑了。 %SPEECH_ON%哦？那你打算用那玩意儿干什么？杀了我？好吧，来啊。动手啊。反正你做得比绿皮还绝，我倒要看看你敢不敢。%SPEECH_OFF%一个女人冲了出来，抓住那个男人把他往后拖。 %SPEECH_ON%去把孩子们带上，行吗？我们必须马上离开！%SPEECH_OFF%那对缩成一团的男女蹒跚着走开了，但那句‘懦夫’的指责依然在你脑海中嗡嗡作响。 | 平民们已经开始挤满道路，急着逃离 %townname%。有几个人瞥了你一眼，其中一个老人甚至拄着拐杖走上前。%SPEECH_ON%瞧瞧，这就是如今的世界！所有的好人都死光了，剩下的只有像这位所谓的剑士一样的懦夫。%SPEECH_OFF%%randombrother% 冲上前，猛地举起武器，一副要杀人的架势。 %SPEECH_ON%你竟敢侮辱 %companyname%？我要割了你的舌头，然后再砍下你的脑袋，老东西！%SPEECH_OFF%你抓住了那名佣兵的肩膀。这些人最不需要的就是暴力，但那个老人刚才喊得又响又清楚。现在你开始担心，到底有谁听到了他的话，又有谁会活下来传播这番话背后的分量。 | 当你试图返回队伍时，一个女人冲上来抱住了你。%SPEECH_ON%先生，求求你！你不能把我们丢下不管！你不知道绿皮会对我们做什么！%SPEECH_OFF%其实你心里非常清楚，但你把这想法藏在了心底。那女人跪倒在地，紧紧抱住你的两只脚踝。你设法挣脱了她的抓握。她有那么一瞬间在泥泞中爬行追赶你，然后停下，开始啜泣。%SPEECH_ON%你根本不知道这是什么滋味。对于我们……对于我来说，生活似乎从来就没有好过。%SPEECH_OFF%见鬼，这真是太可悲了，但你发现自己内心深处竟然涌起了一丝同情。 | 当你拒绝了 %employer% 转身离开时，一个男人从他的住所里走了出来。他正在抚摸着一只鸡，眼里含着泪水。%SPEECH_ON%先生，如果你愿意留下，这只鸡就是你的了。%SPEECH_OFF%那个平民亲吻了一下那只鸡。鸡毫无知觉地乱叫着，完全无法映衬出主人脸上的痛苦。%SPEECH_ON%留下来帮帮这个小镇吧。这只鸡归你。求你了，请留下。%SPEECH_OFF%天哪，事情真的要沦落到这个地步吗？ | 一个衣衫褴褛的老人向你走来。%SPEECH_ON%所以，你决定不帮忙了？我想我不能因此责怪你。%SPEECH_OFF%他挥手指向旁边站着的几个平民。他们带着装满货物的箱子，里面塞满了发霉的蔬菜、一两只鸡，或者那两只鸡其实是一只又小又爱叫的羊羔。%SPEECH_ON%这些人希望你能留下帮忙。但我理解你为什么不愿意。我参加过‘众名之战’，我知道和那些野兽战斗是什么感觉。我不会怪你。只有胸怀大勇之人才敢去面对它们。所以就这样吧，就这样吧，是的先生，我一点都不会怪你。%SPEECH_OFF%他慢慢地蹒跚离去，这时你才注意到，他的一条腿已经被一根木桩代替。几个孩子跑向他，他和那群平民交谈起来。他回头看了你一眼，然后又看向他们，摇了摇头。那种悲伤和失望的情绪几乎要将你淹没。}",
			Image = "",
			List = [],
			ShowEmployer = false,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{该死，我们不能就这样看着这些人去送死。 | 好吧，好吧，我们不会离开 %townname%。但至少得谈谈报酬吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{我相信你们能挺过去的。让开。 | 我不想为了救几个饥肠辘辘的农民，拿 %companyname% 的弟兄们去冒险。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "OrcsAttack",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_49.png[/img]绿皮已经出现了！准备战斗，保护城镇！",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "GoblinsAttack",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_48.png[/img]绿皮已经出现了！准备战斗，保护城镇！",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ItsOver",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_22.png[/img]{战斗结束了。%employer% 得知消息后无疑会很高兴再次见到你。 | 战斗结束了，弟兄们在难得的喘息间闲散下来。%employer% 此刻正在镇上等着你。 | 战斗结束了，你放眼望去，战场上尸横遍野。这是一幅令人毛骨悚然的景象，但不知为何却让你感到一阵莫名的亢奋。眼前这座由死尸堆成的骇人山丘，反而时刻提醒着你，你还没向这个可怕的世界屈服，你体内仍有着生命力。像 %employer% 那样的人真该亲自来看看，但他不会来，那就只能由你去见他了。 | 残肢断臂散落在战场上，几乎无法分辨出属于谁。黑色的秃鹫在头顶盘旋，人字形阴影的光环在死者身上荡漾，鸟儿们等待着哀悼者离开。%randombrother% 来到你的身边，问他们是否应该开始返回 %employer% 那儿了。你离开了战场，点了点头。 |死亡造就了一种别样的残垣断壁。仿佛僵硬与永恒的失去才是他们的自然状态，而它们的整个生命不过是意外的短暂插曲，最终走向了终结。%randombrother% 走过来问你是否还好。老实说，你也不确定，只是回答说，是时候去见 %employer% 了。 | 扭曲畸形的尸体散布在地上，因为战斗让死者无法决定自己以何种方式终结。无头的尸体看起来最安详，因为在战斗中，没有人或野兽有时间真正砍掉脖子，这只发生在最快和最锋利的刀刃挥舞中。你的一部分希望以这种瞬间的结局结束，但另一部分希望你有机会和敌人同归于尽。\n\n%randombrother% 来到你身边，询问指示。你转过身，告诉 %companyname% 的弟兄们准备好回去见 %employer%。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们回市政厅！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ItsOverDidNothing",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_30.png[/img]空气中弥漫着浓烟，以及木材燃烧、家园焚毁时刺鼻的焦味。%townname% 的人们将全部希望都押在了雇佣 %companyname% 上，这无疑是一个致命的错误。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "事情没按计划发展……",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Militia1",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]{在准备保卫  %townname% 时，当地的民兵队已经来到你身边。他们服从你的指挥，只请求你将他们派往最需要的地方。 | 看来民兵队已经加入战斗了！虽然是一群乌合之众，但终究还是能派上用场的。现在的问题是，该把他们派去哪儿？ | %townname% 的民兵已经投入战斗！尽管这是一群装备简陋、杂乱无章的士兵，但他们保卫家园的意愿十分强烈。他们听从你的指挥，并相信你会将他们派往最需要的地方。 | 你并不是孤军奋战！%townname% 的民兵已经加入了你们。他们热切希望参战，并询问你将他们派往哪里他们可以发挥最大的作用。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "列队集合，现在你们归我指挥。",
					function getResult()
					{
						return "Militia2";
					}

				},
				{
					Text = "去保卫  %townname% 的市政厅。",
					function getResult()
					{
						local home = this.Contract.m.Home;
						local party = this.World.FactionManager.getFaction(this.Contract.getFaction()).spawnEntity(home.getTile(), home.getName() + " Militia", false, this.Const.World.Spawn.Militia, home.getResources() * 0.7, this.Contract.getMinibossModifier());
						party.getSprite("banner").setBrush(home.getBanner());
						party.setDescription("勇敢的人们用生命保卫自己的家园。他们有农民、工匠、手艺人，但没一个是真正的士兵。");
						party.setFootprintType(this.Const.World.FootprintsType.Militia);
						this.Contract.m.Militia = this.WeakTableRef(party);
						local c = party.getController();
						local guard = this.new("scripts/ai/world/orders/guard_order");
						guard.setTarget(home.getTile());
						guard.setTime(300.0);
						local despawn = this.new("scripts/ai/world/orders/despawn_order");
						c.addOrder(guard);
						c.addOrder(despawn);
						return 0;
					}

				},
				{
					Text = "去保卫 %townname% 的郊区。",
					function getResult()
					{
						local home = this.Contract.m.Home;
						local party = this.World.FactionManager.getFaction(this.Contract.getFaction()).spawnEntity(home.getTile(), home.getName() + " Militia", false, this.Const.World.Spawn.Militia, home.getResources() * 0.7, this.Contract.getMinibossModifier());
						party.getSprite("banner").setBrush(home.getBanner());
						party.setDescription("勇敢的人们用生命保卫自己的家园。他们有农民、工匠、手艺人，但没一个是真正的士兵。");
						party.setFootprintType(this.Const.World.FootprintsType.Militia);
						this.Contract.m.Militia = this.WeakTableRef(party);
						local c = party.getController();
						local locations = home.getAttachedLocations();
						local targets = [];

						foreach( l in locations )
						{
							if (l.isActive() && !l.isMilitary() && l.isUsable())
							{
								targets.push(l);
							}
						}

						local guard = this.new("scripts/ai/world/orders/guard_order");
						guard.setTarget(targets[this.Math.rand(0, targets.len() - 1)].getTile());
						guard.setTime(300.0);
						local despawn = this.new("scripts/ai/world/orders/despawn_order");
						c.addOrder(guard);
						c.addOrder(despawn);
						return 0;
					}

				},
				{
					Text = "去躲起来，别挡路。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Militia2",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]既然你决定要指挥当地人，他们便前来询问该如何武装自己以迎接即将到来的战斗。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿上弓箭，你们在后方负责射击。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest_ranged");
							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				},
				{
					Text = "拿上剑和盾，你们去前线肉搏。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest");
							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				},
				{
					Text = "想用什么装备随你们便。",
					function getResult()
					{
						for( local i = 0; i != 4; i = ++i )
						{
							local militia;

							if (this.Math.rand(0, 1) == 0)
							{
								militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest");
							}
							else
							{
								militia = this.World.getGuestRoster().create("scripts/entity/tactical/humans/militia_guest_ranged");
							}

							militia.setFaction(1);
							militia.setPlaceInFormation(19 + i);
							militia.assignRandomEquipment();
						}

						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "MilitiaVolunteer",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_80.png[/img]{战斗结束后，一位曾参与防守的民兵亲自来到你面前，深深地鞠了一躬，并献上他的剑。%SPEECH_ON%大人，我为 %townname% 效力的日子已经结束了，但 %companyname% 的英勇表现真是令人惊叹。如果大人允许的话，我非常希望能与您和您的部下并肩作战。%SPEECH_OFF% | 随着战斗的结束，来自 %townname% 的一名民兵表示，他很乐意加入 %companyname% 效力。一方面是因为他非常钦佩这支雇佣兵队伍的战斗力，另一方面则是因为被征召入伍保卫城镇，既不赚钱又太伤身体。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "欢迎加入 %companyname%！",
					function getResult()
					{
						return 0;
					}

				},
				{
					Text = "这里不适合你。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping1",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_30.png[/img]{就在你们警惕地搜寻绿皮行踪时，一个农民跑过来告诉你们，有一群野兽刚刚袭击了附近，还抓走了一批人质。你难以置信地摇摇头，它们是怎么悄无声息地溜进来干这种事的？那平民也跟着摇头。%SPEECH_ON%我以为你们是来帮我们的。为什么你们什么都没做？%SPEECH_OFF% 你问绿皮走远了吗？那农民摇了摇头。看来你们还有机会把人追回来。 | 一个衣衫褴褛、扛着断了齿的干草叉的男人朝着你们的队伍狂奔而来。他扑倒在你脚边哀嚎。%SPEECH_ON%绿皮发起袭击了！你们当时在哪？它们杀了人……烧了房子……还……还抓了好多人！求求你们，去救救他们吧！%SPEECH_OFF% 你看了一眼 %randombrother% 并点了点头。%SPEECH_ON%召集弟兄们，准备行动。我们必须在那帮畜生彻底逃走前追上它们。%SPEECH_OFF% | 你们眼睛紧盯着地平线，搜寻着那些肮脏绿皮的任何踪迹或声响。突然，%randombrother% 带着一个女人来到你面前。他把女人往前一推，点了点头。那女人捂着胸口，啜泣着讲述了一个故事，说绿皮已经发动了袭击，洗劫了附近的一个小村庄。她解释说，那些家伙不只是杀人，还抓走了一些人当俘虏。那名佣兵点了点头。%SPEECH_ON%看来它们是从我们眼皮子底下溜过去的，头儿。%SPEECH_OFF%你现在只有一个选择了，去把那些人带回来！ | 你们驻扎在靠近 %townname% 的地方，等待着绿皮的进攻。本以为这次任务会轻而易举，但一个疯疯癫癫的平民突然出现，情况显然不妙。那平民解释说，那些肮脏的掠夺者已经袭击了最近一个偏远的村庄。他们杀了所有能看见的人，然后掳走了几个男人、女人和孩子。这个男人要么是喝醉了，要么是受了惊吓，说话含糊不清地恳求着。%SPEECH_ON%求求你们……把他们救回来，好吗？%SPEECH_OFF% | 几个愤怒的农民走上道路，带着暴民般的怒火朝你冲来。%SPEECH_ON%我以为我们花钱雇你们是为了保护我们！你们当时在哪？%SPEECH_ON%他们浑身是血，有的还衣衫不整。一个男人正用胸口护着一条胳膊，那只手上已经没了手掌。你问这群人在嚷嚷什么。女人走上前，脚边围着几个挤作一团的孩子。她捂住了孩子们的耳朵。%SPEECH_ON%我们在嚷嚷什么？你们这群该死的佣兵！绿皮来了，还能有谁！你们本应该保护我们，但肯定在忙于互相调情和犯蠢才发现它们已经溜走了！我们逃出来了，但那些跑不掉的都被抓去当俘虏了！你们知道被绿皮抓走会有什么下场吗？因为，嗯，我是说我不知道，但我猜肯定没有歌听，也没有馅饼吃！给我闭嘴，否则我就割了你的舌头，让你的身体为这张破嘴陪葬。%SPEECH_ON%我们会把他们带回来的。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "让我们去找到它们！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{收起佩剑，你命令 %randombrother% 去解救那些被囚禁的俘虏。一群茫然无措的农民被从皮质的牵绳、锁链以及狗笼中解放出来。他们感谢你及时赶到。其中一人挠了挠手腕上曾经被镣铐磨出的伤口。%SPEECH_ON%谢了，佣兵。%SPEECH_OFF%他冲着一处烤肉杆点了点头，上面挂着一具干瘪发黑的尸体，下面的火已经熄灭。%SPEECH_ON%可惜你没来得及救下她。她本来是个大美人。现在嘛，瞧瞧她那样儿。%SPEECH_OFF%那人苦笑了一下，随即放声大哭。 | 该死的绿皮被屠戮殆尽。你派弟兄们四散开来，去营救每一个能找到的平民。人们聚在一起，相拥哭泣，为能从这场可怕的噩梦中幸存下来而欣喜若狂。 | 在杀光了周围的最后一个绿皮后，你吩咐弟兄们去解救被抓走的人质。每个人都依次来到你面前，有的亲吻你的手，有的亲吻你的脚。而你只是告诉他们赶紧回 %townname% 去，你自己随后也会回去。 | 杀光最后一只绿皮后，你下令让弟兄们去解救人质。他们跌跌撞撞地爬出来，完全处于震惊之中，在战场的废墟上蹒跚而行。有几个人翻找着绿皮的营地。你看着一个{男人 | 女人}捡起了一堆正在冒烟的烧焦骨头。那人只是盯着那些残骸看了一会儿，然后放下，起身走进了荒野深处。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "看来这下结束了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Kidnapping3",
			Title = "靠近 %townname%",
			Text = "[img]gfx/ui/events/event_53.png[/img]{不幸的是，那些绿皮带着人质跑了。愿诸神保佑那些可怜的灵魂。 | 你没能救出那些可怜的农民。现在只有天知道他们会遭遇什么。其实你自己也心知肚明，但为了晚上能睡个安稳觉，你选择装傻。 | 遗憾的是，那些肮脏的野兽拖着他们的人类货物逃跑了。那些可怜的人现在只能听天由命了。那些可怜的家伙现在只能自求多福了。然而，你听过的那些传闻告诉你，他们的下场绝对不会好到哪里去。 | 绿皮兽人带着它们的俘虏一起逃走了。你不知道这些人现在会发生什么，但你知道那不是好事。奴役、折磨、死亡。你不确定哪一个更糟糕。 | 那些绿皮怪物带着那些不幸的人质跑了。你希望那些人一切安好，但当风卷起，吹来空洞而刺耳的歌声时，你清楚地知道，任何祝愿或祈祷都救不了那些可怜的灵魂。 | 好吧，绿皮跑了。那一地啃剩的人骨和成堆剥落的皮肉，无声地诉说着你的失败。 | 你捡起一块破布碎片，却发现它刚才正盖在一堆白骨之上。%SPEECH_ON%该死。%SPEECH_OFF%那里有一条食物残渣铺成的路引向远方。绿皮跑了，那些可怜的囚犯也随它们一起消失了。 | %randombrother% 你过去。当你走到他身边时，他指着地上的一堆烂泥。你耸了耸肩。%SPEECH_ON%是啊，有臭味。还有呢？%SPEECH_OFF%他踢开一块白色的东西，从烂泥里翻出一根看起来像是骨头的玩意儿。%SPEECH_ON%那是人骨头，头儿。那些囚犯已经被吃掉了。%SPEECH_OFF%你环顾草地，看到了更多的残骸。脚印通向远方，显然绿皮已经成功甩掉了你的追捕。你叹了口气，命令手下的人准备撤离。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "{%townname% 的人肯定不会喜欢这个消息…… | 希望他们能快速死去。}",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%employer% 带着一个装满 %reward% 克朗的箱子欢迎你归来。%SPEECH_ON%这一份是你应得的，佣兵，这一点我得承认。整个镇子没被碰过一寸，嗯，至少没什么重要的东西受损。%SPEECH_OFF%当你盯着那个箱子时，他停顿了一下。这报酬来之不易，是你用血汗换来的。只是……你本来以为会更多一点。有时候，当佣兵的这种简单粗暴，真的让你很烦。 | 你发现 %employer% 正在喂狗。他一遍又一遍地抚摸着其中一只正在大快朵颐的狗。%SPEECH_ON%我真以为我得放弃这一切了。%SPEECH_OFF%他最后拍了拍那只杂种狗，然后转过头看着你。%SPEECH_ON%谢谢你，佣兵。你做的不止是保护了这个镇子，你保护了一种生活方式。如果没有你，我们不是全都会死，就是更糟——活着看到明天必然会带来的恐怖景象。%SPEECH_OFF%你点点头，走上前想去摸摸其中一只狗，但它却恶狠狠地瞪着你并发出低吼。%employer% 笑了。%SPEECH_ON%请原谅它的无知。%SPEECH_OFF% | %employer% 身边围着一帮男男女女。当你走进房间时，他们几乎是以一种令人毛骨悚然的整齐动作同时转向了你。他们盯着你看了片刻，随即爆发出庆祝的欢呼，冲过来拥抱你，甚至喜极而泣。好不容易推开了这群激动的人，你发现 %employer% 手里拿着一个皮包站在那里。%SPEECH_ON%这是为了感谢你拯救了 %townname%，佣兵。说实话，它不够重，没达到它应有的分量，但这是我们全部的家当了。%SPEECH_OFF% | 当你回来找 %employer% 时，他正望着窗外。外面，民兵们在四处奔跑，镇民们在互相拥抱。 %SPEECH_ON%没一个绿皮踏入过镇中心广场。%SPEECH_OFF%他微笑着递给你一个装满克朗的皮包。%SPEECH_ON%你今天做得非常出色，佣兵。%SPEECH_OFF% | 找到 %employer%并不容易: 整个镇子都陷入了狂欢的骚乱中。他们拔鸡毛拔得太快，有时候鸡还没死透，就半秃着毛、跌跌撞撞地在路上乱跑，孩子们在后面追着，%employer% 趁着节日的混乱，悄悄溜到你身边。%SPEECH_ON%哀悼的日子多的是，但我们留到明天再说。今天，我们要庆祝生命，以及你的功绩，佣兵。%SPEECH_OFF%那人递给你一个装满克朗的皮包，沉甸甸地压在你的手心。 | 你发现 %employer% 正在整理书架。他看起来像是在重新上架他的货物，像个店主一样仔细地清点和编号。当你身后的门砰地一声关上时，他吓了一跳。%SPEECH_ON%啊，佣兵！你吓到我了。%SPEECH_OFF%他从书架上拿下一个箱子递给你。%SPEECH_ON%我本来打算带着这些书、这些卷轴全跑了。但现在，我不需要了，这全得感谢你。%SPEECH_OFF%他的笑容有一瞬间变得苦涩。%SPEECH_ON%并不是每个人都有幸看到今天和你的胜利。今晚，我必须确保阵亡者得到妥善的安葬。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{%companyname%会好好利用这个的。 | 辛苦工作的报酬。}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "成功抵御了强盗对城镇的袭击");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isGreenskinInvasion())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{%employer% 双手抱着头。你指着窗外提醒他：%SPEECH_ON%镇子保住了，你还有什么好哭的？%SPEECH_OFF%他抬起头看着你。%SPEECH_ON%是啊，大部分人确实活下来了，这没错。但这不代表那些绿皮没把这该死的镇子撕开一个大口子。%SPEECH_OFF%他用拇指擦了擦额头，然后把一箱物资推过桌面。%SPEECH_ON%抱歉我这么消沉，但我相信你懂这种感觉，佣兵。至少，我希望你懂。%SPEECH_OFF%你其实懂，但你假装自己毫不在乎。 | 你在住所后面找到了 %employer%。他手里拿着一把铁锹，正打发走几位农民。四处都是新堆起来的土堆。%SPEECH_ON%见到你真让人高兴，佣兵。%SPEECH_OFF%他把身体的重量靠在锹柄上。%SPEECH_ON%就是……呃……埋那些没挺过来的人。你干得很不错，别以为自己做得不好，但很多人确实没能活下来。我一点都没怪你，在我看来，那些绿皮是可怕的对手，指望完美无缺是极不明智的。%SPEECH_OFF%你点点头，那人也回敬了一个点头。他捡起一个放在满是泥泞的铁锹堆里的皮包。那包在空中划过，留下一道泥痕。你接住它，再次点头，然后离开，让他继续他的工作。你走远时，还能听到铁锹‘嚓、嚓’地插入泥土的声音。 | 当你回来时，%employer% 正在研究一张地图。他用一根手指按在一个点上，然后几乎是用语言引导着手指在地图上移动。%SPEECH_ON%这地方没了。这户人家被烧了。这些人死了。我们在树林里找到了这些人。我想他们当时是想躲起来，但他们刚生了孩子。我猜是那孩子的哭声暴露了他们。%SPEECH_OFF%他身体前倾，双手握拳撑在桌上。%SPEECH_ON%你干得很好，佣兵，但不是每个人都能得救。这就是现实，正如人们常说的，我也不会因此怪你。只要我和许多其他人还活着，这就够了。%SPEECH_OFF%他扔给你一袋克朗。你接过来，回敬了一个点头。这就是现实，而这个现实意味着一笔不错的收入。 | %employer% 正用手指缓缓滑过一卷长长的卷轴。他一边点头，一边自顾自地哼着。%SPEECH_ON%你知道读着死去邻居的名字是什么感觉吗？%SPEECH_OFF%你其实知道，但没有去打断他。%SPEECH_ON%那是一种奇怪的感觉。我认识他们，但现在，我却想不起他们的脸。我只认得他们的名字，就像普通的文字一样，不再比其他任何词更特别。现在，他们只是一堆词汇了。我想，是对记忆的描述吧。%SPEECH_OFF%他抬头看向你，然后把卷轴扔到一边，拿了一袋克朗丢给你。%SPEECH_ON%该死，我不是故意那样烦你的，佣兵。这是答应给你的报酬。%SPEECH_OFF% | %employer% 正在指挥一个拿着画笔的男人。他们的画布是厚纸和看起来像玻璃的混合物。出于好奇，你问发生了什么事。%SPEECH_ON%我在把这场战役绘制出来。让它成为纪念碑。%SPEECH_OFF%他指着一个建筑物燃烧的画面。%SPEECH_ON%看到没？当你去迎战绿皮时，它们把那地方烧了。还有那一个。我们都会记住这一切，以免遗忘。%SPEECH_OFF%那人扔给你一袋克朗，然后迅速回到艺术创作中。盯着那幅画，你发现自己所在的队伍在画里哪都没出现。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor, "成功抵御了绿皮对城镇的袭击");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success3",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%employer% 带着一个装满 %reward% 克朗的箱子欢迎你归来。%SPEECH_ON%这一份是你应得的，佣兵。不幸的是，那些绿皮还是掳走了我们几个人。我要扣下你一部分酬劳，用来补偿那些把性命托付给你的人。%SPEECH_OFF%当你盯着那个箱子时，他停顿了一下。你点了点头，既理解那些农民的困境，也意识到在这里争辩对你未来的前途毫无帮助。 | 你发现 %employer% 正在喂狗。他一遍又一遍地抚摸着其中一只正在大快朵颐的狗。%SPEECH_ON%我真以为我得放弃这一切了。%SPEECH_OFF%他最后拍了拍那只杂种狗，然后转过头看着你。%SPEECH_ON% 但并不是所有人都活下来了。你的工钱在角落里，但会比说好的少一点。我必须去安抚那些被掳走的人的家属，我相信你明白为什么我要从你的工钱里扣这笔钱。%SPEECH_OFF% | %employer% 身边围着一帮男男女女。当你走进房间时，他们几乎是以一种令人毛骨悚然的整齐动作同时转向了你。%employer% 正在给他们发克朗，他一边发一边对你说。%SPEECH_ON%你的工钱在外面，交给我的一个守卫了。会有点少，因为我拿了一部分出来，用来安抚那些在战斗中失去亲人的人。%SPEECH_OFF%你瞥了一眼在房间里徘徊的那些可怜人。他们一定是那些被绿皮掳走者的家属。 | 当你回来找 %employer% 时，他正望着窗外。外面，民兵们在四处奔跑，镇民们在互相拥抱。%SPEECH_ON%镇中心算是保住了，但我必须遗憾地告诉你，接下来的几天里，踩在这条路上的人会少很多。%SPEECH_OFF%他微笑着递给你一个装满克朗的皮包，但你觉得它比应有的分量轻了一些。%SPEECH_ON%你今天做得非常出色，但不是每个人都能得救。那些被绿皮掳走的人留下了家人，在这种危急时刻，我得尽力去安抚他们。%SPEECH_OFF% | 找到 %employer%并不容易: 整个镇子都陷入了狂欢的骚乱中。他们拔鸡毛拔得太快，有时候鸡还没死透，就半秃着毛、跌跌撞撞地在路上乱跑，孩子们在后面追着，%employer% 趁着节日的混乱，悄悄溜到你身边。那人递给你一个装满克朗的皮包，沉甸甸地压在你的手心。%SPEECH_ON%不是每个人都能这么兴高采烈，佣兵。那些你没能救下的被掳走的灵魂？他们留下了家人，而你的一部分工钱就给了那些家人。我相信你明白。%SPEECH_OFF% | 你发现 %employer% 正在整理书架。他看起来像是在重新上架他的货物，像个店主一样仔细地清点和编号。当你身后的门砰地一声关上时，他吓了一跳。%SPEECH_ON%啊，佣兵！你吓到我了。%SPEECH_OFF%他从书架上拿下一个箱子递给你。%SPEECH_ON%我本来打算带着这些书、这些卷轴全跑了。但现在，我不需要了，这全得感谢你。%SPEECH_OFF%他的笑容变得苦涩。%SPEECH_ON%并不是每个人都有幸看到今天。当地人已经告诉我发生的事了，那些绿皮掳走了我们的人，而你没能救下他们。没能救下他们是情有可原的，但我相信以你的为人，一定能理解我为什么扣了你一部分工钱，用来帮助那些幸存的家属。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor, "成功抵御了绿皮对城镇的袭击");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success4",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{%employer% 拿着一个比预期轻得多的皮包欢迎你归来。他解释道。%SPEECH_ON%镇子外围几乎被毁了，还有很多人被掳走。抱歉，佣兵，但我需要这笔钱来帮助小镇恢复。如果你想威胁我，尽管动手，但事情就是这样，没得商量。%SPEECH_OFF%你决定接受损失，继续前行。 | 你发现 %employer% 正在视察镇子。几处大火在镇子外围燃烧，向天空中冒着滚滚黑烟。疲惫的农民在道路上艰难跋涉，他们带着能抢救的家当，有的甚至背着受伤的同伴，伤口惨不忍睹。%employer% 对着这景象点了点头。%SPEECH_ON%损失惨重啊，佣兵。你我心里都清楚，我雇你是要完整地保全这个镇子，保护好这里的居民。这两点你都没做到，但至少我们现在还能好好说话，所以我还是会按约定给你一份报酬，虽然只是一小部分。%SPEECH_OFF%他递过来一个装满克朗的皮包。确实，比说好的分量轻多了。但为了以后的合作前景着想，你没有争辩。 | %employer% 正站在窗边远眺。他左右手各拿着一卷卷轴和一支笔，时不时记录两笔。他没有看你，直接开口说道。%SPEECH_ON%嗯，我们都还活着，这挺好。但不好的是那些正在肆虐镇子外围的大火，还有绿皮掳走我们同胞的噩耗。%SPEECH_OFF%终于，他停笔片刻，转过身盯着你。%SPEECH_ON%你的报酬在大厅外面。会比你预期的少。如果你想争辩，我洗耳恭听。%SPEECH_OFF%你意识到争辩也是徒劳，于是干脆地拿走了你应得的那份。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{这只有我们说好的一半而已！ | 没办法，已经这样了...}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() / 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(0);
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() / 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Failure1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{当你走进 %employer% 的房间时，他示意你关上门。就在门锁咔哒一声合上的瞬间，他对你劈头盖脸就是一顿臭骂，满口脏话之多，多到你根本记不住他说了些什么。等他稍微平复了一下情绪，他的声音和用词才恢复到了某种正常的水平。%SPEECH_ON%我们的郊区全被毁了。我到底花钱雇你来干什么的？给我滚出去。%SPEECH_OFF% | %employer% 正猛灌葡萄酒。窗外传来农民们愤怒的喧哗声。%SPEECH_ON%听见了吗？要是我付你钱，他们就要了我的命。你只有一份差事，一份差事！保护这个镇子。而你却搞砸了。所以你现在只能做一件事，而且是免费的：立刻给我滚。%SPEECH_OFF% | %employer% 双手合十放在桌子上。%SPEECH_ON%你到底在期待什么？我真惊讶你居然还有脸回来找我。半个镇子都在燃烧，另一半已经化成灰烬。我雇你不是来制造浓烟和废墟的，佣兵。快滚。%SPEECH_OFF% | 当你回到 %employer% 身边时，他正拿着一杯啤酒。他的手在颤抖，脸色涨红。%SPEECH_ON%我现在全靠意志力强忍着，才没把这酒泼到你脸上。%SPEECH_OFF% 为了以防万一，那人仰头一大口把酒全灌了下去。他把杯子往桌上重重一摔。%SPEECH_ON%这个镇子指望你来保护他们。结果呢？绿皮冲进郊区就他妈像在旅游一样！我才不做资助绿皮毁了我镇子的生意，佣兵。给我滚他妈的远点！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{该死的农民！ | 我们本该要求预付更多报酬的…… | 该死的！}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能成功抵御绿皮对城镇的袭击。");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Failure2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_30.png[/img]{%employer% 不知所踪。他的一名守卫走上前来。%SPEECH_ON%如果你在找我们老板，我劝你还是死心吧。这镇子一半都毁了，他现在正到处去收拾残局呢。%SPEECH_OFF%你问起你的报酬。那人突然爆发出一阵凄凉而粗鲁的笑声。%SPEECH_ON%报酬？抱歉，你这穷鬼佣兵，他可没花钱雇你来搞砸一切。而且那笔钱现在也会投入到城镇建设中去。%SPEECH_OFF% | 你在 %townname% 的燃烧废墟中寻找 %employer%。你发现他正在从一处曾经是房屋的焦黑废墟中，拖出一具具漆黑的尸体。他脚边放下一具烧焦的尸体，几乎要用目光在你身上烧出个洞来。%SPEECH_ON%你来干什么，佣兵？希望不是为了要钱吧，我可没花钱雇你来干成这幅烂摊子。%SPEECH_OFF% | %employer% 被发现正站在窗边远眺。整个地平线都在燃烧，仿佛这个世界要落下两个太阳。他看到你时摇了摇头。%SPEECH_ON%你来这儿干什么？我们有说过要付钱让你看着镇子化为灰烬吗？我想没有吧，佣兵。给我滚。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "{该死的农民！ | 我们本该要求预付更多报酬的…… | 该死的！}",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能成功抵御绿皮对城镇的袭击。");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 3, this.Contract.m.Home, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"reward",
			this.m.Reward
		]);
	}

	function onHomeSet()
	{
		if (this.m.SituationID == 0)
		{
			this.m.SituationID = this.m.Home.addSituation(this.new("scripts/entity/world/settlements/situations/greenskins_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.World.FactionManager.getFaction(this.getFaction()).setActive(true);
			this.m.Home.getSprite("selection").Visible = false;

			if (this.m.Kidnapper != null && !this.m.Kidnapper.isNull())
			{
				this.m.Kidnapper.getSprite("selection").Visible = false;
			}

			if (this.m.Militia != null && !this.m.Militia.isNull())
			{
				this.m.Militia.getController().clearOrders();
			}

			this.World.getGuestRoster().clear();
		}

		if (this.m.Home != null && !this.m.Home.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Home.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		local nearestOrcs = this.getNearestLocationTo(this.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getSettlements());
		local nearestGoblins = this.getNearestLocationTo(this.m.Home, this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).getSettlements());

		if (nearestOrcs.getTile().getDistanceTo(this.m.Home.getTile()) > 20 && nearestGoblins.getTile().getDistanceTo(this.m.Home.getTile()) > 20)
		{
			return false;
		}

		local locations = this.m.Home.getAttachedLocations();

		foreach( l in locations )
		{
			if (l.isUsable() && l.isActive() && !l.isMilitary())
			{
				return true;
			}
		}

		return false;
	}

	function onSerialize( _out )
	{
		this.m.Flags.set("KidnapperID", this.m.Kidnapper != null && !this.m.Kidnapper.isNull() ? this.m.Kidnapper.getID() : 0);
		this.m.Flags.set("MilitiaID", this.m.Militia != null && !this.m.Militia.isNull() ? this.m.Militia.getID() : 0);
		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		this.contract.onDeserialize(_in);
		this.m.Kidnapper = this.WeakTableRef(this.World.getEntityByID(this.m.Flags.get("KidnapperID")));
		this.m.Militia = this.WeakTableRef(this.World.getEntityByID(this.m.Flags.get("MilitiaID")));
	}

});

