
this.deliver_item_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Location = null,
		RecipientID = 0
	},
	function create()
	{
		this.contract.create();
		this.m.DifficultyMult = this.Math.rand(70, 105) * 0.01;
		this.m.Type = "contract.deliver_item";
		this.m.Name = "武装押运";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local recipient = this.World.FactionManager.getFaction(this.m.Destination.getFactions()[0]).getRandomCharacter();
		this.m.RecipientID = recipient.getID();
		this.m.Flags.set("RecipientName", recipient.getName());
		this.contract.start();
	}

	function setup()
	{
		local settlements = this.World.EntityManager.getSettlements();
		local candidates = [];

		foreach( s in settlements )
		{
			if (s.getID() == this.m.Home.getID())
			{
				continue;
			}

			if (!s.isDiscovered() || s.isMilitary())
			{
				continue;
			}

			if (!s.isAlliedWithPlayer())
			{
				continue;
			}

			if (this.m.Home.isIsolated() || s.isIsolated() || !this.m.Home.isConnectedToByRoads(s) || this.m.Home.isCoastal() && s.isCoastal())
			{
				continue;
			}

			local d = this.m.Home.getTile().getDistanceTo(s.getTile());

			if (d < 15 || d > 100)
			{
				continue;
			}

			if (this.World.getTime().Days <= 10)
			{
				local distance = this.getDistanceOnRoads(this.m.Home.getTile(), s.getTile());
				local days = this.getDaysRequiredToTravel(distance, this.Const.World.MovementSettings.Speed, false);

				if (this.World.getTime().Days <= 5 && days >= 2)
				{
					continue;
				}

				if (this.World.getTime().Days <= 10 && days >= 3)
				{
					continue;
				}
			}

			candidates.push(s);
		}

		if (candidates.len() == 0)
		{
			this.m.IsValid = false;
			return;
		}

		this.m.Destination = this.WeakTableRef(candidates[this.Math.rand(0, candidates.len() - 1)]);
		local distance = this.getDistanceOnRoads(this.m.Home.getTile(), this.m.Destination.getTile());
		local days = this.getDaysRequiredToTravel(distance, this.Const.World.MovementSettings.Speed, false);

		if (days >= 2 || distance >= 40)
		{
			this.m.DifficultyMult = this.Math.rand(95, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(70, 85) * 0.01;
		}

		this.m.Payment.Pool = this.Math.max(125, distance * 4.5 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentLightMult());

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("Distance", distance);
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"将货物交付给位于 %objective% 的 %recipient% ，他在 %direction%，去那儿大约需要%days%。"
				];
				local isSouthern = this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState;

				if (!isSouthern && this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else if (isSouthern)
				{
					this.Contract.setScreen("TaskSouthern");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 10)
				{
					if (this.Contract.getDifficultyMult() >= 0.95 && this.World.Assets.getBusinessReputation() > 750 && (!this.World.Ambitions.hasActiveAmbition() || this.World.Ambitions.getActiveAmbition().getID() != "ambition.defeat_mercenaries"))
					{
						this.Flags.set("IsMercenaries", true);
					}
				}
				else if (r <= 15)
				{
					if (this.World.Assets.getBusinessReputation() > 700)
					{
						this.Flags.set("IsEvilArtifact", true);

						if (!this.World.Flags.get("IsCursedCrystalSkull") && this.Math.rand(1, 100) <= 50)
						{
							this.Flags.set("IsCursedCrystalSkull", true);
						}
					}
				}
				else if (r <= 20)
				{
					if (this.World.Assets.getBusinessReputation() > 500)
					{
						this.Flags.set("IsThieves", true);
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"将货物交付给位于 %objective% 的 %recipient% ，他在 %direction%，去那儿大约需要%days%。"
				];

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Destination) && !this.Flags.get("IsStolenByThieves"))
				{
					if (this.Flags.get("IsEnragingMessage"))
					{
						this.Contract.setScreen("EnragingMessage1");
					}
					else
					{
						local isSouthern = this.Contract.m.Destination.isSouthern();

						if (isSouthern)
						{
							this.Contract.setScreen("Success2");
						}
						else
						{
							this.Contract.setScreen("Success1");
						}
					}

					this.World.Contracts.showActiveContract();
				}
				else
				{
					local parties = this.World.getAllEntitiesAtPos(this.World.State.getPlayer().getPos(), 400.0);

					foreach( party in parties )
					{
						if (!party.isAlliedWithPlayer)
						{
							return;
						}
					}

					if (this.Flags.get("IsMercenaries") && this.World.State.getPlayer().getTile().HasRoad)
					{
						if (!this.TempFlags.get("IsMercenariesDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 1)
						{
							this.Contract.setScreen("Mercenaries1");
							this.World.Contracts.showActiveContract();
							this.TempFlags.set("IsMercenariesDialogTriggered", true);
						}
					}
					else if (this.Flags.get("IsEvilArtifact") && !this.Flags.get("IsEvilArtifactDone"))
					{
						if (!this.TempFlags.get("IsEvilArtifactDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 1)
						{
							this.Contract.setScreen("EvilArtifact1");
							this.World.Contracts.showActiveContract();
							this.TempFlags.set("IsEvilArtifactDialogTriggered", true);
						}
					}
					else if (this.Flags.get("IsEvilArtifact") && this.Flags.get("IsEvilArtifactDone"))
					{
						this.Contract.setScreen("EvilArtifact3");
						this.World.Contracts.showActiveContract();
						this.Flags.set("IsEvilArtifact", false);
					}
					else if (this.Flags.get("IsThieves") && !this.Flags.get("IsStolenByThieves") && this.World.State.getPlayer().getTile().Type != this.Const.World.TerrainType.Desert && (this.World.Assets.isCamping() || !this.World.getTime().IsDaytime) && this.Math.rand(1, 100) <= 3)
					{
						local tile = this.Contract.getTileToSpawnLocation(this.World.State.getPlayer().getTile(), 5, 10, [
							this.Const.World.TerrainType.Shore,
							this.Const.World.TerrainType.Ocean,
							this.Const.World.TerrainType.Mountains
						], false);
						tile.clear();
						this.Contract.m.Location = this.WeakTableRef(this.World.spawnLocation("scripts/entity/world/locations/bandit_hideout_location", tile.Coords));
						this.Contract.m.Location.setResources(0);
						this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).addSettlement(this.Contract.m.Location.get(), false);
						this.Contract.m.Location.onSpawned();
						this.Contract.addUnitsToEntity(this.Contract.m.Location, this.Const.World.Spawn.BanditDefenders, 80 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
						this.Const.World.Common.addFootprintsFromTo(this.World.State.getPlayer().getTile(), tile, this.Const.GenericFootprints, this.Const.World.FootprintsType.Brigands, 0.75);
						this.Flags.set("IsStolenByThieves", true);
						this.Contract.setScreen("Thieves1");
						this.World.Contracts.showActiveContract();
					}
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "EvilArtifact")
				{
					this.Flags.set("IsEvilArtifactDone", true);
				}
				else if (_combatID == "Mercs")
				{
					this.Flags.set("IsMercenaries", false);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "EvilArtifact")
				{
					if (this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).getType() == this.Const.FactionType.OrientalCityState)
					{
						this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "无法交付货物。");
					}
					else
					{
						this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "无法交付货物。");
					}

					this.World.Contracts.removeContract(this.Contract);
				}
				else if (_combatID == "Mercs")
				{
					if (this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).getType() == this.Const.FactionType.OrientalCityState)
					{
						this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "无法交付货物。");
					}
					else
					{
						this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "无法交付货物。");
					}

					this.World.Contracts.removeContract(this.Contract);
				}
			}

		});
		this.m.States.push({
			ID = "Running_Thieves",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.Location != null && !this.Contract.m.Location.isNull())
				{
					this.Contract.m.Location.getSprite("selection").Visible = true;
				}

				this.Contract.m.BulletpointsObjectives = [
					"追踪盗贼的踪迹，并取回你的货物",
					"将货物交付给位于 %objective% 的 %recipient% ，他在 %direction%，去那儿大约需要%days%。"
				];
			}

			function update()
			{
				if (this.Contract.m.Location == null || this.Contract.m.Location.isNull())
				{
					this.Contract.setScreen("Thieves2");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_112.png[/img]{%employer% 甚至还没开口，就已经把一个不小的板条箱塞到了你手中。%SPEECH_ON%看看这，我正要运的货，这就找到送货人了！真是太好了！%SPEECH_OFF%他收敛了那副夸张的戏谑表情。%SPEECH_ON%我需要把这个送到 %objective%，那里有个叫 %recipient% 的人在等着。它看着不大，但我愿意出不少克朗确保它平安抵达。有兴趣吗？还是说，它对你来说太重了？%SPEECH_OFF% | 你发现 %employer% 正在关上一个盒子。他迅速抬头瞥了一眼，仿佛正做着什么见不得人的事被抓了个现行。%SPEECH_ON%佣兵！谢谢你来。%SPEECH_OFF%他用几下快速的扣锁声锁好盒子，然后拍了拍箱子好几次，甚至靠在上面，仿佛还需要再加一把大锁才安心。%SPEECH_ON%这里面的货物必须安全送到 %objective%，一个叫 %recipient% 的人在等着它。我不觉得这任务会轻松，因为这货对某些人来说太珍贵了，他们会不惜一切代价弄到手。这就是为什么我找上了你这样……有经验的人。有兴趣帮我这个忙吗？%SPEECH_OFF% | 当你进入 %employer% 的房间时，他正和一个仆人在把箱子钉死。%SPEECH_ON%看到你真好，佣兵。请稍等一下。不，蠢货，把钉子拿稳！我知道刚才砸了你拇指，但我不会再砸了。%SPEECH_OFF%仆人不情愿地捏着钉子，而他把钉子敲了进去。完工后，他擦了擦额头的汗，看向你。%SPEECH_ON%我需要把这个箱子送到 %objective%，大概沿着公路往 %direction% 走%days%的路程。是给一个叫 %recipient% 的人的。好吧，也许你不认识他。但我清楚，这可能不是你平常的业务，但我愿意支付一大笔克朗让你把它安全送达。只要有克朗你就不会在乎，对吧？%SPEECH_OFF% | %employer% 看到你时，双手合十。%SPEECH_ON%这可能是个奇怪的问题，但你有多大兴趣帮我送个货？%SPEECH_OFF%你解释说，只要价格合适，这种脱离日常打打杀杀的差事会让你很欢迎。那人高兴地拍手。%SPEECH_ON%太好了！但不幸的是，我估计没那么简单。这货太重要了，会招来不怀好意的关注。这就是为什么我首先想到了雇佣佣兵。地点是 %objective%，沿着公路往 %direction% 走大概%days%, 一个叫 %recipient% 的人在等着它。所以，你看，你看，这并不是你说的‘脱离’，但如果你感兴趣，这会是一笔不错的收入。%SPEECH_OFF% | %employer% 的手下正围着一批货物站着。看到你，雇主把他们赶走了。%SPEECH_ON%欢迎，欢迎。见到你真好。我需要武装护卫，把这个包裹送到 %objective% 的一个叫 %recipient% 的人手里。我估计像你这样的队伍，大概要走%days%。你有多大兴趣帮我做这事？%SPEECH_OFF% | 当你进去时，%employer%  正把脚翘在桌子上。他双手枕在脑后，看起来对你来说有点太放松了。%SPEECH_ON%好消息，佣兵。怎么样，想不想从打打杀杀里歇一歇。%SPEECH_OFF%他对你的反应挑了挑眉，你根本没反应。%SPEECH_ON%哼，我以为你会抓住这个机会。没关系，刚才那是骗你的：我需要你把这个特定的包裹送给 %objective% 的一个叫 %recipient% 的家伙。这货无疑已经招来了不怀好意的目光，这就是为什么我需要你的人替我盯着它。如果你感兴趣——你应该感兴趣——我们来谈谈价钱。%SPEECH_OFF% | %employer% 欢迎你，并挥手让你进去。%SPEECH_ON%很好，既然你来了，请把门关上。%SPEECH_OFF%他的一名守卫从角落探出头。你笑着慢慢把门关上，把他挡在外面。转过身，你发现 %employer% 正走向一扇窗户。他一边望着窗外一边说话。%SPEECH_ON%我需要送点东西……呃，这……好吧，你不需要知道是什么。我需要把这个‘东西’送给一个叫 %recipient% 的人那里。他在 %objective% 等着。重要的是它必须安全抵达，重要到需要武装护送走%days% 的路。这就是为什么我找上了你和你的队伍。怎么样，佣兵？%SPEECH_OFF% | 昏黄的蜡烛勉强照亮了房间，%employer% 坐在桌后，墙上的影子随着摇曳的火光跳舞。%SPEECH_ON%如果我付你足够的报酬，你会拿起剑为我效劳吗？我需要将{一个小箱子 | 对我来说很重要的东西 | 贵重物品}安全送到 %objective% 的 %recipient%手里，大概要往 %direction% 走%days% 的路。为了这东西，人跟人是会拼命的，所以你必须准备好用生命去守护它。%SPEECH_OFF%他停顿了一下，观察你的反应。%SPEECH_ON%等你把东西送到 %objective% 的联系人手里，我会写一封密封的信函指示他付你钱。怎么样？%SPEECH_OFF% | 一个仆人让你等着 %employer%，说他马上来。于是你等啊等，等啊等。就在你第二次准备离开时，%employer% 猛地打开门，冲向你。%SPEECH_ON%这又是哪位？佣兵？%SPEECH_OFF%他的助手点点头，%employer% 立刻换上一副笑脸。%SPEECH_ON%能在 %townname% 遇到你，真是太幸运了，好队长！”。\n\n我的一些贵重商品必须尽快、最安全地运到 %objective%。你正是我需要的人，因为没有哪个普通的强盗敢攻击你和你的队伍。\n\n是的，我想雇你护送。确保物品送到 %recipient% 手里，当然不能绕路。我们能达成共识吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈价钱。 | 我们具体谈谈多少钱？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{没兴趣。 | 我们不去那边。 | 这不是我们想接的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "TaskSouthern",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_112.png[/img]{维齐尔的一位元老在一群随从的簇拥下向你走来。那些仆人们正费力地将一个不大不小的箱子往你这边搬。%SPEECH_ON%逐币者，维齐尔需要你的帮助。让这些仆人把箱子交给你，然后把它送到 %objective% 的 %recipient% 手里，向 %direction% 大约需要%days%。%SPEECH_OFF%市政大臣鞠了一躬。%SPEECH_ON%虽然这或许只是个简单的任务，但维齐尔愿意为任务的圆满完成支付一笔丰厚的赏金。%SPEECH_OFF% | 你在门厅里找到了正在等候的 %employer%。他正听着一排商人的汇报，每个人都有自己的请求或报价，而他身旁的一位文书则在账本上不停地记录，那账本在大理石地板上摊开得越来越长。看到你，维齐尔打了个响指，旁边的一名男子便走了过来。%SPEECH_ON%逐币者，陛下需要你的服务。带上这个贴着标签的箱子，送到 %objective% 的 %recipient% 手里，需要大约%days% 的路程。货物送到后，到达后你会得到酬劳。%SPEECH_OFF% | 一个戴着滑稽帽子、插着孔雀羽毛的男人不知从哪儿冒出来接近你。他手里拿着一本账本，上面印着 %townname% 某位维齐尔及其卫队的徽章。%SPEECH_ON%%employer% 希望雇用你的服务，逐币者。你需要运送一批精美的材料，当然，为了避开你们这些家伙贪婪的目光，它是被装在箱子里的，然后把它秘密送到 %objective% 的 %recipient% 手里，那地方沿着公路往 %direction% 走大概%days%。一旦货物送达，你就会在目的地拿到报酬。%SPEECH_OFF%那人用羽毛挠了挠头，然后短暂地摇了摇头。%SPEECH_ON%你觉得这个提议符合你目前的财务需求吗？%SPEECH_OFF% | 你先是被一只叼着纸条的鸽子叫住，纸条指引你去找一个年轻男孩，男孩又带你去找一个仆人，仆人领着你穿过一间满是全裸女人的大厅，最后你才到达了一位富商的房间。%SPEECH_ON%啊，你终于到了。我给那些欠我人情的人安排了个简单的任务，居然要这么久才完成？我得去查查这事。%SPEECH_OFF%富商扔给你一本账本，同时整个人瘫倒在一堆软垫里。%SPEECH_ON%我，呃，是维齐尔需要你把一箱货物送到 %objective% 的 %recipient% 手里，那地方沿着公路往 %direction% 大概要%days%。你不能打开那些货物，只能运送。如果你敢打开，维齐尔会知道的。相信我，逐币者，维齐尔只喜欢听到好消息。这就是为什么站在这里的是我，而不是他本人。%SPEECH_OFF%真是一种荣幸啊。}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈价钱。 | 我们具体谈谈多少钱？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{没兴趣。 | 我们不去那边。 | 这不是我们想接的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Mercenaries1",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_07.png[/img]{在路上时，一队全副武装的男人挡住了你的去路。 | 正当你朝着 %objective% 前进时，几个人打断了你安静的旅程，他们武器和盔甲叮当作响，在空气中回荡，随即列成阵势。 | 不幸的是，你的旅程并不简单。许多人走到你面前，显然是在阻挡你的路。 | 一些武装且身着重甲的男人走了出来，制造了一个金属路障。他们看起来似乎打算确保你无法再往前走。 | 几个人停了下来。 你走到前面去看看发生了什么事，却看到一排全副武装的人站在 %companyname% 的面前。 好的，这应该很有趣。}敌方队长向前一步，握紧拳头拍着自己的胸膛。%SPEECH_ON%{站在你面前的是 %mercband%。我们杀死了超乎想象的野兽，是这片被诸神遗忘的土地上的最后希望！ | 我们的名字是 %mercband%，在这片土地上，我们以爱砍头，爱美酒和爱女人而闻名！ | 站在你面前的是传奇的 %mercband%。我们是 %randomtown% 的救世主，也是斩杀伪王的人！ | 看看我骄傲的队伍，%mercband%，我们曾击退一百个兽人，拯救一个城市免于毁灭。 你有什么值得骄傲的？ | 你正在和一个 %mercband% 的人说话。 对我们来说，无论是普通的强盗、肮脏的绿皮还是一袋金币或裙子，没有能从我们手中逃脱的！}%SPEECH_OFF%那人在结束了他的装腔作势和个人吹嘘后，他指了指你携带的货物。%SPEECH_ON%{所以现在你意识到你所面临的危险了，为什么不干脆把货交出来呢？ | 我希望你明白自己面对的是谁，可怜的佣兵，这样你才能确保你的手下今晚能安然入睡。你所要做的就是交出货物，这样我们就不必把你加入 %mercband% 的历史里。 | 啊，我敢打赌你想成为我们历史的一部分，对吧？ 好消息是，你只需要不交出那货物，我们就会用剑把你写进去。 当然，如果你把货物交给我们，你就可以逃脱抄写员的笔。 | 哦，这不是 %companyname% 吗。尽管我很想把你加入我们的胜利名单，但同样作为佣兵，但我还是给你一个机会。你只需要交出货物，我们就会离开。你觉得怎么样？}%SPEECH_OFF%{嗯，好吧，不管怎么说，这要求确实够浮夸的。 | 嗯，不管怎么说，这表演还挺有趣的。 | 你不太明白对表演的需求，但毫无疑问，你发现自己陷入了一个非常严肃的新局面。 | 虽然你欣赏这些赞美和夸张，但现实情况是，这些人确实是认真的。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "如果你想要它，就过来拿吧！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "Mercs";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 120 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getID());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				},
				{
					Text = "这不值得为此送命。拿走那该死的货物，快滚。",
					function getResult()
					{
						return "Mercenaries2";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Mercenaries2",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_07.png[/img]{你不想惹麻烦，于是交出了货物。他们在从你手中接过东西时发出了阵阵嘲笑：%SPEECH_ON%明智的选择，佣兵。也许有朝一日，你会成为那个威胁别人的人。%SPEECH_OFF% | 这批货，不管它是什么，都不值得让你的手下为此送命。你交出了箱子，佣兵们拿走了它。在你离开时，他们还在嘲笑你。%SPEECH_ON%就和追一个婊子一样简单！%SPEECH_OFF% | 现在可不是为了 %employer% 的快递服务而牺牲你手下的时候和地方。你交出了货物。佣兵们拿走后便离开了，他们的队长随手丢给你一枚克朗，那枚硬币旋转着落入了烂泥之中。%SPEECH_ON%给自己买个棺材吧，小子，这工作不适合你。%SPEECH_OFF% | 这群佣兵装备精良，你无法想象如果为了运送一个不知道装着什么鬼东西的箱子而让弟兄们送命，自己是否能睡得安稳。你点了点头，交出了货物。那支佣兵团很高兴地从你手中拿走了它，他们的队长在离开时停下来，带着敬意回敬了一礼。%SPEECH_ON%明智的选择，在我刚开始时，我也经历了很多这样的选择。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "嗯……",
					function getResult()
					{
						this.Flags.set("IsMercenaries", false);
						this.Flags.set("IsMercenariesDialogTriggered", true);

						if (this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "无法交付货物。");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "无法交付货物。");
						}

						local recipientFaction = this.Contract.m.Destination.getFactionOfType(this.Const.FactionType.Settlement);

						if (recipientFaction != null)
						{
							recipientFaction.addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail * 0.5);
						}

						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BountyHunters1",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_07.png[/img]{你在路上偶遇了一伙赏金猎人。他们的囚犯冲你大喊大叫，声音嘶哑地哀求你救救他。他声称自己是个无辜的人。而那帮赏金猎人则让你滚开去死。 | 你正在路上行走时，遇到了一群全副武装的赏金猎人。他们正粗暴地拖拽着一个从头到脚戴满镣铐的男人。%SPEECH_ON%你最好别掺和这档子事。%SPEECH_OFF%其中一人说道，同时狠狠击打囚犯的腿窝。那男人一声惨叫，手脚并用地爬向你，双手和膝盖早已鲜血淋漓。%SPEECH_ON%他们全都是骗子！这些人要杀了我，尽管我根本没做错任何事！救救我，先生们，求求你们了！%SPEECH_OFF% | 你遇到了一大群赏金猎人，两帮人马在荒野中奇异地对峙着，虽然彼此在这世上的目的显然不同。他们正在押送一名囚犯，那人被锁链捆住，嘴里还塞着一块破布。那男人冲你大喊大叫，几乎是在恳求，因为说不出话而憋得满脸通红。其中一名赏金猎人啐了一口唾沫。 %SPEECH_ON%别理他，陌生人，赶紧上路吧。像我们这种人之间，最好别惹出什么麻烦。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "这不关我们的事。",
					function getResult()
					{
						return 0;
					}

				},
				{
					Text = "也许我们可以买下这个囚犯？",
					function getResult()
					{
						return this.Math.rand(1, 100) <= 50 ? "BountyHunters1" : "BountyHunters1";
					}

				},
				{
					Text = "想要的话，就过来拿啊！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "Mercs";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 140 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getID());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Thieves1",
			Title = "露营时…",
			Text = "[img]gfx/ui/events/event_05.png[/img]{你从午睡中醒来，翻了个身，下意识地伸手去摸那个包裹，就好像它是你的情人一样。但那里空空如也，货物也不见了。你迅速跳了起来，开始大声命令弟兄们警戒。这时，%randombrother% 跑过来报告说，他已经追踪到了一些从营地离开的脚印。 | 在休息时，你听到营地某个地方传来了骚乱。你冲过去一看，只见 %randombrother% 脸朝下趴在地上，正揉着后脑勺。%SPEECH_ON%对不起，头儿，我刚才正在撒尿，然后他们就趁机下手把我给撂倒了。另外……他们把包裹偷走了。%SPEECH_OFF%你让他把最后一部分再重复一遍。%SPEECH_ON%该死的小偷把货给偷了！%SPEECH_OFF%是时候去追踪那帮混蛋并把东西抢回来了。 | 很自然地，这趟旅途不可能平平淡淡。不，这个世界太烂了，根本不可能让你顺顺利利。看来小偷们已经带着货物溜之大吉了。幸运的是，他们留下了大量证据，主要是搬运包裹时留下的脚印和拖拽痕迹。要找到他们应该不难…… | 你就想安安静静地从一个镇子走到下一个镇子，就这么一次，行不行？结果呢？你和 %employer% 的这份合同再次招来了麻烦。不知怎么的，小偷竟然摸进了营地把货物偷走了。好消息是，他们没能悄无声息地溜出去：你已经发现了他们的脚印，要追上他们应该不难。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们顺着脚印追！",
					function getResult()
					{
						this.Contract.setState("Running_Thieves");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Thieves2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{盗贼的血流得再多，也掩盖不了事实。你设法找到了雇主的货物，发现它依然在营地里，锁得好好的，安然无恙。这种小插曲，没必要让雇主知道。 | 嗯，一切都还在它该在的地方。%employer% 的货物被发现压在一个扭动的盗贼身体底下。你在捅穿他之前，很贴心地先把他踢开了。毕竟，谁也不想让包裹沾上血不是。 | 杀光了最后一波盗贼，你和手下们散开，在这帮强盗的营地里搜寻那个包裹。%randombrother% 眼尖，一下子就发现了目标，那个容器还被一个死掉的蠢货死死抓在手里。那个佣兵费劲地掰着尸体的手，最后不耐烦了，干脆直接把那混蛋的胳膊给砍了下来。你取回了包裹，在接下来的路程里，打算把它抱得更紧一些。 | 俯视着地上倒毙的盗贼尸体，你琢磨着是不是该让 %employer% 知道这事。包裹看起来还算完好，虽然沾了点血和骨头渣，但擦擦应该就能掉。 | 包裹是有点磕碰磨损，但问题不大。好吧，虽然上面全是血，还有一个盗贼被硬生生剥了皮的手指死死卡在其中一个搭扣里。抛开这些小问题不谈，一切都好得不能再好了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "物归原主了。",
					function getResult()
					{
						this.Flags.set("IsThieves", false);
						this.Flags.set("IsStolenByThieves", false);
						this.Contract.setState("Running");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EnragingMessage1",
			Title = "在 %objective%",
			Text = "{墓地里弥漫着浓雾——或者更确切地说，是尸体散发出的浓重瘴气。等等……那就是尸体在动！全体听令，准备战斗！ | 你的目光落在一块墓碑上，发现碑底有一堆新翻出来的泥土。一串串泥点子像面包屑一样延伸向远方。周围没有铲子……也没有活人……当你顺着痕迹追过去时，一伙正在呻吟哀嚎的亡灵出现在眼前，此刻正死死地盯着你，眼中充满了无法满足的饥渴…… | 一个男人在墓碑的深处徘徊。他身形摇摇欲坠，看起来像是随时都会昏倒。%randombrother% 赶到你身边，摇了摇头。%SPEECH_ON%那可不是人，头儿。是有亡灵出没。%SPEECH_OFF%就在他话音刚落的瞬间，远处的那个陌生人缓缓转过身来，在微光中露出了真容——他的半张脸已经不见了。 | 你发现这里的许多坟墓都被挖空了。不仅仅是被挖开，而是从底部被硬生生掀开的。这绝不是盗墓贼干的……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EvilArtifact1",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{行进途中，你注意到除了你们之外，还有别的东西在动：那就是货物本身。箱子的盖子正在上下跳动，侧面透出一股奇怪的光芒。%randombrother% 走过来，看了看箱子，又看了看你。%SPEECH_ON%头儿，我们要打开它看看吗？或者我直接把它扔进最近的池塘里得了，眼前这景象实在太他妈不对劲了。%SPEECH_OFF%你用手指戳了戳他，问他是不是害怕了。 | 走在山路上，你开始听到一阵低沉的嗡嗡声，源头正是 %employer% 交给你的那个包裹。%randombrother% 正站在旁边，用一根棍子戳它。你一巴掌把他打退，并让他解释。他说道。%SPEECH_ON%头儿，这批货有点邪门……%SPEECH_OFF%你仔细打量着它。盖子边缘闪烁着微弱的光晕。据你所知，火不可能在那种密闭空间里燃烧，而除了月亮和星星之外，还有什么能在黑暗中发光呢？你开始担心，自己的好奇心是不是要战胜理智了…… | 货物安放在你旁边的马车上，随着道路的颠簸和转弯而晃来晃去。突然，它开始发出嗡嗡声，你发誓刚才那一瞬间看到盖子飘了起来。%randombrother%瞥了一眼。%SPEECH_ON%你没事吧，头儿？%SPEECH_OFF%就在他话音刚落的瞬间，箱盖猛地向外炸开，五颜六色的光晕、雾气、灰烬、灼热的火焰和刺骨的寒意喷涌而出。你举起双臂护住自己，等你从臂弯里偷偷瞄过去时，箱子已经完全静止了，盖子也回到了原位。你和那个佣兵对视了一眼，然后两人都死死地盯着那件货物。这可能不仅仅是一次普通的送货任务…… | 一阵低沉的嗡嗡声从旁边传来。你本能地以为是附近的蜂巢，下意识地低头躲避，结果发现声音竟然是那个 %employer% 交给你的货物发出来的。箱子顶端的盖子正在左右摇晃，震得那些用来固定的搭扣和钉子嘎嘎作响。%randombrother% 看起来有点害怕了。%SPEECH_ON%咱们把它扔在这儿吧。这东西绝对有问题。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我想知道这到底是怎么回事。",
					function getResult()
					{
						return "EvilArtifact2";
					}

				},
				{
					Text = "离那东西远点。",
					function getResult()
					{
						this.Flags.set("IsEvilArtifact", false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EvilArtifact2",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_73.png[/img]{好奇心最终战胜了理智。你开始慢慢撬开箱盖。%randombrother% 后退了一步，提出了抗议。%SPEECH_ON%头儿，我觉得咱们最好别碰它。我的天哪，你看看这箱子。%SPEECH_OFF%你无视了他的劝阻，告诉弟兄们没事的，然后猛地掀开了盖子。\n\n情况并不像你说的那样。爆炸的冲击波瞬间将你掀翻在地。周围瞬间充满了可怕的幻影和尖锐的嘶吼。弟兄们本能地抄起武器，只见被操控的幽灵如长矛般刺入大地。土堆隆起，大地开始呻吟。你眼睁睁看着无数双手从地底伸出，拖拽着破败腐朽的尸体爬出深坑。死者复活了，而且他们显然想让你加入他们的行列！ | 完全不顾任何人的理智判断，你强行撬开了货物。起初，什么也没有。箱子里空空如也。%randombrother% 紧张地笑了几声。%SPEECH_ON%呃……看来就这样了。%SPEECH_OFF%但事情真的结束了吗，为什么 %employer% 要让你运送一个空箱子，除非——\n\n当你醒来时，耳鸣声正慢慢消退。你翻过身，发现那个箱子已经完全消失了，只剩下地上一堆像雪片一样的木屑。%randombrother% 冲过来，一把拽起你，拖着你向队伍跑去。他们指着前方，嘴巴张合着大喊大叫……\n\n一群全副武装的人正……摇摇晃晃地朝你们走来？当你看清他们时，发现他们拿着涂满奇异符文的古老木盾，身上的盔甲形状怪异，你从未见过，仿佛是刚学会打铁的人打造的，却又带着一种原始的杀伤力。这些人看起来就像是……远古时代的先民。 | %randombrother% 摇着头，看着你伸手去拿箱盖。费了一番力气撬开后，你迅速后退，准备迎接最坏的情况。但箱子里什么都没有。甚至连一点声音也没有。你拿起一把剑在空箱子里搅动，寻找暗格之类的东西。%randombrother% 笑了。%SPEECH_ON%嘿，原来我们运送的是一箱子空气！我早就觉得这破箱子没那么重！%SPEECH_OFF%就在这时，箱子突然腾空而起，旋转着砸向地面。它无声地、完美地碎裂开来，每一块木片都像古老的石砌建筑一样整齐地铺在草地上。一个无形的幻影从碎裂的仪式中探出头来，扭曲着，咧嘴大笑。%SPEECH_ON%哦，人类，真高兴再次见到你们。%SPEECH_OFF%那个声音像冰锥一样刺入你的脊背。你看着那个幽灵射向天空，然后猛地砸回地面，如长矛般刺入大地。不到一秒，大地就开始喷发，无数尸体开始爬出地面。 | 那个箱子像磁铁一样吸引着你。你毫不犹豫地撬开货物，低头一看。你先是闻到了气味——一股恶臭扑面而来，浓烈到几乎让你失明。一个手下当场呕吐。另一个也干呕起来。当你再看向箱子时，漆黑的烟雾正从中渗出，拉长、蔓延，像触手一样探查着地面。当它们找到目标后，便猛地钻入大地，像钓鱼一样将死人的尸骨硬生生拽了出来。 | 无视几个手下的担忧，你砸开了包裹。映入眼帘的是一堆人头，他们发光的眼睛闪烁着苏醒过来。下巴发出噼啪声，从僵硬的状态变成咔嗒作响的笑声。你迅速想把箱子盖上，但一股力量推着盖子反弹回来。 你和 %randombrother% 以及其他几个人拼命想合上它，但感觉就像有一场无声的风暴在抵抗你们。\n\n仅仅过了一瞬间，你们全都被震飞了出去。箱盖冲天而起，被一股黑色灵魂组成的狂风托举着。它们四处飞窜，梳理着大地，然后集体转向，正对着 %companyname%。你惊恐地看着那些无形的雾气开始凝聚，灵魂的迷雾硬化成很久以前就已迷失的亡魂尸骨。当然，他们还带着武器，那咔嗒作响的颚骨依然在发出空洞的笑声。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "EvilArtifact";
						p.Music = this.Const.Music.UndeadTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Center;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;

						if (this.Flags.get("IsCursedCrystalSkull"))
						{
							this.World.Flags.set("IsCursedCrystalSkull", true);
							p.Loot = [
								"scripts/items/accessory/legendary/cursed_crystal_skull"
							];
						}

						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.UndeadArmy, 120 * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Undead).getID());
						this.World.Contracts.startScriptedCombat(p, false, false, false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EvilArtifact3",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{战斗结束，你立刻冲回那个神器所在的位置，却发现它正悬浮在半空中。%randombrother% 跑到你身边，惊恐地喊道。%SPEECH_ON%头儿，毁了它吧！趁它还没惹出更多麻烦！%SPEECH_OFF% | 你的手下并不是战场上唯一的幸存者——那个神器，或者说它那仍在脉动着残余力量的部分，正无辜地悬浮在你上次见到它的地方。那东西变成了一个能量流转的球体，时不时发出咔嗒声，有时还会低语，说着一种你完全听不懂的语言。%randombrother% 冲着它点了点头，示意你动手。%SPEECH_ON%毁了它吧，头儿。砸了它，让我们彻底结束这场噩梦。%SPEECH_OFF% | 这种力量根本不应该存在于这个世界上！那个神器已经变成了一颗拳头大小的球体。它漂浮在离地半尺的空中，发出嗡嗡声，仿佛在吟唱一首来自异世界的歌谣。这东西看起来几乎像是在等你，就像一条狗在等待它的主人。%SPEECH_ON%头儿。%SPEECH_OFF%%randombrother% 拉了拉你的肩膀，哀求道。%SPEECH_ON%头儿，求你了，毁了它吧。别让我们再带着这东西多走一步了！%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们必须毁了它。",
					function getResult()
					{
						return "EvilArtifact4";
					}

				},
				{
					Text = "我们收钱就是为了送货，那我们就得把它送到。",
					function getResult()
					{
						this.Flags.set("IsEvilArtifact", false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EvilArtifact4",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{你拔出佩剑，站在神器面前，刀刃缓缓举过头顶。%SPEECH_ON%住手！%SPEECH_OFF%你回过头瞥了一眼，只见 %randombrother% 和其他手下正怒视着你。漆黑的阴影笼罩着他们，也笼罩着目之所及的整个世界。他们的眼睛泛着红光，随着每一句咆哮疯狂脉动。%SPEECH_ON%你会永世燃烧！永世燃烧！毁了它，你就将永世受罚！燃烧！燃烧！燃烧殆尽！%SPEECH_OFF%你嘶吼着转过身，挥剑斩向那件遗物。它轻而易举地被劈成两半，一股绚烂的色彩浪潮随即席卷了你的世界。汗水顺着额头倾泻而下，你发现自己正倚靠着剑柄喘息。你回头看去，只见佣兵团的弟兄们正目瞪口呆地盯着你。%SPEECH_ON%头儿，你还好吧？%SPEECH_OFF%你收剑入鞘，点了点头，但你这辈子从未感到如此恐惧。%employer% 肯定不会高兴，但让他和他的怒火见鬼去吧！ | 就在你萌生毁掉这件遗物的念头那一瞬间，一阵惊恐的尖叫声也随之而来。那是妇女和儿童凄厉的哭喊，声音因极度的恐惧而撕裂，仿佛她们浑身着火般向你奔来。她们用数百种语言对你嘶吼，但偶尔会夹杂着你听得懂的语言，而那个词永远只有一个：别。\n\n你拔出佩剑，将其高高举过头顶蓄力。那件神器开始嗡嗡作响并剧烈震动。烟雾般的触手从中飘散，一股粗野的热浪扑面而来。别。\n\n你稳住了手里的剑。\n\n达库尔。耶克拉。伊姆舒达。佩兹兰特。别。\n\n你咽了口唾沫，瞄准了目标。\n\n别。拉夫维特。乌尔拉。奥夏罗。埃布洛。麦吉卡。别。别。别。别——。\n\n这一击精准无比，那诡异的低语也随之消散，神器坠落在地，断成两截。你也随之跪倒在地，几名佣兵团的弟兄赶忙过来将你扶起。%employer% 肯定不会高兴，但你忍不住觉得，自己刚刚让这个世界躲过了一场它本不该看见、也不该听见的恐怖浩劫。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "结束了。",
					function getResult()
					{
						this.Flags.set("IsEvilArtifact", false);

						if (this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "无法交付货物。");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.m.Destination.getFactions()[0]).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "无法交付货物。");
						}

						local recipientFaction = this.Contract.m.Destination.getFactionOfType(this.Const.FactionType.Settlement);

						if (recipientFaction != null)
						{
							recipientFaction.addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail * 0.5);
						}

						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "EvilArtifact5",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{你摇了摇头，转身又找来一个板条箱，小心翼翼地将那个悬浮着的神器推进去，然后迅速盖上了盖子。%employer% 给了你不少钱，嗯，你打算把这活儿干到底。但不知为何，你不确定这个决定究竟是出于你自己的意志，还是这件诡异的遗物在暗中低语，操纵着你的双手为你做出选择。 | 你去找来一个木箱，把它罩在神器上，迅速盖上盖子。有几个佣兵摇了摇头。这或许不是个好主意，但不知为何，你感到一种无法抗拒的冲动，驱使你必须完成这项任务。 | 理智告诉你，你应该毁了这件可怕的遗物，但理智再一次败下阵来。你搬来一个木箱，把它扣在神器上，合上盖子，咔哒一声锁上了搭扣。你完全不知道自己这么做到底是为了什么，但当准备重新上路时，你的身体里却充满了某种突如其来的能量。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们该上路了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_20.png[/img]{%recipient% 正在镇子里等着你。他急匆匆地从你手上接过货物。%SPEECH_ON%哦，哦天哪，我真没想到你们能送到。%SPEECH_OFF%他那双脏兮兮的手在装着货物的箱子上摸索着。接着他转过身，朝手下厉声下令。那人走上前，递给你一个装满克朗的钱袋。 | 终于到了。%recipient% 站在路中间，双手交叠放在肚子上，那张狡黠的脸上挂着一丝油腻的假笑。%SPEECH_ON%佣兵，我真不确定你们能不能活着到这儿。%SPEECH_OFF%你费力地把货物拖过去交给他。%SPEECH_ON%哦？此话怎讲？%SPEECH_OFF%那男人接过箱子，立刻递给了一位穿长袍的人，那人夹着箱子迅速快步离开了。%recipient% 边递给你一个装满克朗的钱袋边笑道。%SPEECH_ON%这些日子的路不好走，不是吗？%SPEECH_OFF%你心知肚明他是在没话找话，只想转移你的注意力，让你别去想刚才交出去的货物。但管他的呢，你拿到了酬金，这就够了。 | %recipient% 迎接了你们，他几个手下赶紧跑过来搬走货物。他拍了拍你的肩膀。%SPEECH_ON%我猜你们的旅途还算顺利吧？%SPEECH_OFF%你省去了那些惊险的细节，直接问起了报酬。%SPEECH_ON%哈，真是典型的佣兵作风。%randomname%，把这个人应得的钱给他！%SPEECH_OFF%%recipient% 的一名保镖走过来，递给你一只装着克朗的小箱子。 | 经过一番寻找，有个路人问你在找谁。当你提到 %recipient% 时，他指向附近的一个围场，只见一个男人正骑在一匹看起来极其奢华的马上踱步。\n\n你走过去，那男人勒住马缰，居高临下地问你是不是送来了 %employer% 的货物。你点了点头。%SPEECH_ON%把它放你脚边就行。我会去取的。%SPEECH_OFF%你并没有照做，而是直接问起了酬金。那男人叹了口气，吹了声口哨叫来一名保镖。%SPEECH_ON%给这位佣兵他应得的报酬。%SPEECH_OFF%最后，你把箱子放在地上，转身离开了。} ",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());

						if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "运送了一些货物");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "运送了一些货物");
						}

						local recipientFaction = this.Contract.m.Destination.getFactionOfType(this.Const.FactionType.Settlement);

						if (recipientFaction != null)
						{
							recipientFaction.addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess * 0.5, "运送了一些货物");
						}

						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.Tactical.getEntityByID(this.Contract.m.RecipientID).getImagePath());
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_163.png[/img]{%SPEECH_START%啊，逐币者。%SPEECH_OFF%声音来自附近的一条小巷。通常这意味着有人想顺走你的钱袋，但没想到对方竟然是来送金子的。%SPEECH_ON%我是 %recipient%，那个包裹归我了。替我向 %employer% 问好，或者不问也行，我无所谓。%SPEECH_OFF%那男人像出现时一样突然，转眼就消失不见了。 | %recipient% 是个矮壮的男人，他佩戴着维齐尔的徽章和标志，却表现得像是扛着你刚交给他的那个箱子一样沉重。%SPEECH_ON%我为维齐尔付出了太多，而他用什么来回报我？用一个逐币者的汗水。愿镀金者在注视那个男人的未来时眨一下眼吧。%SPEECH_OFF%你对此保持沉默，部分原因是怀疑这是否是一场‘考验’，想看看你是否会附和他，从而暴露自己是那位至高无上的维齐尔的敌人。那人盯着你看了一会儿，然后耸耸肩继续说道。%SPEECH_ON%你的酬劳在这儿。钱都算好了，虽然如果你想要亲自点一遍我也不介意。啊，我看你已经在数了。很好。看？一分不少。现在走吧，小逐币者。%SPEECH_OFF% | 你发现 %recipient% 正在一群孩子面前摆架子讲大道理。他迅速点出你，并以此教育孩子们要好好学习，否则长大后就会像你一样。孩子们被遣散后，那个男人走过来，递给你一个装满克朗的钱袋。%SPEECH_ON%我的手下告诉我你到了，而且物资完好无损。这是你那份酬劳，逐币者。%SPEECH_OFF% | 你走进 %recipient% 的家，包裹最终被卸下，随后被仆人们迅速拿走。%recipient% 从一张看起来很舒服的椅子上盯着你，问你的旅途是否顺利。你表示闲聊填不饱口袋，直接问起了报酬。那人挑了挑眉毛。%SPEECH_ON%啊，难道我文明高雅的谈吐冒犯到我们的逐币者了吗？我罪过太大了。好吧，你的酬劳就在角落里，一分不少，如约付清。%SPEECH_OFF% | %recipient% 正对着一面镜子高谈阔论地讲着鸟类的习性。当他从镜子里看到你时，转过身来，表现得好像刚才什么怪事都没发生过一样。%SPEECH_ON%一个逐币者。维齐尔当然会派个逐币者来。我宁愿想象你不敢用眼睛亵渎箱子里的货物，但我甚至不能指望你们这种人具备这种职业素养。不过你对我可以放心：你的酬劳在角落里，保证够数。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());

						if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "运送了一些货物");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "运送了一些货物");
						}

						local recipientFaction = this.Contract.m.Destination.getFactionOfType(this.Const.FactionType.Settlement);

						if (recipientFaction != null)
						{
							recipientFaction.addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess * 0.5, "运送了一些货物");
						}

						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.Tactical.getEntityByID(this.Contract.m.RecipientID).getImagePath());
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		local days = this.getDaysRequiredToTravel(this.m.Flags.get("Distance"), this.Const.World.MovementSettings.Speed, true);
		_vars.push([
			"objective",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.m.Destination.getName()
		]);
		_vars.push([
			"recipient",
			this.m.Flags.get("RecipientName")
		]);
		_vars.push([
			"mercband",
			this.Const.Strings.MercenaryCompanyNames[this.Math.rand(0, this.Const.Strings.MercenaryCompanyNames.len() - 1)]
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.Destination.getTile())]
		]);
		_vars.push([
			"days",
			days <= 1 ? "1天" : days + "天"
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
			}

			if (this.m.Location != null && !this.m.Location.isNull())
			{
				this.m.Location.getSprite("selection").Visible = false;
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive() || !this.m.Destination.isAlliedWithPlayer())
		{
			return false;
		}

		return true;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Location != null && !this.m.Location.isNull())
		{
			_out.writeU32(this.m.Location.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		_out.writeU32(this.m.RecipientID);
		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local location = _in.readU32();

		if (location != 0)
		{
			this.m.Location = this.WeakTableRef(this.World.getEntityByID(location));
		}

		this.m.RecipientID = _in.readU32();

		if (!this.m.Flags.has("Distance"))
		{
			this.m.Flags.set("Distance", 0);
		}

		this.contract.onDeserialize(_in);
	}

});

