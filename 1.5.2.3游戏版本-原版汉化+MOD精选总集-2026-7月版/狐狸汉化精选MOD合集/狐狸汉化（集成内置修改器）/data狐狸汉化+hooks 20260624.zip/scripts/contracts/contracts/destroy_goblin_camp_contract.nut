this.destroy_goblin_camp_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.destroy_goblin_camp";
		this.m.Name = "摧毁哥布林营地。";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		local camp = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).getNearestSettlement(this.World.State.getPlayer().getTile());
		this.m.Destination = this.WeakTableRef(camp);
		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Payment.Pool = 900 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 2);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"摧毁 " + this.Flags.get("DestinationName") + "，位于%origin%的%direction%"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Contract.m.Destination.clearTroops();
				this.Contract.m.Destination.setLastSpawnTimeToNow();

				if (this.Contract.getDifficultyMult() < 1.15 && !this.Contract.m.Destination.getFlags().get("IsEventLocation"))
				{
					this.Contract.m.Destination.getLoot().clear();
				}

				this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.GoblinRaiders, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setLootScaleBasedOnResources(110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setResources(this.Math.min(this.Contract.m.Destination.getResources(), 100 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult()));
				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);

				if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getFlags().get("Betrayed") && this.Math.rand(1, 100) <= 75)
				{
					this.Flags.set("IsBetrayal", true);
				}
				else
				{
					local r = this.Math.rand(1, 100);

					if (r <= 20 && this.World.Assets.getBusinessReputation() > 1000)
					{
						if (this.Contract.getDifficultyMult() >= 0.95)
						{
							this.Flags.set("IsAmbush", true);
						}
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsBetrayal"))
					{
						if (this.Flags.get("IsBetrayalDone"))
						{
							this.Contract.setScreen("Betrayal2");
							this.World.Contracts.showActiveContract();
						}
						else
						{
							this.Contract.setScreen("Betrayal1");
							this.World.Contracts.showActiveContract();
						}
					}
					else
					{
						this.Contract.setScreen("SearchingTheCamp");
						this.World.Contracts.showActiveContract();
						this.Contract.setState("Return");
					}
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				if (this.Flags.get("IsAmbush"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("Ambush");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.LocationTemplate = null;
						p.CombatID = "Ambush";
						p.Music = this.Const.Music.GoblinsTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Center;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.GoblinRaiders, 50 * this.Contract.getScaledDifficultyMult(), this.Contract.m.Destination.getFaction());
						this.World.Contracts.startScriptedCombat(p, false, false, false);
					}
				}
				else
				{
					this.World.Contracts.showCombatDialog();
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Betrayal")
				{
					this.Flags.set("IsBetrayalDone", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Betrayal")
				{
					this.Flags.set("IsBetrayalDone", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_61.png[/img]{当你走进房间时，%employer% 正在阅读一卷羊皮纸。他挥手示意你走开，大概以为你只是个仆人。你把剑鞘在墙上磕得哗哗作响。那人抬起头瞥了一眼，随即迅速丢下手中的文件。%SPEECH_ON%啊，佣兵！见到你真是太好了。我这儿有个活儿，专门为你这种……有特殊‘职业素养’的人准备的。%SPEECH_OFF%他停顿了一下，似乎在等你接话。见你默不作声，他尴尬地继续说道。%SPEECH_ON%是啊，当然，说正事。在 %origin% 的 %direction% 的 %location%，有一群哥布林安营扎寨。本来我想亲自带几个骑士去处理，但事实证明。‘杀哥布林‘这种事在这些骑士们看来是有损颜面的。胡扯！依我看，他们是怕死在那些矮小卑鄙的混蛋手里。什么荣誉、勇气，全是借口。%SPEECH_OFF%他咧嘴一笑，举起一只手。%SPEECH_ON% 但这难不倒你，只要报酬合适，对吧？%SPEECH_OFF% | %employer% 正在冲着一个刚走出房间的人大喊大叫。等他平复下来后，向你致以了‘友好’的问候。%SPEECH_ON%该死的，见到你真是太好了。你知道要让那些‘忠诚’的手下去杀几个哥布林有多难吗?%SPEECH_OFF%他啐了一口，用袖子擦了擦嘴。%SPEECH_ON%他们居然说这任务不够‘高尚’。还说什么那些小杂种从来不公平决斗。你能信吗？一群手下竟敢教我这个高贵的贵族什么叫‘高尚’！不管怎样，活儿就在这儿了，佣兵。我要你去 %origin% 的 %direction% 干掉那些扎营的哥布林。你能办到吗？%SPEECH_OFF% | %employer% 正在拔剑又收剑，似乎一直在盯着剑刃上的倒影看，然后又猛地把剑甩开。%SPEECH_ON% 他们说有个叫  %location% 的地方在 %origin% 的 %direction% 有哥布林扎营。就在今天，有个小男孩被抬到我脚边，脖子上还插着一支毒镖。我没有理由不信他们。%SPEECH_OFF%他把剑狠狠地插回剑鞘。%SPEECH_ON%你愿意替我解决这个麻烦吗？%SPEECH_OFF% | 当你走进房间时，喝得满脸通红的 %employer% 正在猛砸酒杯。%SPEECH_ON%佣兵，对吧？%SPEECH_OFF%他的卫兵看了一眼并点了点头。这位贵族笑了起来。%SPEECH_ON%哦，太好了。又来几个送死的。%SPEECH_OFF%他停顿了一下，随即爆发出一阵大笑。%SPEECH_ON%开玩笑的，这笑话好笑吧？我们这边在 %origin% %direction% 的 %location% 遇到了一些麻烦的哥布林。我要你去处理掉他们。你——嗝——行不行啊？不行的话我再去找别人，让他们去挖自己的……我的意思是……？%SPEECH_OFF%他咕咚一声又灌了一杯酒，把话堵了回去。 | 当你走进房间时，%employer% 正在比较两个卷轴。%SPEECH_ON%我的税务官最近收上来的税少得可怜。真是遗憾，不过我想这对你是好事，因为我现在雇不起那些所谓的‘忠诚’骑士了。%SPEECH_OFF%他把文件扔到一边，双手在桌面上搭成帐篷状。%SPEECH_ON%我的探子报告说，哥布林在一处叫 %location% 的地方扎了营，就在 %origin% 的 %direction%。我要你去那儿，做那些我的封臣拒绝做的事。%SPEECH_OFF% | %employer% 在你进来时正在掰面包，但他一点也没打算分给你。他把两头面包蘸进高脚杯的葡萄酒里，然后塞进嘴里。他试图说话，但喷出来的全是面包屑。 %SPEECH_ON%见到你真好，佣兵。我这儿有群哥布林在 %origin% 的 %direction%，我要你去清除它们。本来我想派我的骑士去，但他们嘛……稍微重要一点，没那么‘好用’。我相信你懂的。 %SPEECH_OFF%他设法把剩下的面包塞进那张丑陋的大嘴里。有一瞬间，他被噎住了，就在那一瞬间，你甚至考虑过关上门，让这一切在这里终结。不幸的是，他痛苦的抽搐引起了卫兵的注意，卫兵冲进来在他胸口猛地一砸，把那块致命的面包全砸了出来，场面极其恶心，差点就酿成了一场‘刺杀’事故。 | 当你找到 %employer% 时，他正在打发几个骑士，一边把他们骂出门外。然而，看到你时，他似乎暂时平复了心情。%SPEECH_ON%佣兵！见到你真是太好了！你比那些所谓的‘人’强多了。%SPEECH_OFF%他坐了下来，给自己倒了杯酒。抿了一口后，他盯着酒杯看了一会儿，然后一饮而尽。%SPEECH_ON%我那些‘忠诚’的封臣拒绝去对付那些在 %origin% 的 %direction% 扎营的哥布林。他们满嘴都是什么伏击、毒药……%SPEECH_OFF%他的口齿愈发含糊不清。%SPEECH_ON%呃……-嗝-，这些你都懂的，对吧？接下来我要说什么你也懂的，对吧？-嗝-，当然懂，给我拿杯酒来！哈，开玩笑的。去把那些哥布林都杀了，行不行？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{杀哥布林这活儿可不便宜。 | 我相信你会为此付出丰厚的报酬。 | 我们谈谈价钱吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不划算。 | 我们还有别的事儿做。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Ambush",
			Title = "接近营地时…",
			Text = "[img]gfx/ui/events/event_48.png[/img]{你走进地精营地，发现里面空无一人。但你心里清楚——你明白自己刚踏入了一个圈套。就在这时，该死的哥布林从四面八方蜂拥而出。你发出一声能调动的最响亮的战吼，命令兄弟们准备战斗！ | 哥布林骗了你！他们撤离了营地，然后绕道包抄回来，将你们团团围住。好好部署一下兄弟们，因为这次包围没那么容易突围。 | 你早该想到的：你直接踩进了哥布林的陷阱里！他们把士兵埋伏在四周，而你的队伍却像一群待宰的绵羊一样站在那里发愣！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "小心！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Betrayal1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{刚解决掉最后一只哥布林，你突然迎面撞上了一群全副武装的家伙。他们的队长走上前来，拇指勾在别着佩剑的腰带上。%SPEECH_ON%呵，呵，你真是蠢到家了。%employer% 的记性可没那么差——他还没忘你上次背叛他的事。这就算是一点点……礼尚往来吧。%SPEECH_OFF%话音刚落，那队长身后的所有人一拥而上。抄家伙！这是埋伏！ | 你正忙着把哥布林的血从剑上擦干净，突然看到一群人朝你走来。他们举着 %employer% 的旗帜，而且正在拔刀。就在他们开始冲锋的那一刻，你才意识到自己中了圈套。这群混蛋！先让你去跟哥布林拼命，他们坐收渔利！跟他们拼了！ | 一个不知从哪儿冒出来的男人向你打招呼。他全副武装，盔甲精良，看起来心情不错，走近时还带着一丝傻笑。%SPEECH_ON%晚上好啊，佣兵们。那些绿皮家伙干得不错，是吧？%SPEECH_OFF%他停顿了一下，笑容逐渐褪去。%SPEECH_ON%%employer% 向你问好。%SPEECH_OFF%就在这时，一群男人从道路两旁蜂拥而出。是埋伏！那个该死的贵族背叛了你！ | 一群穿着 %faction% 颜色制服的武装人员跟在了你们后面，队伍散开，死死盯着你的佣兵团。他们的首领打量着你。%SPEECH_ON%等我把这把剑从你冰凉的尸体手里撬出来时，我会很享受的。%SPEECH_OFF%你耸耸肩，问他为什么要设这个局。%SPEECH_ON%%employer% 从不宽恕那些两面三刀背叛他或他家族的人。这些就足够你死个明白了吧？反正我也用不着跟死人多废话。%SPEECH_OFF%那就拔剑吧！因为这是埋伏！ | 你的手下搜遍了哥布林营地，连个鬼影都没找到。突然，一群穿着 %faction% 颜色制服的人出现在你们身后，领头的带着明显的恶意走上前，手里拿着一块绣着 %employer% 徽记的布。%SPEECH_ON%真遗憾，那些绿皮没能干掉你们。如果你在想我为什么在这儿，那是为了替 %employer% 收一笔债。你承诺任务会圆满完成，但你没能兑现承诺。现在，你得死。%SPEECH_OFF%你拔出佩剑，用剑尖直指那名队长。%SPEECH_ON%看起来，%employer% 又要被迫面对一个无法兑现的承诺了。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationBetrayal);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).getFlags().set("Betrayed", false);
						local tile = this.World.State.getPlayer().getTile();
						local p = this.Const.Tactical.CombatInfo.getClone();
						p.TerrainTemplate = this.Const.World.TerrainTacticalTemplate[tile.TacticalType];
						p.Tile = tile;
						p.CombatID = "Betrayal";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 140 * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Betrayal2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{你用裤腿擦了擦剑上的血，迅速归鞘。那些伏击者已经全部倒地，尸体以各种扭曲怪异的姿势躺着。%randombrother% 走过来问下一步怎么办。看来，跟 %faction% 这帮人是再也别想愉快地打交道了。 | 你一脚把一个伏击者的尸体从剑尖上踢开。看来，以后跟 %faction% 现在起不会是最友善的人了。 也许下一次，当我同意为这些人做点什么的时候，我真的做到了。 | 好吧，不管怎样，这次至少学到了一点：千万别接那种完不成的任务。这片土地上的人，可不太待见那些没能兑现承诺的家伙…… | 是，你背叛了 %faction%，但这没什么好纠结的。是他们先背叛你的！这才是眼下最重要的！而且往后的日子，你最好对所有挂着他们旗帜的人保持高度警惕。 | 看样子，根据你脚边这些死去的士兵判断，%employer% 对你已经彻底不满了。如果你非要猜个原因，大概是因为你过去的某些作为吧——是两面三刀？任务失败？顶撞冒犯？还是睡了某个贵族的女儿？事情太多，你都懒得去细想。眼下重要的是，你们之间的裂痕已经无法轻易弥合。接下来的一段时间，你最好提防着点 %faction% 的人。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "报酬算是全泡汤了……",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SearchingTheCamp",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_83.png[/img]{干掉了最后一只哥布林后，你顺手搜查了一下它们的营地。这帮家伙看起来挺会享受——到处堆满了小玩意儿和乐器，不过这些东西显然也能当武器使。只需要把它们往营地中央那个巨大的毒药锅里蘸一下就行。你一脚把毒药锅踢翻，然后命令手下兄弟们收拾好，准备回去向雇主 %employer% 复命。 | 这帮哥布林打得既顽强又狡猾，但你们还是把它们全干掉了。点燃了敌营后，你下令让兄弟们准备启程，回去向 %employer% 报喜。 | 虽然这帮矮个子绿皮拼死抵抗，但你们的战斗力更胜一筹。解决了最后一只哥布林后，你环顾了一下它们那破败的营地。看来它们并非完全孤立无援——现场有迹象表明，在战斗进行时还有其他哥布林逃跑了。也许是家属？还是孩子？管他呢，该回去找雇佣你的 %employer% 了。 | 啊，这真是一场痛快的战斗。%employer% 肯定正等着听这个好消息呢。 | 难怪没人愿意打哥布林，它们的战斗力简直超越了它们的身材极限。可惜了，没能把它们的脑子装进人体里；不过转念一想，也许这种凶猛的野性还是锁在这么小的身体里，对大家来说反而是件好事！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候领工钱了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你走进 %employer% 的房间，把几颗哥布林头颅扔在地上。他瞥了一眼。%SPEECH_ON%哼，这脑袋实际上比书记官描述的要大不少嘛。%SPEECH_OFF%你简单几句汇报了捣毁绿皮营地的情况。这位贵族点了点头，摸着下巴。%SPEECH_ON%干得漂亮。这是你的酬劳，正如约定的那样。%SPEECH_OFF%他递过来一个钱袋，里面装着 %reward_completion% 克朗。 | 当你走进房间时，%employer% 正在用石头砸一只胆小的猫。他看了你一眼，这可怜的小家伙趁机从窗户溜了出去。贵族追着它扔了几块石头，谢天谢地全都没砸中。%SPEECH_ON%见到你真好，佣兵。我的探子已经把你的战绩告诉我了。这是你应得的报酬，如约付清。%SPEECH_OFF%他从桌上推过来一个木箱子，里面装着 %reward_completion% 克朗。 | 你回来时，%employer% 正在剥坚果。他一边嚼着一边含糊不清地说话。%SPEECH_ON%哟，又见到你了。看来你任务很成功，是吧？%SPEECH_OFF%你拎起几颗哥布林头颅，它们被一根带子串在一起，晃来晃去地瞪着房间和彼此。那人举起手。%SPEECH_ON%打住，我可是体面人。快把那玩意儿拿走。%SPEECH_OFF%你耸耸肩，把头颅递给在大厅外等候的 %randombrother%。%employer% 绕过桌子走过来，递给你一个钱袋，里面有 %reward_completion% 克朗。%SPEECH_ON%和约定的一样，你的报酬。干得好，佣兵。%SPEECH_OFF% | 看到你提着地精头颅进来，%employer% 笑了。%SPEECH_ON%天哪，别往里拿那玩意儿。拿去喂狗吧。%SPEECH_OFF%他有点喝多了。你搞不清他是因为任务成功而高兴，还是单纯喝了点麦酒心情好。%SPEECH_ON%你的报酬是——嗝——%reward_completion% 克朗，对吧？%SPEECH_OFF%你正想趁机‘改口’多要点，但外面的一个卫兵探头看了一眼，冲你摇了摇头。唉，算了，看来就是 %reward_completion% 克朗。 | 当你回到 %employer% 那里时，发现有个女人正趴在他腿上。事实上，她正弯着腰，而他的手举在空中。他们俩都盯着你看，动作停了下来，然后那女人迅速钻到了桌子底下，他也赶紧坐直了身子。%SPEECH_ON%佣兵！见到你真是太好了！我想你已经成功干掉那些绿皮了吧，是吧？%SPEECH_OFF%那可怜的女士在桌子底下撞到了头，但你尽量装作没听见，向他汇报了远征的成功。他拍拍手，刚想站起来，又觉得不妥。%SPEECH_ON%那个……如果你不介意的话，你那份 %reward_completion% 克朗的酬劳就在我身后的书架上。%SPEECH_OFF%你去拿钱时，他尴尬地冲你笑了笑。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "摧毁了哥布林营地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isGreenskinInvasion())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Origin, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"location",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.m.Destination.getName()
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.Const.Strings.Direction8[this.m.Origin.getTile().getDirection8To(this.m.Destination.getTile())]
		]);
	}

	function onOriginSet()
	{
		if (this.m.SituationID == 0)
		{
			this.m.SituationID = this.m.Origin.addSituation(this.new("scripts/entity/world/settlements/situations/greenskins_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}

		if (this.m.Origin != null && !this.m.Origin.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Origin.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			if (this.m.Origin.getOwner().getID() != this.m.Faction)
			{
				return false;
			}

			return true;
		}
		else
		{
			return true;
		}
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

