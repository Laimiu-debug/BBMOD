this.destroy_orc_camp_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Dude = null,
		Reward = 0
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.destroy_orc_camp";
		this.m.Name = "摧毁兽人营地。";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		local camp = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getNearestSettlement(this.m.Origin.getTile());
		this.m.Destination = this.WeakTableRef(camp);
		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Payment.Pool = 900 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();
		local r = this.Math.rand(1, 3);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Completion = 1.0;
		}
		else if (r == 3)
		{
			this.m.Payment.Completion = 0.5;
			this.m.Payment.Count = 0.5;
		}

		local maximumHeads = [
			20,
			25,
			30
		];
		this.m.Payment.MaxCount = maximumHeads[this.Math.rand(0, maximumHeads.len() - 1)];
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"摧毁 " + this.Flags.get("DestinationName") + "，位于%origin%的%direction%"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Contract.m.Destination.clearTroops();
				this.Contract.m.Destination.setLastSpawnTimeToNow();

				if (this.Contract.getDifficultyMult() < 1.15 && !this.Contract.m.Destination.getFlags().get("IsEventLocation"))
				{
					this.Contract.m.Destination.getLoot().clear();
				}

				this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.OrcRaiders, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setLootScaleBasedOnResources(115 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setResources(this.Math.min(this.Contract.m.Destination.getResources(), 100 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult()));
				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);
				this.Flags.set("HeadsCollected", 0);

				if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getFlags().get("Betrayed") && this.Math.rand(1, 100) <= 75)
				{
					this.Flags.set("IsBetrayal", true);
				}
				else
				{
					local r = this.Math.rand(1, 100);

					if (r <= 5)
					{
						this.Flags.set("IsSurvivor", true);
					}
					else if (r <= 15 && this.World.Assets.getBusinessReputation() > 800)
					{
						if (this.Contract.getDifficultyMult() >= 0.95)
						{
							this.Flags.set("IsOrcsAgainstOrcs", true);
						}
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsSurvivor") && this.World.getPlayerRoster().getSize() < this.World.Assets.getBrothersMax())
					{
						this.Contract.setScreen("Volunteer1");
						this.World.Contracts.showActiveContract();
						this.Contract.setState("Return");
					}
					else if (this.Flags.get("IsBetrayal"))
					{
						if (this.Flags.get("IsBetrayalDone"))
						{
							this.Contract.setScreen("Betrayal2");
							this.World.Contracts.showActiveContract();
						}
						else
						{
							this.Contract.setScreen("Betrayal1");
							this.World.Contracts.showActiveContract();
						}
					}
					else
					{
						this.Contract.setScreen("SearchingTheCamp");
						this.World.Contracts.showActiveContract();
						this.Contract.setState("Return");
					}
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				if (this.Flags.get("IsOrcsAgainstOrcs"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("OrcsAgainstOrcs");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "OrcAttack";
						p.Music = this.Const.Music.OrcsTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
						p.IsAutoAssigningBases = false;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.OrcRaiders, 150 * this.Contract.getScaledDifficultyMult(), this.Const.Faction.Enemy);
						this.World.Contracts.startScriptedCombat(p, false, true, true);
					}
				}
				else
				{
					local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
					p.CombatID = "OrcAttack";
					p.Music = this.Const.Music.OrcsTracks;
					this.World.Contracts.startScriptedCombat(p, true, true, true);
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Betrayal")
				{
					this.Flags.set("IsBetrayalDone", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Betrayal")
				{
					this.Flags.set("IsBetrayalDone", true);
				}
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_combatID == "OrcAttack" || this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull() && this.World.State.getPlayer().getTile().getDistanceTo(this.Contract.m.Destination.getTile()) <= 1)
				{
					if (_actor.getFaction() == this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getID())
					{
						this.Flags.set("HeadsCollected", this.Flags.get("HeadsCollected") + 1);
					}
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationPerHead);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_61.png[/img]{%employer% 气呼呼地在房间里踱步。%SPEECH_ON%该死。%SPEECH_OFF%他走到窗边往外看。%SPEECH_ON%我最近办了一场比武大会，结果出了点争议。现在我的骑士们谁也不肯为我打仗，除非把这事摆平。%SPEECH_OFF%你问他，难道他想让佣兵去解决贵族之间的纠纷？那人突然大笑起来。%SPEECH_ON%天哪，别开玩笑了，平民。我需要你去处理一群在 %origin% 的 %direction% 扎营的绿皮。它们骚扰这片地区很久了，我想让你礼尚往来。这听起来像是你感兴趣的活儿吗？还是说，我得去找另一个拿钱办事的佣兵？%SPEECH_OFF% | %employer% 把脚搁在桌子上。%SPEECH_ON%佣兵，对绿皮有什么看法吗，佣兵？%SPEECH_OFF% 你摇摇头说没有。那人歪了歪头。%SPEECH_ON%有意思。大多数人都说它们可怕，或者说它们是能一斧头把人劈成两半的凶残野兽。但你……你不一样。我喜欢。怎么样，去 %origin% 的 %direction%，一个当地人称之为 %location% 的地方吗？我们在那儿发现了一大群兽人，需要把它们赶跑。%SPEECH_OFF% | 一只猫在 %employer% 的桌上。他正抚摸着它，猫咪本来还舒服地缩成一团，突然猛地一扭头咬了那人一口，然后从你进来的那扇门窜了出去。%employer% 拍拍身上的灰。%SPEECH_ON%该死的畜生。前一秒还表现得很亲人，下一秒就……%SPEECH_OFF%他吸了一口拇指上冒出来的血。你问他，要不要你改天再来，等他养好伤。%SPEECH_ON%真幽默，佣兵。不，我要你去  %origin% 的 %direction%，去对付一群盘踞在那里的兽人。我们需要它们被消灭、被驱散，随便你喜欢什么词，只要它们‘消失’就行。这活儿你觉得你能替我们干吗？%SPEECH_OFF% | %employer% 边解释他的困境，边把一卷羊皮纸卷起来。%SPEECH_ON%贵族之间的一场纠纷让我手头缺人手。不幸的是，一群绿皮偏偏选在这个时候闯入了这片区域。它们在 %origin% 的 %direction% 扎营了。我总不能一边被这群该死的东西骚扰，一边收拾家务吧，所以我非常希望你对这事儿感兴趣，佣兵…%SPEECH_OFF% | %employer% 上下打量着你。%SPEECH_ON%你看起来挺壮实，能对付绿皮吗？你的人呢？%SPEECH_OFF%你点了点头，假装这事儿比从树上把猫抱下来还轻松。%employer% 笑了。%SPEECH_ON%很好，因为我听说 %origin% 的 %direction% 有一大群绿皮出没。去那儿把它们干掉。很简单，对吧？这肯定配得上你这种……自信的人。%SPEECH_OFF% | %employer% 正在喂他的狗，给它们吃的那些食物，有些农民见了怕是会拼命。他拍掉手上的油腻。%SPEECH_ON%这是我的厨师做的，你信吗？难吃死了，恶心透顶。%SPEECH_OFF%你点了点头，假装能理解在这个人的世界里，把好东西喂狗是多么正常的一件事。%employer% 把手肘撑在桌上。%SPEECH_ON%行了，给我送肉的那些人报告说，绿皮在杀他们的牛。显然，在 %origin% 的 %direction% 有一个兽人营地。如果你感兴趣，我希望你去那儿把它们全杀了。%SPEECH_OFF% | 你发现 %employer% 正在研究一些卷轴。他抬头看了看你，指了指一把椅子。%SPEECH_ON%你能来真是太好了，佣兵。我在这片区域有个绿皮的麻烦——它们在这儿的 %direction% 扎营了。%SPEECH_OFF%他放下其中一卷卷轴。%SPEECH_ON%我可派不出自己的人。骑士们相当……金贵。但你嘛，正好适合干这活。怎么样？%SPEECH_OFF% | 当你走进 %employer% 的办公室时，正好有一群人离开。他们是骑士，剑鞘在衣袍下叮当作响。%employer% 欢迎你进来。%SPEECH_ON%别理他们。他们只是在好奇我上一个雇的人怎么了。%SPEECH_OFF%你挑了挑眉。那人挥挥手不在意。%SPEECH_ON%哦，别跟我装傻，佣兵。你跟我一样清楚这行的规矩，有时候你们这些人会搞砸，而你知道那意味着……%SPEECH_OFF%你没说话，但停顿了一下后，还是点了点头。%SPEECH_ON%很好，我就知道你明白。如果你想问详情，我在 %origin% 的 %direction% 发现了一群兽人。它们扎了营，我猜自从我上次……呃，派了些人去那儿之后，他们就没挪过窝。你有兴趣帮我把它们全杀了吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{杀兽人这活儿可不便宜。 | 我相信你会为此付出丰厚的报酬。 | 我们谈谈价钱吧。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{这不划算。 | 我们还有别的事儿做。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "OrcsAgainstOrcs",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_49.png[/img]{你刚下令让手下进攻，结果发现这群兽人居然在自相残杀？这些绿皮明显分成了两派，正用把对方劈成两半的方式来解决分歧。这暴力场面简直惨不忍睹。当你正盘算着要不要坐山观虎斗时，两个兽人打着打着就朝你冲过来了，转眼间所有兽人的目光都集中到了你身上。唉，这下想跑也跑不掉了……抄家伙，干吧！ | 你命令 %companyname% 发起冲锋，以为能打兽人一个措手不及。结果发现它们早就全副武装了！而且……还在互相残杀？\n\n只见一个兽人把另一个劈成了两半，另一个又把同伴的脑袋砸了个稀烂。看来这是某个氏族内部的冲突。真倒霉，早知道就多等一会儿，让它们先杀个片甲不留，现在可好，直接演变成了大混战！ | 兽人们正在大打出手！这是一场绿皮之间的群殴，结果你莫名其妙地也被卷了进去。兽人打兽人，再打人类，这叫什么事儿啊！让弟兄们靠紧些，不然真得交代在这鬼地方了。 | 天哪，兽人的数量比你想象的还要多！幸运的是，它们正在互相残杀。你搞不清这是不是不同部落之间的火拼，还是绿皮们特有的酒后斗殴。但不管怎么说，你现在已经被卷入其中了！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Betrayal1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{刚解决掉最后一只兽人，你突然迎面撞上了一群全副武装的家伙。他们的队长走上前来，拇指勾在别着佩剑的腰带上。%SPEECH_ON%呵，呵，你真是蠢到家了。%employer% 的记性可没那么差——他还没忘你们上次背叛 %faction% 的事儿。这就算是一点点……礼尚往来吧。%SPEECH_OFF%话音刚落，那队长身后的所有人一拥而上。抄家伙！这是埋伏！ | 你正忙着把兽人的血从剑上擦干净，突然看到一群人朝你走来。他们举着 %faction% 的旗帜，而且正在拔刀。就在他们开始冲锋的那一刻，你才意识到自己中了圈套。这群混蛋！先让你去跟兽人拼命，他们坐收渔利！跟他们拼了！ | 一个不知从哪儿冒出来的男人向你打招呼。他全副武装，盔甲精良，看起来心情不错，走近时还带着一丝傻笑。%SPEECH_ON%晚上好啊，佣兵们。那些绿皮家伙干得不错，是吧？%SPEECH_OFF%他停顿了一下，笑容逐渐褪去。%SPEECH_ON%%employer% 向你问好。%SPEECH_OFF%就在这时，一群男人从道路两旁蜂拥而出。是埋伏！那个该死的贵族背叛了你！ |战斗刚结束，一群穿着 %faction% 颜色制服的武装人员跟在了你们后面，队伍散开，死死盯着你的佣兵团。他们的首领打量着你。%SPEECH_ON%等我把这把剑从你冰凉的尸体手里撬出来时，我会很享受的。%SPEECH_OFF%你耸耸肩，问他为什么要设这个局。%SPEECH_ON%%employer% 从不宽恕那些两面三刀背叛他或他家族的人。这些就足够你死个明白了吧？反正我也用不着跟死人多废话。%SPEECH_OFF%那就拔剑吧！因为这是埋伏！ | 你的手下搜遍了兽人营地，连个鬼影都没找到。突然，几个陌生人出现在你们身后，领头的带着明显的恶意走上前，手里还拿着一块绣着 %employer%你的手下搜遍了兽人营地，连个鬼影都没找到。突然，几个陌生人出现在你们身后，领头的带着明显的恶意走上前，手里还拿着一块绣着 。%SPEECH_ON%真遗憾，那些兽人没能干掉你们。如果你在想我为什么在这儿，那是为了替 %faction% 收一笔债。你承诺任务会圆满完成，但你没能兑现承诺。现在，你得死。%SPEECH_OFF%你拔出佩剑，用剑尖直指那名队长。%SPEECH_ON%看起来，%faction% 又要被迫面对一个无法兑现的承诺了。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationBetrayal);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).getFlags().set("Betrayed", false);
						local tile = this.World.State.getPlayer().getTile();
						local p = this.Const.Tactical.CombatInfo.getClone();
						p.TerrainTemplate = this.Const.World.TerrainTacticalTemplate[tile.TacticalType];
						p.Tile = tile;
						p.CombatID = "Betrayal";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 140 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.getFaction());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Betrayal2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{你用裤腿擦了擦剑上的血，迅速归鞘。那些伏击者已经全部倒地，尸体以各种扭曲怪异的姿势躺着。%randombrother% 走过来问下一步怎么办。看来，跟 %faction% 这帮人是再也别想愉快地打交道了。 | 你一脚把一个伏击者的尸体从剑尖上踢开。看来，以后跟 %faction% 现在起不会是最友善的人了。 也许下一次，当我同意为这些人做点什么的时候，我真的做到了。 | 好吧，不管怎样，这次至少学到了一点：千万别接那种完不成的任务。这片土地上的人，可不太待见那些没能兑现承诺的家伙…… | 是，你背叛了 %faction%，但这没什么好纠结的。是他们先背叛你的！这才是眼下最重要的！而且往后的日子，你最好对所有挂着他们旗帜的人保持高度警惕。 | 看样子，根据你脚边这些死去的士兵判断，%employer% 对你已经彻底不满了。如果你非要猜个原因，大概是因为你过去的某些作为吧——是两面三刀？任务失败？顶撞冒犯？还是睡了某个贵族的女儿？事情太多，你都懒得去细想。眼下重要的是，你们之间的裂痕已经无法轻易弥合。接下来的一段时间，你最好提防着点 %faction% 的人。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "报酬算是全泡汤了……",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SearchingTheCamp",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_32.png[/img]{战斗结束，你搜查了兽人的营地。在废墟中，你发现了一些厚重的盔甲和人类的武器，但都已经损坏得无法使用。遗憾的是，你并没有找到这些东西原本的主人。 | 干掉兽人后，你环顾了一下他们的营地。这里简直是个垃圾堆，字面意思，到处都是屎。这帮该死的家伙根本不懂什么叫卫生。%randombrother% 蹒跚着走过来，正用帐篷柱子刮掉靴子上的脏东西。%SPEECH_ON%头儿，咱们是继续找，还是走人……？%SPEECH_OFF%你觉得自己已经看得够多，闻得够多了。 | 这个兽人营地简直就是一片充满各种堕落行径的荒原。你能闻到他们交配和排泄的臭味。难怪他们这么好战，因为他们根本不懂文明人所理解的生活是什么样。 | 兽人营地已被摧毁，但你还是花点时间在废墟里翻找了一下。在一堆灰烬般的篝火坑里，你发现了几具人类的尸体。从他们的武器来看，这些人似乎和你一样，也是佣兵。真可惜……他们的装备现在都被烧毁了，一点用处也没有。 | 你手下的几个佣兵在兽人营地的废墟里转悠。他们翻找着残骸，翻出来这个那个没用的小玩意儿。%randombrother% 插回了他那把沾满血的剑。%SPEECH_ON%这儿啥也没有，头儿。%SPEECH_OFF%你点了点头，下令让兄弟们准备启程返回 %employer% 那里。 | 战斗结束后，你在营地里晃悠，想找点有用的东西。虽然没找到能带走的财物，但你发现了一堆死去的骑士。他们脸色惨白，爬满了蠕虫和蛆虫，看样子已经死在这里很久了。谁也不知道兽人之前对他们做了什么。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候领工钱了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Volunteer1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_32.png[/img]{战斗虽然结束了，但你还能听到尖叫声。你让 %randombrother% 闭嘴，因为他老是喜欢莫名其妙地低吼或乱叫，但他摇摇头，说不是他。就在这时，一个戴着镣铐的男人从一堆曾经是兽人营地的灰烬里站了起来。%SPEECH_ON%晚上好，各位先生！我觉得你们已经解放我了。%SPEECH_OFF%他踉踉跄跄地走过来，身后扬起一股幽灵般的、盘旋的烟尘。%SPEECH_ON%我非常感激，显然，我想回报你们的恩情。你们是佣兵，对吧？如果是的话，我想为你们效力。%SPEECH_OFF%他从地上捡起一把刀，在手里转了几圈，挥舞得像是从娘胎里就开始练一样。这个提议刚刚变得更加诱人了…… | 正在擦拭武器时，一个声音从一顶倒塌的兽人帐篷里传了出来。%SPEECH_ON%好吧，先生们，你们做到了！%SPEECH_OFF%只见一个咧着嘴笑的男人钻了出来。%SPEECH_ON%你们救了我！我想通过伸出援手来报答你们的服务！%SPEECH_OFF%他伸出手，停顿了一下，又缩了回去。%SPEECH_ON%我是说为你们战斗！我想为你们战斗，先生！如果你们能做成这种事，那我肯定能跟对人，对吧？%SPEECH_OFF%嗯，一个有趣的提议。你扔给他一件武器，他轻松接住。他把刀柄转来转去，双手翻飞，最后试图把它插进一个根本不存在的剑鞘里。%SPEECH_ON%我叫 %dude_name%。%SPEECH_OFF% | 一个穿着破烂凹陷盔甲的男人正朝你狂奔而来。他的双手被反绑在身后。%SPEECH_ON%你们做到了！真不敢相信！抱歉，让我解释一下我的失态。一天前，当我们试图攻打营地时，我被兽人抓住了。我想他们正准备把我串在烤叉上烤了，结果你们就出现了。我一找到机会就逃了出来，但现在我觉得，跟着你和你的团队可能更有前途。%SPEECH_OFF%你让那男人直说重点。他照做了。%SPEECH_ON%先生，我想为你们战斗。我有经验——在领主的军队干过，当过佣兵，还有……嗯，别的事儿。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "欢迎加入我们！",
					function getResult()
					{
						this.World.getPlayerRoster().add(this.Contract.m.Dude);
						this.World.getTemporaryRoster().clear();
						this.Contract.m.Dude.onHired();
						this.Contract.m.Dude = null;
						return 0;
					}

				},
				{
					Text = "你得到别处去碰碰运气了。",
					function getResult()
					{
						this.World.getTemporaryRoster().clear();
						this.Contract.m.Dude = null;
						return 0;
					}

				}
			],
			function start()
			{
				local roster = this.World.getTemporaryRoster();
				this.Contract.m.Dude = roster.create("scripts/entity/tactical/player");
				this.Contract.m.Dude.setStartValuesEx(this.Const.CharacterVeteranBackgrounds);

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand).removeSelf();
				}

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Offhand) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Offhand).removeSelf();
				}

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Head) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Head).removeSelf();
				}

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Body) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Body).setArmor(this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Body).getArmor() * 0.33);
				}

				if (this.Contract.m.Dude.getTitle() == "")
				{
					this.Contract.m.Dude.setTitle("幸存者");
				}

				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回到 %employer% 那里汇报情况，他却挥手让你走开。%SPEECH_ON%拜托，佣兵。我早就知道了。你以为我在这一带没安插眼线吗？%SPEECH_OFF%他指了指桌上角落的一个钱袋。你拿过钱，那人又甩了甩手。%SPEECH_ON%这谢礼应该够了，现在请从我眼前消失。%SPEECH_OFF% | 你给 %employer% 看了一颗兽人头颅。他盯着头颅，又盯着你。他看着它，然后看着你。%SPEECH_ON%有意思。所以，我是不是该理解为你完成了我交代的任务？%SPEECH_OFF%你点了点头。那人笑了，递过来一个木箱子，里面装着 %reward% 克朗。%SPEECH_ON%我就知道可以信任你，佣兵。%SPEECH_OFF% | 你回来时，%employer% 死死地盯着你。%SPEECH_ON%我听说你的事了。%SPEECH_OFF%他语气古怪，让你不由得迅速回想过去一周干过的破事。难道是那个……那个贵族女士？不，不可能。%SPEECH_ON%兽人死光了。干得好，佣兵。%SPEECH_OFF%他塞给你一个装着 %reward% 克朗的钱袋, 你心里也顿时松了一口气。 | 你走进 %employer% 的房间，一屁股坐下，还给自己倒了杯葡萄酒。那贵族似乎用目光在你身上烧了个洞。%SPEECH_ON%我敢说，这可是个斩首示众的罪过，要是我心情好点，就判你个绞刑，要是不好，那就是火刑。%SPEECH_OFF% 你喝完酒，猛地把一颗兽人头颅砸在桌上。酒杯被震得摇晃倒地。%employer% 吓得往后一仰，随即镇定下来。%SPEECH_ON%啊，对，这酒给你喝值了。反正也不是我最好的酒。我的卫兵 %randomname% 正在外面等你。他会给你我们说好的 %reward% 克朗。%SPEECH_OFF% | 你举起一颗兽人头颅给 %employer% 看。那张绿色的大嘴张开着，舌头耷拉在獠牙之间。%employer% 点点头，弹了弹手指。%SPEECH_ON%行了，行了，别毁了我的清梦，快拿走。%SPEECH_OFF% 你照做了。那人摇摇头。%SPEECH_ON%最近我怎么能睡得着觉，你们老是搬弄这种东西？算了，你的 %reward% 克朗已经在我卫兵那儿等着你了。谢了，佣兵。%SPEECH_OFF% | 你来到 %employer% 的房间，发现他正在看卷轴上的一幅画。他盯着你，纸张的边缘都折了回去。%SPEECH_ON%我女儿觉得自己是个艺术家，你信吗？%SPEECH_OFF%他把卷轴给你看。那上面画着一个男人，画得还挺像，但怎么看怎么像 %employer% 本人。画中人正面对着一个刽子手。%employer% 笑了。%SPEECH_ON%蠢丫头。%SPEECH_OFF% 他把卷轴揉成一团扔到一边。%SPEECH_ON%行了，我的探子已经告诉我你的战绩了。这是说好的报酬。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Reward);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "摧毁了兽人的营地");
						this.World.Contracts.finishActiveContract();

						if (this.World.FactionManager.isGreenskinInvasion())
						{
							this.World.FactionManager.addGreaterEvilStrength(this.Const.Factions.GreaterEvilStrengthOnCommonContract);
						}

						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() + this.Flags.get("HeadsCollected") * this.Contract.m.Payment.getPerCount();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Origin, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"location",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.m.Destination.getName()
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.Const.Strings.Direction8[this.m.Origin.getTile().getDirection8To(this.m.Destination.getTile())]
		]);
		_vars.push([
			"dude_name",
			this.m.Dude == null ? "" : this.m.Dude.getNameOnly()
		]);
		_vars.push([
			"reward",
			this.m.Reward
		]);
	}

	function onOriginSet()
	{
		if (this.m.SituationID == 0)
		{
			this.m.SituationID = this.m.Origin.addSituation(this.new("scripts/entity/world/settlements/situations/greenskins_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}

		if (this.m.Origin != null && !this.m.Origin.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Origin.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			if (this.m.Origin.getOwner().getID() != this.m.Faction)
			{
				return false;
			}

			return true;
		}
		else
		{
			return true;
		}
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

