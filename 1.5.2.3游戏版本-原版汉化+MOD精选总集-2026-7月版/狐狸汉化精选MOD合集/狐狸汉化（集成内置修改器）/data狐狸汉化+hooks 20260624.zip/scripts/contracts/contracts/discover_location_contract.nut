this.discover_location_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Location = null,
		LastHelpTime = 0.0
	},
	function create()
	{
		this.contract.create();
		this.m.DifficultyMult = this.Math.rand(75, 105) * 0.01;
		this.m.Type = "contract.discover_location";
		this.m.Name = "寻找营地";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		this.contract.start();
	}

	function setup()
	{
		local locations = clone this.World.FactionManager.getFactionOfType(this.Const.FactionType.Undead).getSettlements();
		locations.extend(this.World.FactionManager.getFactionOfType(this.Const.FactionType.Zombies).getSettlements());
		local lowestDistance = 9000;
		local best;
		local myTile = this.m.Home.getTile();

		foreach( b in locations )
		{
			if (b.isLocationType(this.Const.World.LocationType.Unique))
			{
				continue;
			}

			if (b.isDiscovered())
			{
				continue;
			}

			local region = this.World.State.getRegion(b.getTile().Region);

			if (!region.Center.IsDiscovered)
			{
				continue;
			}

			if (region.Discovered < 0.25)
			{
				this.World.State.updateRegionDiscovery(region);
			}

			if (region.Discovered < 0.25)
			{
				continue;
			}

			local d = myTile.getDistanceTo(b.getTile());

			if (d > 20)
			{
				continue;
			}

			if (d + this.Math.rand(0, 5) < lowestDistance)
			{
				lowestDistance = d;
				best = b;
			}
		}

		if (best == null)
		{
			this.m.IsValid = false;
			return;
		}

		this.m.Location = this.WeakTableRef(best);
		this.m.Flags.set("Region", this.World.State.getTileRegion(this.m.Location.getTile()).Name);
		this.m.Flags.set("Location", this.m.Location.getName());
		this.m.DifficultyMult = this.Math.rand(70, 85) * 0.01;
		this.m.Payment.Pool = this.Math.max(300, 100 + (this.World.Assets.isExplorationMode() ? 100 : 0) + lowestDistance * 15.0 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentLightMult());

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.m.Flags.set("Bribe", this.beautifyNumber(this.m.Payment.Pool * (this.Math.rand(110, 150) * 0.01)));
		this.m.Flags.set("HintBribe", this.beautifyNumber(this.m.Payment.Pool * 0.1));
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"找到 %direction% %region% 区域附近 %distance% 名叫 %location% 的营地。"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 15)
				{
					this.Flags.set("IsAnotherParty", true);
					this.Flags.set("IsShowingAnotherParty", true);
				}

				this.Contract.m.LastHelpTime = this.Time.getVirtualTimeF() + this.Math.rand(10, 40);
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"在 %direction% 的 %region% 区域寻找一个叫做 %location% 的营地"
				];

				if (this.Contract.m.Location != null && !this.Contract.m.Location.isNull())
				{
					this.Contract.m.Location.getSprite("selection").Visible = true;
				}
			}

			function update()
			{
				if (this.Flags.get("IsShowingAnotherParty"))
				{
					this.Flags.set("IsShowingAnotherParty", false);
					this.Contract.setScreen("AnotherParty1");
					this.World.Contracts.showActiveContract();
				}

				if (this.TempFlags.get("IsDialogTriggered"))
				{
					return;
				}

				if (this.Contract.m.Location.isDiscovered())
				{
					if (this.Flags.get("IsTrap"))
					{
						this.TempFlags.set("IsDialogTriggered", true);
						this.Contract.setScreen("Trap");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setScreen("FoundIt");
						this.World.Contracts.showActiveContract();
					}
				}
				else
				{
					local parties = this.World.getAllEntitiesAtPos(this.World.State.getPlayer().getPos(), 400.0);

					foreach( party in parties )
					{
						if (!party.isAlliedWithPlayer)
						{
							return;
						}
					}

					if (this.Time.getVirtualTimeF() >= this.Contract.m.LastHelpTime + 70.0)
					{
						this.Contract.m.LastHelpTime = this.Time.getVirtualTimeF() + this.Math.rand(0, 30);
						local r = this.Math.rand(1, 100);

						if (r <= 50)
						{
							this.Contract.setScreen("SurprisingHelpAltruists");
						}
						else
						{
							this.Contract.setScreen("SurprisingHelpOpportunists1");
						}

						this.World.Contracts.showActiveContract();
					}
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "DiscoverLocation")
				{
					this.Contract.setState("Return");
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "DiscoverLocation")
				{
					this.Contract.setState("Return");
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];

				if (this.Contract.m.Location != null && !this.Contract.m.Location.isNull())
				{
					this.Contract.m.Location.getSprite("selection").Visible = false;
				}

				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					if (this.Flags.get("IsAnotherParty"))
					{
						this.Contract.setScreen("AnotherParty2");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_45.png[/img]{%employer% 正盯着一张画得歪歪扭扭的地图，然后抬头看向你，仿佛你就是这张地图的制作者。%SPEECH_ON%听着，佣兵，这任务听起来可能有点怪，但你看起来是个头脑清醒的家伙。看到这块黑色区域了吗？你愿意去那边探探路，找找 %location% 在哪儿吗？它大概就在 %region% 这一带。%SPEECH_OFF% | 你走进 %employer% 的房间，他直接把一张地图塞到你面前。%SPEECH_ON%{佣兵！该去探险了！看到这个未探明的区域了吗？就在这儿 %direction% 的 %region% 地区，我需要你去那里寻找一个 %location% 的地方，接不接？ | 好吧，这事儿可能听起来有点离谱，但我需要找到并标记一个叫 %location% 的地方。关于这个地点，我们的地图信息不全，至少我认为它就在 %direction% 的 %region% 地区。去把它找出来，带着坐标回来，我会给你一笔适当的报酬。 | 这世上还有不少地方是人类尚未踏足、未绘入地图的。我要找的是 %location%，大概就在这儿的 %direction%，靠近 %region% 的区域。关于它的信息我只知道这么多，但我确定它确实存在。所以，去给我把它找出来，报酬少不了你的。 | 我要找个地方，佣兵。它位于这儿的 %direction% 的 %region% 地区。普通人称它为 %location%，但不管它是个什么东西，我必须知道它的确切位置，明白吗？把它找出来，你会得到丰厚的报酬。 | 我现在既需要士兵又需要探险家，佣兵，我觉得你正好能一人分饰两角。别急着说我小气，不肯分别雇两个人。咱们明说吧，只要你帮我办成这事，有的是克朗让你赚。什么事儿？嗯……我知道有个地方叫  %location%，但除了它大概在这儿 %direction% 的 %region% 地区之外，我也不知道具体在哪儿。去把它找出来，把它画在地图上，士兵和探险家的酬劳我都会付给你！}%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{报酬是多少？ | 只要价钱合适，我们就把它找出来。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{没兴趣。 | 我们暂时不往那边去。 | 这不是我们想接的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "FoundIt",
			Title = "在%location%。",
			Text = "[img]gfx/ui/events/event_57.png[/img]{通过望远镜，你一眼就瞥见了 %location%，并顺手在地图上做了标记。轻松搞定。是时候回去找 %employer% 交差了。 | 嗯，既然 %location% 比你预想的更容易找到，那现在就该回去找 %employer% 交差了。当你把它标记在地图上时，你停顿了一下，轻笑并摇了摇头。真是走运。 | %location% 映入眼帘，你立刻尽自己所能将其最生动地重现于地图之上。%randombrother%问这就是全部要做的事吗。你点了点头。不管过程艰难还是轻松，%employer% 都会付给你报酬。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候回去了。",
					function getResult()
					{
						this.Contract.setState("Return");
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Trap",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_07.png[/img]%location% 已经被发现——还有 %companyname% 也同样被发现了。那个号称‘无私’的、给你指路的人正站在那里，只不过现在他身边多了一群强壮且面目不善的手下。%SPEECH_ON%{嘿，看起来你总算能听懂人话了。当告诉一个白痴在哪儿碰头时，设下埋伏简直轻而易举。好了，把他们全杀了！ | 嘿，佣兵。真没想到会在这里见到你。哦等等，不对，我早料到了。把他们全杀了！ | 该死，你可真够墨迹的！怎么，连怎么走进自己坟墓这种简单的指令都听不懂吗？愚蠢的佣兵，而且蠢得令人厌烦。好了，让我们快点结束这一切吧。把他们全杀了！}%SPEECH_OFF%",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local tile = this.World.State.getPlayer().getTile();
						local p = this.Const.Tactical.CombatInfo.getClone();
						p.Music = this.Const.Music.BanditTracks;
						p.TerrainTemplate = this.Const.World.TerrainTacticalTemplate[tile.TacticalType];
						p.Tile = tile;
						p.CombatID = "DiscoverLocation";
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.BanditRaiders, 100 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getID());
						this.World.Contracts.startScriptedCombat(p, false, false, false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SurprisingHelpAltruists",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_76.png[/img]{一个男人友好地挥着手走近。你则回应以将剑拔出一半。他笑了。%SPEECH_ON%这么多人对 %location% 感兴趣，所以我不能怪你这么防备。。听着，我会直接告诉你它到底在哪儿。就在这儿往 %direction%，%distance% 的 %terrain% 里。%SPEECH_OFF%他一边大笑着一边离开了。%SPEECH_ON%我不知道我是做了件好事还是坏事，但这正是我喜欢的那种乐趣！%SPEECH_OFF% | 一群看遍世事、疲惫不堪的探险者！他们在路中央停了下来，一半身上沾着泥，一半盖着树叶，无意中形成了很好的伪装。其中一人揉着额头，仔细打量着你，随后咧嘴笑了。%SPEECH_ON%呃，我一眼就能认出你是个探索者。你在找 %location%，对吧？那你可真是走运了，我们正从那儿过来！来，把你的地图给我，我指给你看具体位置。你看，从我们现在的地方往 %direction% %distance% %terrain% 里就是。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "非常感谢。",
					function getResult()
					{
						if (this.Math.rand(1, 100) <= 20 && this.Contract.getDifficultyMult() > 0.95)
						{
							this.Flags.set("IsTrap", true);
						}

						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SurprisingHelpOpportunists1",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_76.png[/img]{这个陌生人孤身一人，与你们保持着距离，一只脚踩在路上，另一只脚则慢慢向逃跑的方向挪动。%SPEECH_ON%嘿，那边的！%SPEECH_OFF%他扫视了一眼你的人马，缓缓地笑了，仿佛能感觉到你们的迷茫。%SPEECH_ON%你们在找 %location% 吗？嗯，是啊。那这样吧，给我 %hint_bribe% 克朗，我就告诉你它到底在哪儿！要是敢拔剑追我，我保证比你眨眼消失得还快！%SPEECH_OFF% | 你看着那个陌生人走进了路旁的光亮里，他用手遮着眼睛，好让大部分脸庞都隐藏在暗处。%SPEECH_ON%你们看起来就是那种在找东西却不知道去哪儿找的人！ %location% 就是这么难找。好在我知道它在哪儿。更巧的是，只要你们把 %hint_bribe% 克朗给我，你们也能知道。我可是你们见过跑得最快的人，所以别想用你们那些亮闪闪的剑从我这儿硬逼出来。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "行，这是克朗。现在讲吧。",
					function getResult()
					{
						return "SurprisingHelpOpportunists2";
					}

				},
				{
					Text = "不必了，我们自己会找到它的。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "SurprisingHelpOpportunists2",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_76.png[/img]你接受了那人的提议，而他也如约说出了详情。%SPEECH_ON%你看，它就在那儿，当然啦，在我们现在的位置往 %direction% %distance% %terrain% 里。很简单吧。%SPEECH_OFF%他一边走开一边吹着口哨，毫无疑问，这对他来说是一笔非常轻松的外快。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "明白了。",
					function getResult()
					{
						this.World.Assets.addMoney(-this.Flags.get("HintBribe"));
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你失去了 [color=" + this.Const.UI.Color.NegativeEventValue + "]" + this.Flags.get("HintBribe") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "AnotherParty1",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_51.png[/img]{当你和 %companyname% 准备启程时，%randombrother% 说有一个男人想直接和你谈谈。你点了点头，让人把他带过来。那是一个神情忧郁的小个子男人，他声称 %townname% 的‘统治者’对 %location% 感兴趣完全出于贪婪。这当然是显而易见的，但这又有什么问题呢？那人点了点头。%SPEECH_ON%听着，我这边有一些人希望永远把 %location% 隐藏起来。如果你找到了它，嗯，先来找我谈谈。我们会给你一大笔钱。%SPEECH_OFF% | 当 %companyname% 正在准备寻找 %location% 的旅程时，一个男人悄悄地溜到你身边。他递给你一张纸条，然后一言不发地离开了。卷轴上写着：让 %locationC% 安安静静地待在那儿。如果你找到了它，先来找我们。我们用克朗换你的保密。%townnameC% 的统治者不需要知道任何事！ | 一个男人走向了队伍。在他身后，你瞥见了几户贫穷的家庭在观望。你不确定他是不是他们的代言人，但不管怎样，他径直走向你，低声提出了一个建议。%SPEECH_ON%听着，佣兵。如果你出去找到了 %location%，先来找我们。%townname% 的统治者不需要把他们的贪婪和对权力的渴望带到那个地方。把它留给我们，好吗？我们会给你丰厚的报酬。%SPEECH_OFF%在你来得及说一句话之前，他已经挺直身子继续往前走了。当你再次回头看时，路上那些家庭已经不见了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我会考虑的。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "AnotherParty2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_51.png[/img]{当你前往 %townname% 时，一个陌生人走上了道路。他是你之前交谈过的那个人，但这次他手里提着一个袋子。%SPEECH_ON%{你没有理由告诉这个城镇的统治者 %location% 在哪里。把它的秘密留给我们吧，你根本不知道我们在那里留下了多少传家宝和历史。为了你的沉默，我们愿意以 %bribe% 克朗作为报酬。求你了，先生，收下吧。 | 听着，佣兵，我知道你只懂一种语言，那就是金钱的语言。把这个袋子收下，作为我们感激的象征——前提是你保持沉默。你不必告诉 %townname% 的统治者 %location% 在哪里。那个地方属于我们的家族。那些卑微的统治者只会用他们的贪婪和对权力的追逐毁了它。那么，你觉得如何？愿意收下吗？里面有 %bribe% 克朗。你要做的就是收下它，然后闭嘴。}%SPEECH_OFF% | 进入 %townname% 时，一张熟悉的面孔拦住了你：就是那个在你最初出发前曾向你打招呼的人。但这次他随身带了一个袋子。%SPEECH_ON%{%bribe%克朗买你的沉默。只要你对这个城镇的统治者只字不提，这笔钱就是你的。他们不需要知道我们之间的交易，他们只需要不知道那个地方在哪里。这对我们至关重要，那里有无法估量的历史，而他们只会去那里掠夺和洗劫。求你了，收下吧。 |  拿去吧，这是 %bribe% 克朗。这就是我们为换取你的沉默准备付出的代价。%townname% 的统治者拿到你的情报后，会用它去掠夺 %location%，因为他们知道我们与那里有着家族关联，而嗯，我们早就失宠了。我们所剩无几了，所以，求你了，让我们保留我们的传家宝和老家吧。}%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我想不行。只有我们的雇主才会知道它在哪里。",
					function getResult()
					{
						return "AnotherParty3";
					}

				},
				{
					Text = "我们已经达成交易了。除了你，不会再有别人会知道它在哪里。",
					function getResult()
					{
						return "AnotherParty4";
					}

				},
				{
					Text = "既然能拿两份钱，为什么只拿一份呢？",
					function getResult()
					{
						return "AnotherParty5";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "AnotherParty3",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_51.png[/img]{在拒绝了那个男人后，他双膝跪地，大声哭喊起来，这让 %companyname% 的队员觉得十分好笑。他悲叹着说，你把他的家族历史交到了一群色鬼和高利贷者手中。而你告诉他，你根本不在乎。 | 告诉那个男人你没有兴趣背叛你最初的雇主后，他彻底失控了。他试图攻击你，挥舞着愤怒的双手扑上来想要抱住你。%randombrother% 将他推开，并用刀刃威胁要杀了他。那人这才退了下去。他坐在路边，头埋在膝盖之间，啜泣着。当你们经过时，队伍里有个人还递给了他一块手帕。 | 你告诉那个男人不行。他开始乞求。你又拒绝了他一次。他又继续乞求。你突然意识到，你曾对一两个女人也做过类似的事情。这让你看起来很糟糕。你把这话说了出来，但他此刻情绪太过激动，根本听不进去。他开始哀嚎，喋喋不休地说着掌管 %townname% 的那些贪婪的混蛋会如何毁了他的家族名声。你告诉他，如果换做是他来掌管这个城镇，或许他所谓的家族名声就能保住了。但这话并没有止住他的眼泪。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "让开。",
					function getResult()
					{
						return "Success1";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "AnotherParty4",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_51.png[/img]{你同意把这个探险细节卖给那个男人。他对整件事欣喜若狂，但 %employer% 可就不这么觉得了。显然，有个小孩目睹了这笔交易，并把你背叛的事报告给了 %townname% 的首领。毫无疑问，你在这里的名声已经受到了不小损害。 | 好吧，一方面，你保全了这个男人所谓的家族家园，使其免遭 %townname% 统治者的破坏。但另一方面，%townname%的统治者也很快得知了你的所作所为。你本该多留意一下，小镇的人口规模虽然不大，但作为散布谣言的绝佳渠道可是绰绰有余的。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "嗯，%employer% 本来就该给我们更多酬劳。",
					function getResult()
					{
						this.World.Assets.addMoney(this.Flags.get("Bribe"));
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "出卖了位置。" + this.Flags.get("Location") + "转交给另外一方");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Flags.get("Bribe") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "AnotherParty5",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]你告诉那个男人，你会对他家族故居的地点保密。在他为此庆祝时，你却转身去告诉了 %employer% 那个 %location% 到底在哪里。能从两方都拿到报酬，这买卖简直太美了。虽然因此遭两边恨确实不怎么爽，但既然雇的是佣兵，他们又能指望什么呢？",
			Image = "",
			List = [],
			Options = [
				{
					Text = "那些人永远不会吸取教训。",
					function getResult()
					{
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.Assets.addMoney(this.Flags.get("Bribe"));
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail * 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail * 1.5, "向竞争对手透露了情报");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Flags.get("Bribe") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_20.png[/img]{%employer% 热情地欢迎你们归来。你递上刚刚绘制好的地图，他仔细地端详着，用手背拍了拍地图上那个标好的地点。%SPEECH_ON%当然，它就在这儿！%SPEECH_OFF%他得意地一笑，并付给了你应得的报酬。 | 你来到 %employer% 的房间，手里拿着一张崭新的地图。他从你手中接过地图，仔细查看。%SPEECH_ON%好吧。我本以为这个地点未免太容易找到了，但既然有约定在先，那就这样吧。%SPEECH_OFF%他递给你一个袋子，里面装的克朗刚好是你应得的数目。 | 你向 %employer% 报告，告诉了他 %location% 的具体位置。他点点头，一边抄录着你地图上的笔记。出于好奇，你问他怎么确定你没有撒谎。那人坐进一把椅子，向后一靠，双手交叉放在肚子上。%SPEECH_ON%我雇了一个跟踪的人，他一直紧跟在你们队伍附近。他比你们先到这里，而你现在的报告只是证实了我已知的情报。希望你不要介意我采取的这些措施。%SPEECH_OFF%你点点头，心想这确实是个明智的举动，然后拿上你的报酬离开了。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "被雇来寻找 " + this.Flags.get("Location"));
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		local distance = this.m.Location != null && !this.m.Location.isNull() ? this.World.State.getPlayer().getTile().getDistanceTo(this.m.Location.getTile()) : 0;
		distance = this.Const.Strings.Distance[this.Math.min(this.Const.Strings.Distance.len() - 1, distance / 30.0 * (this.Const.Strings.Distance.len() - 1))];
		_vars.push([
			"region",
			this.m.Flags.get("Region")
		]);
		_vars.push([
			"location",
			this.m.Flags.get("Location")
		]);
		_vars.push([
			"locationC",
			this.m.Flags.get("Location").toupper()
		]);
		_vars.push([
			"townnameC",
			this.m.Home.getName().toupper()
		]);
		_vars.push([
			"direction",
			this.m.Location == null || this.m.Location.isNull() ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.Location.getTile())]
		]);
		_vars.push([
			"terrain",
			this.m.Location != null && !this.m.Location.isNull() ? this.Const.Strings.Terrain[this.m.Location.getTile().Type] : ""
		]);
		_vars.push([
			"distance",
			distance
		]);
		_vars.push([
			"bribe",
			this.m.Flags.get("Bribe")
		]);
		_vars.push([
			"hint_bribe",
			this.m.Flags.get("HintBribe")
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Location != null && !this.m.Location.isNull())
			{
				this.m.Location.getSprite("selection").Visible = false;
			}

			this.m.Home.getSprite("selection").Visible = false;
		}
	}

	function onIsValid()
	{
		if (this.m.Location == null || this.m.Location.isNull() || !this.m.Location.isAlive() || this.m.Location.isDiscovered())
		{
			return false;
		}

		return true;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Location != null && !this.m.Location.isNull() && _tile.ID == this.m.Location.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Location != null && !this.m.Location.isNull())
		{
			_out.writeU32(this.m.Location.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local location = _in.readU32();

		if (location != 0)
		{
			this.m.Location = this.WeakTableRef(this.World.getEntityByID(location));
		}

		this.contract.onDeserialize(_in);
	}

});

