this.drive_away_bandits_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Dude = null,
		Reward = 0,
		OriginalReward = 0
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.drive_away_bandits";
		this.m.Name = "驱逐强盗";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function generateName()
	{
		local vars = [
			[
				"randomname",
				this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]
			],
			[
				"randomtown",
				this.Const.World.LocationNames.VillageWestern[this.Math.rand(0, this.Const.World.LocationNames.VillageWestern.len() - 1)]
			]
		];
		return this.buildTextFromTemplate(this.Const.Strings.BanditLeaderNames[this.Math.rand(0, this.Const.Strings.BanditLeaderNames.len() - 1)], vars);
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		local banditcamp = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getNearestSettlement(this.m.Home.getTile());
		this.m.Destination = this.WeakTableRef(banditcamp);
		this.m.Flags.set("DestinationName", banditcamp.getName());
		this.m.Flags.set("RobberBaronName", this.generateName());
		this.m.Payment.Pool = 550 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往 %origin% 的 %direction%，驱逐位于 " + this.Flags.get("DestinationName") + " 的强盗"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Contract.m.Destination.clearTroops();
				this.Contract.m.Destination.setLastSpawnTimeToNow();

				if (this.Contract.getDifficultyMult() <= 1.15 && !this.Contract.m.Destination.getFlags().get("IsEventLocation"))
				{
					this.Contract.m.Destination.getLoot().clear();
				}

				this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.BanditDefenders, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setLootScaleBasedOnResources(110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setResources(this.Math.min(this.Contract.m.Destination.getResources(), 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult()));
				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);

				if (this.World.Assets.getBusinessReputation() >= 500 && this.Contract.getDifficultyMult() >= 0.95 && this.Math.rand(1, 100) <= 20)
				{
					this.Flags.set("IsRobberBaronPresent", true);

					if (this.World.Assets.getBusinessReputation() > 600 && this.Math.rand(1, 100) <= 50)
					{
						this.Flags.set("IsBountyHunterPresent", true);
					}
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsRobberBaronDead"))
					{
						this.Contract.setScreen("RobberBaronDead");
						this.World.Contracts.showActiveContract();
					}
					else if (this.Math.rand(1, 100) <= 10)
					{
						this.Contract.setScreen("Survivors1");
						this.World.Contracts.showActiveContract();
					}
					else if (this.Math.rand(1, 100) <= 10 && this.World.getPlayerRoster().getSize() < this.World.Assets.getBrothersMax())
					{
						this.Contract.setScreen("Volunteer1");
						this.World.Contracts.showActiveContract();
					}

					this.Contract.setState("Return");
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				if (this.Flags.get("IsRobberBaronPresent"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("AttackRobberBaron");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						properties.Music = this.Const.Music.BanditTracks;
						properties.Entities.push({
							ID = this.Const.EntityType.BanditLeader,
							Variant = 0,
							Row = 2,
							Script = "scripts/entity/tactical/enemies/bandit_leader",
							Faction = _dest.getFaction(),
							Callback = this.onRobberBaronPlaced.bindenv(this)
						});
						properties.EnemyBanners.push(this.Contract.m.Destination.getBanner());
						this.World.Contracts.startScriptedCombat(properties, true, true, true);
					}
				}
				else
				{
					this.World.Contracts.showCombatDialog();
				}
			}

			function onRobberBaronPlaced( _entity, _tag )
			{
				_entity.getFlags().set("IsRobberBaron", true);
				_entity.setName(this.Flags.get("RobberBaronName"));
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_actor.getFlags().get("IsRobberBaron") == true)
				{
					this.Flags.set("IsRobberBaronDead", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					if (this.Flags.get("IsRobberBaronDead"))
					{
						this.Contract.setScreen("Success2");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}

				if (this.Flags.get("IsRobberBaronDead") && this.Flags.get("IsBountyHunterPresent") && !this.TempFlags.get("IsBountyHunterTriggered") && this.World.Events.getLastBattleTime() + 7.0 < this.Time.getVirtualTimeF() && this.Math.rand(1, 1000) <= 2)
				{
					this.Contract.setScreen("BountyHunters1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsBountyHunterRetreat"))
				{
					this.Contract.setScreen("BountyHunters3");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "BountyHunters")
				{
					this.Flags.set("IsBountyHunterPresent", false);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "BountyHunters")
				{
					this.Flags.set("IsBountyHunterPresent", false);
					this.Flags.set("IsBountyHunterRetreat", true);
					this.Flags.set("IsRobberBaronDead", false);
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_20.png[/img]{%employer% 愤怒地摇着头。%SPEECH_ON%强盗们在这一带横行霸道太久了！我之前派了个小伙子，就是 %randomname% 的儿子，去寻找他们的踪迹。你猜怎么着？最后回来的只有他的脑袋。当然，那帮蠢货强盗还专门派了个人把头送回来。我们抓住了那个送信的并进行了审讯……所以现在我们知道他们的老巢在哪了。%SPEECH_OFF%男人向后靠去，若有所思地摆弄着大拇指。%SPEECH_ON%我手头没有足够的人手，但是我有克朗——要不，我给你一笔钱，你去干掉他们?%SPEECH_OFF% | %employer%给自己倒了一杯酒，盯着杯子看了一会儿，又多倒了一些。他似乎一口气就喝干了，随后打着酒嗝说出了消息。%SPEECH_ON%强盗杀了 %randomname% 和他全家。你能相信吗？我知道你不认识他们，但他们可是这一带有名的好人家。我想你已经能猜到了，我要彻底除掉这些强盗。为了找到他们的营地，我已经折损了一半的人手，现在我准备花掉我一半……呃，一些克朗请你去杀了他们。你有兴趣吗？%SPEECH_OFF% | %employer%正望着窗外，手指沿着酒杯边缘滑动，权衡着自己的想法。%SPEECH_ON%强盗一直在偷走贵重的牲畜。他们趁着夜色摸进来，我说的是那些强盗，他们剪掉牛铃，悄无声息地把牲口牵走。我确信牲畜对你来说不算什么，但一头牛犊、一头母牛或一头公牛？对这一带的某些人来说，那就是一笔财富。\n\n所以前几天，我派了个小伙子顺着动物的足迹追出城去，现在他已经告诉我那些强盗的确切位置了。如你所料，我抽不出人手去对付这帮恶棍，但克朗……我最不缺的就是克朗。如果我把钱放到你手上，你会愿意将剑插入那些强盗的胸膛吗？%SPEECH_OFF% | %employer%叹了口气，仿佛对这些琐事感到厌倦，又仿佛即将开始一段早已重复过多次的谈话。%SPEECH_ON%%randomname%，本地一个有头有脸的人物，说强盗骚扰了他的女儿们。现在他担心下次他们还会干出什么出格的事。幸运的是，那人挺有钱，轻而易举就追踪到了这些强盗。如果我付给你一笔丰厚的报酬，你有多大把握能把你那把大剑捅进一两个强盗的身体里？%SPEECH_OFF% | %employer% 坐在一张大得足以容纳两人的椅子上，手里晃动着一个杯子。%SPEECH_ON%强盗骚扰我们好几周了，就在昨天，他们居然想放火烧了一家酒馆。你能相信吗？谁会烧那种地方？幸好我们及时扑灭了火，但情况正在变得越来越糟。如果他们威胁到了我们宝贵的酒水，接下来还会干什么？幸运的是，我们找到了这帮流窜犯藏身的地方。所以……是的，我看到你的眼神了。任务很简单，佣兵：我们要你去杀光那里的每一个强盗。你愿意和我们合作吗？%SPEECH_OFF% |  当你走进房间时，%employer%喝干了一杯眼镜蛇酒，随手把杯子扔出了窗外。你听到杯子在遥远的地方发出空洞的撞击声。他转向你。%SPEECH_ON%当我走在路上时，强盗包围了我的马车，抢走了我所有的货物！他们留了我的命，这没关系，但他们那副厚颜无耻的样子让我彻夜难眠。我闭眼就能看到他们嘲讽的脸……听到他们的笑声……我相信这是一个警告，是冲着我来的，因为我拒绝给他们‘过路费’。好吧，好吧，现在我也准备付一笔钱了——付给你，佣兵。如果你去宰了那帮恶棍，我会付一笔非常可观的酬金。你觉得怎么样？%SPEECH_OFF% | 当你准备坐下时，%employer%朝你扔过来一个卷轴。就在你接住它的时候，卷轴展开了。你正要阅读，但 %employer% 已经自顾自地开始说起消息了。%SPEECH_ON%%randomtown%的商人们都达成了一致，在我们的强盗问题解决之前，不再光顾 %townname%。事情的起因很简单，我想你也清楚那些强盗的手段，但这帮该死的流窜犯一直在袭扰公路，劫掠车队并杀害商人。\n\n我确切知道他们在哪里，我只需要一个有胆识且渴望荣耀——或者金币！——的人去杀了他们。所以你怎么说，佣兵？开个价，我们可以谈谈。%SPEECH_OFF% | 当你向 %employer%问好时，他正浑身发抖。他愤怒得简直要吐白沫了——或者也许只是喝得太醉了。%SPEECH_ON%这座美好城镇的居民正在挨饿。为什么？因为强盗一直趁着夜色溜进来劫掠粮仓！如果我们抓住他们，他们就会烧毁建筑！现在我们不能坐以待毙了……现在……我要通过杀光他们来保卫自己。%SPEECH_OFF%男人摇晃了一下，仿佛随时会瘫倒在桌子上。他稳住身子继续说道。%SPEECH_ON%当然，我要你去杀了那些流窜犯。你只需要表现出兴趣，然后……——嗝——……开个价。%SPEECH_OFF% | %employer%庄重地看着地面。他展开一个卷轴，给你看一张人像。%SPEECH_ON%这是 %randomname%，一个在逃的强盗，我们前几天抓住了他。他曾经带领一伙流窜犯，日夜袭扰和掠夺我们的城镇。问题是，他不是真正的蛇头，而是九头蛇的一个脑袋。光杀掉一个只会有另一个取而代之。那答案是什么？当然是，把他们全部杀了。这正是我想要你做的，佣兵。你有兴趣吗？%SPEECH_OFF% | 当你正寻找座位时，%employer%转向你。%SPEECH_ON%嘿，佣兵，距离你上次用邪恶残忍之人的鲜血来滋润你的剑刃，过了多久了？%SPEECH_OFF%他收起了嘲讽的语气，你心想现在估计得站着听了。%SPEECH_ON%我们在 %townname% 这里正和当地一些强盗闹了点小纠纷。说是‘当地’，是因为他们的耗子洞离这儿不远。显然，我认为解决这个问题的办法就是雇佣一些像你这样装备精良的人。所以，这能引起你的兴趣吗，佣兵？还是说我需要去找些更强壮的人来干这活？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{你愿意为此出多少钱？ | %townname% 准备出多少钱来买他们的平安？ | 我们来谈谈价钱。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{不感兴趣。 | 我们有更要紧的事要处理。 | 祝你们好运，但我们不会掺和这件事。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "AttackRobberBaron",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_54.png[/img]{当你正在侦查强盗营地时，你注意到一个男人的侧影，当地人曾近乎狂热地向你描述过他：他是 %robberbaron%，一个在这片区域作威作福的著名强盗首领。他身边跟着一群看起来凶神恶煞的手下。\n\n你敢打赌，砍下他的脑袋能多换些克朗。 | 你本没打算见到他，但毫无疑问那人就是他本人：%robberbaron% 就在强盗的营地里。这位臭名昭著的杀手显然正在巡视他麾下的一处犯罪势力。他严谨地在窃贼们中间踱步，指指点点，评论着这样那样东西的‘质量’。\n\n几名护卫寸步不离地跟着他。你估摸着，加上营地里其他的强盗，大概有 %totalenemy% 号人在闲逛。 | 这份合同原本只是要剿灭这些强盗，但现在看来，又加了一个更大的诱饵：的杀手和拦路强盗 %robberbaron% 就在营地里。在护卫的随行下，这位强盗首领似乎正在评估他手下这帮罪犯的实力。\n\n你不禁在心里盘算，%robberbaron% 的人头能值多少钱…… | %robberbaron%。就是他，你确信无疑。透过望远镜窥视，你能清晰地认出那个声名狼藉的强盗头目的身影，他正在强盗营地中走动。虽然他不在你的计划之内，合同里也没提过他，但毫无疑问，如果你能把他的脑袋带回到镇上，绝对能为自己的辛苦多换来一笔额外的赏钱。 | 在侦察强盗营地时，你数了数，约有 %totalenemy% 人在其中走动，你发现了一个完全没料到会出现的身影:%robberbaron%，那个臭名昭著的强盗首领。这家伙和他的护卫们肯定是在视察营地的情况。\n\n真是天赐良机！如果你能砍下他的脑袋带回给雇主，说不定能为自己多捞一笔奖金。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "RobberBaronDead",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{战斗结束，你走到 %robberbaron% 的尸体旁，手起剑落两下便斩下了他的头颅，第一剑切断皮肉，第二剑砍断颈椎。你将一个钩子穿过脖颈处的皮肉，系上绳索，将这颗头颅挂在了自己的腰间。 | 战斗结束后，你迅速在遍地尸首中找到了 %robberbaron% 的尸体。即使面色苍白，他看起来依然凶神恶煞。当你把他的脑袋从身体上摘下时，他看起来依然十分狰狞。虽然你把头颅扔进麻袋后就再也看不见他的脸了，但你猜，他看起来肯定还是很吓人。 | %robberbaron% 此刻正躺在你的脚边，已然毙命。你将尸体翻过身，拉直他的脖颈，好让剑刃有更清晰的着力点。两剑利落的劈砍后，你取下了他的头颅，并迅速塞进了一个粮食袋里。 | 他死了之后，你突然觉得 %robberbaron% 像极了过去认识的很多人。你没让这种似曾相识的恍惚感停留太久：手起剑落几下，你便割下了这人的脑袋，随即扔进了袋子里。 | %robberbaron% 的确进行了顽强的抵抗，甚至在他死后，他的脖子也似乎还在‘负隅顽抗’，那些筋腱和骨骼让你费了好大劲才顺利收取了这份赏金。 | 你收好了 %robberbaron% 的头颅。%randombrother% 在你走过时指着那袋子，说道：%SPEECH_ON%那是什么？难道是 %robberbaron%的……？%SPEECH_OFF%你摇了摇头。%SPEECH_ON%不，那个家伙已经死了。这只是额外奖金而已。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们出发！",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BountyHunters1",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_07.png[/img]{在回去兑现赏金的路上，几个男人突然拦住了你的去路。其中一人指着你身上挂着的 %robberbaron% 的脑袋，说道：%SPEECH_ON%我们是这一带要价最高的赏金猎人，我相信你们截胡了属于我们的生意。把那个脑袋交出来，今晚大家都能安安稳稳地睡个好觉。%SPEECH_OFF%你笑了。%SPEECH_ON%你得想点更有说服力的理由才行。%robberbaron% 的脑袋值不少克朗呢，我的朋友。%SPEECH_OFF%这些所谓赏金猎人的头领立刻回以大笑，随即举起一个沉甸甸的袋子。%SPEECH_ON%这个袋子里装的是 %randomname%，这一带最有名的通缉犯之一。而这个......%SPEECH_OFF%他举起另一个袋子。%SPEECH_ON%是杀掉他的那个人的脑袋。明白了吗？所以把那个脑袋交出来，大家相安无事，各走各路。%SPEECH_OFF% | 一个男人走到路中央，挺直身子，冲你摆出架势。%SPEECH_ON%你好，先生们。我相信你们手里拿着 %robberbaron% 的脑袋。%SPEECH_OFF%你点了点头。那人露出了微笑。%SPEECH_ON%能不能请你们行个方便，把它交给我？%SPEECH_OFF%你笑着摇了摇头。那人收起了笑容，取而代之的是抬手打了个响指。一群武装精良的男人从附近的灌木丛中涌出，伴随着沉重的金属碰撞声踏上大路。他们看起来就像死刑犯在行刑前夜会梦到的索命鬼。他们的首领露出一口夹杂着金牙的狞笑。%SPEECH_ON%我不会再问你第二次。%SPEECH_OFF% | 正在和 %randombrother% 交谈时，一声大喝引起了你的注意。你抬头望向道路前方，发现一群人挡住了去路。他们装备着各式各样的武器和盔甲。他们的头儿走上前，宣称他们是名声显赫的赏金猎人。%SPEECH_ON%我们只想要%robberbaron% 的脑袋。%SPEECH_OFF%你耸了耸肩。%SPEECH_ON%人是我们杀的，赏金也该我们领。现在，给我让开。%SPEECH_OFF%当你向前迈出一步时，赏金猎人们纷纷举起了武器。他们的首领朝你跨进一小步。%SPEECH_ON%现在有个选择摆在眼前，这个选择可能会让很多人送命。我知道这不容易决定，但我劝你最好仔细考虑清楚。%SPEECH_OFF% | 一一声尖锐的哨音引起了你和你手下的注意。你转向路边，看到一群人从灌木丛中走出来。所有人立刻拔出了武器，但那些陌生人并没有再靠近一步。他们的头儿走了过来。胸前斜跨着一串耳朵做成的背带，那是他‘手艺’的总结。%SPEECH_ON%嘿，伙计们。如果你们还没看出来的话，我们是赏金猎人，而且我相信你们手里正拿着属于我们目标的脑袋。%SPEECH_OFF%你拎起 %robberbaron% 的脑袋。%SPEECH_ON%你是说这个？%SPEECH_OFF%头目露出了温和的微笑。%SPEECH_ON%当然。现在如果你能把它交出来，我和我的弟兄们会非常感激的。%SPEECH_OFF%他轻敲着剑柄，咧嘴一笑。%SPEECH_ON%这只是生意。我相信你能理解。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "该死，拿走这个脑袋，然后滚吧。",
					function getResult()
					{
						this.Flags.set("IsRobberBaronDead", false);
						this.Flags.set("IsBountyHunterPresent", false);
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractPoor);
						return "BountyHunters2";
					}

				},
				{
					Text = "{既然你这么想要它，那就用鲜血来换吧。 | 想让你的脑袋跟这个凑成一对吗？那就来吧，赌赌你的运气。}",
					function getResult()
					{
						this.TempFlags.set("IsBountyHunterTriggered", true);
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						local tile = this.World.State.getPlayer().getTile();
						local p = this.Const.Tactical.CombatInfo.getClone();
						p.Music = this.Const.Music.BanditTracks;
						p.TerrainTemplate = this.Const.World.TerrainTacticalTemplate[tile.TacticalType];
						p.Tile = tile;
						p.CombatID = "BountyHunters";
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.BountyHunters, 130 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getID());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BountyHunters2",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_07.png[/img]你觉得今天见的血已经够多了，于是交出了那颗脑袋。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们走吧，还得回去领赏金呢。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "BountyHunters3",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_07.png[/img]这些赏金猎人对 %companyname% 来说实在太强了！为了不让手下白白送命，你下令匆忙撤退。不幸的是，%robberbaron% 的脑袋在混乱中丢了……。",
			Image = "",
			List = [],
			Options = [
				{
					Text = "哎，算了。我们还是回去领赏金吧。",
					function getResult()
					{
						this.Flags.set("IsBountyHunterRetreat", false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivors1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{随着战斗接近尾声，几名敌人跪倒在地，乞求怜悯。%randombrother% 看向你，等待下一步指示。 | 战斗结束后，你的手下围拢了残余的强盗。幸存者们苦苦哀求饶命。其中一个看起来更像是个孩子而不是成年人，但他却是所有人中最沉默的一个。 | 意识到大势已去，最后几名站着的强盗放下武器请求宽恕。你现在不禁在想，如果易地而处，他们又会如何对待你。 | 战斗已经结束，但仍有抉择要做：几名强盗在战斗中活了下来。%randombrother% 站在其中一人身前，剑刃抵住囚犯的脖子，询问你打算如何处置。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "割断他们的喉咙。",
					function getResult()
					{
						this.World.Assets.addMoralReputation(-1);
						return "Survivors2";
					}

				},
				{
					Text = "收缴他们的武器，把他们赶走。",
					function getResult()
					{
						this.World.Assets.addMoralReputation(2);
						return "Survivors3";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivors2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{仁慈是天真者的专利。你下令处决了战俘。 | 你回想起强盗曾多少次残杀无辜的商人。当你下令处死这些俘虏时，脑海中几乎立刻浮现出那些画面。他们发出了简短的抗议，但很快就被长剑和长矛打断了。 | 你转过身去。%SPEECH_ON%割断他们的喉咙。动作利索点。%SPEECH_OFF%佣兵们执行了命令，很快你就听到了垂死之人喉咙里发出的咕噜声。事实上，这个过程一点都不痛快。 | 你摇了摇头。俘虏们大声哭喊起来，但你的手下们已经扑向了他们，劈砍、斩杀、捅刺。幸运的人在意识到死亡降临之前就被斩首了，而那些试图反抗的人则痛苦地挣扎到了最后一刻。 | 仁慈需要时间：需要时刻回头张望，需要反复思量决定是否正确。你没有时间，也没有仁慈。俘虏被处决了，这几乎没花多少时间。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们有更要紧的事要处理。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivors3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{今天已经死了够多人了。你释放了俘虏，收缴了他们的武器和盔甲后便让他们离开了。 | 对小偷和强盗而言，宽大处理并不常见，因此当你释放他们时，他们亲吻你的脚，仿佛那是神明的脚一般。 | 你沉思了一会儿，然后点了点头。%SPEECH_ON%就这样吧，给他们一条生路。收走他们的装备，把他们放了。%SPEECH_OFF%俘虏们被释放了，留下了他们所有的武器和盔甲。 | 你让强盗们脱得只剩内衣——如果他们有内衣的话——然后放他们走。当你看着一群半裸的男人匆忙逃离时。%randombrother% 正在翻找留下的装备。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "杀他们又没钱拿。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Volunteer1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{战斗刚刚结束，四周正归于平静时，你突然听到一个男人的喊叫声。循声而去，你发现了一个被强盗俘虏的人。他的嘴被勒着，双手被绑着，你迅速解开了绳索。在缓过气后，他怯生生地问能否加入你的队伍。 | 你在强盗营地里发现了一个被捆绑的俘虏。为他松绑后，那人解释说自己来自 %randomtown%，几天前被这伙恶棍绑架了。他询问是否可以加入你的佣兵团。 | 在搜刮强盗营地残余物资时，你发现了一个被他们关押的人。获救后，这名男子坐起来解释说，他在前往 %randomtown% 找工作的途中被强盗绑架了。你心想，或许他可以为你效力……。 | 战斗结束后，现场留下了一个人。他不是强盗，而是他们的俘虏。当你询问他是谁时，他提到自己来自 %randomtown%，正在找工作。你问他是否会用剑，他点了点头。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "你不妨加入我们。",
					function getResult()
					{
						return "Volunteer2";
					}

				},
				{
					Text = "你还是回家去吧。",
					function getResult()
					{
						return "Volunteer3";
					}

				}
			],
			function start()
			{
				local roster = this.World.getTemporaryRoster();
				this.Contract.m.Dude = roster.create("scripts/entity/tactical/player");
				this.Contract.m.Dude.setStartValuesEx(this.Const.CharacterLaborerBackgrounds);

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand).removeSelf();
				}

				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "Volunteer2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{那人加入了你的行列，融入了这群兄弟之中。对于一群收钱杀人的佣兵来说，大家对他还算热情。这位新人声称自己精通所有武器，但你觉得最好还是由你来决定他最擅长什么。 | 那名俘虏听你让他加入，顿时笑逐颜开。几个兄弟问他想要什么武器，但你耸了耸肩，打算亲自看看该给这人配备什么。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "我来看看该给你配什么武器。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.Contract.m.Dude.getImagePath());
				this.World.getPlayerRoster().add(this.Contract.m.Dude);
				this.World.getTemporaryRoster().clear();
				this.Contract.m.Dude.onHired();
				this.Contract.m.Dude = null;
			}

		});
		this.m.Screens.push({
			ID = "Volunteer3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_22.png[/img]{你摇了摇头，表示拒绝。那人皱起眉头。%SPEECH_ON%您确定吗？我其实挺擅长……%SPEECH_OFF%你打断了他。%SPEECH_ON%我很确定。现在，去享受你重获的自由吧，陌生人。%SPEECH_OFF% | 你打量了一番这人，觉得他并不适合过佣兵这种刀头舔血的生活。%SPEECH_ON%陌生人，我们心领了，但佣兵的生活非常危险。回你的家人身边去吧，回到你的工作和家园中。%SPEECH_OFF% | 虽然你手下的兄弟已经够用了，但你甚至有一瞬间动了念头，想招了他来顶替 %randombrother% 的位置，好看看那家伙被降职时的反应。但最终，你只是跟这名囚犯握了握手，打发他上路。虽然有些失望，但他还是感谢了你的救命之恩。}",
			Image = "",
			Characters = [],
			List = [],
			Options = [
				{
					Text = "你走吧。",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.Contract.m.Dude.getImagePath());
				this.World.getTemporaryRoster().clear();
				this.Contract.m.Dude = null;
			}

		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你回到了 %townname%，并与 %employer% 进行了交谈，你的旅程经历很简单：你杀了那些强盗。他点点头，嘴角露出一丝短暂的微笑，随后按照约定付给了你赏金。%SPEECH_ON%干得好，伙计们。那些强盗之前给我们惹了不少麻烦。%SPEECH_OFF% | 当你回到 %employer% 的家时，他为你开了门。手里提着一个钱袋，举起来问道。%SPEECH_ON%看你回来了，想必那些强盗都死透了吧？%SPEECH_OFF%你点点头。那人将钱袋扔向你。你半开玩笑地说自己可能在撒谎。%employer% 耸了耸肩。%SPEECH_ON%也许吧，但对于那些恩将仇报的人来说，消息传得可快了。干得好，佣兵。当然，除非你真的在撒谎，那我就会来找你算账。%SPEECH_OFF% | 当你进入房间并将装在袋子里的脑袋放在桌上时，%employer% 咧嘴笑了起来。%SPEECH_ON%你不必用这玩意来弄脏我精美的家具，以此证明你完成了任务。佣兵，我早就收到你们成功的消息了——这片土地上的消息总是传得像鸟儿飞一样快，不是吗？你的报酬就在角落里。%SPEECH_OFF% | 当你汇报完毕时，%employer% 用手帕擦了擦额头。%SPEECH_ON%真的，他们都死了？天哪……佣兵，你不知道你帮我卸下了多重的担子。一点也不知道！这是你的赏金，正如约定的那样。%SPEECH_OFF%他把钱袋放在桌上，你迅速将其收好。分文不差，正如约定的那样。 | %employer% 抿了一口高脚杯里的酒，点了点头。%SPEECH_ON%你知道的，我不怎么待见你们这种人，但你干得不错，佣兵。在你到达之前，%randomname% 就向我报告了，说所有强盗都被你们干掉了。按他的描述，那活儿干得相当漂亮。而且，好吧……。%SPEECH_OFF%他把一个沉甸甸的钱袋摔在桌上。%SPEECH_ON%这是约定的丰厚报酬。%SPEECH_OFF% | %employer% 向后靠在椅子上，双手交叠放在大腿上。%SPEECH_ON%佣兵在很多人眼里都不是什么好东西，大概是因为你们常会为了一点小钱就毁掉整个村庄，但我不得不承认，你们这次干得不错。%SPEECH_OFF%他示意了一下房间角落里一个没上锁的木箱。%SPEECH_ON%都在里面了，不过如果你要数一下，我也不会介意。%SPEECH_OFF%你数了数，确实分文不差。 | %employer% 的桌子上堆满了沾满灰尘、摊开的卷轴。他正对着它们微笑，仿佛在对着一堆宝藏喃喃自语。%SPEECH_ON%贸易协定！到处都是贸易协定！快乐的农夫！幸福的家庭！每个人都很开心！啊，做我自己可真好。当然，做你的感觉也不错，佣兵，因为你的口袋刚刚又变重了一点！%SPEECH_OFF%那人扔给你一个小钱袋，又扔了一个，又一个。%SPEECH_ON%我本可以用大袋子装钱给你，但我就喜欢这种感觉。%SPEECH_OFF%他又调皮地扔过来一个钱袋，你顺手接住了它。作为一个剑上还沾着热血的男人，你接钱的动作透着一种毫无波澜的沉稳。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "摧毁了强盗营地");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你把那罪犯的脑袋扔在 %employer% 的桌子上，你咧嘴一笑，指着它说。%SPEECH_ON%这就是 %robberbaron%。%SPEECH_OFF%%employer% 站起身，揭开了覆盖在战利品上的麻布袋。他点了点头。%SPEECH_ON%没错，就是他。我想你会为此得到一笔额外赏金。%SPEECH_OFF%由于你不仅铲除了强盗，还杀了附近多个犯罪团伙的首领，你获得了一笔总计 %reward% 克朗的赏金。 | 当你提着一颗人头进入房间时，%employer%向后靠了靠。万幸的是，那脑袋没再往下滴血。%SPEECH_ON%这位就是 %robberbaron%。或者我该说‘曾经是’？%SPEECH_OFF%%employer%缓缓站起身，草草瞥了一眼。%SPEECH_ON%‘曾经是’这个词用得很妙……看来，你不仅端掉了那帮强盗的耗子洞，还把他们头儿的脑袋带给了我。干得漂亮，佣兵，你会为此得到额外报酬的。%SPEECH_OFF%男人先交出了装有 %original_reward% 克朗的钱袋，接着从自己身上又解下一个钱袋扔给了你。 | 你拎起 %robberbaron% 的脑袋，它那倾斜的目光转向了沾满血迹的乱发。%employer% 的脸上缓缓勾勒出一抹微笑。%SPEECH_ON%你知道你做了什么吗，佣兵？你知道仅仅是把那家伙的脑袋从肩膀上搬走，就给这一带带来了多大的解脱吗？你会得到比约定更多的报酬！原本的任务给你 %original_reward% 克朗，然后……%SPEECH_OFF%男人在桌子上推过来一个沉甸甸的钱包。%SPEECH_ON%这是给你一路上带着这件‘额外重物’的小小心意。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() * 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "摧毁了强盗营地");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() * 2;
				this.Contract.m.OriginalReward = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"reward",
			this.m.Reward
		]);
		_vars.push([
			"original_reward",
			this.m.OriginalReward
		]);
		_vars.push([
			"robberbaron",
			this.m.Flags.get("RobberBaronName")
		]);
		_vars.push([
			"totalenemy",
			this.m.Destination != null && !this.m.Destination.isNull() ? this.beautifyNumber(this.m.Destination.getTroops().len()) : 0
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive() ? "" : this.Const.Strings.Direction8[this.m.Home.getTile().getDirection8To(this.m.Destination.getTile())]
		]);
	}

	function onHomeSet()
	{
		if (this.m.SituationID == 0)
		{
			this.m.SituationID = this.m.Home.addSituation(this.new("scripts/entity/world/settlements/situations/ambushed_trade_routes_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}

		if (this.m.Home != null && !this.m.Home.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Home.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			return true;
		}
		else
		{
			return true;
		}
	}

	function onSerialize( _out )
	{
		_out.writeI32(0);

		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		_in.readI32();
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

