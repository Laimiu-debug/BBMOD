this.drive_away_barbarians_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Dude = null,
		Reward = 0,
		OriginalReward = 0
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.drive_away_barbarians";
		this.m.Name = "驱逐蛮子";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		local banditcamp = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).getNearestSettlement(this.m.Home.getTile());
		this.m.Destination = this.WeakTableRef(banditcamp);
		this.m.Flags.set("DestinationName", banditcamp.getName());
		this.m.Flags.set("EnemyBanner", banditcamp.getBanner());
		this.m.Flags.set("ChampionName", this.Const.Strings.BarbarianNames[this.Math.rand(0, this.Const.Strings.BarbarianNames.len() - 1)] + " " + this.Const.Strings.BarbarianTitles[this.Math.rand(0, this.Const.Strings.BarbarianTitles.len() - 1)]);
		this.m.Flags.set("ChampionBrotherName", "");
		this.m.Flags.set("ChampionBrother", 0);
		this.m.Payment.Pool = 600 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往 %origin% 的 %direction%，驱逐位于 " + this.Flags.get("DestinationName") + " 的野蛮人"
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Contract.m.Destination.setLastSpawnTimeToNow();
				this.Contract.m.Destination.clearTroops();

				if (this.Contract.getDifficultyMult() <= 1.15 && !this.Contract.m.Destination.getFlags().get("IsEventLocation"))
				{
					this.Contract.m.Destination.getLoot().clear();
				}

				this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.Barbarians, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setLootScaleBasedOnResources(110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setResources(this.Math.min(this.Contract.m.Destination.getResources(), 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult()));
				this.Contract.m.Destination.setDiscovered(true);
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);
				local r = this.Math.rand(1, 100);

				if (r <= 20)
				{
					if (this.World.getTime().Days >= 10)
					{
						this.Flags.set("IsDuel", true);
					}
				}
				else if (r <= 40)
				{
					if (this.World.Assets.getBusinessReputation() >= 500 && this.Contract.getDifficultyMult() >= 1.0)
					{
						this.Flags.set("IsRevenge", true);
					}
				}
				else if (r <= 50)
				{
					this.Flags.set("IsSurvivor", true);
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));
				}
			}

			function update()
			{
				if (this.Flags.get("IsDuelVictory"))
				{
					this.Contract.setScreen("TheDuel2");
					this.World.Contracts.showActiveContract();
					this.Flags.set("IsDuelVictory", false);
				}
				else if (this.Flags.get("IsDuelDefeat"))
				{
					this.Contract.setScreen("TheDuel3");
					this.World.Contracts.showActiveContract();
					this.Flags.set("IsDuelDefeat", false);
				}
				else if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsSurvivor"))
					{
						this.Contract.setScreen("Survivor1");
						this.World.Contracts.showActiveContract();
					}

					this.Contract.setState("Return");
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				if (this.Flags.get("IsDuel"))
				{
					this.Contract.setScreen("TheDuel1");
					this.World.Contracts.showActiveContract();
				}
				else if (!this.Flags.get("IsAttackDialogTriggered"))
				{
					this.Flags.set("IsAttackDialogTriggered", true);
					this.Contract.setScreen("Approaching");
					this.World.Contracts.showActiveContract();
				}
				else
				{
					this.World.Contracts.showCombatDialog();
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Duel")
				{
					this.Flags.set("IsDuelVictory", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Duel")
				{
					this.Flags.set("IsDuelDefeat", true);
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Flags.get("IsRevengeVictory"))
				{
					this.Contract.setScreen("Revenge2");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsRevengeDefeat"))
				{
					this.Contract.setScreen("Revenge3");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsRevenge") && this.Contract.isPlayerNear(this.Contract.m.Home, 600))
				{
					this.Contract.setScreen("Revenge1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onCombatVictory( _combatID )
			{
				if (_combatID == "Revenge")
				{
					this.Flags.set("IsRevengeVictory", true);
				}
			}

			function onRetreatedFromCombat( _combatID )
			{
				if (_combatID == "Revenge")
				{
					this.Flags.set("IsRevengeDefeat", true);
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_20.png[/img]{%employer% 叹了口气，将一张纸条推向你。那是一份罪行清单。你点点头，注意到上面记录的恶行确实罄竹难书。那人也向你点了点头。%SPEECH_ON%如果只是个普通的小罪犯，我打发个治安官或者赏金猎人就能解决。但我把你找来，佣兵，是因为这是野蛮人的行径。清单上的一切，我要如数奉还给他们。他们在离这儿的往 %direction% 的地方有个村子。我要你去‘拜访’一下，让他们明白，虽然我们住在炉火旁，拥有文明，但原始的血性尚未磨灭，野蛮的行径必将遭到野蛮的报复。你明白吗？%SPEECH_OFF%你注意到那页罪行录上满是断裂的羽毛笔尖划痕，仿佛书写者在记录时愈发愤怒。 | 一群当地骑士正和 %employer% 待在房间里。他们神色平淡地打量着你，仿佛你只是头推开门闯进来的野狗。%employer% 从椅子上弯下腰，捡起一个卷轴扔给你。%SPEECH_ON%我去查看附近一个被夷为平地的农场时，那些蛮子留下了这个。%SPEECH_OFF%纸上画着符文，还有看起来像是被绞死的图案。%employer% 点了点头。%SPEECH_ON%他们屠杀了农民，至少男人都死了。恐怕只有旧神才知道那些女人会落得什么下场。往 %direction% 去，佣兵，找到那伙该死的野蛮人。只要能把他们彻底、干净、完全地抹杀掉，你会得到一笔丰厚的报酬。%SPEECH_OFF% | 当你走进房间时，%employer% 看起来烦躁不安。他提到 %townname% 曾经与北方的野蛮人保持着不错的关系。%SPEECH_ON%但我看我是在自欺欺人，居然觉得能跟那群畜生平起平坐。%SPEECH_OFF%他说他们一直在袭击商队、谋杀旅人并洗劫民宅。%SPEECH_ON%所以我要以牙还牙。往这儿的 %direction% 去，把他们的村子给屠个干净。你有兴趣接这活儿吗？%SPEECH_OFF% | 当你进入房间时，%employer% 大笑起来。%SPEECH_ON%我不是在拿你寻开心，佣兵，我只是在笑这种残酷的巧合——为了迅速彻底地抹杀野蛮人，竟然真的得找个雇佣兵。你看，就在这儿的 %direction%，有一群裹着熊皮的杂种，一直在剥商人的头皮，拿斧头砍杀旅人。我绝不容忍这种事。部分原因是他们坏了规矩，但主要是因为我有钱，能请你这种没教养的家伙替我摆平这事。%SPEECH_OFF%他又自顾自地笑了起来。你感觉这个男人从未亲手把剑捅进过任何活物的身体。%SPEECH_ON%所以你怎么说，佣兵，有兴趣去宰了那群畜生吗？%SPEECH_OFF% | 当你进入 %employer% 的房间时，他正盯着一颗狗头。脖颈处断断续续滴下的液体顺着桌沿流下。男人正揉搓着其中一只狗耳朵。%SPEECH_ON%什么样的杂种会杀了一个人的狗，砍下头，还他妈寄给主人？%SPEECH_OFF%你想象着这人一定有个死对头，但保持了沉默。%employer% 向一名仆人示意，狗头被拿走了。他现在看向你。%SPEECH_ON%%direction% 的野蛮人干的。起初他们只是对商人和定居者下手，像往常那样奸淫掳掠。于是我派人回击，杀了几个他们的人，结果就换来了这个。好吧，这群狗杂种的好日子到头了。我要你前往他们的村子，把他们杀个精光，一个不留。%SPEECH_OFF%你差点想问问，这是否也包括杀光他们的狗。 | 你发现 %employer% 身边坐着一个污秽满身、泥泞不堪的女人。她披头散发，身上满是各种刑具留下的伤痕。她对着你冷笑，仿佛这一切都是你造成的一样。%employer% 一脚把她踢翻在地。%SPEECH_ON%别管这个贱人，佣兵。我们抓到她和她的同伙在抢劫粮仓。我们杀了那群蛮子中的大部分，我想说留下她是为了找乐子，但打她就像打狗一样无趣。她那副男人婆的样子简直败兴。%SPEECH_OFF%他又踢了她一脚，女人咆哮着回应。%SPEECH_ON%看到了吗？呵，我有消息了！我们已经找到了她出来的那个村子，我打算把它付之一炬。这就轮到你出马了。那个蛮族村子就在这儿的 %direction%，消灭他们，你会得到丰厚的报酬。%SPEECH_OFF%那女人听不懂在说什么，但她眼神中透出的一丝松动似乎表明，她开始明白为什么像你这样的人会走进这个地方。%employer% 咧嘴一笑。%SPEECH_ON%你有兴趣吗？还是说我得去找个心肠更歹毒的人？%SPEECH_OFF% | %employer% 的房间里挤满了一群平民。人数之多，超出了任何身处他这种地位的人所能忍受的近距离范围，但奇怪的是，他们似乎并不打算私刑处死他。见到你，%employer% 叫你上前。%SPEECH_ON%啊，终于来了！我们的救星到了！佣兵，%direction%的蛮子一直在掠夺附近的村庄，强奸一切有洞的玩意。我们受够了，坦白说，我一点也不想让那些肮脏蛮子的玩意儿靠近我的屁股，大伙儿肯定也一样。%SPEECH_OFF%人群发出一阵嘲弄和愤怒的呼喊，一个男人喊道：那些蛮子{砍掉了他母亲的脑袋 | 还杀光了他养的羊 | 抢走了他所有的狗，那些畜生 | 吃了他小儿子的肝脏}。%employer%点了点头。%SPEECH_ON%没错，没错，伙计们，没错！所以我要说，佣兵，你给我想法子杀到那群蛮子的村里去，让他们见识见识什么是对等的、妥当的、文明的正义。%SPEECH_OFF% | %employer% 挥手示意你进屋。他手里拿着一把火钳，顶端挂着一块头皮。%SPEECH_ON%北边的蛮子今天送了我这个。它被粘在信使身上，他们挖掉了那人的眼睛，割了舌头。这就是那群畜生的本性，用这种方式跟我‘沟通’。所以，我觉得在你的帮助下，我也会‘回敬’他们。去这儿的 %direction%，找到他们的村子，把它烧成灰烬。%SPEECH_OFF%那块头皮从火钳上脱落，‘啪嗒’一声湿乎乎地摔在石地板上。 | %employer% 极不情愿地欢迎你进来，就像一个人被世俗逼到不得不求助佣兵时那样。他说话言简意赅。%SPEECH_ON%那群蛮子在 %direction% 有一个村子，他们从那里派出劫掠队。他们奸淫掳掠，除了长着人样，简直就是害虫和毒虫。我要他们全部消失，一个不留。你愿意接这活儿吗？%SPEECH_OFF% | %employer% 的膝头上趴着一只猫，但当你走近时，你才发现那只是个猫头，他刚才一直在用拇指拨弄着一截断掉的尾巴。他抿起嘴唇。%SPEECH_ON%那些蛮子干的。他们还奸淫掳掠了周围好些农场，还把一对双胞胎婴儿吊在树上，但这事儿……%SPEECH_OFF%他手掌摊开，猫头滚落下来，在石地板上发出一声沉闷的撞击声。%SPEECH_ON%够了。我要你去 %direction% 找到那群畜生的老巢，把他们施加在我们身上的痛苦，如数奉还！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{你愿意为此出多少钱？ | %townname% 准备出多少钱来买他们的平安？ | 我们来谈谈价钱。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{不感兴趣。 | 我们有更要紧的事要处理。 | 祝你们好运，但我们不会掺和这件事。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Approaching",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_138.png[/img]{你找到了野蛮人村落，以及通往那里的一系列石堆。这些石头被堆成人的形状，每个石堆顶上都放着一颗刚砍下的人头。%randombrother% 点了点头。%SPEECH_ON%我在想，他们是不是觉得这样做能让他们更接近他们的神？%SPEECH_OFF%你怀疑自己有另一种让他们更接近神明的方法：那就是杀光他们。是时候策划进攻方案了。 | 你找到了野蛮人的村子，就在郊外的雪地里躺着一块圆形的巨石。它大到即使整个连队的士兵头脚相接躺成一排，也无法跨越它的中心。巨石的外缘刻满了符文，长长的凹槽里凝固着陈旧的血迹。石板中心有一个小小的方形凸起，带有一道贴合脖颈的弧度。%randombrother% 啐了一口。%SPEECH_ON%看起来像个祭祀方台……呃，圆台。%SPEECH_OFF%环顾四周，你大声纳闷他们把尸体都放哪儿了。那名佣兵耸了耸肩。%SPEECH_ON%鬼知道，没准被他们吃了。%SPEECH_OFF%如果真是这样，你也不会感到意外。你盯着村庄，盘算着是直接进攻还是继续等待。 | 蛮子的村庄就在不远处。那是一副游牧景象：帐篷被临时的铁匠铺围绕着，还有盖着防水布的马车充当粮仓。你感觉到他们不会在任何地方逗留太久。%randombrother% 笑了。%SPEECH_ON%看那家伙。他在拉屎呢。真是个畜生。%SPEECH_OFF%的确，其中一个野蛮人正一边蹲着一边和同村人聊天。这简直就像一个隐喻，说明你可以趁整座营地猝不及防时给他们致命一击。 | 这个野蛮人村庄出人意料地不像你预想中的人间炼狱。除了那具倒挂在木制神圣图腾上的剥皮尸体外，这里看起来和其他普通人的聚居地没什么两样。当然，除了所有人都穿着厚重的衣服，且每个人都带着斧头或某种剑类武器。一切都挺‘正常’的。有个家伙正在砍下尸体的腿喂猪，不过这种场面在哪儿都能见到。%randombrother% 点了点头。%SPEECH_ON%头儿，我们准备好进攻了。只要你一声令下。%SPEECH_OFF% | 你发现了野蛮人的村庄，它盘踞在冰雪荒原上。这村子在那里的时间肯定不长：大部分都是帐篷，顶上没积多少雪。他们肯定是在一处驻扎一段时间，然后就重新上路，要么是为了保持猎物新鲜，要么是为了躲避被他们抢劫的那些人报复。可惜，他们这次没能躲掉。你让战团做好了战斗准备。 | 你找到了一个野蛮人村落。但是，乍一看，他们看起来和普通人没什么两样，男人、女人、孩子都有。男人、女人、孩子。有铁匠、皮匠，一个独眼龙在制箭，还有一个身材魁梧的处刑人正在给尸体开膛破肚，并在驴背上清洗脏器。就是那个家伙。那个家伙提醒了你来这里的原因。 | 你找到了蛮子的村落。野蛮人们正处于某种宗教仪式之中。一个戴着玳瑁项链的老人正把拳头伸进一个剃过头的断头里。他任由鲜血顺着前臂流下，孩子们用马鬃刷蘸取这些‘涂料’，跑去抹在柱立着的十英尺高的木制图腾上。原始人围观着，用一种你完全听不懂的语言吟唱。%randombrother% 轻声低语，仿佛比起担心被发现，他更多是对仪式本身保持着某种敬畏。%SPEECH_ON%好吧。我说，我们下去做个自我介绍，怎么样？%SPEECH_OFF% | 你找到了野蛮人正在村子里闲逛。这里大多是帐篷和临时搭建的雪屋。老妇人围坐成一圈编织篮子，年轻女性边制箭边向走动的壮汉投去目光。男人们则假装不在意，但你一眼就能看出那是公孔雀在开屏。还有孩子们在任务间匆忙穿梭。而在村庄外围，立着一连串木桩，赤裸的尸体从肛门一直被贯穿到嘴部，胸腔像蝴蝶翅膀一样被掰开，内脏像松散的刺绣一样垂挂下来。%SPEECH_ON%惨不忍睹。%SPEECH_OFF%%randombrother% 说道。你点了点头。确实如此，但这正是你来这里的原因。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备攻击。",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "TheDuel1",
			Title = "当你接近时…",
			Text = "[img]gfx/ui/events/event_139.png[/img]{就在 %companyname% 准备与这群野人开战时，一个孤独的身影走了出来，站在两军对垒的阵线之间。他那分叉的长胡须上系着乌龟壳，头顶扣着一个带有倾斜口鼻部的狼头骨。这位长老除了手中那根挂满鹿角、叮当作响的长杖外，并未携带武器。令人震惊的是，他竟然用你们的语言开口了。%SPEECH_ON%外来者，欢迎来到北方。我们并不像你们想象的那样不近人情。根据我们的传统，我们相信两名战士之间的决斗，与两支军队之间的交战同样神圣且富有价值。因此，我派出我最强大的勇士，%barbarianname%。%SPEECH_OFF%一名魁梧的男子走上前。他解开皮草并将其扔到一旁，露出了那满是肌肉、筋腱与伤疤的身躯。长老点了点头。%SPEECH_ON%派出你们的勇士吧，外来者，我们将共同度过让所有先祖都为之欣慰的一天。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我宁愿把这整个营地焚毁。进攻！",
					function getResult()
					{
						this.Flags.set("IsDuel", false);
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			],
			function start()
			{
				local raw_roster = this.World.getPlayerRoster().getAll();
				local roster = [];

				foreach( bro in raw_roster )
				{
					if (bro.getPlaceInFormation() <= 17)
					{
						roster.push(bro);
					}
				}

				roster.sort(function ( _a, _b )
				{
					if (_a.getXP() > _b.getXP())
					{
						return -1;
					}
					else if (_a.getXP() < _b.getXP())
					{
						return 1;
					}

					return 0;
				});
				local name = this.Flags.get("ChampionName");
				local difficulty = this.Contract.getDifficultyMult();
				local e = this.Math.min(3, roster.len());

				for( local i = 0; i < e; i = ++i )
				{
					local bro = roster[i];
					this.Options.push({
						Text = roster[i].getName() + "将派出我们的冠军与你战斗！",
						function getResult()
						{
							this.Flags.set("ChampionBrotherName", bro.getName());
							this.Flags.set("ChampionBrother", bro.getID());
							local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
							properties.CombatID = "Duel";
							properties.Music = this.Const.Music.BarbarianTracks;
							properties.Entities = [];
							properties.Entities.push({
								ID = this.Const.EntityType.BarbarianChampion,
								Name = name,
								Variant = difficulty >= 1.15 ? 1 : 0,
								Row = 0,
								Script = "scripts/entity/tactical/humans/barbarian_champion",
								Faction = this.Contract.m.Destination.getFaction(),
								function Callback( _entity, _tag )
								{
									_entity.setName(name);
								}

							});
							properties.EnemyBanners.push(this.Contract.m.Destination.getBanner());
							properties.Players.push(bro);
							properties.IsUsingSetPlayers = true;
							properties.BeforeDeploymentCallback = function ()
							{
								local size = this.Tactical.getMapSize();

								for( local x = 0; x < size.X; x = ++x )
								{
									for( local y = 0; y < size.Y; y = ++y )
									{
										local tile = this.Tactical.getTileSquare(x, y);
										tile.Level = this.Math.min(1, tile.Level);
									}
								}
							};
							this.World.Contracts.startScriptedCombat(properties, false, true, false);
							return 0;
						}

					});
				}
			}

		});
		this.m.Screens.push({
			ID = "TheDuel2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_138.png[/img]{%champbrother% 收起武器，站在那名被击杀的野蛮人尸体旁。这位获胜的佣兵向你点了点头。%SPEECH_ON%解决了，头儿。%SPEECH_OFF%长者再次走上前，举起了他的长杖。%SPEECH_ON%既然如此，你们来到这里寻求暴力，究竟想要解决什么问题？%SPEECH_OFF%你告诉他，南面的人们对此愤怒至极，希望他们离开这片土地。长者点了点头。%SPEECH_ON%如果这是你们本想通过战争达成的目的，那么通过这场荣耀的决斗，事情已经了结。我们会离开。%SPEECH_OFF%野蛮人们被用他们的方言告知收拾行囊离开。令人惊讶的是，几乎没有什么反驳或抱怨。如果他们守信用的话，你现在就可以回去回复 %employer%。}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "一个好的结局。",
					function getResult()
					{
						this.Contract.setState("Return");
						this.Contract.m.Destination.die();
						this.Contract.m.Destination = null;
						return 0;
					}

				}
			],
			function start()
			{
				local bro = this.Tactical.getEntityByID(this.Flags.get("ChampionBrother"));
				this.Characters.push(bro.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "TheDuel3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_138.png[/img]{这是一场精彩的对决，是大地之上勇士间的碰撞，旁观者们肃然起息，仿佛在敬畏某种永恒而神圣的仪式。但是，%champbrother% 已经倒在地上。他战败被杀了。长老再次走上前。他的脸上没有任何幸灾乐祸或嘲讽的迹象。%SPEECH_ON%外来者，两人之间的战斗等同于我们所有人加在一起的较量。我们赢了，远古之石的凝视保佑着我们，因此我们请求你们离开这片土地，永不复返。%SPEECH_OFF%几名佣兵愤怒地看向你。其中一人说，他觉得如果结果反过来，这些野蛮人根本不会遵守约定，战团应该不论胜负直接把这群蛮族全部剿灭。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们会信守诺言，让你们平安留下。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.Assets.addMoralReputation(5);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能摧毁野蛮人营地。" + this.Contract.m.Home.getName());
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				},
				{
					Text = "全军进攻！",
					function getResult()
					{
						this.World.Assets.addMoralReputation(-3);
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivor1",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{战斗结束了，%randombrother% 示意你过去。在其中一个帐篷里，一名野蛮人战士正在处理伤口。他的周围横七竖八地躺着男人、女人和孩子。佣兵指着他。%SPEECH_ON%我们把他追到了这里。我想周围这些都是他的家人，或者是他认识的人，因为他一倒下就再没动弹过。%SPEECH_OFF%你走向那个男人，在他面前蹲下。你踢了踢他那双鹿皮靴的一角，问他是否听得懂你的话。他点了点头，又耸了耸肩。%SPEECH_ON%懂一点。这是你们干的。没必要这样，但你们做了。杀了我，或者让我跟随你去战斗。无论选哪样，都算体面。%SPEECH_OFF%他似乎是在提议为战团效力，这无疑是某种你所陌生的北方准则。他也表示如果你想要他的脑袋，他也随时奉上，而且他看起来完全不惧死亡。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们将不留活口。",
					function getResult()
					{
						this.World.Assets.addMoralReputation(-1);
						return "Survivor2";
					}

				},
				{
					Text = "让他滚。",
					function getResult()
					{
						this.World.Assets.addMoralReputation(2);
						return "Survivor3";
					}

				}
			],
			function start()
			{
				if (this.World.getPlayerRoster().getSize() < this.World.Assets.getBrothersMax())
				{
					this.Options.push({
						Text = "我们需要他加入我们。",
						function getResult()
						{
							return "Survivor4";
						}

					});
				}
			}

		});
		this.m.Screens.push({
			ID = "Survivor2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{你拔出长剑，压低剑尖指向那个人。剑身的弧面上映照出帐篷内模糊的尸体倒影，而那名幸存野蛮人的脸在剑尖的倒影中扭曲变形。他咧嘴一笑，用那双大手死死攥住剑刃，任由掌心鲜血直流，仿佛双手便是这柄剑的剑鞘。%SPEECH_ON%杀戮与死亡，对我们这种人来说，并不丢人。对吗？%SPEECH_OFF%你点了点头，将长剑刺入他的胸膛，顺势将他按倒在地上。剑尖承载的重量沉若磐石。当你拔出剑时，他的尸体重重地摔回尸堆，发出一声闷响。你收剑入鞘，吩咐同伴们搜刮所有能带走的物资，准备动身返回 %employer% 那里。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候去拿报酬了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivor3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{你将刀刃拔出一半，停顿片刻好让那蛮子看个清楚，随后猛地将其掼回鞘中。你点了点头，问道。%SPEECH_ON%明白了吗？%SPEECH_OFF%野蛮人站起身，身子在帐篷支柱上歪靠了一下。你转过身，伸手指向帐篷帘口。他点了点头。%SPEECH_ON%嗯，我知道了。%SPEECH_OFF%他跌跌撞撞地走了出去，步入光亮之中，向着北方的荒原远去。他的身影左右晃动，愈缩愈小，最终消失不见。你告诉弟兄们准备启程返回 %employer% 那里，去领取那份应得的报酬。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "是时候去拿报酬了。",
					function getResult()
					{
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Survivor4",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{你凝视着那个男人，随即拔出匕首，划开了自己的掌心。你紧握拳头催出鲜血，将匕首丢给那个野蛮人，然后伸出那只血流不止的手。那蛮子接过匕首，也依样划破了自己的手。他站起身，向你伸出手，你们击掌为盟。他点了点头。%SPEECH_ON%荣誉，永随。追随你，是唯一的路，且生死不渝。%SPEECH_OFF%那人跌跌撞撞地走出帐篷。你下令弟兄们别杀他，反而要为他配备装备，这引来了一阵惊疑的目光。他的加入虽在意料之外，却大有裨益。南方的雇佣兵们迟早会习惯的，但眼下，%companyname% 必须启程回到 %employer% 身边了。}",
			Image = "",
			List = [],
			Characters = [],
			Options = [
				{
					Text = "欢迎加入 %companyname% 战团。",
					function getResult()
					{
						this.World.getPlayerRoster().add(this.Contract.m.Dude);
						this.World.getTemporaryRoster().clear();
						this.Contract.m.Dude.worsenMood(1.0, "亲眼目睹自己的村庄惨遭屠杀。");
						this.Contract.m.Dude.onHired();
						this.Contract.m.Dude = null;
						return 0;
					}

				}
			],
			function start()
			{
				local roster = this.World.getTemporaryRoster();
				this.Contract.m.Dude = roster.create("scripts/entity/tactical/player");
				this.Contract.m.Dude.setStartValuesEx([
					"barbarian_background"
				]);

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Mainhand).removeSelf();
				}

				if (this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Offhand) != null)
				{
					this.Contract.m.Dude.getItems().getItemAtSlot(this.Const.ItemSlot.Offhand).removeSelf();
				}

				this.Characters.push(this.Contract.m.Dude.getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "Revenge1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_135.png[/img]{一个老人挡住了你的去路。看他的长相，他不像是来自南方地界的人。%SPEECH_ON%啊，外来者。你们踏入我们的土地，袭击了一座毫无防备的村子。%SPEECH_OFF%你啐了一口，点了点头。%randombrother% 高声吼道，这本就是野蛮人们自己平日里的行径。老人露出一丝微笑。%SPEECH_ON%所以我们身处轮回之中。通过这暴力，我们终将获得新生，但暴力必不可少。等我们收拾完你们，%townname% 也不会幸免。%SPEECH_OFF%一群壮汉从他们藏身的草木丛中站起身来。看样子，这就是那座被焚毁的村子的主力。你袭击村子时，他们可能正外出掠夺。而现在，他们出现在这里，誓要以野蛮人的方式血债血偿。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						properties.CombatID = "Revenge";
						properties.Music = this.Const.Music.BarbarianTracks;
						properties.EnemyBanners.push(this.Flags.get("EnemyBanner"));
						properties.Entities = [];
						this.Const.World.Common.addUnitsToCombat(properties.Entities, this.Const.World.Spawn.Barbarians, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).getID());
						this.World.Contracts.startScriptedCombat(properties, false, true, false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Revenge2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_145.png[/img]{野蛮人被赶出了 %townname%。尽管获得了胜利，但村民们还是过了一会儿才敢露头，亲眼见证你的大获全胜。%employer% 最终拍着手、吆喝着走了出来。他身后跟着一众看起来垂头丧气的副官，他们正局促地环顾四周，膝盖上沾满了泥巴，身上还挂着零星的稻草和土块。显然，他们刚才一直躲起来了。%SPEECH_ON%干得好，佣兵，干得真漂亮！旧神肯定会记住这一切，并在合适的时机奖赏你的！%SPEECH_OFF%你收剑入鞘，对着那群没用的副官点了点头。%SPEECH_ON%也许吧，但你最好先打赏。既然某些人——咱们姑且这么说吧——指望不上，旧神肯定更愿意看到你替他们行赏，不是吗。%SPEECH_OFF%那人抿起嘴唇，瞥了一眼他的副官们，而他们纷纷避开了视线。你的雇主露出了微笑并点了点头。%SPEECH_ON%当然，那是当然，佣兵。我明白你的意思。酬金会一分不少地付给你，而且还有额外的小费！这都是你应得的，确实如此！%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "辛苦劳作的一天。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion() * 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "你摧毁了一个野蛮人营地。" + this.Contract.m.Home.getName());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "你拯救了" + this.Contract.m.Home.getName() + "来自野蛮人的复仇");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion() * 2;
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Revenge3",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_94.png[/img]{你踉跄着逃离战场，撤退到一处相对安全的地方，眼睁睁地看着 %townname% 陷入毁灭。那些蛮子闯进房子，开始强奸和杀戮。孩子被抓起来，被装进用骨头和皮革制成的笼子里，而一名长者竟在那儿‘慈祥’地给他们递上苹果片和樟脑水。在城镇广场，你看到那些原始人围攻了 %employer% 的府邸。几名守卫试图上前阻拦，却瞬间被砍倒。其中一人被剥光衣服按在地上，踢向两条恶犬，恶犬从各个角度撕咬着他，而他却在痛苦中挣脱不得，挣扎了许久才断气。 \n\n最后，%employer% 被拖出了家门。野蛮人的首领盯着他，点了点头，随后一只手掐住他的脖子，另一只手捂住他的脸。就这样，他被悬空掐死。尸体随即被扔给了其他蛮子，他们将其剥光、凌辱，然后用长矛从肛门贯穿至口腔，高高地架在广场中央。掠夺结束后，蛮子带上战利品扬长而去。你看到的最后一幕，是一条野狗嘴里叼着人类的肋骨小跑着跟在队伍后面。%randombrother% 走到你身边。%SPEECH_ON%哎。头儿，我觉得我们这回是拿不到工钱了。%SPEECH_OFF%没错。你也是这么想的。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "一切全完了。",
					function getResult()
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).getRoster().remove(this.Tactical.getEntityByID(this.Contract.m.EmployerID));
						this.Contract.m.Home.addSituation(this.new("scripts/entity/world/settlements/situations/raided_situation"), 4);
						this.Contract.m.Home.setLastSpawnTimeToNow();
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail * 2);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail * 2, "你没有成功救下。" + this.Contract.m.Home.getName() + "来自为复仇而来的野蛮人。");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "临近 %townname%…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{%employer% 鼓着掌欢迎你的到来。%SPEECH_ON%我的斥候追踪你的团队一直到了北方，而且我敢说，你们理所当然地成功了！宰掉那些野蛮人的活儿干得真漂亮。这肯定能让他们在下次胆敢来这里前好好掂量掂量！%SPEECH_OFF%那人付清了欠你的酬金。 | 你进入 %employer% 的房间，发现他瘫坐在椅子上。他正盯着一个赤裸的女人在房间里走来走去。他摇着头，眼睛一刻也没离开那场表演，就这样对你开口了。%SPEECH_ON%我的斥候已经把你们的所作所为告诉我了。说你们收拾那些蛮子时，简直就像他们亲自得罪了你一样。我喜欢那样。我喜欢那种毫不留情劲儿。真希望我手下能有更多人像你这样。%SPEECH_OFF%一个此前未被察觉的仆人迅速穿过房间。他头顶着一根红蜡烛，手里捧着一箱克朗。你拿了报酬，尽可能快地离开了房间。 | 你发现 %employer% 和一群穿着盔甲的人围在桌子旁。躺着一具蛮子的尸体。血肉已经发灰，但强健的肌肉和坚韧的体魄还没腐烂。他们询问你是否真的在和这种人战斗。你开门见山地讨要报酬。%employer%拍着手向众人展示你的存在。%SPEECH_ON%这就是我想招入麾下的那种人！无所畏惧，时刻专注。%SPEECH_OFF%其中一名贵族吐了口唾沫，低声说了一些你没听清的话。你让他有话大声说，但 %employer% 赶忙上前，手里拎着一箱克朗，把你送走了。 | 找到 %employer% 费了点功夫，最后居然在一个看似荒废的谷仓里找到了他。你看到他站在一具死去的蛮子尸体面前，那具尸体像渔获一样被倒挂在房梁上。尸体被火烧过、被肢解过，惨不忍睹。%employer% 蹲下身，在一个水桶里洗了洗手。%SPEECH_ON%不得不说，佣兵，你干掉那么多野蛮人确实令人印象深刻。这儿留下的这个撑了很久，他承受痛苦的样子，就好像他打算十倍报复给我似的。但他永远没机会了，对吧？%SPEECH_OFF%男人轻轻拍了拍那个蛮子的脸，锁链叮当作响，尸体微微扭动。%employer% 点了点头。%SPEECH_ON%外面的仆人会把酬金给你。干得好，佣兵。%SPEECH_OFF% | 你发现 %employer% 和一群人正在视察 %townname% 的防御工事，毫无疑问是在为下一次进攻做准备。从这些人的面相来看，他们的生存期望终将撞上远比他们预想中残酷的现实。但你对此保持沉默。%employer% 感谢你出色地完成了任务，并支付了酬劳。 | %townname% 的居民看到你归来时流露出惊恐和困惑，把你误认为了他们所熟知的野蛮人。窗户紧闭，大门反锁，孩子们被匆忙带走，还有几个胆大的拿着草叉走了出来。%employer% 匆忙从住处跑出来安抚他们，解释说你们才是故事里的英雄，说你们向北进发并全歼了野蛮人、烧毁了他们的村子，将他们驱散到了荒原上。窗户重新推开，房门吱嘎作响，孩子们也回来玩耍了。正当你以为秩序已经恢复时，一位老妇人吼道：%SPEECH_ON%佣兵也不过是换个名字的野蛮人罢了！%SPEECH_OFF%你叹了口气，让 %employer% 给钱。 | %employer% 正在研究几卷卷轴。他一边记笔记，一边划掉另一些内容。他抬头解释说，他正要把你载入史册，记作“前往荒原屠杀野蛮人，手段极其得体且极具南方风范的英雄”。他问你叫什么名字。你让他付你应得的报酬。 | %employer% 正陪着一群泣不成声的女人。他安慰着她们，当你进入时，他站起身指着你对她们说：%SPEECH_ON%看呐！就是这个人干掉了杀害你们丈夫的凶手！%SPEECH_OFF%女人们哀嚎着接连向你围拢过来，你除了严肃而冷静地克制点头外，不知该如何是好。%employer% 是人群中最后一个走向你的，他手臂里夹着一箱克朗，脸上带着一丝狡黠的微笑。你拿了报酬，他则回到女人堆里。%SPEECH_ON%好了好了，女士们，世界将迎来新的黎明。请随我来，有人想喝点酒吗？%SPEECH_OFF% | %employer% 张开双臂欢迎你。你拒绝了拥抱，并索要报酬。他回到了书桌后。%SPEECH_ON%我并没打算抱你，佣兵。%SPEECH_OFF%他有些垂头丧气地敲了敲箱子。%SPEECH_ON%但你杀那些野蛮人确实干得漂亮。我有好几个斥候汇报说，你在那儿度过了一段“非常愉快的时光”。这是你应得的。%SPEECH_OFF%他把箱子推过桌面，你隔着一段距离接过来，感觉到他在抓着箱子时还有一丝轻微的抗拒。你匆忙离开房间，没再看他一眼。 | 你费了好大的劲才找到 %employer% ，最后发现他正半吊在井筒里，用一块石板堵住一个洞。他冲上面喊道：%SPEECH_ON%啊，佣兵。伙计们，把我拉上去！%SPEECH_OFF%滑轮组吊起了他坐着的木板。他晃动双腿跨出井口，坐在井沿上休息。%SPEECH_ON%我们的石匠被驴踢死了，所以我打算亲自搭把手。没什么比干点粗活更能让一个好汉在早晨精神抖擞的了。%SPEECH_OFF%\n他用戴着手套的手拍了拍你的胸口，留下了一个粉尘印记。他点点头，叫来一名仆人去取你的酬金。%SPEECH_ON%干得好，佣兵。非常、非常好。嘿。%SPEECH_OFF%你没理会他的幽默。 | 你发现 %employer% 正在向一群农民发表演讲。他讲述了一支无名的南方力量如何向北进军并消灭了野蛮人杂种的故事。在演讲中，从头到尾都没提到你或 %companyname% 的名字。当他讲完时，那群乡巴佬欢呼鼓掌，鲜花四散，到处是一派节日气氛。%employer% 找到你，一边和你握手一边把一箱克朗推向你。%SPEECH_ON%我倒想在这群淳朴的人面前称你为英雄，但佣兵的名声向来不太好。 %SPEECH_OFF%你接过酬金，身体前倾说道：%SPEECH_ON%我只要钱。祝你玩得开心，%employer%。%SPEECH_OFF% | 你发现 %employer% 正在参加一场葬礼。他们正在点燃一座堆着三具尸体的柴堆，或许还有第四具小的，可能是一家子。%employer% 说了几句悼词，然后点燃了木架。一名仆人带着一箱克朗突然出现在你面前。%SPEECH_ON%%employer% 不希望被打扰。这是你的报酬，佣兵。如果不放心，请清点一下数额。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "你摧毁了一个野蛮人营地。" + this.Contract.m.Home.getName());
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.Contract.m.Reward = this.Contract.m.Payment.getOnCompletion();
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Reward + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"reward",
			this.m.Reward
		]);
		_vars.push([
			"original_reward",
			this.m.OriginalReward
		]);
		_vars.push([
			"barbarianname",
			this.m.Flags.get("ChampionName")
		]);
		_vars.push([
			"champbrother",
			this.m.Flags.get("ChampionBrotherName")
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive() ? "" : this.Const.Strings.Direction8[this.m.Home.getTile().getDirection8To(this.m.Destination.getTile())]
		]);
	}

	function onHomeSet()
	{
		if (this.m.SituationID == 0)
		{
			this.m.SituationID = this.m.Home.addSituation(this.new("scripts/entity/world/settlements/situations/ambushed_trade_routes_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);
			}

			this.m.Home.getSprite("selection").Visible = false;
		}

		if (this.m.Home != null && !this.m.Home.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Home.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			return true;
		}
		else
		{
			return true;
		}
	}

	function onSerialize( _out )
	{
		_out.writeI32(0);

		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		_in.readI32();
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

