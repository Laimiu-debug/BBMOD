this.drive_away_nomads_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Dude = null,
		Reward = 0
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.drive_away_nomads";
		this.m.Name = "驱逐游牧民";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		local banditcamp = this.World.FactionManager.getFactionOfType(this.Const.FactionType.OrientalBandits).getNearestSettlement(this.m.Home.getTile());
		this.m.Destination = this.WeakTableRef(banditcamp);
		this.m.Flags.set("DestinationName", banditcamp.getName());
		this.m.Payment.Pool = 600 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult();

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"前往 %origin% 的 %direction%，驱逐位于 " + this.Flags.get("DestinationName") + " 的游牧民"
				];
				this.Contract.setScreen("Task");
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				this.Contract.m.Destination.clearTroops();
				this.Contract.m.Destination.setLastSpawnTimeToNow();

				if (this.Contract.getDifficultyMult() <= 1.15 && !this.Contract.m.Destination.getFlags().get("IsEventLocation"))
				{
					this.Contract.m.Destination.getLoot().clear();
				}

				this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.NomadDefenders, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setLootScaleBasedOnResources(110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
				this.Contract.m.Destination.setResources(this.Math.min(this.Contract.m.Destination.getResources(), 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult()));
				this.Contract.m.Destination.setDiscovered(true);
				this.Contract.m.Destination.resetDefenderSpawnDay();
				this.World.uncoverFogOfWar(this.Contract.m.Destination.getTile().Pos, 500.0);
				local r = this.Math.rand(1, 100);

				if (r <= 10)
				{
					if (this.Contract.getDifficultyMult() >= 0.95 && this.World.Assets.getBusinessReputation() > 700)
					{
						this.Flags.set("IsSandGolems", true);
					}
				}
				else if (r <= 25)
				{
					if (this.Contract.getDifficultyMult() >= 0.95 && this.World.Assets.getBusinessReputation() > 300)
					{
						this.Flags.set("IsTreasure", true);
						this.Contract.m.Destination.clearTroops();
						this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.NomadDefenders, 150 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}
				}
				else if (r <= 35)
				{
					if (this.World.Assets.getBusinessReputation() > 800)
					{
						this.Flags.set("IsAssassins", true);
					}
				}
				else if (r <= 45)
				{
					if (this.World.getTime().Days >= 3)
					{
						this.Flags.set("IsNecromancer", true);
						this.Contract.m.Destination.clearTroops();
						local zombies = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Zombies);
						this.World.FactionManager.getFaction(this.Contract.m.Destination.getFaction()).removeSettlement(this.Contract.m.Destination);
						this.Contract.m.Destination.setFaction(zombies.getID());
						zombies.addSettlement(this.Contract.m.Destination.get(), false);
						this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.NecromancerSouthern, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
					}
				}
				else if (r <= 50)
				{
					this.Flags.set("IsFriendlyNomads", true);
				}

				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
					this.Contract.m.Destination.setOnCombatWithPlayerCallback(this.onDestinationAttacked.bindenv(this));

					if (this.Flags.get("IsNecromancer"))
					{
						this.Contract.m.Destination.m.IsShowingDefenders = false;
					}
				}
			}

			function update()
			{
				if (this.Contract.m.Destination == null || this.Contract.m.Destination.isNull())
				{
					if (this.Flags.get("IsTreasure"))
					{
						this.Flags.set("IsTreasure", false);
						this.Contract.setScreen("Treasure2");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						this.Contract.setState("Return");
					}
				}
			}

			function onDestinationAttacked( _dest, _isPlayerAttacking = true )
			{
				if (this.Flags.get("IsSandGolems"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("SandGolems");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						properties.Music = this.Const.Music.OrientalBanditTracks;
						properties.EnemyBanners.push(this.Contract.m.Destination.getBanner());
						local e = this.Math.max(1, 70 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult() / this.Const.World.Spawn.Troops.SandGolem.Cost);

						for( local i = 0; i < e; i = ++i )
						{
							properties.Entities.push({
								ID = this.Const.EntityType.SandGolem,
								Variant = 0,
								Row = -1,
								Script = "scripts/entity/tactical/enemies/sand_golem",
								Faction = this.Const.Faction.Enemy
							});
						}

						this.World.Contracts.startScriptedCombat(properties, true, true, true);
					}
				}
				else if (this.Flags.get("IsTreasure") && !this.Flags.get("IsAttackDialogTriggered"))
				{
					this.Flags.set("IsAttackDialogTriggered", true);
					this.Contract.setScreen("Treasure1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsNecromancer") && !this.Flags.get("IsAttackDialogTriggered"))
				{
					this.Flags.set("IsAttackDialogTriggered", true);
					this.Contract.setScreen("Necromancer");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsAssassins"))
				{
					if (!this.Flags.get("IsAttackDialogTriggered"))
					{
						this.Flags.set("IsAttackDialogTriggered", true);
						this.Contract.setScreen("Assassins");
						this.World.Contracts.showActiveContract();
					}
					else
					{
						local properties = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						properties.Music = this.Const.Music.OrientalBanditTracks;
						properties.EnemyBanners.push(this.Contract.m.Destination.getBanner());
						local e = this.Math.max(1, 30 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult() / this.Const.World.Spawn.Troops.Assassin.Cost);

						for( local i = 0; i < e; i = ++i )
						{
							properties.Entities.push({
								ID = this.Const.EntityType.Assassin,
								Variant = 0,
								Row = 2,
								Script = "scripts/entity/tactical/humans/assassin",
								Faction = this.Contract.m.Destination.getFaction()
							});
						}

						this.World.Contracts.startScriptedCombat(properties, true, true, true);
					}
				}
				else
				{
					this.World.Contracts.showCombatDialog();
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"返回" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_163.png[/img]{{没有喇叭奏乐，没有庆贺彩纸，也没有欢呼，但当你进入 %employer% 的房间时，仍然有着相当讲究的排场。 房内装饰着金银，尽是名匠打造的精美珠宝，还有一群百里挑一的美人。这一切奢华景象足以激起任何人的动力，哪怕只是为了有机会过上这种日子，为此你也甘愿做任何事儿。%employer% 坐在层层叠叠的靠垫上。%SPEECH_ON%啊，逐币者。我一直在等你。请站远点，你会吓着我的宝贝们。我有一件简单的差事交给你。游牧民一直在劫掠我的商队，导致我金库里的克朗缩水了不少。我想你一定能理解被抢劫的滋味，对吧？啊，你看起来可真够呆的。一脸茫然。这么说吧，和你干的活有关。我需要那些游牧民死，我愿意支付 %reward% 克朗来作为报酬。这种价码，能让你那颗脑袋瓜子听懂吗？%SPEECH_OFF% | %employer% 半坐在丝绸软垫的宝座上，半躺在一群美人的身体上。他抬起手。%SPEECH_ON%停，你们这些逐币者要是再敢离我近点，那么你们就是不知分寸了，知道吧？ 聪明人知道自己的位置。我有个简单的任务要交给你。 %townname% 城外的游牧民开始干些偷鸡摸狗、打家劫舍的勾当了。只要你出面干掉这些让我生活不顺心的家伙，我会给你一份丰厚的赏钱。%SPEECH_OFF% | %employer% 正在给笼子里的一只鸟喂食。那只鸟羽色斑斓，有些颜色你甚至怀疑自己从未见过。察觉到了你的存在，或者可能是闻到了你身上的气味，%employer% 带着一丝厌恶转过身来。%SPEECH_ON%你吓到我的宝贝鸟儿了，逐币者，为了不让它受惊，我会长话短说。有些游牧民在我领地的边缘游荡，我需要他们被死个干净。 我知道你们，呃，你们这种人，应该会很乐意接下这种活儿吧？%SPEECH_OFF% | 你进入 %employer% 的房间。他正吃着水果，下半身埋在一群美人之中，一群侍妾正吵吵闹闹地服侍着他。你在旁边站了太久，刚准备开口，那男人就举手制止了你。他指了指其中一名仆人，打了个响指。那名仆人穿着丝底凉鞋，悄无声息地穿过大理石地面小跑过来。他递给你一张纸，上面写着：%SPEECH_ON%致有意前来的逐币者，游牧民近期骚扰 %townname% 周边的安宁。现招募人手即刻处理此事，赏金 %reward%。无意者请立即离去。%SPEECH_OFF%仆人看着你，等待你的答复。 | 当你进入 %employer% 的房间时，他叹了口气。%SPEECH_ON%啊，是逐币者啊，我都差点忘了我邀请过你们，让你们来毁掉我今天的雅兴。%SPEECH_OFF%你盯着这位维齐尔，他似乎累得连动都懒得动一下，陷在由无数软垫和一群不停帮他拍打软垫的美人构成的‘海洋’里。%SPEECH_ON%好吧，既然来了，我就勉强浪费一个小时把这事办了。游牧民正在劫掠我的商队，就像他们这种流民一贯的做法那样，搞得我的市场上缺了不少我想买的货。我出 %reward% 克朗，作为找到并干掉这些满身沙尘的害虫的奖赏。%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们再谈谈报酬的事。 | 我能彻底解决这个麻烦。}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{不感兴趣。 | 我们有更要紧的事处理。 | 祝你们好运，但我们不会掺和这件事。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Treasure1",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_54.png[/img]{这些游牧民的数量多的惊人，且反常地停留在原地，但原因很快便浮出水面：你发现这些沙漠居民正簇拥在地面的一个深洞周围。他们在洞口架起了起重滑轮，正狂热地忙碌着，试图把他们在沙漠中发现的宝贝拽上来。从负责监督的那个人脸上的笑容来看，那毫无疑问是一处藏宝地。\n\n你可以现在发动攻击，但会面临更顽强的抵抗，或者你也可以等他们完事，带着挖出来的东西离开后再动手。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我们现在进攻！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				},
				{
					Text = "我们等到他们完事，等营地防御没那么严密了再说。",
					function getResult()
					{
						return "Treasure1A";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Treasure1A",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_54.png[/img]{你耐心地等待游牧民将财宝拉出来。不出所料，那是一个箱子。当他们撬开箱子时，脸上露出了一丝满意的神情。同样不出所料，游牧民随后分兵了，其中一队最强壮的人带着财宝离开，大概是打算去哪里脱手。现在，游牧民的营地实力大减，防御也变得脆弱不堪，正适合发起进攻……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "准备进攻！",
					function getResult()
					{
						this.Flags.set("IsTreasure", false);
						this.Contract.m.Destination.clearTroops();
						this.Contract.addUnitsToEntity(this.Contract.m.Destination, this.Const.World.Spawn.NomadDefenders, 110 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult());
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Treasure2",
			Title = "战斗之后…",
			Text = "[img]gfx/ui/events/event_168.png[/img]{把所有游牧民干掉后，你自然要去看看他们到底从地底下挖出了什么鬼东西。你站在他们架起的滑轮旁，俯视着那个深洞。可以看到一个箱子正躺在洞底，绳索早已将其牢牢缚住。你对着那些死去的游牧民‘致谢’，感谢他们替你完成了所有的重活，随后转身轻而易举地将箱子从土里拉了出来。你将其开启，发现里面竟然是……}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "宝藏！",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				local e = 2;

				for( local i = 0; i < e; i = ++i )
				{
					local item;
					local r = this.Math.rand(1, 4);

					switch(r)
					{
					case 1:
						item = this.new("scripts/items/loot/ancient_gold_coins_item");
						break;

					case 2:
						item = this.new("scripts/items/loot/silverware_item");
						break;

					case 3:
						item = this.new("scripts/items/loot/jade_broche_item");
						break;

					case 4:
						item = this.new("scripts/items/loot/white_pearls_item");
						break;
					}

					this.World.Assets.getStash().add(item);
					this.List.push({
						id = 10,
						icon = "ui/items/" + item.getIcon(),
						text = "你获得了" + item.getName()
					});
				}
			}

		});
		this.m.Screens.push({
			ID = "SandGolems",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_160.png[/img]{正当你准备发起进攻时，一个男人突然从沙堆中窜了出来。他惊惶失措，猛地躲闪并尖叫着滚下沙丘，向游牧民的营地冲去。你亮出武器紧追其后，准备将其击杀。在颠簸的余光中，你看到那些游牧民正连滚带爬地翻过同伴、撞倒帐篷，急于寻回自己的武器。当你再次看向那个哨兵时，他突然消失在流沙的吞噬中，紧接着一只与沙丘相连的巨臂从地底伸出，在你面前拔地而起，形体上不断滑落着尘土与黄沙。\n\n你简直不敢相信自己的眼睛，但那些游牧民似乎都在尖叫着同一个词：‘伊弗利特！伊弗利特！伊弗利特！’而这个面目模糊、仿佛无穷无尽的‘伊弗利特’，在即将到来的战斗中显然不属于任何一方。 | 你冲下沙丘，向游牧民发起冲锋。他们惊恐万分，大声发号施令并奔向武器。当你靠近营地时，一股沙尘暴席卷了营地的一角，几名游牧民被掀飞到空中。紧接着一秒钟后，一块巨石从尘云中飞射而出，将一名游牧民彻底砸成了肉泥。一个巨大的砂砾形成的怪物怒吼着大步向前。‘伊弗利特！伊弗利特！’游牧民们尖叫着，你意识到这个‘伊弗利特’不会站在任何人那一边。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Assassins",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_165.png[/img]{你冲进营地时，正巧看到一名黑衣男子从其中一座帐篷里走出来。他正与游牧民首领握手——这显然不是什么好兆头。而那两人在握手中途停下、齐刷刷盯着你发起的进攻，这显然不是什么好兆头。游牧民首领大声呼喝，要求他的刺客们拿出表现来证明自己没白拿钱。那名黑衣杀手点点头，抽出一柄利刃，随后一队同样打扮的刺客相继从帐篷中涌出，加入了游牧民的阵营并投入战斗!}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "冲锋！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Necromancer",
			Title = "在攻击前…",
			Text = "[img]gfx/ui/events/event_161.png[/img]{破碎的帐篷。散架的篮筐。在沙地上翻滚的衣物。而在这一切混乱的中心，坐着一名身披黑袍的男子，他那张阴森恐怖的脸从兜帽的阴影中窥视着一切。%SPEECH_ON%你来得正是时候，却也晚了一步。%SPEECH_OFF%他一边说着一边站起身来。篷布沙沙作响，篮筐倾斜，衣物猛地被掀开，这片土地瞬间充满了诡异的‘生机’。突然间，沙子滑入地下的深坑通道，那些充满敌意的游牧民从地底倾巢而出，他们爬出地面，有的纵身跃起仿佛要靠呼吸新鲜空气来复活，有的则像旗杆一样笔直地从脚跟向脚尖挺起。他们的动作极不自然，僵硬且歪斜，而那个黑衣人则在这些蹒跚而行的方阵后露出了狰狞的笑容。他可不是普通的无赖，而是一名亡灵巫师！}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						this.Contract.getActiveState().onDestinationAttacked(this.Contract.m.Destination, false);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{一名仆人拦住了你去见 %employer% 的路。他递给你一份卷轴和一个钱袋。尽管已经把东西交到了你手里，那仆人还是背着手，盯着天花板背诵道：%SPEECH_ON%根据此前的约定，给予那个逐币者 %reward_completion% 克朗作为酬劳。领了报酬之后，让他即刻离开这里。%SPEECH_OFF%仆人低下头看着你，点了点头。%SPEECH_ON%滚吧。%SPEECH_OFF%他说道。 | 你试图进入 %employer% 的房间，的房间，但一名满脸伤疤的壮硕卫兵将长柄武器的刀刃横在门前。%SPEECH_ON%禁止入内。%SPEECH_OFF%你声明自己与维齐尔有公事要办。卫兵摇了摇头。一名仆人从你身后走来，将一个钱袋塞进你怀里，随后便飞速离去。卫兵将长矛收回身侧。%SPEECH_ON%当你第一次离开这里时，你与维齐尔之间的那点琐事就一笔勾销了。别再留在这里破坏他的兴致，立刻离开。趁你还没破坏他的心情之前。%SPEECH_OFF% | 当你靠近 %employer% 的房间时，大厅对面传来一个女人的击掌声。你望过去，发现她已经走到了近前。四只鸟停在她的肩头，随着她的步伐微微晃动。%SPEECH_ON%逐币者。%SPEECH_OFF%她拿出一个钱袋递了过来。%SPEECH_ON%%employer% 没必要再忍受你身上的气味了，让你到这里已经是极限了，如果你想侮辱我们，就当面数钱，如果你想讨好我们，就拿钱走人。%SPEECH_OFF%她随即转身走开，那件异域风情的长裙随之摇曳。其中一只鸟在她的肩膀上转过身，对着你发出了一声尖叫。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "行吧，反正克朗到手了。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "摧毁了一个游牧营地。");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
				this.Contract.m.SituationID = this.Contract.resolveSituation(this.Contract.m.SituationID, this.Contract.m.Home, this.List);
			}

		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"totalenemy",
			this.m.Destination != null && !this.m.Destination.isNull() ? this.beautifyNumber(this.m.Destination.getTroops().len()) : 0
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive() ? "" : this.Const.Strings.Direction8[this.m.Home.getTile().getDirection8To(this.m.Destination.getTile())]
		]);
	}

	function onHomeSet()
	{
		if (this.m.SituationID == 0 && this.World.getTime().Days > 3 && this.Math.rand(1, 100) <= 50)
		{
			this.m.SituationID = this.m.Home.addSituation(this.new("scripts/entity/world/settlements/situations/ambushed_trade_routes_situation"));
		}
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
				this.m.Destination.setOnCombatWithPlayerCallback(null);

				if (this.m.Flags.get("IsNecromancer"))
				{
					local nomads = this.World.FactionManager.getFactionOfType(this.Const.FactionType.OrientalBandits);
					this.World.FactionManager.getFaction(this.m.Destination.getFaction()).removeSettlement(this.m.Destination);
					this.m.Destination.setFaction(nomads.getID());
					nomads.addSettlement(this.m.Destination.get(), false);
				}
			}

			this.m.Home.getSprite("selection").Visible = false;
		}

		if (this.m.Home != null && !this.m.Home.isNull() && this.m.SituationID != 0)
		{
			local s = this.m.Home.getSituationByInstance(this.m.SituationID);

			if (s != null)
			{
				s.setValidForDays(4);
			}
		}
	}

	function onIsValid()
	{
		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			return true;
		}
		else
		{
			return true;
		}
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		this.contract.onDeserialize(_in);
	}

});

