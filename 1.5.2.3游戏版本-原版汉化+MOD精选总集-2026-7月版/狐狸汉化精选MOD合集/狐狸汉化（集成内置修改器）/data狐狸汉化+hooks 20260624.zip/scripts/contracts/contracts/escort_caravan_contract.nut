this.escort_caravan_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null,
		Caravan = null,
		NobleHouseID = 0,
		NobleSettlement = null,
		IsEscortUpdated = false
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.escort_caravan";
		this.m.Name = "护送商队";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
		this.m.MakeAllSpawnsAttackableByAIOnceDiscovered = true;
	}

	function onImportIntro()
	{
		this.importSettlementIntro();
	}

	function start()
	{
		local nobleHouses = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);

		foreach( i, h in nobleHouses )
		{
			if (h.getSettlements().len() == 0)
			{
				continue;
			}

			if (this.m.Home.getOwner() != null && this.m.Home.getOwner().getID() == h.getID())
			{
				nobleHouses.remove(i);
				break;
			}
		}

		if (nobleHouses.len() != 0)
		{
			this.m.NobleHouseID = nobleHouses[this.Math.rand(0, nobleHouses.len() - 1)].getID();
		}

		local name = this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)] + "冯" + this.World.FactionManager.getFaction(this.m.NobleHouseID).getNameOnly();
		this.m.Flags.set("NobleName", name);
		local settlements = this.World.EntityManager.getSettlements();
		local bestDist = 9000;
		local best;

		foreach( s in settlements )
		{
			if (!s.isDiscovered() || !s.isMilitary())
			{
				continue;
			}

			if (s.getID() == this.m.Destination.getID())
			{
				continue;
			}

			if (s.getOwner() != null && s.getOwner().getID() == this.m.NobleHouseID)
			{
				local d = this.getDistanceOnRoads(s.getTile(), this.m.Home.getTile());

				if (d < bestDist)
				{
					bestDist = d;
					best = s;
				}
			}
		}

		if (best != null)
		{
			this.m.NobleSettlement = this.WeakTableRef(best);
			this.m.Flags.set("NobleSettlement", best.getID());
		}

		this.contract.start();
	}

	function setup()
	{
		local settlements = this.World.EntityManager.getSettlements();
		local candidates = [];

		foreach( s in settlements )
		{
			if (s.getID() == this.m.Origin.getID())
			{
				continue;
			}

			if (!s.isAlliedWith(this.getFaction()))
			{
				continue;
			}

			if (this.m.Origin.isIsolated() || s.isIsolated() || !this.m.Origin.isConnectedToByRoads(s) || this.m.Origin.isCoastal() && s.isCoastal())
			{
				continue;
			}

			local d = this.m.Origin.getTile().getDistanceTo(s.getTile());

			if (d <= 12 || d > 100)
			{
				continue;
			}

			local distance = this.getDistanceOnRoads(this.m.Origin.getTile(), s.getTile());
			local days = this.getDaysRequiredToTravel(distance, this.Const.World.MovementSettings.Speed * 0.6, true);

			if (days > 7 || distance < 15)
			{
				continue;
			}

			if (this.World.getTime().Days <= 10 && days > 4)
			{
				continue;
			}

			if (this.World.getTime().Days <= 5 && days > 2)
			{
				continue;
			}

			candidates.push(s);
		}

		if (candidates.len() == 0)
		{
			this.m.IsValid = false;
			return;
		}

		this.m.Destination = this.WeakTableRef(candidates[this.Math.rand(0, candidates.len() - 1)]);
		local distance = this.getDistanceOnRoads(this.m.Origin.getTile(), this.m.Destination.getTile());
		local days = this.getDaysRequiredToTravel(distance, this.Const.World.MovementSettings.Speed * 0.6, true);

		if (days >= 5)
		{
			this.m.DifficultyMult = this.Math.rand(115, 135) * 0.01;
		}
		else if (days >= 2)
		{
			this.m.DifficultyMult = this.Math.rand(95, 105) * 0.01;
		}
		else
		{
			this.m.DifficultyMult = this.Math.rand(70, 85) * 0.01;
		}

		this.m.Payment.Pool = this.Math.max(150, distance * 7.0 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult());
		local r = this.Math.rand(1, 3);

		if (r == 1)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else if (r == 2)
		{
			this.m.Payment.Count = 0.25;
			this.m.Payment.Completion = 0.75;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		local maximumHeads = [
			15,
			20,
			25,
			30
		];
		this.m.Payment.MaxCount = maximumHeads[this.Math.rand(0, maximumHeads.len() - 1)];
		this.m.Flags.set("HeadsCollected", 0);
		this.m.Flags.set("Distance", distance);
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"护送车队前往 %objective%，大约向 %direction% 行驶%days%",
					"战团的伙食将由商队提供"
				];
				local isSouthern = this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState;

				if (!isSouthern && this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else if (isSouthern)
				{
					this.Contract.setScreen("TaskSouthern");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				local isSouthern = this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState;
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 5)
				{
					if (this.World.Assets.getBusinessReputation() > 700 && !isSouthern)
					{
						this.Flags.set("IsStolenGoods", true);
						this.Flags.set("IsEnoughCombat", true);

						if (this.Contract.m.Home.getOwner() != null)
						{
							this.Contract.m.NobleHouseID = this.Contract.m.Home.getOwner().getID();
						}
						else if (this.Contract.m.Destination.getOwner() != null)
						{
							this.Contract.m.NobleHouseID = this.Contract.m.Destination.getOwner().getID();
						}
						else
						{
							local nobles = this.World.FactionManager.getFactionsOfType(this.Const.FactionType.NobleHouse);
							this.Contract.m.NobleHouseID = nobles[this.Math.rand(0, nobles.len() - 1)].getID();
						}
					}
				}
				else if (r <= 10)
				{
					if (this.World.Assets.getBusinessReputation() > 1000 && this.Contract.getDifficultyMult() >= 0.95)
					{
						this.Flags.set("IsVampires", true);
						this.Flags.set("IsEnoughCombat", true);
					}
				}
				else if (r <= 15)
				{
					this.Flags.set("IsValuableCargo", true);
				}
				else if (r <= 20)
				{
					if (this.Contract.m.NobleHouseID != 0 && this.Flags.has("NobleName") && this.Flags.has("NobleSettlement") && !isSouthern)
					{
						this.Flags.set("IsPrisoner", true);
					}
				}
				else if (this.Contract.getDifficultyMult() < 0.95 || this.World.Assets.getBusinessReputation() <= 500 || this.Contract.getDifficultyMult() <= 1.1 && this.Math.rand(1, 100) <= 20)
				{
					this.Flags.set("IsEnoughCombat", true);
				}

				this.Contract.spawnCaravan();
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
				this.World.State.setCampingAllowed(false);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = true;
				}

				if (this.Contract.m.Payment.Count != 0)
				{
					if (this.Contract.m.BulletpointsObjectives.len() >= 2)
					{
						this.Contract.m.BulletpointsObjectives.remove(1);
					}

					this.Contract.m.BulletpointsObjectives.push("你杀死的每一个攻击者的头颅都会得到报酬 (%killcount%/%maxcount%)");
				}

				this.World.State.setEscortedEntity(this.Contract.m.Caravan);
			}

			function update()
			{
				if (this.Contract.m.Caravan == null || this.Contract.m.Caravan.isNull() || !this.Contract.m.Caravan.isAlive() || this.Contract.m.Caravan.getTroops().len() == 0)
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
					return;
				}

				if (!this.Contract.m.IsEscortUpdated)
				{
					this.World.State.setEscortedEntity(this.Contract.m.Caravan);
					this.Contract.m.IsEscortUpdated = true;
				}

				this.World.State.setCampingAllowed(false);
				this.World.State.getPlayer().setPos(this.Contract.m.Caravan.getPos());
				this.World.State.getPlayer().setVisible(false);
				this.World.Assets.setUseProvisions(false);
				this.World.getCamera().moveTo(this.World.State.getPlayer())

				if (this.Flags.get("IsFleeing"))
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
					return;
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					if (this.Flags.get("IsCaravanHalfDestroyed"))
					{
						this.Contract.setScreen("Success2");
					}
					else
					{
						this.Contract.setScreen("Success1");
					}

					this.World.Contracts.showActiveContract();
				}
				else if (!this.Flags.get("IsEnoughCombat"))
				{
					if (this.Contract.spawnEnemies())
					{
						this.Flags.set("IsEnoughCombat", true);
					}
				}
				else
				{
					local parties = this.World.getAllEntitiesAtPos(this.World.State.getPlayer().getPos(), 400.0);
					local numParties = 0;

					foreach( party in parties )
					{
						numParties = ++numParties;
					}

					if (numParties > 2)
					{
						return;
					}

					if (this.Flags.get("IsStolenGoods") && this.World.State.getPlayer().getTile().HasRoad)
					{
						if (!this.TempFlags.get("IsStolenGoodsDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 1)
						{
							this.TempFlags.set("IsStolenGoodsDialogTriggered", true);
							this.Contract.setScreen("StolenGoods1");
							this.World.Contracts.showActiveContract();
						}
					}
					else if (this.Flags.get("IsVampires") && !this.World.getTime().IsDaytime)
					{
						if (!this.TempFlags.get("IsVampiresDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 2)
						{
							this.TempFlags.set("IsVampiresDialogTriggered", true);
							this.Contract.setScreen("Vampires1");
							this.World.Contracts.showActiveContract();
						}
					}
					else if (this.Flags.get("IsValuableCargo"))
					{
						if (!this.TempFlags.get("IsValuableCargoDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 1)
						{
							this.TempFlags.set("IsValuableCargoDialogTriggered", true);
							this.Contract.setScreen("ValuableCargo1");
							this.World.Contracts.showActiveContract();
						}
					}
					else if (this.Flags.get("IsPrisoner"))
					{
						if (!this.TempFlags.get("IsPrisonerDialogTriggered") && this.Contract.getDistanceToNearestSettlement() >= 6 && this.Math.rand(1, 1000) <= 1)
						{
							this.TempFlags.set("IsPrisonerDialogTriggered", true);
							this.Contract.setScreen("Prisoner1");
							this.World.Contracts.showActiveContract();
						}
					}
				}
			}

			function onCombatVictory( _combatID )
			{
				this.Flags.set("IsEnoughCombat", true);

				if (_combatID == "StolenGoods")
				{
					this.Flags.set("IsStolenGoods", false);
					this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).addPlayerRelation(this.Const.World.Assets.RelationAttacked, "杀了一些他们的人");
				}
				else if (_combatID == "Vampires")
				{
					this.Flags.set("IsVampires", false);
				}

				this.start();
				this.World.State.getWorldScreen().updateContract(this.Contract);
			}

			function onRetreatedFromCombat( _combatID )
			{
				this.Flags.set("IsEnoughCombat", true);
				this.Flags.set("IsFleeing", true);
				this.Flags.set("IsStolenGoods", false);
				this.Flags.set("IsVampires", false);

				if (_combatID == "StolenGoods")
				{
					this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).addPlayerRelation(this.Const.World.Assets.RelationAttacked, "攻击了他们手下的一些人");
				}

				if (this.Contract.m.Caravan != null && !this.Contract.m.Caravan.isNull())
				{
					this.Contract.m.Caravan.die();
					this.Contract.m.Caravan = null;
				}

				this.start();
				this.World.State.getWorldScreen().updateContract(this.Contract);
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_actor.getType() == this.Const.EntityType.CaravanDonkey && _actor.getWorldTroop() != null && _actor.getWorldTroop().Party.getID() == this.Contract.m.Caravan.getID())
				{
					this.Flags.set("IsCaravanHalfDestroyed", true);
				}
				else
				{
					this.Contract.addKillCount(_actor, _killer);
				}
			}

			function end()
			{
				this.World.State.setCampingAllowed(true);
				this.World.State.setEscortedEntity(null);
				this.World.State.getPlayer().setVisible(true);
				this.World.Assets.setUseProvisions(true);
				this.World.State.resetSpeedToNormal();

				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}

				this.Contract.clearSpawnedUnits();
			}

		});
		this.m.States.push({
			ID = "Running_Prisoner",
			function start()
			{
				if (this.Contract.m.Destination != null && !this.Contract.m.Destination.isNull())
				{
					this.Contract.m.Destination.getSprite("selection").Visible = false;
				}

				if (this.Contract.m.NobleSettlement != null && !this.Contract.m.NobleSettlement.isNull())
				{
					this.Contract.m.NobleSettlement.getSprite("selection").Visible = true;
				}

				this.Contract.m.BulletpointsObjectives = [
					"将 %noble% 安全送回位于 %nobledirection% 的 %noblesettlement%。"
				];
				this.Contract.m.BulletpointsPayment = [];
				this.Contract.m.BulletpointsPayment.push("到达目的地获得报酬");
			}

			function update()
			{
				if (this.Contract.isPlayerAt(this.Contract.m.NobleSettlement))
				{
					if (this.Flags.get("IsPrisonerLying"))
					{
						this.Contract.setScreen("Prisoner4");
					}
					else
					{
						this.Contract.setScreen("Prisoner3");
					}

					this.World.Contracts.showActiveContract();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationPerHeadAtDestination);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_98.png[/img]{%employer% 的书房里火炉烧得正旺。他为你让了一个座，并递过一盏葡萄酒，你顺手接了过来。%SPEECH_ON%佣兵，你应该很清楚这些日子路上有多不太平吧？%SPEECH_OFF%老天，这酒真不错。你点了点头，努力掩饰内心的惊讶。%employer% 略显僵硬地笑了笑，继续说道。%SPEECH_ON%很好，那你就能理解我交给你的这项任务了。我需要有人护送一支车队沿路前往 %objective%，去那儿大约需要%days%。挺简单的，对吧？你有时间接活儿吗？有的话我们谈谈。%SPEECH_OFF% | 你发现 %employer% 正在桌上研究几幅地图。他的手指沿着一张地图的边缘划过，一直延伸到另一张地图上。%SPEECH_ON%我需要有人护送车队去 %objective%，就在 %direction% 大约%days%路程。会危险吗？当然。这就是我找你的原因，佣兵。有兴趣吗？%SPEECH_OFF% | %employer% 抱起双臂，抿了抿嘴唇。%SPEECH_ON%通常我是不会请佣兵来守卫车队的，但我手下那帮老伙计最近指望不上——生病的、喝醉的、鬼混的……我想你懂我的意思。重要的是我有一批重要的货物要运往 %objective%，就在 %direction% 大约%days%路程，我需要有人盯着它。你有兴趣吗？%SPEECH_OFF% | %employer% 望着窗外，看着一群人正往几辆货车上装货。他头也不回地说道。%SPEECH_ON%我有一批重要的货物要运往 %objective%，就在 %direction% 大约%days%路程。不幸的是，一个竞争对手出价超过我，抢走了当地的一支车队护卫队。现在我需要你的服务。如果你感兴趣，我们来谈谈价钱。%SPEECH_OFF% | %employer% 从架子上抓起一个箱子放在桌上。当他打开箱子时，一大堆文件弹了出来，简直像是急着逃跑。他抓起一张铺开，一面是合同，另一面是一幅简易地图。%SPEECH_ON%这活儿很简单，佣兵。我承接了一份合同，要把一些……特殊的货物运到 %objective%。货我有，但我缺护卫。如果你有兴趣当一阵子车队护卫，大概%days%左右，跟我说一声，我们可以谈谈价钱。%SPEECH_OFF% | 你望向 %employer% 的窗外，看着工人们把货物装上货车。%employer% 走到你身边，手里拿着两盏葡萄酒。你接过一盏，仰头一饮而尽。那男人盯着你。%SPEECH_ON%那酒可不便宜，你应该慢慢品的。%SPEECH_OFF%你耸了耸肩。%SPEECH_ON%抱歉，能再给我来一杯让我重新品品吗？%SPEECH_OFF%%employer% 转身回到桌旁。%SPEECH_ON%那么，我需要有人护卫车队去 %objective%。就在 %direction% 大约%days%路程。挺简单的，对吧？如果你愿意接，报酬少不了你的。%SPEECH_OFF% | %employer% 翻看着他的账本，查阅着大量数字。%SPEECH_ON%我有一批特殊货物要运往 %objective%，很快就要启程了。我需要一批强悍的佣兵来确保它安全抵达。这大概需要%days%。 你干得了吗?%SPEECH_OFF% | %employer% 开门见山地说道。%SPEECH_ON%我有一批货要送……至于是什么，你没必要知道。它要被运往 %objective%。像大多数人一样，我也担心路上的强盗。我需要你盯好车队，并确保它在%days%后平安抵达。听起来像是你会感兴趣的活儿吗？%SPEECH_OFF% | %employer% 望着窗外。%SPEECH_ON%我们都清楚，强盗和各种鬼知道什么玩意正搅得这片地区鸡犬不宁，而且他们都特别喜欢盯着大路。在经历了几次惨痛的损失后，我以前的护卫们都吓破了胆。现在我需要别人来照看我的货物。下一趟是去 %direction% 的 %objective%，大概需要%days%。那地方听起来像是你想去赚一笔的样子吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈价钱。 | 你打算出多少克朗？ | 报酬给多少？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{不感兴趣。 | 这不是我们想找的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "TaskSouthern",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_98.png[/img]{钟楼与鸟舍交相林立，钟鸣与鸟啼在空中回荡，宛如一座囚城中散漫的晨祷。喧嚣之下，在宫殿那冷清的大理石厅堂里，你发现 %employer% 在下令处死一个仆人。你并不清楚他的罪名，但维齐尔对此浑不在意，他面带微笑、双手洁净地向你走来。%SPEECH_ON%几位议员正准备将货物送往 %objective%，就在 %direction% 大约%days%路程。这些货物送到等待的商人手中时，必须保持完好。我相信像你这样的逐币者可以干好这活，对吧？%SPEECH_OFF% | 你见到了维齐尔 %employer%，手下的几位议员和市政官。他们拿着一份盖有他纹章的文件向你走来。%SPEECH_ON%我们很快就要带着一支货运车队前往 %objective%，。城里的卫兵拒绝协助我们保护商品，但我们在镀金者的注视下依然熠熠生辉，口袋里也装满了金币。我们会付钱给你，逐币者，雇你在接下来的%days%里护送我们到达目的地。%SPEECH_OFF% | 一个仆从孩子一手牵着一串奴隶，另一手拿着一张便条。他呈上了后者，上面写着与一群商人会面的指令。商人们宣布，根据镀金者和维齐尔的共同命令，他们正准备前往 %objective%，就在 %direction% 大约%days%路程，并且需要保护。为此，他们需要你的能力，并会支付相当丰厚的报酬。 | 城里的广场生意兴隆，显然，他们也想让你分一杯羹。几位维齐尔手下最精明的商人正打算带一支车队前往 %objective%，大概%days%路程。其中一人简短地解释道。%SPEECH_ON%如果镀金者能视而不见，那我祈祷这城里所谓的士兵都去死好了。你，逐币者，我猜你愿意在别人退缩时帮我们一把？当然，是为了钱。%SPEECH_OFF% | 你看着奴隶们把货物捆扎好装入一连串货车中。车主们发现了你并找上门来，他们推开挡路的劳工，或者毫无理由地扇他们巴掌——似乎仅仅因为这样做能带来某种莫名的快感。其中一人在向你打招呼时满脸堆笑。他伸出一只手，但你没有去握。%SPEECH_ON%啊，逐币者，这只手确实因为碰触奴隶的身体而被玷污了，但你没必要这样拘谨。在镀金者的注视下，我们不都一样熠熠生辉？ 我们有一个活儿交给你，考虑到我们领主 %employer% 的治理，这活儿非常重要。车队正前往 %objective%，大概%days%路程，并且需要足够的护卫确保安全抵达。这项活儿符合你对金币的追求吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈价钱。 | 你打算出多少克朗？ | 报酬给多少？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{不感兴趣。 | 这不是我们想找的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "StolenGoods1",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{一群打着 %noblehouse% 旗号的人出现在道路上。他们的马匹拴在路边，缰绳散落在泥土里，看起来已经等候多时了。其中一人走上前，双手叉腰。%SPEECH_ON%伙计们，你们运送的是赃物，是属于 %noblehouse% 的赃物。立刻交出来，否则后果自负。%SPEECH_OFF%哼，你早该想到 %employer% 运送的东西肯定没那么干净。 | 几个人拦在了路中央。他们带着 %noblehouse% 的旗帜，这恐怕不是什么好兆头。对方的副官走到你们面前。%SPEECH_ON%诸位好！很不凑巧，你们运送的是属于 %noblehouse% 的赃物。离车队远点，原路返回。照做，你们就能活，留下，你们就得死。%SPEECH_OFF% | 看来 %employer% 对你并没完全说实话：一群举着 %noblehouse% 旗帜的士兵拦住了你们，质问你们为什么要运送从他们那儿偷来的货物。他们的副官对着你们大喊。%SPEECH_ON%如果你们还想见到明天的太阳，就交出货物，原路返回。我明白你们只是拿钱办事，但你们的职责可不包括违抗我。如果非要和我对着干，我保证，你们今天全都得死在这儿。%SPEECH_OFF% | 一个男人挡在路中央，丝毫没有让路的意思。一个车夫拉紧了缰绳，就在此时，一大群武装人员加入到了那个拦路人的行列中。他们佩戴着 %noblehouse% 的纹章。%SPEECH_ON%原来 %noblehouse的货物都跑到这儿来了。伙计们，你们运的东西可是属于我们家族的。想活的话，就统统交出来，想死的话，那就尽管拒绝我的要求，看看会有什么下场。%SPEECH_OFF%%randombrother% 走到你身边，低声说道。%SPEECH_ON%我们就不该信 %employer% 那个杂种。%SPEECH_OFF% | 你确实应该再加把劲打听清楚自己运的是什么。一群人在路上截住了你，要求你交出车队并原路返回。当你询问是谁提出的要求时，他们声明自己来自 %noblehouse%，并称你们运送的每一件货物都是一周前被偷的。他们的副官给出了和平解决的方案。%SPEECH_ON%离开这儿，你们就能活。我跟你们这些人没仇，只跟你们的雇主有账要算。但如果你们妨碍我们收回它，你们就得死。别为了不属于你们的货丢了命，不值。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "我可不这么想。如果有必要，我们会血战到底。",
					function getResult()
					{
						return "StolenGoods2";
					}

				},
				{
					Text = "那点报酬还不值得让我们和 %noblehouse% 为敌。东西你们拿走吧。",
					function getResult()
					{
						return "StolenGoods3";
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getUIBannerSmall();

				if (this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getPlayerRelation() >= 80)
				{
					this.Options.push({
						Text = "你的领主可不会希望看到他的盟友，%companyname%，像这样被你们拦在路上。",
						function getResult()
						{
							return "StolenGoods4";
						}

					});
				}
			}

		});
		this.m.Screens.push({
			ID = "StolenGoods2",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你点了点头。%SPEECH_ON%听起来确实挺有道理，但不幸的是，我们拿钱是来保护货物的，可不是来查清楚货到底归谁。%SPEECH_OFF%副官也点了下头，带着一种近乎理解的神情。%SPEECH_ON%那好吧。%SPEECH_OFF%他拔出了长剑，你也拔出了你的。那人举起手，准备下达命令。%SPEECH_ON%真遗憾最后闹成这样。冲锋！%SPEECH_OFF% | 你拔出了长剑。%SPEECH_ON%我来这儿不是为了在贵族之间当说客的。我的任务是护送这支车队前往 %objective%。如果你非要挡路，那么今天你就死在这吧。%SPEECH_OFF% | 你你朝货车队列挥了下手。%SPEECH_ON%%employer% 下令让我护送他的货物到达目的地，而这也正是我打算做的事。%SPEECH_OFF%你直视着副官，缓缓抽出了长剑。他也如法炮制，并点了点头。%SPEECH_ON%真遗憾非得闹到这一步。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos(), true);
						p.CombatID = "StolenGoods";
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.IsAutoAssigningBases = false;
						p.TemporaryEnemies = [
							this.Contract.m.NobleHouseID
						];
						p.EnemyBanners = [
							this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getPartyBanner()
						];

						foreach( e in p.Entities )
						{
							if (e.Faction == this.Contract.getFaction())
							{
								e.Faction = this.Const.Faction.PlayerAnimals;
							}
						}

						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Noble, 120 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.Contract.m.NobleHouseID);
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getUIBannerSmall();
			}

		});
		this.m.Screens.push({
			ID = "StolenGoods3",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{%employer% 肯定不会喜欢这个结果，但如果他运的是赃物，他早该告诉你的。你挥了挥手，命令弟兄们退到一旁。那些士兵立刻围拢到车队旁开始卸货，而那些无助的劳工和商人们只能眼巴巴地看着。 | 你可不想为了这些你根本不在乎的货物打一场恶战。你退到一旁，示意那些士兵带走本就属于他们的东西。%randombrother% 嘀咕道，%employer% 知道这事肯定会大发雷霆。你点了下头。%SPEECH_ON%哼，那是他的麻烦，不是我的。%SPEECH_OFF% | 你可不想做倒卖赃物的买卖，也不想杀掉那些跟你没仇的士兵。于是你无视了那几个商人的抗议，退到一旁，让车队及其货物物归原主。一个商人挥舞着拳头对你叫嚣，说 %employer% 听到你没有履行合同，肯定会非常恼怒。}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "真不走运。",
					function getResult()
					{
						this.Flags.set("IsStolenGoods", false);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能保护商队");
						this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).addPlayerRelation(this.Const.World.Assets.RelationNobleContractPoor, "与对方士兵达成协作");
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.updateAchievement("NeverTrustAMercenary", 1, 1);
				this.Banner = this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getUIBannerSmall();
			}

		});
		this.m.Screens.push({
			ID = "StolenGoods4",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_78.png[/img]{你告诉那些人，你与他们的 %noblehouse% 家族交情匪浅，完全无意闹僵这份关系。其中一个袭击者犹豫了。%SPEECH_ON%该死，他可能在撒谎，但万一是真的……那就不值得冒这个险了。我们走。%SPEECH_OFF% | 你简短而有力地告诉那些人，你对 %noblehouse% 家族非常熟悉，并随口点出了几位家族成员的名字。那些人收回了长剑，不想把局势搞得更乱。在这个世道，稳妥总比事后后悔强。 | 你让那些人知道你和 %noblehouse% 家族关系不错。他们要求你证明这一点，于是你列举了所有你能想到的贵族名字，甚至还顺带说了几个人的特殊癖好。证据足够充分了——袭击者放下了武器，不再找你们的麻烦。}",
			Image = "",
			List = [],
			Banner = "",
			Options = [
				{
					Text = "我们继续前进！",
					function getResult()
					{
						this.Flags.set("IsStolenGoods", false);
						return 0;
					}

				}
			],
			function start()
			{
				this.Banner = this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getUIBannerSmall();
			}

		});
		this.m.Screens.push({
			ID = "ValuableCargo1",
			Title = "露营时…",
			Text = "[img]gfx/ui/events/event_55.png[/img]{趁着车队休息，%randombrother% 拽着你的胳膊，神神秘秘地把你领到其中一辆货车后头。他四下张望确认没人注意到这边，随后掀开了一个木箱的盖子。里面的宝石叮当作响，在微弱的光线下闪烁着刺眼的光芒。他合上盖子。%SPEECH_ON%你打算怎么办？头儿，这可值不少钱啊。%SPEECH_OFF% | 当车队停下来修理车轮时，一根车轴突然折断，整辆货车侧翻在地。一个木箱哐当一声掉在地上，盖子被震开了。你抓起锤子正准备把它钉回去，却发现一堆宝石从箱子里滚了出来。%randombrother% 也看到了这一幕，他的手摸向了自己的武器。%SPEECH_ON%这批货……呃，成色可真够扎眼的，头儿。我们要把这事儿压下去，还是……？%SPEECH_OFF% | 车队领队突然尖叫起来。你看着他追上并猛地扑倒了一个正想开溜的家伙。两人在地上扭打成一团，像旋风一样纠缠在一起，这时一个棕色袋子从混乱中飞了出来。它正好落在你脚边，由于封口没扎紧，里面的宝石滚落了一地。%randombrother% 弯腰捡起了几颗。他直起身子，另一只手按在武器上，盯着你。%SPEECH_ON%这儿的东西多得是，你知道的，绝对值这个价……%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "在我动手抽你之前，给我滚回去干活。我们还有合同要履行。",
					function getResult()
					{
						this.Flags.set("IsValuableCargo", false);
						return 0;
					}

				},
				{
					Text = "终于，幸运女神向我们微笑了。这些宝石归我们了！",
					function getResult()
					{
						return "ValuableCargo2";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "ValuableCargo2",
			Title = "露营时…",
			Text = "[img]gfx/ui/events/event_50.png[/img]{一个车队护卫走了过来。%SPEECH_ON%嘿伙计们，咱们该让这支队伍重新上路了，对吧？%SPEECH_OFF%你对着你的佣兵部下使了个眼色。他心领神会地回了个礼，随后猛地转身，将一把匕首狠狠地刺进了那个护卫的下巴。佣兵团的其他成员立刻意识到发生了什么，纷纷拔出武器扑向护卫们。对方根本没有还手之力，当这场血洗结束后，你成了那些璀璨宝石的新主人。 | 宝石的魔力彻底征服了你！随着一声简短的示意和呐喊，你命令 %companyname% 杀光所有的护卫。过程异常迅速，毕竟他们之前还完全信任你们能提供保护，有几个人倒下时甚至还在质问，为什么要如此残暴地背叛他们。 | 这些宝石的价值远超任何合同能给你的报酬。你放开嗓门大声下达命令，让 %companyname% 杀光视线内的每一个护卫。你的部下行动迅速、毫无迟疑，而那些护卫则反应迟钝、满脸困惑。转瞬之间，宝石都归你了。%employer% 肯定会大发雷霆，但去他的吧，你现在有宝石了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "这些应该值很多克朗。",
					function getResult()
					{
						this.Flags.set("IsValuableCargo", false);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationBetrayal, "屠杀了一个负责保护的商队");
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractBetrayal);
						this.World.Assets.addMoralReputation(-10);
						this.Contract.m.Caravan.die();
						this.Contract.m.Caravan = null;
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				local n = this.Math.min(this.Math.max(1, this.World.Assets.getBusinessReputation() / 1000), 3) + 1;

				for( local i = 0; i != n; i = ++i )
				{
					local gems = this.new("scripts/items/trade/uncut_gems_item");
					this.World.Assets.getStash().add(gems);
					this.List.push({
						id = 10,
						icon = "ui/items/" + gems.getIcon(),
						text = "你获得了" + gems.getName()
					});
				}
			}

		});
		this.m.Screens.push({
			ID = "Prisoner1",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_53.png[/img]{当你随车队行进时，看到几个护卫正往一个笼子里吐唾沫。里面关着一个男人，衣衫褴褛，双脚沾满泥土。他隔着仇恨的迷雾发现了你，哀求道。%SPEECH_ON%求你了，佣兵！我是 %noblehouse% 家族的 %noble%。只要你杀光这些人，你将得到极为丰厚的赏赐！%SPEECH_OFF%一个护卫嘲笑道。%SPEECH_ON%别信他的鬼话，佣兵。%SPEECH_OFF% | 你走过一辆货车时，突然有什么东西抓住了你的胳膊。你猛地转身，长剑已经在手，而那只紧抓不放的手则缩回了货车车厢的阴影里。你小心地掀开防水布，看到一个男人被锁在那里。他的声音沙哑难听，仿佛开口的第一句话就该是讨水喝。%SPEECH_ON%别在意我这身破烂，佣兵，我是 %noblehouse% 家族的 %noble%。杀光这些护卫，放我出去，送我回家。作为回报，我会给你很多克朗。%SPEECH_OFF%一个护卫打断了他的话，囚犯畏缩着退回了禁闭处。护卫笑道。%SPEECH_ON%那小杂种又在撒谎了吗？走吧，佣兵，前头还有很长的路要赶呢。%SPEECH_OFF% | 你听到其中一辆货车里传来呕吐声。过去查看时，你发现一个衣衫褴褛的男人蜷缩着身体，一个护卫在头顶得意地笑着。%SPEECH_ON%再敢用那种语气跟我说话，我就打掉你的牙让你吞下去。明白了吗，囚犯？%SPEECH_OFF%倒地的男人点了点头，向后挪了挪。他看到了你，随后虚弱地示意。%SPEECH_ON%佣兵，我是 %noblehouse% 家族的 %noble%。我相信你听过我的名号。如果你杀了这个没用的废物和他的同伙，我保证会给你一大笔钱。%SPEECH_OFF%那个护卫紧张地笑了笑。%SPEECH_ON%佣兵，一个字都别信他的！%SPEECH_OFF% | %SPEECH_ON%佣兵！能谈谈吗？%SPEECH_OFF%你转过身，惊讶地发现一辆货车的后部有个男人。他全身锁着铁链。%SPEECH_ON%我要让你知道，我是 %noblehouse% 家族的 %noble%。显然我遇到了一点小麻烦，但这拦不住你的，对吧？杀光这些护卫，把我送回家族。我想他们出的价绝对比你守着这狗屎车队拿到的赏钱要多得多。%SPEECH_OFF%其中一个卫兵走过来，笑道。%SPEECH_ON%唔，那杂种又在撒谎了？ 别理他，佣兵。来吧，回到工作上。%SPEECH_OFF% | 你听到了清晰的锁链声，那是金属环扣相互摩擦时发出的清脆响声，这种声音总让人觉得只要稍微一动就能重获自由。然而，一个并不自由的人正向你哀求。%SPEECH_ON%终于能跟你说上话了。佣兵，听着，你可能不信，但我是 %noblehouse% 家族的 %noble%。不知道这些人为什么要抓我，但那不重要。重要的是你要对得起你的名号，尤其是‘佣兵’的那个‘佣’字。如果你杀光这些护卫并带我回家，我保证你会得到丰厚的回报！%SPEECH_OFF%一个护卫走上前。%SPEECH_ON%闭嘴，你这杂种！别理他，佣兵。我们还有活要干，快走。%SPEECH_OFF% | 车队短暂休息时，你发现一个男人正躺着休息，腿从货车边垂了下来。只不过他的脚并不自由——双脚被铁链锁在一起，双手的境遇也好不到哪儿去。他看见了你。%SPEECH_ON%你认得我吗？我是 %noblehouse% 家族的 %noble%，一个价值不菲的俘虏，我相信我的名号已经暗示了这一点。但作为一个自由人，我的价值会更高。杀了这些护卫，带我回家，到那时候你口袋里的克朗多得让你路都走不动！%SPEECH_OFF%一个护卫走过来，用剑鞘拍打着那男人的小腿。%SPEECH_ON%老实点，你！快走，佣兵，我们准备重新上路了。别理这杂种，好吗？他嘴里没一句真话。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "别白费口舌了。老子才不在乎你到底是谁。",
					function getResult()
					{
						this.Flags.set("IsPrisoner", false);
						return 0;
					}

				},
				{
					Text = "救了你可得兑现你的承诺（67%概率为真，获得3000克朗）。",
					function getResult()
					{
						this.updateAchievement("NeverTrustAMercenary", 1, 1);
						return "Prisoner2";
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Prisoner2",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_60.png[/img]{{你吐了一口唾沫，清了清嗓子，随即长剑瞬间出鞘，将那个车队护卫砍倒在地。%randombrother% 见状，立即大声命令 %companyname% 的其余人马跟上。现场陷入了短暂而混乱的厮杀，车队护卫们还没搞清楚发生了什么，你的手下就已经扑向了他们。\n\n 解救囚犯后，他向你千恩万谢，并让你在前领路。%SPEECH_ON%只要我们到了 %noblesettlement%，等他们看到我这张活生生的笑脸，你就会被克朗淹没的！%SPEECH_OFF% | 你拔出长剑，砍到卫兵的脸上。他踉跄转身，你顺势将剑刃劈进了他的脑壳，脑浆在那倾斜的碎骨间翻涌喷溅，活像个炸裂的蛋奶酥。%randombrother% 目睹了这一幕，随即号召全团投入战斗。他们迅速解决掉了剩下的车队护卫。当你救出 %noble% 后，他指向道路前方。%SPEECH_ON%去 %noblesettlement%！我的家族会给你超乎想象的重赏！%SPEECH_OFF% | 当那个车队护卫转身时，你掏出匕首狠狠地扎进了他的腋下，直捅心脏。他咕哝了一句模糊不清的话，随后栽倒在地。另一个护卫闻声赶来，正撞见你的长剑将他开膛破肚。然而，他的惨叫声可没被捂住。战斗随即爆发，但这完全是一场一边倒的屠杀， %companyname% 干净利落地收拾掉了所有车队护卫。\n\n 当一切尘埃落地，%noble% 被放了出来。他揉着紫青的手腕，指引你前往 %noblesettlement%。%SPEECH_ON%出发吧，把我送回家族，我要用满满一口袋的金币来酬谢你们的英勇！%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "我已经看到我的口袋里塞满克朗的样子了！",
					function getResult()
					{
						this.Flags.set("IsPrisoner", false);
						this.Flags.set("IsPrisonerLying", this.Math.rand(1, 100) <= 33);
						this.Contract.setState("Running_Prisoner");
						this.World.State.setCampingAllowed(true);
						this.World.State.getPlayer().setVisible(true);
						this.World.Assets.setUseProvisions(true);
						this.World.State.resetSpeedToNormal();
						this.Contract.m.Caravan.die();
						this.Contract.m.Caravan = null;
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationAttacked, "屠杀了一个负责保护的商队");
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractBetrayal);
						this.World.Assets.addMoralReputation(-5);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Prisoner3",
			Title = "在%noblesettlement%",
			Text = "[img]gfx/ui/events/event_31.png[/img]{你们抵达了 %noblesettlement%。一个全副武装的守卫认出了 %noble%，随即发出一声呐喊，这道命令迅速传遍了整个城镇。很快，几匹快马疾驰而来，骑手们飞速下马。看来那人没有撒谎。%noblehouse% 兑现了赏赐，正如那个囚犯之前承诺的一样。 | 还没等你们进入 %noblesettlement%，几个骑手就出城迎接了。他们的身后，贵族风格的长巾在风中飘扬。不远处还跟着一大队全副武装的护卫。看着他们迅速将那个囚犯接回阵中，显然已无需多言。在喧闹的欢迎仪式中，其中一人折返回来，将赏金递到了你手上。对于保住了贵族脑袋的平民，他们没再多说半个字。唉，意料之中。 | 那囚犯没撒谎，但你很快就清醒地意识到了自己的社会地位：一个全副武装的守卫冷冰冰地递给了你赏金。尽管你救了他们的血亲，但 %noblehouse% 家族的人似乎根本不想和你说话。现实就是如此。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "至少报酬不错。",
					function getResult()
					{
						this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).addPlayerRelation(this.Const.World.Assets.RelationFavor, "解救了一个被囚禁的贵族");
						this.World.Assets.addMoney(3000);
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你将获得[color=" + this.Const.UI.Color.PositiveValue + "]3000[/color] 克朗"
				});
				this.List.push({
					id = 10,
					icon = "ui/icons/relations.png",
					text = "你与" + this.World.FactionManager.getFaction(this.Contract.m.NobleHouseID).getName() + "改进"
				});
			}

		});
		this.m.Screens.push({
			ID = "Prisoner4",
			Title = "在%noblesettlement%",
			Text = "[img]gfx/ui/events/event_31.png[/img]{当你们靠近 %noblesettlement% 时，%noble% 突然窜到了灌木丛后面。%SPEECH_ON%抱歉了，亲爱的朋友们，我去拉个屎。%SPEECH_OFF%你点了点头，开始等待。等了又等。等了再等。当你意识到不对劲并冲到灌木丛后时，发现那家伙早已溜得没影了，而你的鞋上还沾了点屎。 | %noble% 要求停一下。他跑向了一处河里。%SPEECH_ON%等等，伙计们。让我清理一下，别让我的家人看到我这副邋遢样！%SPEECH_OFF%听起来合情合理。你让他自己去忙，但当你回去查看时，他已经不见了。泥泞的脚印一直延伸到山坡上，你跟了过去。山坡另一头是一片农田，庄稼长得郁郁葱葱，任何骗子都能轻易钻进去消失不见。%randombrother% 走到你身边。%SPEECH_ON%操。%SPEECH_OFF%确实，真操蛋。 | 在前往 %noblesettlement% 的路上有几个农民。他们正互相剪头发，这似乎吸引了 %noble% 的注意。%SPEECH_ON%抱歉，伙计们，我得去打理一下。可不想让家里那位老太太看到我这副德行，你们懂的。%SPEECH_OFF%你点了点头，去清点货物以打发时间。当你回到农夫那儿询问那个贵族去哪了时，其中一人盯着你。%SPEECH_ON%我没看见什么贵族啊？%SPEECH_OFF%你解释说他穿着一身破烂，并迅速描述了他的样子。他们耸了耸肩。%SPEECH_ON%我看见那个家伙跑进那边的田里了，然后骑上一匹马，越跑越远。我们还以为他脑子有病呢，因为他一路上都在狂笑。%SPEECH_OFF%你感到怒火中烧。 | 你带着 %noble% 进入了 %noblesettlement%。进城时他几乎在发抖。%SPEECH_ON%啊，我只是有点紧张。%SPEECH_OFF%守卫们谁也不认识这个男人，但考虑到他的穿着，这也可以理解。你走向一个全副武装的卫兵，请他叫一位贵族出来。他朝你斜了下身子，几乎没有挪动他那笔挺的站位。%SPEECH_ON%你要为谁通报？%SPEECH_OFF%你转身指过去。%SPEECH_ON%呃，就是……那个……那个……%SPEECH_OFF%%noble% 已经不见踪影了。你环顾四周。%randombrother% 的注意力正被一个荡妇吸引，其他佣兵也在四处闲逛。人群川流不息，在这个灰蒙蒙的闹市里，一个骗子太容易消失了。你愤怒地攥紧双拳。守卫把你推了回去。%SPEECH_ON%如果你没正事，我请你离开这里，否则我们要动手了。%SPEECH_OFF%}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "该死的！",
					function getResult()
					{
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Vampires1",
			Title = "在路上…",
			Text = "[img]gfx/ui/events/event_33.png[/img]{当车队停下休息时，你听见一种奇怪的声音，就像有人在啃咬苹果并吮吸汁液。绕过一辆货车，你发现一个苍白的人影正趴在一个死去的护卫身上，那怪物的獠牙深深刻进了男人的脖子。你能看见皮肉随着咬合向上拱起，那满脸血污的畜生正一边吞饮一边狞笑。\n\n 你拔出长剑，对着你的佣兵们大声吼道。%SPEECH_ON%邪恶的畜生！弟兄们，抄家伙！%SPEECH_OFF% | 一个箱子的盖子动了一下。你盯着它，和一个车队护卫交换了眼神。%SPEECH_ON%你们这货运的是狗吗？%SPEECH_OFF%突然，箱盖炸裂开来，木屑随一股强大而狂暴的力量四散飞溅。伴随着呻吟声，一个生物从箱中缓缓升起，双臂交叉在胸前。它的脸面色惨白，皮肤紧绷且透着寒意。那是……一个……\n\n 车队护卫尖叫着逃跑。%SPEECH_ON%货逃出来了！货逃出来了！%SPEECH_OFF%货？谁竟敢把这种恐怖的东西称为‘货’？ | 你看着一个护卫从板条箱里抓起一只猫。那小畜生四脚悬空地叫着，乱蹬着想找个落脚点，随后气急败坏地抓挠着那个把它拎起来的家伙。你心生好奇，便上前询问他在做什么。他耸了耸肩，掀开一个木箱盖，把猫扔了进去。%SPEECH_ON%喂食。%SPEECH_OFF%猫发出了凄厉的尖叫，挣扎时的哀嚎异常凶猛，但很快就归于死寂。就在护卫转身准备离开木箱时，箱盖砰地炸裂，一个苍白的生物直挺起身体，动作轻盈得近乎虚幻，它双臂合拢死死抱住了那个男人，将獠牙刺入了他的脖子。护卫的颈部泛起一片青紫，随即迅速褪色，额头上的青筋根根暴起，仿佛在竭力帮血液逃离被吞噬的命运。\n\n 你退后几步，拔出长剑，向弟兄们发出警报，迎接这突如其来的恐怖。 | 休息时，一个年轻的护卫神神秘秘地凑到你身边。%SPEECH_ON%嘿，佣兵，想看点好东西吗？%SPEECH_OFF%你正闲得发慌，便随他去了。他带你来到一辆货车旁，掀开了一个箱子的顶盖。里面躺着一个苍白的人影，双臂交叉在胸前，面无血色，皮肤紧绷，一副安详沉睡的模样。你猛地跳了回来，因为那不是普通的尸体。护卫大笑起来。%SPEECH_ON%怎么，你还怕死人？%SPEECH_OFF%就在这时，那怪物的细长手臂猛地弹起，一把拽住那小子拖进了箱子。你压根没打算去救那个蠢货，而是立刻转身召集弟兄们，奔跑中，你四周的箱子接二连三地弹开了。 | 在路边休息时，你听到货车队列深处传来一声惨叫。你拔出长剑，迅速冲向声源。一个车队护卫捂着脖子从你身边踉跄而过，他瞪大双眼，嘴巴惊恐地张着，却发不出半点声音。%SPEECH_ON%它们出来了！它们出来了！%SPEECH_OFF%另一个护卫迅速跑过并喊道，甚至没停下来帮同伴一把。你往前看去，只见一群苍白的人影在护卫间腾挪跳跃，用黑色的斗篷裹住受害者，将他们拖入阴影之中。在它们靠近你之前，你转身向佣兵团发出了这恐怖危险的警报。 | 在车队休息时，你散散步来检查货车以确保一切都还规矩。 不过最后一辆载重货车倾斜到了土里，它的驮兽躺在泥地里。 附近有两个死掉的护卫。 他们的皮肤惨白，但姿势却还很鲜活。 将你的目光上移，你看到了群脸上全是血的生物弯腰蹲在车上，而且他们嘴里挂着人！\n\n%randombrother% 跑到你身后，武器在手，并将你推到后方。%SPEECH_ON%去警告伙计们，头！%SPEECH_OFF%这应该是这时候最好的主意了。 你尽可能大地喊叫，好唤来其余的伙计们加入战斗。 | 你抽空去撒尿时一声可怕的尖叫打断了你。 穿上衣服，你转身跑去查看。 在那里你看到了一个商队护卫面朝前摔倒，他的双腿交叉地绊倒了他自己之后一头栽在了地上。 在他身后，一个苍白的生物正在擦去它嘴边的血。 另一边的载重货车上箱子正在被打开，惨白的身影从它们中立起，双眼里闪烁着嗜血的光芒。\n\n 你看到得已经足够让你赶紧跑去警告伙计们了。}",
			Image = "",
			List = [],
			Options = [
				{
					Text = "保护车队！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos(), true);
						p.CombatID = "Vampires";
						p.Music = this.Const.Music.UndeadTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Center;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Circle;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Vampires, 80 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Undead).getID());
						this.World.Contracts.startScriptedCombat(p, false, false, false);
						return 0;
					}

				},
				{
					Text = "快逃啊！快跑！快跑！",
					function getResult()
					{
						this.Contract.m.Caravan.die();
						this.Contract.m.Caravan = null;
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能保护商队");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			]
		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_04.png[/img]{抵达 %objective% 之后，车队领队提着一个大钱袋朝你走来。%SPEECH_ON%谢了，佣兵，多亏你把我们带到这儿。%SPEECH_OFF%你接过钱袋递给 %randombrother% 清点。他数完后点了点头。车队领队笑了笑。%SPEECH_ON%也谢谢你没背叛我们，你知道的，没把我们赶尽杀绝之类的。%SPEECH_OFF%佣兵被感谢的方式总是这么稀奇古怪。 | 到达 %objective% 后，车队的货车立刻开始卸货，货物被运往附近的仓库。等一切清理完毕，领队递给你一袋克朗，感谢你确保了旅途的安全。 | %objective% 的门口围着一群寻找生计的散工。车队领队四处分发克朗，那些脏兮兮的手立刻伸向货车开始卸货。等他打发完那帮人，领队转头看向你，手里提着个钱袋。%SPEECH_ON%这是给你的，佣兵。%SPEECH_OFF%你接过了钱。几个临时工盯着这笔钱的交接，活像猫盯着摇晃的老鼠。 | 你做到了，按照你对 %employer% 的承诺将车队送达。车队领队支付了一袋克朗作为酬劳。他似乎对自己还能活着感到万分庆幸，还拉着你简短地讲了一段他曾从土匪伏击中死里逃生的往事。你虚伪地应和着，心里对他那些陈年烂事根本不在乎。 | 车队驶入了 %objective%，每辆货车的高大轮子都在干涸的泥堆上颠簸起伏。随车伙计们忙着卸货，还得时不时赶走一两个乞丐。领队递给你一个钱袋，仅此而已。他忙着指挥干活，没心思和你多费口舌。这种沉默倒也让人受用。 | 抵达 %objective% 后，车队领队搭起话来，仿佛你们之间有什么共同语言似的。他聊起年轻时的往事，说那时他还是个身手敏捷的小伙子，本可以干成这番或那番事业。显然，他错过了不少建功立业的战斗。真遗憾。你听得百无聊赖，直接让他付钱，好让你赶紧离开这个破地方。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "当之无愧的报酬。",
					function getResult()
					{
						local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(money);

						if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "按承诺保护了商队");
						}
						else if (this.Flags.get("IsStolenGoods"))
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess * 2.0, "保护了一个商队的赃物");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractSuccess, "按承诺保护了商队");
						}

						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
				this.Contract.addSituation(this.new("scripts/entity/world/settlements/situations/well_supplied_situation"), 3, this.Contract.m.Destination, this.List);
			}

		});
		this.m.Screens.push({
			ID = "Success2",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你禁不住怀疑，像 %objective% 这种破地方是否值得搭上几条人命。你确实带队赶到了，但并非所有的货车都安然无恙。车队领队朝你走来，手里提着一个比预期轻得多的钱袋。%SPEECH_ON%佣兵，我本想多给你点，毕竟我也知道这世道想保全万事很难，但 %employer% 坚持要根据……那个，根据我们的损失来扣钱。想必你能理解吧？%SPEECH_OFF%他看起来很怕你会对他进行报复，但你只是拿了钱转身就走。合同就是合同。 | 抵达 %objective% 后，车队领队转向你，手里攥着钱袋。%SPEECH_ON%这比你预想的要少。%SPEECH_OFF%确实少了。他继续说道：%SPEECH_ON%不不是每辆车都带到了。%SPEECH_OFF%确实没带到。%SPEECH_ON%我只是替 %employer% 传话的。请别杀我。%SPEECH_OFF%你不会杀他。虽然……算了。 | 到达 %objective% 后，车队领队让随车伙计开始卸货。他们少了几个帮手，也少了几辆货车。领队带着酬金走过来向你说明情况。%SPEECH_ON%%employer% 特意交代过，让我根据运抵的货物量来付钱。不幸的是，我们损失了一些……%SPEECH_OFF%你点了点头并收下报酬。毕竟，契约就是契约。 | 当你抵达 %objective% 时，车队领队几乎要哭出来了。他说这一路他失去了不少好弟兄，而丢失的货车也会让他们往后的日子举步维艰。你并不在乎，只是礼貌性地对他点了点头以示安慰。%SPEECH_ON%我想我还是得谢谢你，佣兵。毕竟我们还活着。不幸的是……我只能给你这么多。%employer% 要求所有的损失都得从你的酬劳里扣除。%SPEECH_OFF%你再次点头，拿走了你应得的那份报酬。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "这活儿干的不太顺利……",
					function getResult()
					{
						local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
						money = this.Math.floor(money / 2);
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(money);

						if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractPoor, "保护了一个商队，尽管很糟糕");
						}
						else if (this.Flags.get("IsStolenGoods"))
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor * 2.0, "保护了一个商队的赃物, 尽管很糟糕");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractPoor, "保护了一个商队，尽管很糟糕");
						}

						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				local money = this.Contract.m.Payment.getOnCompletion() + this.Contract.m.Payment.getPerCount() * this.Flags.get("HeadsCollected");
				money = this.Math.floor(money / 2);
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + money + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Failure1",
			Title = "战斗之后",
			Text = "[img]gfx/ui/events/event_60.png[/img]{你出发时，随行的商队成员和商人们都对你寄予厚望。而现在，他们的尸首横七竖八地躺在这片土地上，手臂摊开，苍蝇在指尖盘旋起舞。烈日很快就会让你这次失败的任务散发出腐烂的恶臭。该离开了。 | 货车侧翻在地。四肢残缺的尸体散落各处。废墟中传来一声呻吟，但那是临终的哀鸣，随后便归于死寂。草地上掠过道道阴影，成群的秃鹫在你头顶盘旋。由着它们去饱餐一顿吧，毕竟你已经无能为力了。 | 雇佣你的商人就死在你的脚下。他并不是完全脸朝下趴着，因为他的脸已经不复存在了。鲜血在地上一股股地喷涌，你不由自主地盯着这惨状，它是你失败的总结。你的一名手下发现尸体抽动了一下，但你很清楚那只是假象。一切都无可挽回。车队的其他部分更是惨不忍睹。留在这里已经没有意义了。 | 战斗渐渐平息，但你发现那名商人正瘫靠在翻倒的货车边。他瞪大双眼，拼命捂着被割开的脖子。血索般的红流从指缝间喷溅而出，还没等你采取任何措施，他就断了气。你试着抢救他，但为时已晚。他双眼无神地盯着你。你的手下 %randombrother% 帮他合上了双眼，随后起身去翻检车队的残骸。 | 你在货车残骸间步履蹒跚。死因一目了然：商人的脑袋被某个大箱子给砸扁了，也许他在战斗最激烈时正躲在那后面寻求庇护。唉，车队里没一个活口。这场战斗即便以你的标准衡量也异常惨烈，眼前的杀戮场面甚至让几名兄弟忍不住作呕。如果噩梦注定要来，那就让它来吧。面对这样的失败，这也是你应得的报酬。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "该死！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);

						if (this.World.FactionManager.getFaction(this.Contract.getFaction()).getType() == this.Const.FactionType.OrientalCityState)
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "没能保护商队");
						}
						else
						{
							this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationCivilianContractFail, "没能保护商队");
						}

						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
	}

	function addKillCount( _actor, _killer )
	{
		if (_killer != null && _killer.getFaction() != this.Const.Faction.Player && _killer.getFaction() != this.Const.Faction.PlayerAnimals)
		{
			return;
		}

		if (this.m.Flags.get("HeadsCollected") >= this.m.Payment.MaxCount)
		{
			return;
		}

		if (_actor.getXPValue() == 0)
		{
			return;
		}

		if (_actor.getType() == this.Const.EntityType.GoblinWolfrider || _actor.getType() == this.Const.EntityType.Wardog || _actor.getType() == this.Const.EntityType.Warhound || _actor.getType() == this.Const.EntityType.SpiderEggs || this.isKindOf(_actor, "lindwurm_tail"))
		{
			return;
		}

		if (!_actor.isAlliedWithPlayer() && !_actor.isResurrected())
		{
			this.m.Flags.set("HeadsCollected", this.m.Flags.get("HeadsCollected") + 1);
		}
	}

	function spawnCaravan()
	{
		local faction = this.World.FactionManager.getFaction(this.getFaction());
		local party;

		if (faction.hasTrait(this.Const.FactionTrait.OrientalCityState))
		{
			party = faction.spawnEntity(this.m.Home.getTile(), "Trading Caravan", false, this.Const.World.Spawn.CaravanSouthernEscort, this.m.Home.getResources() * this.Math.rand(10, 25) * 0.01, this.getMinibossModifier());
		}
		else
		{
			party = faction.spawnEntity(this.m.Home.getTile(), "Trading Caravan", false, this.Const.World.Spawn.CaravanEscort, this.m.Home.getResources() * 0.4, this.getMinibossModifier());
		}

		party.getSprite("banner").Visible = false;
		party.getSprite("base").Visible = false;
		party.setMirrored(true);
		party.setDescription("一队来自 " + this.m.Home.getName() + " 的贸易商队，正在各个定居点之间运输各类货物。");
		party.setMovementSpeed(this.Const.World.MovementSettings.Speed * 0.6);
		party.setLeaveFootprints(false);

		if (this.m.Home.getProduce().len() != 0)
		{
			for( local j = 0; j != 3; j = ++j )
			{
				party.addToInventory(this.m.Home.getProduce()[this.Math.rand(0, this.m.Home.getProduce().len() - 1)]);
			}
		}

		party.getLoot().Money = this.Math.rand(0, 100);
		local c = party.getController();
		c.getBehavior(this.Const.World.AI.Behavior.ID.Attack).setEnabled(false);
		c.getBehavior(this.Const.World.AI.Behavior.ID.Flee).setEnabled(false);
		local move = this.new("scripts/ai/world/orders/move_order");
		move.setDestination(this.m.Destination.getTile());
		move.setRoadsOnly(true);
		local unload = this.new("scripts/ai/world/orders/unload_order");
		local despawn = this.new("scripts/ai/world/orders/despawn_order");
		local wait = this.new("scripts/ai/world/orders/wait_order");
		wait.setTime(4.0);
		c.addOrder(move);
		c.addOrder(unload);
		c.addOrder(wait);
		c.addOrder(despawn);
		this.m.Caravan = this.WeakTableRef(party);
	}

	function spawnEnemies()
	{
		local tries = 0;
		local myTile = this.m.Destination.getTile();
		local tile;

		while (tries++ == 0)
		{
			local tile = this.getTileToSpawnLocation(myTile, 7, 11);

			if (tile.getDistanceTo(this.World.State.getPlayer().getTile()) <= 6)
			{
				continue;
			}

			local nearest_bandits = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getNearestSettlement(tile);
			local nearest_goblins = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).getNearestSettlement(tile);
			local nearest_orcs = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).getNearestSettlement(tile);
			local nearest_barbarians = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians) != null ? this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).getNearestSettlement(tile) : null;
			local nearest_nomads = this.World.FactionManager.getFactionOfType(this.Const.FactionType.OrientalBandits) != null ? this.World.FactionManager.getFactionOfType(this.Const.FactionType.OrientalBandits).getNearestSettlement(tile) : null;

			if (nearest_bandits == null && nearest_goblins == null && nearest_orcs == null && nearest_barbarians == null && nearest_nomads == null)
			{
				this.logInfo("没有找到敌人的营地");
				return false;
			}

			local bandits_dist = nearest_bandits != null ? nearest_bandits.getTile().getDistanceTo(tile) + this.Math.rand(0, 10) : 9000;
			local goblins_dist = nearest_goblins != null ? nearest_bandits.getTile().getDistanceTo(tile) + this.Math.rand(0, 10) : 9000;
			local orcs_dist = nearest_orcs != null ? nearest_bandits.getTile().getDistanceTo(tile) + this.Math.rand(0, 10) : 9000;
			local barbarians_dist = nearest_barbarians != null ? nearest_barbarians.getTile().getDistanceTo(tile) + this.Math.rand(0, 10) : 9000;
			local nomads_dist = nearest_nomads != null ? nearest_nomads.getTile().getDistanceTo(tile) + this.Math.rand(0, 10) : 9000;
			local party;
			local origin;

			if (bandits_dist <= goblins_dist && bandits_dist <= orcs_dist && bandits_dist <= barbarians_dist && bandits_dist <= nomads_dist)
			{
				party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).spawnEntity(tile, "Brigands", false, this.Const.World.Spawn.BanditRaiders, this.Math.rand(80, 100) * this.getDifficultyMult() * this.getScaledDifficultyMult());
				party.setDescription("一群蛮横凶悍的强盗，正四处劫掠食物。");
				party.setFootprintType(this.Const.World.FootprintsType.Brigands);
				party.getLoot().Money = this.Math.rand(50, 100);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 20);
				local r = this.Math.rand(1, 6);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}
				else if (r == 5)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				origin = nearest_bandits;
			}
			else if (goblins_dist <= bandits_dist && goblins_dist <= orcs_dist && goblins_dist <= barbarians_dist && goblins_dist <= nomads_dist)
			{
				party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Goblins).spawnEntity(tile, "Goblin Raiders", false, this.Const.World.Spawn.GoblinRaiders, this.Math.rand(80, 100) * this.getDifficultyMult() * this.getScaledDifficultyMult());
				party.setDescription("一群难缠的哥布林，小而狡猾，不可低估。");
				party.setFootprintType(this.Const.World.FootprintsType.Goblins);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 30);
				local r = this.Math.rand(1, 4);

				if (r == 1)
				{
					party.addToInventory("supplies/strange_meat_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				origin = nearest_goblins;
			}
			else if (barbarians_dist <= goblins_dist && barbarians_dist <= bandits_dist && barbarians_dist <= orcs_dist && barbarians_dist <= nomads_dist)
			{
				party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Barbarians).spawnEntity(tile, "Barbarians", false, this.Const.World.Spawn.Barbarians, this.Math.rand(80, 100) * this.getDifficultyMult() * this.getScaledDifficultyMult());
				party.setDescription("一支野蛮人部落的队伍。");
				party.setFootprintType(this.Const.World.FootprintsType.Barbarians);
				party.getLoot().Money = this.Math.rand(0, 50);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 5);
				party.getLoot().Ammo = this.Math.rand(0, 30);

				if (this.Math.rand(1, 100) <= 50)
				{
					party.addToInventory("loot/bone_figurines_item");
				}

				if (this.Math.rand(1, 100) <= 50)
				{
					party.addToInventory("loot/bead_necklace_item");
				}

				local r = this.Math.rand(2, 5);

				if (r == 2)
				{
					party.addToInventory("supplies/roots_and_berries_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/dried_fruits_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/ground_grains_item");
				}
				else if (r == 5)
				{
					party.addToInventory("supplies/pickled_mushrooms_item");
				}

				origin = nearest_barbarians;
			}
			else if (nomads_dist <= barbarians_dist && nomads_dist <= goblins_dist && nomads_dist <= bandits_dist && nomads_dist <= orcs_dist)
			{
				party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.OrientalBandits).spawnEntity(tile, "Nomads", false, this.Const.World.Spawn.NomadRaiders, this.Math.rand(80, 100) * this.getDifficultyMult() * this.getScaledDifficultyMult());
				party.setDescription("一群沙漠掠夺者，专门劫掠任何试图穿越这片沙海的人。");
				party.setFootprintType(this.Const.World.FootprintsType.Nomads);
				party.getLoot().Money = this.Math.rand(50, 200);
				party.getLoot().ArmorParts = this.Math.rand(0, 10);
				party.getLoot().Medicine = this.Math.rand(0, 2);
				party.getLoot().Ammo = this.Math.rand(0, 20);
				local r = this.Math.rand(1, 4);

				if (r == 1)
				{
					party.addToInventory("supplies/bread_item");
				}
				else if (r == 2)
				{
					party.addToInventory("supplies/dates_item");
				}
				else if (r == 3)
				{
					party.addToInventory("supplies/rice_item");
				}
				else if (r == 4)
				{
					party.addToInventory("supplies/dried_lamb_item");
				}

				origin = nearest_nomads;
			}
			else
			{
				party = this.World.FactionManager.getFactionOfType(this.Const.FactionType.Orcs).spawnEntity(tile, "Orc Marauders", false, this.Const.World.Spawn.OrcRaiders, this.Math.rand(80, 100) * this.getDifficultyMult() * this.getScaledDifficultyMult());
				party.setDescription("一群气势汹汹的兽人，这些绿皮怪物的体型足以俯视任何人类。");
				party.setFootprintType(this.Const.World.FootprintsType.Orcs);
				party.getLoot().ArmorParts = this.Math.rand(0, 25);
				party.getLoot().Ammo = this.Math.rand(0, 10);
				party.addToInventory("supplies/strange_meat_item");
				origin = nearest_orcs;
			}

			party.getSprite("banner").setBrush(origin.getBanner());
			party.setAttackableByAI(false);
			party.setAlwaysAttackPlayer(true);
			local c = party.getController();
			local intercept = this.new("scripts/ai/world/orders/intercept_order");
			intercept.setTarget(this.World.State.getPlayer());
			c.addOrder(intercept);
			this.m.UnitsSpawned.push(party.getID());
			return true;
		}

		return false;
	}

	function onPrepareVariables( _vars )
	{
		local days = this.getDaysRequiredToTravel(this.m.Flags.get("Distance"), this.Const.World.MovementSettings.Speed * 0.6, true);
		_vars.push([
			"objective",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.m.Destination.getName()
		]);
		_vars.push([
			"direction",
			this.m.Destination == null || this.m.Destination.isNull() ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.Destination.getTile())]
		]);
		_vars.push([
			"noblehouse",
			this.World.FactionManager.getFaction(this.m.NobleHouseID).getName()
		]);
		_vars.push([
			"noble",
			this.m.Flags.get("NobleName")
		]);
		_vars.push([
			"noblesettlement",
			this.m.NobleSettlement == null || this.m.NobleSettlement.isNull() ? "" : this.m.NobleSettlement.getName()
		]);
		_vars.push([
			"nobledirection",
			this.m.NobleSettlement == null || this.m.NobleSettlement.isNull() ? "" : this.Const.Strings.Direction8[this.World.State.getPlayer().getTile().getDirection8To(this.m.NobleSettlement.getTile())]
		]);
		_vars.push([
			"killcount",
			this.m.Flags.get("HeadsCollected")
		]);
		_vars.push([
			"days",
			days <= 1 ? "1天" : days + "天"
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.World.State.setCampingAllowed(true);
			this.World.State.setEscortedEntity(null);
			this.World.State.getPlayer().setVisible(true);
			this.World.Assets.setUseProvisions(true);
			this.World.State.resetSpeedToNormal();

			if (this.m.Destination != null && !this.m.Destination.isNull())
			{
				this.m.Destination.getSprite("selection").Visible = false;
			}

			if (this.m.NobleSettlement != null && !this.m.NobleSettlement.isNull())
			{
				this.m.NobleSettlement.getSprite("selection").Visible = false;
			}
		}
	}

	function onIsValid()
	{
		if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive() || !this.m.Destination.isAlliedWith(this.getFaction()))
		{
			return false;
		}

		return true;
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		if (this.m.Caravan != null && !this.m.Caravan.isNull())
		{
			_out.writeU32(this.m.Caravan.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		_out.writeU32(this.m.NobleHouseID);
		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local destination = _in.readU32();

		if (destination != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(destination));
		}

		local caravan = _in.readU32();

		if (caravan != 0)
		{
			this.m.Caravan = this.WeakTableRef(this.World.getEntityByID(caravan));
		}

		this.m.NobleHouseID = _in.readU32();

		if (!this.m.Flags.has("Distance"))
		{
			this.m.Flags.set("Distance", 0);
		}

		if (!this.m.Flags.has("HeadsCollected"))
		{
			this.m.Flags.set("HeadsCollected", 0);
		}

		this.contract.onDeserialize(_in);

		if (this.m.Flags.has("NobleSettlement"))
		{
			local e = this.World.getEntityByID(this.m.Flags.get("NobleSettlement"));

			if (e != null)
			{
				this.m.NobleSettlement = this.WeakTableRef(e);
			}
		}
	}

});

