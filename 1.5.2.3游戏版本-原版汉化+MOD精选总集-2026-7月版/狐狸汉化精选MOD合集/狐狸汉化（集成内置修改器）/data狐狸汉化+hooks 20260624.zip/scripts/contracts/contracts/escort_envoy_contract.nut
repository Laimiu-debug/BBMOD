this.escort_envoy_contract <- this.inherit("scripts/contracts/contract", {
	m = {
		Destination = null
	},
	function create()
	{
		this.contract.create();
		this.m.Type = "contract.escort_envoy";
		this.m.Name = "护送特使";
		this.m.TimeOut = this.Time.getVirtualTimeF() + this.World.getTime().SecondsPerDay * 7.0;
	}

	function onImportIntro()
	{
		this.importNobleIntro();
	}

	function start()
	{
		if (this.m.Home == null)
		{
			this.setHome(this.World.State.getCurrentTown());
		}

		local settlements = this.World.EntityManager.getSettlements();
		local candidates = [];

		foreach( s in settlements )
		{
			if (s.getID() == this.m.Home.getID())
			{
				continue;
			}

			if (!s.isDiscovered() || s.isMilitary())
			{
				continue;
			}

			if (s.getOwner() == null || s.getOwner().getID() == this.getFaction())
			{
				continue;
			}

			if (s.isIsolated() || !this.m.Home.isConnectedTo(s) || this.m.Home.isCoastal() && s.isCoastal())
			{
				continue;
			}

			candidates.push(s);
		}

		this.m.Destination = this.WeakTableRef(candidates[this.Math.rand(0, candidates.len() - 1)]);
		local distance = this.getDistanceOnRoads(this.m.Home.getTile(), this.m.Destination.getTile());
		this.m.Payment.Pool = this.Math.max(250, distance * 7.0 * this.getPaymentMult() * this.Math.pow(this.getDifficultyMult(), this.Const.World.Assets.ContractRewardPOW) * this.getReputationToPaymentMult());

		if (this.Math.rand(1, 100) <= 33)
		{
			this.m.Payment.Completion = 0.75;
			this.m.Payment.Advance = 0.25;
		}
		else
		{
			this.m.Payment.Completion = 1.0;
		}

		local titles = [
			"特使",
			"使者"
		];
		this.m.Flags.set("EnvoyName", this.Const.Strings.CharacterNames[this.Math.rand(0, this.Const.Strings.CharacterNames.len() - 1)]);
		this.m.Flags.set("EnvoyTitle", titles[this.Math.rand(0, titles.len() - 1)]);
		this.m.Flags.set("DestinationName", this.m.Destination.getName());
		this.m.Flags.set("Bribe", this.beautifyNumber(this.m.Payment.Pool * this.Math.rand(75, 150) * 0.01));
		this.m.Flags.set("EnemyName", this.m.Destination.getOwner().getName());
		this.contract.start();
	}

	function createStates()
	{
		this.m.States.push({
			ID = "Offer",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"护送 %envoy_title% %envoy% 前往位于 %direction% 的 " + this.Contract.m.Destination.getName() + " "
				];

				if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.IntroChance)
				{
					this.Contract.setScreen("Intro");
				}
				else
				{
					this.Contract.setScreen("Task");
				}
			}

			function end()
			{
				this.World.Assets.addMoney(this.Contract.m.Payment.getInAdvance());
				local r = this.Math.rand(1, 100);

				if (r <= 10)
				{
					if (this.Contract.getDifficultyMult() >= 1.0)
					{
						this.Flags.set("IsShadyDeal", true);
					}
				}

				local envoy = this.World.getGuestRoster().create("scripts/entity/tactical/humans/envoy");
				envoy.setName(this.Flags.get("EnvoyName"));
				envoy.setTitle(this.Flags.get("EnvoyTitle"));
				envoy.setFaction(1);
				this.Flags.set("EnvoyID", envoy.getID());
				this.Contract.setScreen("Overview");
				this.World.Contracts.setActiveContract(this.Contract);
			}

		});
		this.m.States.push({
			ID = "Running",
			function start()
			{
				this.Contract.m.Destination.getSprite("selection").Visible = true;
			}

			function update()
			{
				if (this.World.getGuestRoster().getSize() == 0)
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Destination))
				{
					this.Contract.setScreen("Arrival");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Flags.get("IsShadyDeal"))
				{
					if (!this.Flags.get("IsShadyDealAnnounced"))
					{
						this.Flags.set("IsShadyDealAnnounced", true);
						this.Contract.setScreen("ShadyCharacter1");
						this.World.Contracts.showActiveContract();
					}
					else if (this.World.State.getPlayer().getTile().HasRoad && this.Math.rand(1, 1000) <= 1)
					{
						local enemiesNearby = false;
						local parties = this.World.getAllEntitiesAtPos(this.World.State.getPlayer().getPos(), 400.0);

						foreach( party in parties )
						{
							if (!party.isAlliedWithPlayer)
							{
								enemiesNearby = true;
								break;
							}
						}

						if (!enemiesNearby && this.Contract.getDistanceToNearestSettlement() >= 6)
						{
							this.Contract.setScreen("ShadyCharacter2");
							this.World.Contracts.showActiveContract();
						}
					}
				}
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_actor.getID() == this.Flags.get("EnvoyID"))
				{
					this.World.getGuestRoster().clear();
				}
			}

		});
		this.m.States.push({
			ID = "Waiting",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"在 " + this.Contract.m.Destination.getName() + " 附近等候，直到 %envoy_title% %envoy% 办完事为止。"
				];
				this.Contract.m.Destination.getSprite("selection").Visible = true;
			}

			function update()
			{
				this.World.State.setUseGuests(false);

				if (this.Contract.isPlayerAt(this.Contract.m.Destination) && this.Time.getVirtualTimeF() >= this.Flags.get("WaitUntil"))
				{
					this.Contract.setScreen("Departure");
					this.World.Contracts.showActiveContract();
				}
			}

		});
		this.m.States.push({
			ID = "Return",
			function start()
			{
				this.Contract.m.BulletpointsObjectives = [
					"护送 %envoy% %envoy_title% 回到" + this.Contract.m.Home.getName()
				];
				this.Contract.m.Destination.getSprite("selection").Visible = false;
				this.Contract.m.Home.getSprite("selection").Visible = true;
			}

			function update()
			{
				this.World.State.setUseGuests(true);

				if (this.World.getGuestRoster().getSize() == 0)
				{
					this.Contract.setScreen("Failure1");
					this.World.Contracts.showActiveContract();
				}
				else if (this.Contract.isPlayerAt(this.Contract.m.Home))
				{
					this.Contract.setScreen("Success1");
					this.World.Contracts.showActiveContract();
				}
			}

			function onActorKilled( _actor, _killer, _combatID )
			{
				if (_actor.getID() == this.Flags.get("EnvoyID"))
				{
					this.World.getGuestRoster().clear();
				}
			}

		});
	}

	function createScreens()
	{
		this.importScreens(this.Const.Contracts.NegotiationDefault);
		this.importScreens(this.Const.Contracts.Overview);
		this.m.Screens.push({
			ID = "Task",
			Title = "谈判",
			Text = "[img]gfx/ui/events/event_63.png[/img]{%employer% 身旁站着一个人。你几乎看不清他的脸，每当你侧头想看仔细些，他也随之偏过头去，确保你看不到。%SPEECH_ON%烦请见谅，佣兵。这位是 %envoy%。你无需看清他的脸，我只要你把他送到 %objective%。他此行是为了说服那里的人加入我们的阵营。当然，%enemynoblehouse% 不会乐意看到这事儿，所以必须谨慎低调。%SPEECH_OFF%你点了点头，心领神会各家族间错综复杂的政治关系。%SPEECH_ON%很好，佣兵。现在，你有兴趣吗？%SPEECH_OFF% | 一个男人仿佛是从 %employer% 房间的阴影中走了出来，径直向你伸出手来。你与他握手，他自我介绍道：%SPEECH_ON%我是 %envoy%，受雇于这位 %employer%。我们……%SPEECH_OFF%%employer% 插话道：%SPEECH_ON%我需要你护送这个人前往 %objective%。显而易见，那里是 %enemynoblehouse% 的地盘，所以必须秘密行事。这就是你需要介入的地方。你只需确保这个人安全抵达，之后把他带回来，你就能拿到酬金。这活儿符合你的心意吗？%SPEECH_OFF% | %employer% 将一卷羊皮纸拍在你胸口。%SPEECH_ON%我门外站着一个人，是一名特使。他叫 %envoy%，正准备前往 %objective%，游说那里的人加入我们。%SPEECH_OFF%你接过羊皮纸，就眼前明摆着的问题询问道：那是 %enemynoblehouse% 的地盘。%employer% 点了点头。%SPEECH_ON%是的，没错。这就是为什么站在这里的是你，而不是我的士兵。没必要挑起一场战争，不是吗？我只需要你把 %envoy% 送到那里再带回来。如果你感兴趣，我们谈谈价钱，然后你就可以把这卷轴交给那边的特使出发了。%SPEECH_OFF% | %employer% 盯着地图，询问你是否对政治感兴趣。你耸了耸肩，他点头表示理解。%SPEECH_ON%我就知道。好吧，不幸的是，我有个政治相关的活儿要交给你。我需要你护送一位名叫 %envoy% 的特使。他要去 %objective% 执行……嗯，一些政治性质的任务，说服那里的人加入我们，没什么好担心的。显然，那里不是我的地盘，这也是为什么我要雇一个像你这样‘没名没姓’的人。我没有什么冒犯的意思。%SPEECH_OFF%你摆手表示不在意。%employer% 继续说道。%SPEECH_ON%好吧，如果你感兴趣，就把那个人带到那里再带回来。听起来挺简单的，对吧？你甚至都不用开口说话！%SPEECH_OFF% | %employer% 正在研究地图，特别是那些标示着他与 %enemynoblehouse% 的边界的颜色对比。他一拳砸在对方的领土上。%SPEECH_ON%听好了，佣兵。我需要几个靠得住的人护送我的使者 %envoy%。他要去 %objective%，如果你懂点政治，就知道那里不在我的控制之下。%SPEECH_OFF%你点了点头，让这位贵族知道你明白这项要求的背后含义。%SPEECH_ON%你把他送到那里，他负责谈判，然后你再把他带回来。对外界而言，你只是个跟着他的无名小卒，明白了吗？如果你感兴趣，我们谈谈报酬吧？%SPEECH_OFF% | %employer% 将一张破烂的纸片扔在桌上，显然那不是什么好消息。%SPEECH_ON%我的女儿们要出嫁了，但我没有足够的领地收税来为她们举办应有的庆典。%SPEECH_OFF%你对此并不关心，并示意他有话直说。%SPEECH_ON%行了，行了。废话少说，我需要你护送我的特使 %envoy%，前往 %objective%。他打算去说服他们归顺于我们。听着，那个小地方是 %enemynoblehouse% 的地盘，可以肯定他们发现我们在那附近晃悠会很不高兴。这就是为什么要雇你这个没名没姓的佣兵，来给我的特使当护卫。%SPEECH_OFF%男人双手交叠放在腿上。%SPEECH_ON%你对这活儿有兴趣吗？你只需把他送到那里再带回来。就能轻轻松松赚上一笔！%SPEECH_OFF% | %employer% 读着一卷羊皮纸，忽然笑出声来，随即似乎压不住嘴角的笑意。%SPEECH_ON%好消息，佣兵！%enemynoblehouse% 的人民似乎对他们的统治不再满意了！%SPEECH_OFF%你挑了挑眉，敷衍地应和着。那人将椅子挪到办公桌前，仔细查看铺在上面的地图，继续说道：%SPEECH_ON%更好的消息是，我有一位名叫 %envoy% 的特使今天正要去 %objective% 去做点……交流。 很显然，那条路上显然少不了鬼鬼祟祟的盗贼，而 %enemynoblehouse% 的领主比他们还要居心叵测，所以这人需要保护！这就是你的用武之地。你只需负责护送他往返即可。%SPEECH_OFF% | %employer% 身边站着一个男人。他和你握了手，自我介绍说是 %envoy%，一个特使。你询问这个人的重要性，%employer% 赶忙解释道。%SPEECH_ON%他要去 %objective%——如果你不知道的话，那是 %enemynoblehouse% 的地盘，。我们或许能说服那里的人归顺我们的统治。既然你已经认识了这个人并了解他的任务，想必你也明白为什么我找的是你，而不是我的士兵。\n\n我需要你把这个人送到 %objective%，当他办完该办的事后，再把他带回来。之后，你会得到报酬。你接这活儿吗？%SPEECH_OFF%}",
			Image = "",
			List = [],
			ShowEmployer = true,
			ShowDifficulty = true,
			Options = [
				{
					Text = "{我们来谈谈价钱。 | 这活儿对你来说值多少钱？ | 报酬是多少？}",
					function getResult()
					{
						return "Negotiation";
					}

				},
				{
					Text = "{你得去别处找保镖了。 | 这不是我们要找的活儿。}",
					function getResult()
					{
						this.World.Contracts.removeContract(this.Contract);
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "Arrival",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_20.png[/img]{你抵达了 %objective%。%envoy% %envoy_title% 走进一栋建筑，随手轻轻关上了身后的门。你把一只靴子抵在墙上，等着他回来。几个农夫来来去去，鸟儿在枝头啁啾。你已许久没有留心过它们的歌声了。\n\n看来这要等上一阵子。也许你该利用这段时间为返程采购些补给？ | 特使进入了 %objective% 的一座议事厅。你已安全将他送达，剩下的便是他自己的事了。你靠在其中一扇窗户旁，侧耳倾听里面的谈话，细细品味。这人口齿伶俐，他鼓动人们加入其事业的本事，远比你和几把刀剑更有说服力。使节透过窗户瞥见你，不动声色地挥手示意你离开。你悄悄退开，等他办完事。 | 几个衣着考究的人将你们迎入 %objective%。他们询问 %envoy%  %envoy_title% 你是否是随行人员。随即俯身向议员们低语了几句。众人会意地点头，不多时便一齐溜进附近一家酒馆。你在外面等候。或许你可以利用这段时间为返程采购些补给？ | %employer% 猜测 %objective% 或许会倒向他的阵营，这一判断似乎得到了印证：当地的民众早已涌上街头，汇聚成一支声势浩大的人潮。一列卫兵守在一座大型建筑外，横着长矛将人群往外推搡。一名富态的男子探出窗外，试图以言语驱散人群，却根本没人听——愤怒已经将他们的耳朵堵得严严实实。%envoy% 轻松穿过人群，与几名身着斗篷的议员碰头，随即一同溜入附近一栋建筑，你在外面守候。 | %objective% 看起来相当萧条——街上的农夫们要么在为什么事发愁，要么在无所事事地偷懒。无论哪种都不是一个健康社群该有的景象。%envoy%  %envoy_title% 走进一家当地酒馆，一群缩在角落的男人谨慎地与他打了声招呼。他挥手示意你离开，于是你便站在门外，等他办完事。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "{别磨蹭太久。 | 我们会在附近守着的。}",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.World.getGuestRoster().get(0).getImagePath());
				this.Flags.set("WaitUntil", this.Time.getVirtualTimeF() + this.Math.rand(20, 60) * 1.0);
				this.Contract.setState("Waiting");
			}

		});
		this.m.Screens.push({
			ID = "Departure",
			Title = "在 %objective%",
			Text = "[img]gfx/ui/events/event_20.png[/img]{过了一阵子，特使才从里面走了出来。你询问他是否遇到了麻烦，他说没有。是时候回到 %employer% 那里了。 | 门开了，特使走了出来，让你带路回去。 | 没过多久，特使便出来了。他告诉你事情已经办妥，需要尽快赶回 %employer% 身边。 | %envoy% 匆匆返回到你身边，告诉你们需要尽快赶回 %employer% 那里。 | 特使回来后说谈得很顺利，让你尽快送他回到 %employer% 那里。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "{终于办完了，我们走吧！ | 怎么磨蹭了这么久？}",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.World.getGuestRoster().get(0).getImagePath());
				this.Contract.setState("Return");
			}

		});
		this.m.Screens.push({
			ID = "ShadyCharacter1",
			Title = "在 %townname%",
			Text = "[img]gfx/ui/events/event_51.png[/img]{正当你准备离开城镇时，一名披着斗篷的男人走过来向你搭话。他的脸隐藏在披肩的阴影下，你只能偶尔瞥见他的牙齿和尖削的下巴。%SPEECH_ON%当时机成熟时，你会选择袖手旁观吗，佣兵？%SPEECH_OFF%还没等你回话，他便消失了。 | 在准备出城时，一个男人与你撞了个满怀。他没有道歉，而是从一件长长的黑色斗篷下方抬眼打量你。%SPEECH_ON%迟早有个时候，你得做出抉择。留下战斗，或者离开并活到明天。走第二条路，金币会追随你，走第一条路，铲子会埋葬你……%SPEECH_OFF%你伸手想抓住这人，他却轻巧地向后一退，融入一群恰好从旁匆匆经过的平民之中，转眼便无影无踪。 | 就在你准备离开 %townname% 时，，一个身着深色斗篷的男子靠近你身侧。他并不看你，只是自顾自地开口。%SPEECH_ON%我的雇主早料到你会来。%employer% 选择雇你确实很明智。然而，你面临着一个选择——到了那个时候……你会走哪条路？%SPEECH_OFF%你让这人带着他的预言滚远点。 | 在你离开 %employer% 的视线后，一个黑衣男子拦住了你。他朝你两侧扫了一眼，随即压低声音：%SPEECH_ON%%employer% 给你的报酬确实丰厚，但我认识一个出手更阔绰的人。到了关键时刻，装作没看见就行……%SPEECH_OFF%那陌生人退后一步，闪身躲入一扇门后。你推门追去，里面却空无一人，只有一个厨房帮工站在那里，一副 {他 | 她} 什么也没看见的神情。 | 带着 %employer% 交代的任务，你准备出发。在整备物资时，一个身披斗篷的陌生人走近前来，说话的声音像是嗓子里含着碎石子。%SPEECH_ON%很多双眼睛正盯着你，佣兵。你接下来的每一步都要走得小心。你现在还有机会抽身事外。到了那个时候，我们只求你退到一旁。%SPEECH_OFF%你拔剑指向那人以作威慑，他却转身溜走，飘动的斗篷一闪便没入人群中，周围的农夫们似乎被你突然亮剑的举动吓了一跳。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "{这下有意思了…… | 看来麻烦要找上门了。}",
					function getResult()
					{
						return 0;
					}

				}
			],
			function start()
			{
			}

		});
		this.m.Screens.push({
			ID = "ShadyCharacter2",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_07.png[/img]{在你们赶路途中，一群武装人员仿佛凭空冒出，拦住了你们的去路。之前见过的那个可疑身影也混迹其中。他们宣称将特使从你手中带走，作为交换，你将得到一大笔钱—— %bribe% 克朗。\n\n否则，哼，他们就只能动武了…… | 你正逐渐进入状态——听着特使喋喋不休，又懒得搭理，暗自盼着他一个人钻进树林里永远别回来——就在这时，一群武装人员突然出现，将你们拦了下来。此前与你搭话的那个陌生人也站在其中。他们声明必须把特使交出来。作为报酬，你会得到 %bribe% 克朗。如果你拒绝，好吧，他们就会直接采取更暴力的手段。\n\n你权衡着利弊，而特使此刻则破天荒地沉默无言。 | 在赶路时，一群武装人员出来拦截。你认出此前见过的那个陌生人也站在其中。他们要你交出特使，一边示意着一只沉甸甸的钱袋，自称里面有 %bribe% 克朗。一边同时指了指他们的武器，言下之意，如果你拒绝，他们已经做好了动手的准备。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "既然你们白送钱，何必要流血呢？成交。",
					function getResult()
					{
						return "ShadyCharacter3";
					}

				},
				{
					Text = "想要他？那就用你们的命来拿吧。",
					function getResult()
					{
						return "ShadyCharacter4";
					}

				}
			],
			function start()
			{
				this.Characters.push(this.World.getGuestRoster().get(0).getImagePath());
				this.Flags.set("IsShadyDeal", false);
			}

		});
		this.m.Screens.push({
			ID = "ShadyCharacter3",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{当你权衡利弊时，特使凑到你身旁，低声说道。%SPEECH_ON%你不会让他们把我带走的，对吧？%employer% 让你保护我，给了你不少钱呢。%SPEECH_OFF%你点点头，将手搭在他肩上，低声回道：%SPEECH_ON%你说得对。他是给钱了。但他们给得更多。%SPEECH_OFF%话音未落，你将他往前一推。他挣扎着想要反抗，但声音被冰冷的剑刃切断了。鲜血溅落在地，当剑刃拔出时，一串内脏随之拖了出来。那神秘的陌生人递给你一袋承诺好的克朗。%SPEECH_ON%感谢合作，佣兵。%SPEECH_OFF% | 你看了看特使，又望向那群神秘人，朝他们点了点头。特使死死抓住你的衣服，苦苦哀求：%SPEECH_ON%不，你不能这样！你向 %employer% 保证过我的安全！%SPEECH_OFF%你一把将他交了出去。他们眨眼间便割断了他的喉咙，他扑通跪倒在地，双手捂着伤口，鲜血汩汩涌出。杀手们对着他踢来踢去，特使在众人的嘲笑声中渐渐断了气。一个钱袋落入你手中，给钱的人拍了拍你的肩膀。%SPEECH_ON%感谢你的配合，佣兵。不愧是‘佣兵’。%SPEECH_OFF% | 你瞥了一眼特使，摇了摇头。%SPEECH_ON%我是个佣兵，价高者得。%SPEECH_OFF%特使惨叫出声，但一个男人走上前去，用一把手弩一箭射在他眉心，箭杆穿透颅骨从脑后钻出，上面还裹着搅烂的脑浆。那神秘人朝你扔了一袋克朗。%SPEECH_ON%这对于在场的人来说，这算是一场遗憾，还是皆大欢喜？%SPEECH_OFF%你清点着克朗回答道：%SPEECH_ON%在你的人给特使的脑袋开个洞之前，两者皆有。现在嘛，只是皆大欢喜了。%SPEECH_OFF%那神秘人嘴角微微一扯，露出一丝苦笑。%SPEECH_ON%真是遗憾。我个人倒是挺喜欢不同意见的。正如人们所说，那样更有戏剧性。%SPEECH_OFF%}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "{轻松的克朗。 | 每个人都得偿所愿。}",
					function getResult()
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).getFlags().set("Betrayed", true);
						this.World.Assets.addMoney(this.Flags.get("Bribe"));
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractBetrayal);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "没能保护特使");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			],
			function start()
			{
				this.updateAchievement("NeverTrustAMercenary", 1, 1);
				this.Characters.push(this.World.getGuestRoster().get(0).getImagePath());
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Flags.get("Bribe") + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "ShadyCharacter4",
			Title = "在途中…",
			Text = "[img]gfx/ui/events/event_50.png[/img]{你一手将特使推到身后，另一手拔剑出鞘。那神秘人点了点头，缓缓退回到己方战线之后。%SPEECH_ON%真遗憾，但我的事还是得办下去。相信你能理解。%SPEECH_OFF% | 神秘人伸出一只手臂，手指微屈，仿佛要把特使从你身边勾走。然而，你却将使节往后一推，挡在己方战线之后。陌生人随即点了点头。%SPEECH_ON%我可以理解。但没有退路。佣兵，你我各为其主。你必须忠于你的雇主，我也是。就让我们当中最强的那个人站到最后，去回报那些将信任交付于我们手中的人。%SPEECH_OFF% | 特使向你苦苦哀求，你让他闭嘴，随即转身面向那队杀手。%SPEECH_ON%特使会活着离开这里。%SPEECH_OFF%那神秘的陌生人点了点头，悄然退回己方战线之后。%SPEECH_ON%我明白。生意就是生意，而眼下，这桩生意必须有个结果。%SPEECH_OFF%他的手下走上前，纷纷拔出了长剑。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "拿起武器！",
					function getResult()
					{
						local p = this.World.State.getLocalCombatProperties(this.World.State.getPlayer().getPos());
						p.CombatID = "Mercs";
						p.Entities = [];
						p.Parties = [];
						p.Music = this.Const.Music.NobleTracks;
						p.PlayerDeploymentType = this.Const.Tactical.DeploymentType.Line;
						p.EnemyDeploymentType = this.Const.Tactical.DeploymentType.Line;
						this.Const.World.Common.addUnitsToCombat(p.Entities, this.Const.World.Spawn.Mercenaries, 120 * this.Contract.getDifficultyMult() * this.Contract.getScaledDifficultyMult(), this.World.FactionManager.getFactionOfType(this.Const.FactionType.Bandits).getID());
						this.World.Contracts.startScriptedCombat(p, false, true, true);
						return 0;
					}

				}
			],
			function start()
			{
				this.Characters.push(this.World.getGuestRoster().get(0).getImagePath());
			}

		});
		this.m.Screens.push({
			ID = "Success1",
			Title = "你回来后…",
			Text = "[img]gfx/ui/events/event_04.png[/img]{你带着特使回到了 %employer% 身边。%SPEECH_ON%啊，佣兵，看来你不负所托。还有你，特使……？%SPEECH_OFF%%envoy% 俯身上前，在贵族耳边低语了几句。他往椅背上一靠，点了点头。%SPEECH_ON%好，很好。我们谈谈……哦，对了，佣兵，你的赏金就在外面。去找门口的卫兵领就行。%SPEECH_OFF%两人转身离去。你走出大厅，一个魁梧的男人递给你一只装有 %reward_completion% 克朗的钱袋。 | 回到 %employer% 身边后，特使离开你身侧，迅速而悄声地向那人汇报了些消息。%employer% 点了点头，对消息的内容不露半点声色，随即向附近一名卫兵打了个响指。那个卫兵走上前来，将一只钱袋递到你手中。等你接过抬起头来，贵族与特使已双双不见踪影。 | 护送 %envoy% 平安归来后，特使向你道谢。%employer% 却没那么客气，径自无视你的存在，转而与那神秘使者低声交谈。当你站在一旁等着领赏时，一个守卫悄悄走过来，将一个木箱塞进你怀里。%SPEECH_ON%这是 %reward_completion% 克朗。你要数的话随便数。%SPEECH_OFF% | 关于 %employer% 那个鬼鬼祟祟的特使在那座城镇干了什么，你几乎一无所知。特使与雇主相见，立刻凑在一起窃窃私语，声音压得极低。当你上前询问酬劳时，一名卫兵拦住了你，将一个钱袋塞进你怀里。正如承诺的那样，里面有 %reward_completion% 克朗。你对政治毫无兴趣，自然不会在此久留，看这两人在谋划什么。 | %employer% 张开双臂欢迎你们。%SPEECH_ON%啊，你保住了 %envoy% 的安全！%SPEECH_OFF%他抱了抱特使，却只是和你握了握手，顺便把一袋克朗塞到了你手里。%SPEECH_ON%我就知道你靠得住，佣兵。那么，请……%SPEECH_OFF%他朝门口示意。你转身离去，留下两人继续交谈。}",
			Image = "",
			Characters = [],
			List = [],
			ShowEmployer = true,
			Options = [
				{
					Text = "来之不易的克朗。",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractSuccess);
						this.World.Assets.addMoney(this.Contract.m.Payment.getOnCompletion());
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractSuccess, "安全护送特使");
						this.World.Contracts.finishActiveContract();
						return 0;
					}

				}
			],
			function start()
			{
				this.List.push({
					id = 10,
					icon = "ui/icons/asset_money.png",
					text = "你获得了[color=" + this.Const.UI.Color.PositiveEventValue + "]" + this.Contract.m.Payment.getOnCompletion() + "[/color]克朗"
				});
			}

		});
		this.m.Screens.push({
			ID = "Failure1",
			Title = "战斗之后",
			Text = "[img]gfx/ui/events/event_60.png[/img]{特使没能活下来。%employer% 虽然能偶尔接受一些损失，但他不会对此满意的。往后尽量别再让他失望了。 | 可惜，%envoy% %envoy_title% 此时就死在你的脚下。对于一个得到了安全承诺的人来说，这真是个悲惨的结局！唉，算了。往后的日子里，最好不要一直搞砸 %employer% 的事儿了。 | 好吧，看看这是怎么了：特使死了。你唯一的职责就是让那人好好活着，而现在，他做不到这一点了。你甚至不需要去见 %employer% 也知道，他肯定气炸了。 | 你保证过要保护特使安全。可比起直接丢了命，恐怕也没有比这更重的伤害了，你在这项任务上失败得相当彻底。 | 保护特使。只需让特使活着。特使必须活下去。喂，我可是特使，我太重要了，不能就这么死掉！\n\n 这些话显然都被当成了耳边风，因为这位特使已经死透了。 | 当整个世界都想要一个人的命时，就很难让他活下去。遗憾的是，%envoy% %envoy_title% 没能走完这段旅程。%employer% 显然不会对此有什么好脸色。}",
			Image = "",
			List = [],
			ShowEmployer = false,
			Options = [
				{
					Text = "该死的！",
					function getResult()
					{
						this.World.Assets.addBusinessReputation(this.Const.World.Assets.ReputationOnContractFail);
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationNobleContractFail, "没能保护特使");
						this.World.Contracts.finishActiveContract(true);
						return 0;
					}

				}
			]
		});
	}

	function onPrepareVariables( _vars )
	{
		_vars.push([
			"objective",
			this.m.Flags.get("DestinationName")
		]);
		_vars.push([
			"bribe",
			this.m.Flags.get("Bribe")
		]);
		_vars.push([
			"envoy",
			this.m.Flags.get("EnvoyName")
		]);
		_vars.push([
			"envoy_title",
			this.m.Flags.get("EnvoyTitle")
		]);
		_vars.push([
			"enemynoblehouse",
			this.m.Flags.get("EnemyName")
		]);
		_vars.push([
			"direction",
			this.m.Destination != null && !this.m.Destination.isNull() ? this.Const.Strings.Direction8[this.m.Home.getTile().getDirection8To(this.m.Destination.getTile())] : ""
		]);
	}

	function onClear()
	{
		if (this.m.IsActive)
		{
			this.m.Destination.getSprite("selection").Visible = false;
			this.m.Home.getSprite("selection").Visible = false;
			this.World.State.setUseGuests(true);
			this.World.getGuestRoster().clear();
		}
	}

	function onIsValid()
	{
		if (this.World.FactionManager.isCivilWar())
		{
			return false;
		}

		if (this.m.IsStarted)
		{
			if (this.m.Destination == null || this.m.Destination.isNull() || !this.m.Destination.isAlive())
			{
				return false;
			}

			return true;
		}
		else
		{
			local settlements = this.World.EntityManager.getSettlements();
			local hasPotentialDestination = false;

			foreach( s in settlements )
			{
				if (!s.isDiscovered() || s.isMilitary() || s.isIsolated())
				{
					continue;
				}

				if (s.getOwner() == null || s.getOwner().getID() == this.getFaction())
				{
					continue;
				}

				hasPotentialDestination = true;
				break;
			}

			if (!hasPotentialDestination)
			{
				return false;
			}

			return true;
		}
	}

	function onIsTileUsed( _tile )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull() && _tile.ID == this.m.Destination.getTile().ID)
		{
			return true;
		}

		return false;
	}

	function onSerialize( _out )
	{
		if (this.m.Destination != null && !this.m.Destination.isNull())
		{
			_out.writeU32(this.m.Destination.getID());
		}
		else
		{
			_out.writeU32(0);
		}

		this.contract.onSerialize(_out);
	}

	function onDeserialize( _in )
	{
		local dest = _in.readU32();

		if (dest != 0)
		{
			this.m.Destination = this.WeakTableRef(this.World.getEntityByID(dest));
		}

		this.contract.onDeserialize(_in);
	}

});

