local gt = this.getroottable();

if (!("Contracts" in gt.Const))
{
	gt.Const.Contracts <- {};
}

gt.Const.Contracts.Overview <- [
	{
		ID = "Overview",
		Title = "任务概述",
		Text = "你方谈判的合同如下。你同意这些条款吗？",
		Image = "",
		List = [],
		Options = [
			{
				Text = "我接受这份合同。",
				function getResult()
				{
					this.Contract.setState("Running");
					return 0;
				}

			},
			{
				Text = "我需要点时间考虑考虑。",
				function getResult()
				{
					this.World.State.getTownScreen().updateContracts();
					return 0;
				}

			},
			{
				Text = "我想了想，我拒绝这份合同。",
				function getResult()
				{
					this.World.Contracts.removeContract(this.Contract);
					this.World.State.getTownScreen().updateContracts();
					return 0;
				}

			}
		],
		ShowObjectives = true,
		ShowPayment = true,
		ShowEmployer = true,
		ShowDifficulty = true,
		function start()
		{
			this.Contract.m.IsNegotiated = true;
		}

	}
];
gt.Const.Contracts.NegotiationDefault <- [
	{
		ID = "Negotiation",
		Title = "谈判",
		Text = "",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [],
		function start()
		{
			this.Options = [];
			this.Options.push({
				Text = "我接受你的报价。",
				function getResult()
				{
					this.Contract.m.BulletpointsPayment = [];

					if (this.Contract.m.Payment.Advance != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getInAdvance() + "克朗预付款。");
					}

					if (this.Contract.m.Payment.Completion != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getOnCompletion() + "克朗当合同完成时。");
					}

					return "Overview";
				}

			});
			this.Options.push({
				Text = "我们需要更多的报酬。",
				function getResult()
				{
					if (!this.World.Retinue.hasFollower("follower.negotiator"))
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelationEx(-0.5);
					}

					this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

					if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
					{
						return "Negotiation.Fail";
					}

					if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
					{
						this.Contract.m.Payment.IsFinal = true;
					}
					else
					{
						this.Contract.m.Payment.IsFinal = false;
						this.Contract.m.Payment.Pool = this.Contract.m.Payment.Pool * (1.0 + this.Math.rand(3, 10) * 0.01);
					}

					return "Negotiation";
				}

			});

			if (this.Contract.m.Payment.Advance < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Advance == 0 ? "我们需要预付款。" : "我们需要更多的预付款。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Advance >= this.World.Assets.m.AdvancePaymentCap || this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;
							this.Contract.m.Payment.Advance = this.Math.minf(1.0, this.Contract.m.Payment.Advance + 0.25);
							this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.25);
						}

						return "Negotiation";
					}

				});
			}

			if (this.Contract.m.Payment.Completion < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Completion == 0 ? "我们需要在工作完成后得到报酬。" : "我们需要在工作完成后得到更多报酬。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;
							this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.25);
							this.Contract.m.Payment.Completion = this.Math.minf(1.0, this.Contract.m.Payment.Completion + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			this.Options.push({
				Text = "算了吧，这不值得。",
				function getResult()
				{
					this.World.Contracts.removeContract(this.Contract);
					this.World.State.getTownScreen().updateContracts();
					return 0;
				}

			});

			if (!this.Contract.m.Payment.IsNegotiating)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{他点点头。%SPEECH_ON%很好。我刚才就在考虑给你的报酬。 | 他挺直了身子。%SPEECH_ON%那么，聊聊钱的事。 | 他笑了笑。%SPEECH_ON%我的朋友，这会让你大赚一笔。 | 他深吸了一口气。%SPEECH_ON%很好，这是我准备给你开出的价码。 | 他把手搭在你的肩膀上，安抚地微笑着。%SPEECH_ON%我想我已经为你的服务准备好了合适的报酬。 | 他比划着手势，点着手指好像在算账，但你完全看不懂他在算什么。%SPEECH_ON%凭我的经验，这活儿给这些钱已经很公道了。 | 他点点头。%SPEECH_ON%你看上去挺有本事，所以我愿意多出点钱。 | 他摇晃着一个钱袋，发出叮当声。%SPEECH_ON%只要你帮我搞定这件事，这些就全是你的。 | 他摊开了双手。%SPEECH_ON%我最近手头比较紧，所以别问了，我现在就这么多。 | %SPEECH_ON%放心吧，我现在的开价对你的工作来说是一笔丰厚的奖赏。} ";
				this.Contract.m.Payment.IsNegotiating = true;
			}
			else if (this.Contract.m.Payment.IsFinal)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%我拒绝再多付哪怕一个子儿。 | %SPEECH_START%放聪明点。 | %SPEECH_START%不，不，不。 | %SPEECH_START%你以为你是谁？报酬多少由我说了算。 | 他只是严肃地看着你，摇了摇头。%SPEECH_ON% | %SPEECH_START%没门！%SPEECH_OFF%他愤怒地咆哮道。%SPEECH_ON% | %SPEECH_START%不，你拿到的报酬已经远超你的身价了。 | %SPEECH_START%不。别把我逼急了！ | %SPEECH_START%我想你还没搞清楚这里的规矩。如果你想拿钱办事，我们就得达成共识。我的报价还是刚才那样。}";
			}
			else
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%就这么多? | 他深吸了一口气。%SPEECH_ON% | 他叹了口气。%SPEECH_ON% | %SPEECH_START%挺公平。 | %SPEECH_START%行吧，行吧。 | %SPEECH_START%如果非要这样的话。 | %SPEECH_START%好吧。这样如何？ | %SPEECH_START%当然，当然，我理解。 | %SPEECH_START%合情合理。 | %SPEECH_START%有点意思。我想这样会更合适一些。 | %SPEECH_START%换成这个你能接受吗？ | %SPEECH_START%让我报下价吧。 | %SPEECH_ON%公道。换成这个你接受吗？ | %SPEECH_START%很好。考虑到你的要求，我给你这个数  | %SPEECH_START%让我们快点搞定这事。这是我的新报价。 | %SPEECH_START%大家都是朋友，不是吗？让我看看……}";
			}

			if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance == 0)
			{
				this.Text += "合同完成后 {你会得到 | 你会收到 | 我会给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你} %reward_advance% 克朗的预付款, 并且当你完成后再付 %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else
			{
				this.Text += "你一分钱都拿不到。这就是你想要的吗？%SPEECH_OFF%";
			}
		}

	},
	{
		ID = "Negotiation.Fail",
		Title = "谈判",
		Text = "[img]gfx/ui/events/event_74.png[/img]{%SPEECH_START%你搞得好像这世上只有你们会拿钱卖命似的。我想我会去别处找我需要的人手。祝你好运。%SPEECH_OFF% | %SPEECH_START%我的耐心也是有限的，看来我是在这儿浪费时间。%SPEECH_OFF% | %SPEECH_START%我受够了！我相信我能找到别人来干这活儿！%SPEECH_OFF% | %SPEECH_START%别侮辱我的智商！忘了这份合同吧，我们谈崩了。%SPEECH_OFF% | 他的脸因为愤怒而变得通红。%SPEECH_ON%给我滚出去，我没有和贪婪的魔鬼做交易的习惯！%SPEECH_OFF% | 他叹了口气。%SPEECH_ON%算了……就当没发生过。我打一开始就不该信任你。走吧，我要去找其他更靠谱的人。%SPEECH_OFF% | %SPEECH_START%我真以为我们关系很不错呢。但你要知道，泥人也有三分火气。我想我们谈不拢了。我先失陪了。%SPEECH_OFF% | %SPEECH_ON%这对我来说完全是浪费时间。在你学会什么是公道之前，别再回来了。%SPEECH_OFF%}",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [
			{
				Text = "我们不会为了这么点微薄的薪水去玩命……",
				function getResult()
				{
					this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationContractNegotiationsFail, "谈判搞砸了");
					this.World.Contracts.removeContract(this.Contract);
					return 0;
				}

			}
		]
	}
];
gt.Const.Contracts.NegotiationPerHead <- [
	{
		ID = "Negotiation",
		Title = "谈判",
		Text = "",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [],
		function start()
		{
			this.Options = [];
			this.Options.push({
				Text = "我接受你的报价。",
				function getResult()
				{
					this.Contract.m.BulletpointsPayment = [];

					if (this.Contract.m.Payment.Advance != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getInAdvance() + "克朗预付款。");
					}

					if (this.Contract.m.Payment.Count != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getPerCount() + "克朗，为你带回来的每个人头，最多" + this.Contract.m.Payment.MaxCount + "个。");
					}

					if (this.Contract.m.Payment.Completion != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getOnCompletion() + "克朗当合同完成时。");
					}

					return "Overview";
				}

			});
			this.Options.push({
				Text = "我们需要更多的报酬。",
				function getResult()
				{
					if (!this.World.Retinue.hasFollower("follower.negotiator"))
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelationEx(-0.5);
					}

					this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

					if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
					{
						return "Negotiation.Fail";
					}

					if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
					{
						this.Contract.m.Payment.IsFinal = true;
					}
					else
					{
						this.Contract.m.Payment.IsFinal = false;
						this.Contract.m.Payment.Pool = this.Contract.m.Payment.Pool * (1.0 + this.Math.rand(3, 10) * 0.01);
					}

					return "Negotiation";
				}

			});

			if (this.Contract.m.Payment.Count < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Count == 0 ? "我们需要按带回的脑袋数量来结算报酬。" : "带回的每颗脑袋，你得付给我们更多的钱。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Completion > 0 && this.Contract.m.Payment.Advance > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.125);
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.125);
							}
							else if (this.Contract.m.Payment.Advance > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.25);
							}

							this.Contract.m.Payment.Count = this.Math.minf(1.0, this.Contract.m.Payment.Count + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			if (this.Contract.m.Payment.Advance < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Advance == 0 ? "我们需要预付款。" : "我们需要更多的预付款。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Contract.m.Payment.Advance >= this.World.Assets.m.AdvancePaymentCap || this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Completion > 0 && this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.125);
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.125);
							}
							else if (this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.25);
							}

							this.Contract.m.Payment.Advance = this.Math.minf(1.0, this.Contract.m.Payment.Advance + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			if (this.Contract.m.Payment.Completion < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Completion == 0 ? "我们需要在工作完成后得到报酬。" : "我们需要在工作完成后得到更多报酬。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Advance > 0 && this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.125);
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.125);
							}
							else if (this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.25);
							}

							this.Contract.m.Payment.Completion = this.Math.minf(1.0, this.Contract.m.Payment.Completion + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			this.Options.push({
				Text = "算了吧，这不值得。",
				function getResult()
				{
					this.World.Contracts.removeContract(this.Contract);
					this.World.State.getTownScreen().updateContracts();
					return 0;
				}

			});

			if (!this.Contract.m.Payment.IsNegotiating)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{他点点头。%SPEECH_ON%很好。我刚才就在考虑给你的报酬。 | 他笑了笑。%SPEECH_ON%我的朋友，这会让你大赚一笔。 | 他深吸了一口气。%SPEECH_ON%很好，这是我准备给你开出的价码。 |  他把手搭在你的肩膀上，安抚地微笑着。%SPEECH_ON%我想我已经为你的服务准备好了合适的报酬。 | 他比划着手势，点着手指好像在算账，但你完全看不懂他在算什么。%SPEECH_ON%凭我的经验，这活儿给这些钱已经很公道了。 | 他点点头。%SPEECH_ON%你看上去挺有本事，所以我愿意多出点钱。 | 他摇晃着一个钱袋，发出叮当声。%SPEECH_ON%只要你帮我搞定这件事，这些就全是你的。 | 他摊开了双手。%SPEECH_ON%我最近手头比较紧，所以别问了，我现在就这么多。 | %SPEECH_ON%放心吧，我现在的开价对你的工作来说是一笔丰厚的奖赏。} ";
				this.Contract.m.Payment.IsNegotiating = true;
			}
			else if (this.Contract.m.Payment.IsFinal)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%我拒绝再多付哪怕一个子儿。 | %SPEECH_START%放聪明点。  | %SPEECH_START%不，不，不。 | %SPEECH_START%你以为你是谁？报酬多少由我说了算。 | 他只是严肃地看着你，摇了摇头。%SPEECH_ON% | %SPEECH_START%没门！%SPEECH_OFF%他愤怒地咆哮道。%SPEECH_ON% | %SPEECH_START%不，你拿到的报酬已经远超你的身价了。 | %SPEECH_START%不。别把我逼急了！ | %SPEECH_START%我想你还没搞清楚这里的规矩。如果你想拿钱办事，我们就得达成共识。我的报价还是刚才那样。}";
			}
			else
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%就这么多? | 他深吸了一口气。%SPEECH_ON% | 他叹了口气。%SPEECH_ON% | %SPEECH_START%挺公平。 | %SPEECH_START%行吧，行吧。 | %SPEECH_START%如果非要这样的话。 | %SPEECH_START%好吧。这样如何？ | %SPEECH_START%当然，当然，我理解。 | %SPEECH_START%合情合理。 | %SPEECH_START%有点意思。我想这样会更合适一些。 | %SPEECH_START%换成这个你能接受吗？ | %SPEECH_START%让我报下价吧。 | %SPEECH_ON%公道。换成这个你接受吗？ | %SPEECH_START%很好。考虑到你的要求，我给你这个数  | %SPEECH_START%让我们快点搞定这事。这是我的新报价。 | %SPEECH_START%大家都是朋友，不是吗？让我看看……}";
			}

			if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "合同完成后 {你会得到 | 你会收到 | 我会给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "每带回一个脑袋 {你会得到 | 你会收到 | 我会给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你} %reward_advance% 克朗的预付款, 完工后再拿剩下的 %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款, 并且每带回一个脑袋 {你会再得到 | 你会再收到 | 我会再给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "每带回一个脑袋 {你会得到 | 你会收到 | 我会给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。合同完成后 {你会再得到 | 你会再收到 | 我会再给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你} %reward_advance% 克朗的预付款, 并且每带回一个脑袋 {你会得到 | 你会收到 | 我会给你} %reward_count% 克朗, {封顶 %maxcount% 个头 | 我最多给你 %maxcount% 个脑袋的钱 }。合同完成后 {你会再得到 | 你会再收到 | 我会再给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else
			{
				this.Text += "你一分钱都拿不到。这就是你想要的吗？%SPEECH_OFF%";
			}
		}

	},
	{
		ID = "Negotiation.Fail",
		Title = "谈判",
		Text = "[img]gfx/ui/events/event_74.png[/img]{%SPEECH_START%你搞得好像这世上只有你们会拿钱卖命似的。我想我会去别处找我需要的人手。祝你好运。%SPEECH_OFF% | %SPEECH_START%我的耐心也是有限的，看来我是在这儿浪费时间。%SPEECH_OFF% | %SPEECH_START%我受够了！我相信我能找到别人来干这活儿！%SPEECH_OFF% | %SPEECH_START%别侮辱我的智商！忘了这份合同吧，我们谈崩了。%SPEECH_OFF% | 他的脸因为愤怒而变得通红。%SPEECH_ON%给我滚出去，我没有和贪婪的魔鬼做交易的习惯！%SPEECH_OFF% | 他叹了口气。%SPEECH_ON%算了……就当没发生过。我打一开始就不该信任你。走吧，我要去找其他更靠谱的人。%SPEECH_OFF% | %SPEECH_START%我真以为我们关系很不错呢。但你要知道，泥人也有三分火气。我想我们谈不拢了。我先失陪了。%SPEECH_OFF% | %SPEECH_START%这对我来说完全是浪费时间。在你学会什么是公道之前，别再回来了。%SPEECH_OFF%}",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [
			{
				Text = "我们不会为了这么点微薄的薪水去玩命……",
				function getResult()
				{
					this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationContractNegotiationsFail, "谈判搞砸了");
					this.World.Contracts.removeContract(this.Contract);
					return 0;
				}

			}
		]
	}
];
gt.Const.Contracts.NegotiationPerHeadAtDestination <- [
	{
		ID = "Negotiation",
		Title = "谈判",
		Text = "",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [],
		function start()
		{
			this.Options = [];
			this.Options.push({
				Text = "我接受你的报价。",
				function getResult()
				{
					this.Contract.m.BulletpointsPayment = [];

					if (this.Contract.m.Payment.Advance != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getInAdvance() + "克朗预付款。");
					}

					if (this.Contract.m.Payment.Count != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getPerCount() + "克朗，为你抵达时的每个头颅，最多" + this.Contract.m.Payment.MaxCount + "个。");
					}

					if (this.Contract.m.Payment.Completion != 0)
					{
						this.Contract.m.BulletpointsPayment.push("得到" + this.Contract.m.Payment.getOnCompletion() + "克朗当合同完成时。");
					}

					return "Overview";
				}

			});
			this.Options.push({
				Text = "我们需要更多的报酬。",
				function getResult()
				{
					if (!this.World.Retinue.hasFollower("follower.negotiator"))
					{
						this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelationEx(-0.5);
					}

					this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

					if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
					{
						return "Negotiation.Fail";
					}

					if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
					{
						this.Contract.m.Payment.IsFinal = true;
					}
					else
					{
						this.Contract.m.Payment.IsFinal = false;
						this.Contract.m.Payment.Pool = this.Contract.m.Payment.Pool * (1.0 + this.Math.rand(3, 10) * 0.01);
					}

					return "Negotiation";
				}

			});

			if (this.Contract.m.Payment.Count < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Count == 0 ? "我们需要你按照我们带来的脑袋数量付款。" : "我们需要你为我们带来的每个脑袋付更多的款。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Completion > 0 && this.Contract.m.Payment.Advance > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.125);
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.125);
							}
							else if (this.Contract.m.Payment.Advance > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.25);
							}

							this.Contract.m.Payment.Count = this.Math.minf(1.0, this.Contract.m.Payment.Count + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			if (this.Contract.m.Payment.Advance < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Advance == 0 ? "我们需要预付款。" : "我们需要更多的预付款。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Contract.m.Payment.Advance >= this.World.Assets.m.AdvancePaymentCap || this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Completion > 0 && this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.125);
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.125);
							}
							else if (this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Completion = this.Math.maxf(0.0, this.Contract.m.Payment.Completion - 0.25);
							}

							this.Contract.m.Payment.Advance = this.Math.minf(1.0, this.Contract.m.Payment.Advance + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			if (this.Contract.m.Payment.Completion < 1.0)
			{
				this.Options.push({
					Text = this.Contract.m.Payment.Completion == 0 ? "我们需要在工作完成后得到报酬。" : "我们需要在工作完成后得到更多报酬。",
					function getResult()
					{
						this.Contract.m.Payment.Annoyance += this.Math.maxf(1.0, this.Math.rand(this.Const.Contracts.Settings.NegotiationAnnoyanceGainMin, this.Const.Contracts.Settings.NegotiationAnnoyanceGainMax) * this.World.Assets.m.NegotiationAnnoyanceMult);

						if (this.Contract.m.Payment.Annoyance > this.Const.Contracts.Settings.NegotiationMaxAnnoyance)
						{
							return "Negotiation.Fail";
						}

						if (this.Math.rand(1, 100) <= this.Const.Contracts.Settings.NegotiationRefuseChance * this.Contract.m.Payment.Annoyance)
						{
							this.Contract.m.Payment.IsFinal = true;
						}
						else
						{
							this.Contract.m.Payment.IsFinal = false;

							if (this.Contract.m.Payment.Advance > 0 && this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.125);
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.125);
							}
							else if (this.Contract.m.Payment.Count > 0)
							{
								this.Contract.m.Payment.Count = this.Math.maxf(0.0, this.Contract.m.Payment.Count - 0.25);
							}
							else
							{
								this.Contract.m.Payment.Advance = this.Math.maxf(0.0, this.Contract.m.Payment.Advance - 0.25);
							}

							this.Contract.m.Payment.Completion = this.Math.minf(1.0, this.Contract.m.Payment.Completion + 0.25);
						}

						return "Negotiation";
					}

				});
			}

			this.Options.push({
				Text = "算了吧，这不值得。",
				function getResult()
				{
					this.World.Contracts.removeContract(this.Contract);
					this.World.State.getTownScreen().updateContracts();
					return 0;
				}

			});

			if (!this.Contract.m.Payment.IsNegotiating)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{他点点头。%SPEECH_ON%很好。我刚才就在考虑给你的报酬。 | 他笑了笑。%SPEECH_ON%我的朋友，这会让你大赚一笔。 | 他深吸了一口气。%SPEECH_ON%很好，这是我准备给你开出的价码。 | 他把手搭在你的肩膀上，安抚地微笑着。%SPEECH_ON%我想我已经为你的服务准备好了合适的报酬。 | 他比划着手势，点着手指好像在算账，但你完全看不懂他在算什么。%SPEECH_ON%凭我的经验，这活儿给这些钱已经很公道了。 | 他点了点头。%SPEECH_ON%你看上去挺有本事，所以我愿意多出点钱。 | 他摇晃着一个钱袋，发出叮当声。%SPEECH_ON%只要你帮我搞定这件事，这些就全是你的。 | 他摊开了双手。%SPEECH_ON%我最近手头比较紧，所以别问了，我现在就这么多。 | %SPEECH_ON%放心吧，我现在的开价对你的工作来说是一笔丰厚的奖赏。} ";
				this.Contract.m.Payment.IsNegotiating = true;
			}
			else if (this.Contract.m.Payment.IsFinal)
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%我拒绝再多付哪怕一个子儿。 | %SPEECH_START%放聪明点。  | %SPEECH_START%不，不，不。 | %SPEECH_START%你以为你是谁？报酬多少由我说了算。 | 他只是严肃地看着你，摇了摇头。%SPEECH_ON% | %SPEECH_START%没门！%SPEECH_OFF%他愤怒地咆哮道。%SPEECH_ON% | %SPEECH_START%不，你拿到的报酬已经远超你的身价了。 | %SPEECH_START%不。别把我逼急了！ | %SPEECH_START%我想你还没搞清楚这里的规矩。如果你想拿钱办事，我们就得达成共识。我的报价还是刚才那样。}";
			}
			else
			{
				this.Text = "[img]gfx/ui/events/event_04.png[/img]{%SPEECH_START%就这么多? | 他深吸了一口气。%SPEECH_ON% | 他叹了口气。%SPEECH_ON% | %SPEECH_START%挺公平。 | %SPEECH_START%行吧，行吧。 | %SPEECH_START%如果非要这样的话。 | %SPEECH_START%好吧。这样如何？ | %SPEECH_START%当然，当然，我理解。 | %SPEECH_START%合情合理。 | %SPEECH_START%有点意思。我想这样会更合适一些。 | %SPEECH_START%换成这个你能接受吗？ | %SPEECH_START%让我报下价吧。 | %SPEECH_ON%公道。换成这个你接受吗？ | %SPEECH_START%很好。考虑到你的要求，我给你这个数  | %SPEECH_START%让我们快点搞定这事。这是我的新报价。 | %SPEECH_START%大家都是朋友，不是吗？让我看看……}";
			}

			if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "合同完成后 {你会得到 | 你会收到 | 我会给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "每带来一个脑袋 {你会得到 | 你会收到 | 我会给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count == 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你} %reward_advance% 克朗的预付款, 并且当你完成后再付 %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion == 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款, 每带回一个脑袋 {你会再得到 | 你会再收到 | 我会再给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance == 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "每带来一个脑袋 {你会得到 | 你会收到 | 我会给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }。合同完成后 {你会再得到 | 你会再收到 | 我会再给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else if (this.Contract.m.Payment.Completion != 0 && this.Contract.m.Payment.Advance != 0 && this.Contract.m.Payment.Count != 0)
			{
				this.Text += "{你会得到 | 你会收到 | 我会给你}共 %reward_advance% 克朗的预付款, 每带来一个脑袋 {你会再得到 | 你会再收到 | 我会再给你} %reward_count% 克朗, {封顶 %maxcount% 个 | 我最多给你 %maxcount% 个脑袋的钱 }, 合同完成后 {你会再得到 | 你会再收到 | 我会再给你} %reward_completion% 克朗。%SPEECH_OFF%";
			}
			else
			{
				this.Text += "你一分钱都拿不到。这就是你想要的吗？%SPEECH_OFF%";
			}
		}

	},
	{
		ID = "Negotiation.Fail",
		Title = "谈判",
		Text = "[img]gfx/ui/events/event_74.png[/img]{%SPEECH_START%你搞得好像这世上只有你们会拿钱卖命似的。我想我会去别处找我需要的人手。祝你好运。%SPEECH_OFF% | %SPEECH_START%我的耐心也是有限的，看来我是在这儿浪费时间。%SPEECH_OFF% | %SPEECH_START%我受够了！我相信我能找到别人来干这活儿！%SPEECH_OFF% | %SPEECH_START%别侮辱我的智商！忘了这份合同吧，我们谈崩了。%SPEECH_OFF% | 他的脸因为愤怒而变得通红。%SPEECH_ON%给我滚出去，我没有和贪婪的魔鬼做交易的习惯！%SPEECH_OFF% | 他叹了口气。%SPEECH_ON%算了……就当没发生过。我打一开始就不该信任你。走吧，我要去找其他更靠谱的人。%SPEECH_OFF% | %SPEECH_START%我真以为我们关系很不错呢。但你要知道，泥人也有三分火气。我想我们谈不拢了。我先失陪了。%SPEECH_OFF% | %SPEECH_START%这对我来说完全是浪费时间。在你学会什么是公道之前，别再回来了。%SPEECH_OFF%}",
		Image = "",
		List = [],
		ShowEmployer = true,
		ShowDifficulty = true,
		Options = [
			{
				Text = "我们不会为了这么点微薄的薪水去玩命……",
				function getResult()
				{
					this.World.FactionManager.getFaction(this.Contract.getFaction()).addPlayerRelation(this.Const.World.Assets.RelationContractNegotiationsFail, "谈判搞砸了");
					this.World.Contracts.removeContract(this.Contract);
					return 0;
				}

			}
		]
	}
];

