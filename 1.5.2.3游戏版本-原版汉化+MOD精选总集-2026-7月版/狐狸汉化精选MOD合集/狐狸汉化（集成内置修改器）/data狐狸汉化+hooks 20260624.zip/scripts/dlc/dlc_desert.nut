local gt = this.getroottable();

if (!("DLC" in gt.Const))
{
	gt.Const.DLC <- {};
	gt.Const.DLC.Mask <- 0;
}

if (!("Desert" in gt.Const.DLC) || !this.Const.DLC.Desert)
{
	this.Const.DLC.Desert <- this.hasDLC(1361280) && this.Const.Serialization.Version >= 63;

	if (this.Const.DLC.Desert)
	{
		this.Const.DLC.Mask = this.Const.DLC.Mask | 64;
		this.Const.LoadingScreens.push("ui/screens/loading_screen_10.jpg");
		local tips = [
			"南方城邦在医学、占星术和炼金术方面取得了无可匹敌的进步。",
			"南方人以他们的神命名自己为“镀金者”，他们整日沐浴在神光之中。",
			"“负债者”是城邦国家中的一个社会阶层，由罪犯、战俘和违犯宗教教义者组成，其本质是奴隶。",
			"南方城邦是在古代帝国的废墟上建立起来的。",
			"游牧民是一群不受城邦统治的南方人。",
			"游牧民是沙漠战争和利用环境优势的专家，这包括向你的面部抛洒沙尘。",
			"伊弗利特是一种支配岩石和流沙的恶灵。",
			"一把卡塔尔匕首最好与其他能够使敌人茫然或击晕的武器结合使用。",
			"火铳需要一整个回合才能重新装填 - 除非你的角色拥有“弩与火器精通”特技。",
			"火铳是一种远程武器，能够一次攻击最多击中6个目标，但是射程比弓和弩都要近。",
			"火矛和投掷武器一样，每场战斗后都需要重新装填。",
			"竞技场比赛提供了一种快速赚钱的方法，但你不能中途撤退或拾取战利品。",
			"竞技场锦标赛是具有不同规则的特殊活动。使用五名手下连续赢得三场战斗即可得到一件著名物品！",
			"每五场竞技场比赛就会提供一个赢取一件角斗士装备的机会，别的地方可买不到。",
			"火油罐不仅可以对你的对手造成伤害，还可以用来封锁格子并迟滞对手的行动。",
			"即使你的手下已经被卷入近战，烟雾弹也可以使其安全撤退。",
			"城邦的迫击炮只有在有一名工程师在旁操作时才能开火。",
			"使用“搜捕者”起源时，你可以在每场与人类的战斗后抓捕俘虏，并迫使他们为你而战。",
			"使用“角斗士”起源时，你将永久三个强大的初始角色，但失去全部三人将使你的战役结束。",
			"雇佣非战斗随从加入你的随行人员可以让你按照自己的游戏风格定制战役。",
			"被兽人摧毁了著名盾牌？为你的战团雇一个铁匠并修复一切物品，即使它的耐久度降至零。",
			"训练新兵需要太长时间？雇佣一个教官以让他们更快的获得经验。",
			"遇到的敌方冠军太少？雇佣一个赏金猎人以找到更多冠军，并且可以为你杀死的每一个得到一份赏金。",
			"工资支出太多了吗？雇佣一名出纳员来减少你需要支付的工资。",
			"想知道谁去了那边？雇佣一个观察员以从地图上的足迹中获取更多信息。",
			"总是缺少弹药和工具？雇佣一个拾荒者来回收你使用了的弹药，并从你摧毁的护甲中收集工具。",
			"物品栏满了？在随从界面为你的战团购买马车和货车。",
			"通过获取声望，你可以解锁更多的非战斗随从栏位。",
			"凶猛的鬣狗在南方的沙漠游荡，它们有着强大的颚骨，甚至可以咬碎金属护甲并造成出血伤口。",
			"尝试不同随从，并找到与你的游戏风格和起源匹配的那些。"
		];
		this.Const.TipOfTheDay.extend(tips);
		this.Const.Music.BeastsTracksSouth.push("music/beasts_04.ogg");
		this.Const.Music.ArenaTracks.push("music/beasts_04.ogg");
		this.Const.Music.WorldmapTracksSouth.push("music/worldmap_11.ogg");
		this.Const.Music.WorldmapTracksGreaterEvilSouth.push("music/worldmap_11.ogg");
		this.Const.PlayerBanners.push("banner_28");
		this.Const.PlayerBanners.push("banner_29");
		this.Const.PlayerBanners.push("banner_30");
		this.Const.Items.NamedWeapons.push("weapons/named/named_qatal_dagger");
		this.Const.Items.NamedWeapons.push("weapons/named/named_swordlance");
		this.Const.Items.NamedWeapons.push("weapons/named/named_polemace");
		this.Const.Items.NamedWeapons.push("weapons/named/named_two_handed_scimitar");
		this.Const.Items.NamedWeapons.push("weapons/named/named_handgonne");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_qatal_dagger");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_swordlance");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_polemace");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_two_handed_scimitar");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_shamshir");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_qatal_dagger");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_swordlance");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_polemace");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_two_handed_scimitar");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_spear");
		this.Const.Items.NamedSouthernWeapons.push("weapons/named/named_handgonne");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_shamshir");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_qatal_dagger");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_swordlance");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_polemace");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_two_handed_scimitar");
		this.Const.Items.NamedSouthernMeleeWeapons.push("weapons/named/named_spear");
		this.Const.Items.NamedShields.push("shields/named/named_sipar_shield");
		this.Const.Items.NamedSouthernShields.push("shields/named/named_sipar_shield");
		this.Const.Items.NamedSouthernArmors.push("armor/named/black_and_gold_armor");
		this.Const.Items.NamedSouthernArmors.push("armor/named/leopard_armor");
		this.Const.Items.NamedArmors.push("armor/named/black_and_gold_armor");
		this.Const.Items.NamedArmors.push("armor/named/leopard_armor");
		this.Const.Items.NamedSouthernHelmets.push("helmets/named/red_and_gold_band_helmet");
		this.Const.Items.NamedSouthernHelmets.push("helmets/named/gold_and_black_turban");
		this.Const.Items.NamedHelmets.push("helmets/named/red_and_gold_band_helmet");
		this.Const.Items.NamedHelmets.push("helmets/named/gold_and_black_turban");
		this.Const.World.Settings.SizeY = 170;
		this.Const.World.Settlements.Master.push({
			Amount = 3,
			List = this.Const.World.Settlements.CityStates,
			IgnoreSide = true,
			AdditionalSpace = 13
		});
		this.Const.Faces.Barber.extend(this.Const.Faces.SouthernMale);
		this.Const.Bodies.Barber.extend(this.Const.Bodies.SouthernMale);
		this.Const.Hair.Barber.extend(this.Const.Hair.SouthernMaleOnly);
		this.Const.Beards.Barber.extend(this.Const.Beards.SouthernOnly);
	}
}

