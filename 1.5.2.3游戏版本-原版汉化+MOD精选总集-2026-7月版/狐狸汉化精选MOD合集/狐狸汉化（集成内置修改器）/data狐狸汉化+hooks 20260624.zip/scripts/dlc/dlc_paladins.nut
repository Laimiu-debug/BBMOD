local gt = this.getroottable();

if (!("DLC" in gt.Const))
{
	gt.Const.DLC <- {};
	gt.Const.DLC.Mask <- 0;
}

if (!("Paladins" in gt.Const.DLC) || !this.Const.DLC.Paladins)
{
	this.Const.DLC.Paladins <- this.hasDLC(1910050) && this.Const.Serialization.Version >= 64;

	if (this.Const.DLC.Paladins)
	{
		this.Const.DLC.Mask = this.Const.DLC.Mask | 256;
		this.Const.LoadingScreens.push("ui/screens/loading_screen_11.jpg");
		local tips = [
			"使用“解剖学家”起源时，击败新类型的敌人能够获取药剂，可以用来突变你的手下并使他们获得特殊能力。",
			"使用“宣誓者”起源时，你无法选择野心，但可以选择提供不同增益和负担的誓言。"
		];
		this.Const.TipOfTheDay.extend(tips);
		this.Const.PlayerBanners.push("banner_32");
		this.Const.PlayerBanners.push("banner_33");
	}
}

