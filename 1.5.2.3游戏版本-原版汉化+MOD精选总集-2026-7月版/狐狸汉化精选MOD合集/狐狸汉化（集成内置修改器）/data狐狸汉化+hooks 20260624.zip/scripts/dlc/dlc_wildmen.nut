local gt = this.getroottable();

if (!("DLC" in gt.Const))
{
	gt.Const.DLC <- {};
	gt.Const.DLC.Mask <- 0;
}

if (!("Wildmen" in gt.Const.DLC) || !this.Const.DLC.Wildmen)
{
	this.Const.DLC.Wildmen <- this.hasDLC(1067690) && this.Const.Serialization.Version >= 48;

	if (this.Const.DLC.Wildmen)
	{
		this.Const.DLC.Mask = this.Const.DLC.Mask | 16;
		this.Const.LoadingScreens.push("ui/screens/loading_screen_06.jpg");
		this.Const.LoadingScreens.push("ui/screens/loading_screen_09.jpg");
		local tips = [
			"北方居住着凶猛的野蛮人部落。",
			"野蛮人往往在战斗开始时就能压制对手，但很快就会疲惫不堪。",
			"北方的战獒比南方的战犬更加结实，但速度和敏捷上有所不如。",
			"部落鼓手们有节奏的韵律能够每回合少量降低战场上所有野蛮人的疲劳。",
			"兽王无法在与敌人相邻时挥鞭子指挥他们的野兽战争机器。",
			"野蛮人期望在死后与他们的先祖相遇。",
			"尝试不同的起源来使战役适合你的游戏风格。",
			"使用“独狼”起源时，你将拥有一个玩家角色。如果他死了，这场战役就结束了。",
			"使用“平民民兵”起源时，你一次能带16名手下参加战斗。",
			"使用“邪教徒”起源时，你的神将会要求你进行献祭，但同时也会奖赏那些忠于他的人。",
			"使用“偷猎者团队”起源时，你在世界地图上的移动速度更快。",
			"使用“贸易商队”起源时，你在买入和卖出时都会得到更好的价格。",
			"投石索的攻击命中头部可造成“茫然”状态效果。",
			"由于石头到处都是，投石索永远不会用光弹药。",
			"战鞭能够暂时解除对手的武器，阻止他们使用武器技能。",
			"战鞭能够造成流血伤口，但对抗护甲时效率低下。",
			"匕首和弯刀在打击目标时更容易造成致残伤。"
		];
		this.Const.TipOfTheDay.extend(tips);
		this.Const.PlayerBanners.push("banner_24");
		this.Const.PlayerBanners.push("banner_25");
		this.Const.Tattoos.All.push("warpaint_02");
		this.Const.Tattoos.All.push("warpaint_03");
		this.Const.Tattoos.All.push("tattoo_02");
		this.Const.Tattoos.All.push("tattoo_03");
		this.Const.Tattoos.All.push("tattoo_04");
		this.Const.Tattoos.All.push("tattoo_05");
		this.Const.Tattoos.All.push("tattoo_06");
		this.Const.Items.NamedWeapons.push("weapons/named/named_bardiche");
		this.Const.Items.NamedWeapons.push("weapons/named/named_shamshir");
		this.Const.Items.NamedWeapons.push("weapons/named/named_battle_whip");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_bardiche");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_shamshir");
		this.Const.Items.NamedMeleeWeapons.push("weapons/named/named_battle_whip");
		this.Const.Items.NamedHelmets.push("helmets/named/norse_helmet");
		this.Const.Items.NamedHelmets.push("helmets/named/named_conic_helmet_with_faceguard");
		this.Const.Items.NamedHelmets.push("helmets/named/named_nordic_helmet_with_closed_mail");
		this.Const.Items.NamedHelmets.push("helmets/named/named_steppe_helmet_with_mail");
		this.Const.Items.NamedSouthernHelmets.push("helmets/named/named_steppe_helmet_with_mail");
		this.Const.Items.NamedArmors.push("armor/named/named_golden_lamellar_armor");
		this.Const.Items.NamedArmors.push("armor/named/named_noble_mail_armor");
		this.Const.Items.NamedArmors.push("armor/named/named_sellswords_armor");
		this.Const.Items.NamedSouthernArmors.push("armor/named/named_golden_lamellar_armor");
		this.Const.Items.NamedBarbarianHelmets.push("helmets/named/named_metal_bull_helmet");
		this.Const.Items.NamedBarbarianHelmets.push("helmets/named/named_metal_nose_horn_helmet");
		this.Const.Items.NamedBarbarianHelmets.push("helmets/named/named_metal_skull_helmet");
		this.Const.Items.NamedBarbarianArmors.push("armor/named/named_bronze_armor");
		this.Const.Items.NamedBarbarianArmors.push("armor/named/named_plated_fur_armor");
		this.Const.Items.NamedBarbarianArmors.push("armor/named/named_skull_and_chain_armor");
		this.Const.Items.NamedBarbarianWeapons.push("weapons/named/named_rusty_warblade");
		this.Const.Items.NamedBarbarianWeapons.push("weapons/named/named_skullhammer");
		this.Const.Items.NamedBarbarianWeapons.push("weapons/named/named_heavy_rusty_axe");
		this.Const.Items.NamedBarbarianWeapons.push("weapons/named/named_two_handed_spiked_mace");
	}
}

