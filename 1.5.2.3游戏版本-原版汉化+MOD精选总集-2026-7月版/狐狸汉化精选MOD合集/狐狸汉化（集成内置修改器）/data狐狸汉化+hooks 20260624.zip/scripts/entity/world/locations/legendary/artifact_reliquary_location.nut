this.artifact_reliquary_location <- this.inherit("scripts/entity/world/location", {
	m = {},
	function getDescription()
	{
		return "这座倾颓的遗迹早已湮灭在岁月长河之中。然而摇曳不定的火炬微光，以及从废墟深处传来的诡谲声响，无不昭示着现今的居住者们仍未离去……";
	}

	function create()
	{
		this.location.create();
		this.m.TypeID = "location.artifact_reliquary";
		this.m.LocationType = this.Const.World.LocationType.Unique;
		this.m.IsShowingDefenders = false;
		this.m.IsShowingBanner = false;
		this.m.IsAttackable = true;
		this.m.VisibilityMult = 0.0;
		this.m.Resources = 500;
		this.m.OnEnter = "event.location.artifact_reliquary_enter";
	}

	function onSpawned()
	{
		this.m.Name = "遗宝秘匣";
		this.location.onSpawned();
	}

	function onDiscovered()
	{
		this.location.onDiscovered();
		this.World.Flags.increment("LegendaryLocationsDiscovered", 1);

		if (this.World.Flags.get("LegendaryLocationsDiscovered") >= 10)
		{
			this.updateAchievement("FamedExplorer", 1, 1);
		}
	}

	function onDropLootForPlayer( _lootTable )
	{
		this.location.onDropLootForPlayer(_lootTable);
		this.dropTreasure(2, [
			"loot/marble_bust_item"
		], _lootTable);
		_lootTable.push(this.new("scripts/items/helmets/golems/grand_diviner_headdress"));
		_lootTable.push(this.new("scripts/items/armor/golems/grand_diviner_robes"));
	}

	function onInit()
	{
		this.location.onInit();
		local body = this.addSprite("body");
		body.setBrush("world_artifact_reliquary");
	}

});

