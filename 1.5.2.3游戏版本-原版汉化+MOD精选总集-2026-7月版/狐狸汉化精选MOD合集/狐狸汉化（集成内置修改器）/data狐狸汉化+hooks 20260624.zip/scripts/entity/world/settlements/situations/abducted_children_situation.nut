this.abducted_children_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.abducted_children";
		this.m.Name = "被诱拐的孩童";
		this.m.Description = "这个定居点不断有孩子失踪。猜忌与恐惧笼罩着街道，正慢慢毒害着整个社区。";
		this.m.Icon = "ui/settlement_status/settlement_effect_34.png";
		this.m.Rumors = [
			"传闻说，%settlement% 的孩子在摇篮里就凭空消失了。想想那些父母该有多绝望……",
			"我奶奶曾讲过一个关于女巫拐走孩子是为了他们纯洁血液的故事。如今在 %settlement%，失踪的孩子就和故事里一模一样。",
			"千万，千万别和女巫做交易！在 %settlement% 的一个亲戚多年前就这么做了，现在他的孩子失踪了。"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.25;
		_modifiers.SellPriceMult *= 0.75;
		_modifiers.RecruitsMult *= 0.5;
	}

});

