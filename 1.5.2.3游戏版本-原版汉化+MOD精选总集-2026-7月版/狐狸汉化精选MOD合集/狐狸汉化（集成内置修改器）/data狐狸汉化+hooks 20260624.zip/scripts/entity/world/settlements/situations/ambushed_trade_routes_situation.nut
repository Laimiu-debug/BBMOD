this.ambushed_trade_routes_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.ambushed_trade_routes";
		this.m.Name = "商路被埋伏";
		this.m.Description = "最近通往这里的道路极不安全，许多商队遭到了伏击与劫掠。由于贸易往来受阻，这里货物的种类变少但价格更高。";
		this.m.Icon = "ui/settlement_status/settlement_effect_12.png";
		this.m.Rumors = [
			"这些强盗真是我们行商的天灾！我的一个老朋友就在 %settlement% 外面遭到了伏击，不仅钱没了，还挨了一顿毒打！",
			"如果你身上带着值钱货，最好离 %settlement% 远点。那地方现在到处都是杀人犯、土匪和拦路抢劫的强盗！",
			"卫兵们已经尽力了，但那帮强盗打一枪换一个地方，专在路上截杀商人。听说他们现在就潜伏在 %settlement% 附近！"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.removeSituationByID("situation.safe_roads");
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.2;
		_modifiers.SellPriceMult *= 1.1;
		_modifiers.RarityMult *= 0.75;
	}

});

