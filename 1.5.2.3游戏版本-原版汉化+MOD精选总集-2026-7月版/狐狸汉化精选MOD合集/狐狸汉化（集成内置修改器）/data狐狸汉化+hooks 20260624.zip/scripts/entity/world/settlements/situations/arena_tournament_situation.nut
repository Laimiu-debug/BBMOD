this.arena_tournament_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.arena_tournament";
		this.m.Name = "竞技场锦标赛";
		this.m.Description = "竞技场即将举办一场大型锦标赛。报名参加，赢取丰厚奖赏！";
		this.m.Icon = "ui/settlement_status/settlement_effect_45.png";
		this.m.Rumors = [
			"你看起来像个能打的战士。%settlement% 的竞技场正在举办锦标赛，你现在报名肯定还来得及！",
			"喝完这杯我就直接动身去 %settlement% ，去瞧瞧那场伟大的竞技场锦标赛！那可是全年最棒的娱乐项目了！",
			"我听说今年 %settlement% 竞技场大赛冠军的奖品比往年还要丰厚得多！"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 5;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
	}

	function onUpdateDraftList( _draftList )
	{
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
	}

});

