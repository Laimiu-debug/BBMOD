this.besieged_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.besieged";
		this.m.Name = "被围困";
		this.m.Description = "这个地方目前或就在近期遭到了敌军围攻！城镇损毁严重，补给匮乏，许多人在此丧命。";
		this.m.Icon = "ui/settlement_status/settlement_effect_13.png";
		this.m.Rumors = [
			"飞石与火箭横飞，热油倾盆而下，百姓饥寒交迫而死——这就是围城。你可以去 %settlement% 亲眼见识一下那副惨状。",
			"年轻时我曾在 %randomnoble% 的军队服役。最糟糕的回忆莫过于我们参与的那场围攻战，整整持续了数月。遗憾的是，同样的惨剧如今正发生在 %settlement%。",
			"你听说了吗？%settlement% 正遭到围攻！困在那里的可怜人这下有得受了。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(false);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 1.0;
		_modifiers.BuyPriceMult *= 1.25;
		_modifiers.FoodPriceMult *= 2.0;
		_modifiers.RecruitsMult *= 0.5;
		_modifiers.RarityMult *= 0.5;
	}

});

