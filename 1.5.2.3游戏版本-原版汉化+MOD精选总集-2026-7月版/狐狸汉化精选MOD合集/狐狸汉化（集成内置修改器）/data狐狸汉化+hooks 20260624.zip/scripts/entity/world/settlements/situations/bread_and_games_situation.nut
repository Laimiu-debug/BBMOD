this.bread_and_games_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.bread_and_games";
		this.m.Name = "面包与竞技";
		this.m.Description = "市政厅下令开启一段充满食物、美酒与竞技的狂欢期，以取悦民众。此时粮酒充足，角斗士们纷至沓来，竞技场的赏金也比往常更高。";
		this.m.Icon = "ui/settlement_status/settlement_effect_39.png";
		this.m.Rumors = [
			"赞美 %settlement% 英明的市政厅！美酒佳肴与竞技狂欢的时刻终于到了！",
			"去过南方著名的竞技庆典吗？去 %settlement% 亲眼见识一下那场盛会的荣耀吧！",
			"一年到头辛苦劳作是为了什么？我告诉你：为了美酒、美食和竞技！我要动身去 %settlement% 凑个热闹，你也该一起去。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 3;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 1.5;
		_modifiers.FoodPriceMult *= 0.9;
	}

	function onUpdateDraftList( _draftList )
	{
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
		_draftList.push("gladiator_background");
	}

});

