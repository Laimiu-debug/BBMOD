this.ceremonial_season_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.ceremonial_season";
		this.m.Name = "祭祀时节";
		this.m.Description = "在祭祀时节，神庙会消耗大量的熏香。熏香的需求量与价格正处于历史最高点。";
		this.m.Icon = "ui/settlement_status/settlement_effect_44.png";
		this.m.Rumors = [
			"在每年的这个时候，%settlement% 的神庙冒出的烟简直像着了火的破屋子！我真纳闷他们哪来那么多熏香……",
			"如果你是个虔诚的人，你可能想去 %settlement% 烧点香，再做个祷告。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 3;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
	}

	function onUpdate( _modifiers )
	{
		_modifiers.IncensePriceMult *= 1.5;
	}

});

