this.conquered_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.conquered";
		this.m.Name = "被征服";
		this.m.Description = "这里近期遭到了征服。无数生命逝去，幸存者不得不忍受征服者肆意掠夺战利品。定居点的大部分建筑仍处于损毁状态，民心涣散。";
		this.m.Icon = "ui/settlement_status/settlement_effect_02.png";
		this.m.Rumors = [
			"听说 %settlement% 最近被攻陷了。我总是那句话：‘换了新领主，还是一样烂’……",
			"征服领土是贵族的游戏。我听说他们刚刚洗劫了 %settlement%。",
			"噢，嘿，佣兵！你参加了 %settlement% 的围攻战吗？那可真是他妈的‘恭喜’你啊。你杀了多少人？又糟蹋了多少姑娘？"
		];
		this.m.IsStacking = false;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 0.9;
		_modifiers.BuyPriceMult *= 1.1;
		_modifiers.RarityMult *= 0.6;
		_modifiers.FoodRarityMult *= 0.9;
	}

});

