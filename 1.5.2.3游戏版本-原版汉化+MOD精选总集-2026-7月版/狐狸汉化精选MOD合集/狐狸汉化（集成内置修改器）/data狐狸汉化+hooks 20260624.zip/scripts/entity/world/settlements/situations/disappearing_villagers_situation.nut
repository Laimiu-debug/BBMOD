this.disappearing_villagers_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.disappearing_villagers";
		this.m.Name = "村民失踪";
		this.m.Description = "这里的村民接连失踪，闹得人心惶惶。街头能招募到的新兵变少了，人们对待陌生人的态度也变得愈发冷淡。";
		this.m.Icon = "ui/settlement_status/settlement_effect_11.png";
		this.m.Rumors = [
			"一听说 %settlement% 那边有人失踪，我就立刻取消了行程。离麻烦远点儿，这可是我一直以来的处世之道！",
			"我的邻居 %randomname% 大约一周前去了 %settlement%，从之后就音讯全无了。我只希望他没出什么事，毕竟这年头到处都是横行的强盗和怪物……",
			"这世间邪恶力量横行。它们藏在林子里，藏在山峦中，也藏在阴影里。有时候人就这么无影无踪地消失了，而现在的 %settlement% 正在重演这一切。"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.25;
		_modifiers.SellPriceMult *= 0.75;
		_modifiers.RecruitsMult *= 0.5;
	}

});

