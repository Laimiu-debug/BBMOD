this.full_nets_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.full_nets";
		this.m.Name = "渔获颇丰";
		this.m.Description = "水里满是鱼群。鲜鱼供应充足，价格十分低廉。";
		this.m.Icon = "ui/settlement_status/settlement_effect_19.png";
		this.m.Rumors = [
			"每年的这个时候，成群的大鱼总会经过 %settlement%。他们只需要把网撒进水里，拉上来的鱼多得根本吃不完！真是走了狗运！",
			"明天我就动身去 %settlement%，把我的车装满鱼。传闻那边的渔民们撞了大运了！",
			"你是做买卖的吗？我听说 %settlement% 那边的渔网里全是满满当当的鲜鱼。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 3;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 2.0;
		_modifiers.FoodPriceMult *= 0.5;
	}

});

