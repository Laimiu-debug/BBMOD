this.good_harvest_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.good_harvest";
		this.m.Name = "五谷丰登";
		this.m.Description = "农作物的生长条件几近完美。粮食供应充沛，且价格更为低廉。";
		this.m.Icon = "ui/settlement_status/settlement_effect_17.png";
		this.m.Rumors = [
			"如果你需要储备粮食，就去 %settlement% 吧。那帮走运的混蛋今年赶上了一个大丰收年。",
			"我从 %settlement% 赶过来卖掉我们多余的农产品。神明眷顾，赐予了我们多年来最好的一次丰收！",
			"我刚听说，多亏了这场丰收，%settlement% 的粮仓和地窖现在都塞得满满当当的。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 7;
	}

	function getAddedString( _s )
	{
		return _s + "受益于" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再受益于" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 2.0;
		_modifiers.FoodPriceMult *= 0.5;
	}

});

