this.greenskins_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.greenskins";
		this.m.Name = "绿皮肆虐";
		this.m.Description = "绿皮正在周边土地上制造恐怖。随着兽人和哥布林不断袭击偏远农场、摧毁商队，许多人因此丧命。物资开始匮乏，民众陷入绝望。";
		this.m.Icon = "ui/settlement_status/settlement_effect_01.png";
		this.m.Rumors = [
			"我听说那些邪恶的绿皮正在 %settlement% 周边到处烧杀抢掠！是真的吗？我希望它们可千万别窜到咱们这儿来……",
			"你看见傍晚天边的那几道烟柱了吗？那是从 %settlement% 升起来的，那些绿皮正在那边的乡下杀人放火呢。",
			"嘿，瞧瞧我这只手落下的残疾！自从前阵子撞上那帮绿皮后，我这手就没了指头，几乎废了。现在听说它们又回来了，就在咱们说话这会儿，它们正围着 %settlement% 劫掠呢。"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.RarityMult *= 0.75;
		_modifiers.RecruitsMult *= 0.75;
	}

});

