this.high_spirits_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.high_spirits";
		this.m.Name = "士气高涨";
		this.m.Description = "这里民心振奋，人们非常渴望与你做生意。";
		this.m.Icon = "ui/settlement_status/settlement_effect_05.png";
		this.m.Rumors = [
			"我今天刚从 %settlement% 过来，身上的衣服还带着路上的尘土。那边的人心情好得不得了，虽然我也不太清楚是为什么……",
			"不用给我倒酒了，我还没从 %settlement% 的庆典里清醒过来呢。那帮人可真知道怎么找乐子！",
			"传闻说 %settlement% 的居民刚刚找回了一件极其重要的圣物。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 1.05;
		_modifiers.BuyPriceMult *= 0.95;
		_modifiers.RarityMult *= 1.1;
	}

});

