this.hunting_season_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.hunting_season";
		this.m.Name = "狩猎季";
		this.m.Description = "森林里鹿群出没，狩猎季已经开启。鹿肉与毛皮供应极其充足。";
		this.m.Icon = "ui/settlement_status/settlement_effect_36.png";
		this.m.Rumors = [
			"你喜欢吃鹿肉吗，佣兵？你手下那帮兄弟呢？我听说 %settlement% 的狩猎季已经开始了。随口提个醒儿。",
			"一年里所有猎人都在苦苦等待的时节到了。%settlement% 周边的狩猎季就在刚才拉开了帷幕！",
			"非法偷猎可是会被剁掉双手的！不过这也没关系了，反正 %settlement% 的森林狩猎季很快就要开始。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 5;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 2.0;
		_modifiers.FoodPriceMult *= 0.5;
	}

});

