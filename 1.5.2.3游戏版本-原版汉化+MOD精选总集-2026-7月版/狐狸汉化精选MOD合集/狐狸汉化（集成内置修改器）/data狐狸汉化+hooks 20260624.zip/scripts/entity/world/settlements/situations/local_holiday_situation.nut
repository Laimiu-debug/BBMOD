this.local_holiday_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.local_holiday";
		this.m.Name = "本地节日";
		this.m.Description = "当地的节日让人们心情大好，出手也大方了起来。是时候大吃大喝一顿了！";
		this.m.Icon = "ui/settlement_status/settlement_effect_22.png";
		this.m.Rumors = [
			"如果你想找点乐子，就赶紧去 %settlement% 参加他们的庆典吧！天呐，真希望我也能在那儿。",
			"恕我直言，你看起来不太像是那种喜欢过节的人，但也许你手下那帮兄弟会想念美酒佳肴。哎呀，%settlement% 现在到处都是这些好东西，他们那儿正过节呢。",
			"%settlement% 的好心人们这会儿正过着一年一度的节日呢。要是手头有克朗，我早就去那儿吃喝玩乐了。朋友，介意再给我弄杯麦芽酒吗？"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 2;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 1.05;
		_modifiers.BuyPriceMult *= 0.95;
		_modifiers.FoodRarityMult *= 1.5;
		_modifiers.FoodPriceMult *= 0.9;
	}

});

