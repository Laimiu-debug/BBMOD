this.lost_at_sea_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.lost_at_sea";
		this.m.Name = "海难";
		this.m.Description = "一艘渔船在风暴中失踪了。如今无论是鲜鱼还是愿意入伍的新兵，在镇上都难得一见。";
		this.m.Icon = "ui/settlement_status/settlement_effect_18.png";
		this.m.Rumors = [
			"他们再也没能从海上回来……一想到 %settlement% 那些葬身大海的可怜灵魂，我就忍不住打冷颤。",
			"%settlement% 那帮该死的婆娘，哭天喊地的没个完。我本想去卖给她们几头猪，结果只听见满街哀号，一个男人都见不着。说是有船在海上丢了。我一头猪都没卖出去，直接扭头回来了。",
			"出海向来是个卖命的活儿。这就是为什么我转行不出海了。不得不说，我转得正是时候，要不然 %settlement% 丢掉的那艘船上，指不定就有我一个。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 4;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 0.5;
		_modifiers.FoodPriceMult *= 2.0;
		_modifiers.RecruitsMult *= 0.5;
	}

});

