this.mine_cavein_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.mine_cavein";
		this.m.Name = "矿井坍塌";
		this.m.Description = "一场悲剧性的意外发生了，其中一座矿井发生了坍塌。在修缮完毕前，生产完全停滞，矿工们也失去了养家糊口的活计。";
		this.m.Icon = "ui/settlement_status/settlement_effect_24.png";
		this.m.Rumors = [
			"我才不去地底下干活儿，我又不是臭烘烘的鼹鼠！那地方简直就是个夺命陷阱！不久前 %settlement% 的一座矿井塌了，我甚至都不想知道那天死了多少人……",
			"%settlement% 矿区本该今天送达一批矿石和矿物，但唉，到现在还没见着影子。那边准是出什么事了。",
			"听说 %settlement% 的一座矿井生了坍塌。光是想想被活埋在厚重的岩层和泥土深处，就让人毛骨悚然……"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 5;
	}

	function getAddedString( _s )
	{
		return _s + "遭受" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再遭受" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.RecruitsMult *= 1.25;
	}

	function onUpdateShopList( _id, _list )
	{
		for( local i = 0; i < _list.len(); i++ )
		{
			if (_list[i].S == "trade/uncut_gems_item" || _list[i].S == "trade/copper_ingots_item")
			{
				_list.remove(i);
				i--;
			}
		}
	}

	function onUpdateDraftList( _draftList )
	{
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
		_draftList.push("miner_background");
	}

});

