this.mirage_sightings_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.mirage_sightings";
		this.m.Name = "海市蜃楼";
		this.m.Description = "酷热的高温使空气不断扭动，引发了频繁的海市蜃楼，据传还有诡异的身影在幻象中穿梭。";
		this.m.Icon = "ui/settlement_status/settlement_effect_43.png";
		this.m.Rumors = [
			"我跟你说，那是片奇妙且繁茂的绿洲，远处的金色屋顶闪闪发光，还有彩虹色的鸟儿在前方飞翔！在哪见到的？就在去往 %settlement% 的路上。我发誓！",
			"有些邪恶并非在黑夜中降临，也不躲藏在阴影里。它们会在烈日当头的中午现身。想知道我在说什么，就去 %settlement% 看看吧。",
			"沙漠里偶尔能见到幻像，但若是跟着它们走，下场可能比在沙漠里迷路还要惨得多。"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.removeSituationByID("situation.safe_roads");
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
	}

});

