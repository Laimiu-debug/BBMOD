this.moving_sands_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.moving_sands";
		this.m.Name = "流沙大蛇";
		this.m.Description = "城市周边地区被成群的沙漠大蛇侵扰，其中一些体型庞大得惊人。贸易因此受阻，商品变得稀缺且昂贵。";
		this.m.Icon = "ui/settlement_status/settlement_effect_42.png";
		this.m.Rumors = [
			"有消息说，去往 %settlement% 的商贩都被流沙给活吞了。不过，谁会相信这种胡言乱语呢？",
			"你怕蛇吗？最近在 %settlement% 附近见到了很多蛇，有的跟我胳膊一样长，有的居然跟商人的马车一样长！"
		];
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.removeSituationByID("situation.safe_roads");
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 1.1;
		_modifiers.RarityMult *= 0.85;
	}

});

