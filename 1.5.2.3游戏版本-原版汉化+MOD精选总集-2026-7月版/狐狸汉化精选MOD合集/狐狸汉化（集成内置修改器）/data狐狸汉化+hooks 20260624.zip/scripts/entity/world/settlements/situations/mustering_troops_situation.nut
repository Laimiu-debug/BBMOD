this.mustering_troops_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.mustering_troops";
		this.m.Name = "强制征兵";
		this.m.Description = "此定居点已下达征兵令。装备和新兵目前供应紧张，但在这里出售武器和盔甲能赚上一笔。";
		this.m.Icon = "ui/settlement_status/settlement_effect_35.png";
		this.m.Rumors = [
			"又是个该死的贵族在 %settlement% 强迫年轻人入伍。呸，我跟你说这些干嘛，佣兵？你们也没好到哪儿去！",
			"如果我是个拉着满车武器盔甲的商人，我准知道该去哪儿脱手——%settlement% 正在集结军队，肯定愿意出高价。可惜，我既不是商人，也没什么武器。",
			"我只是路过。好不容易才从 %settlement% 的强征入伍里逃出来。他们想逼我给某个领主卖命，但我说：‘多谢了，门儿都没有’，然后我就开溜了。我打算去南边碰碰运气。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 4;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(false);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.PriceMult *= 1.25;
		_modifiers.RecruitsMult *= 0.5;
		_modifiers.RarityMult *= 0.5;
	}

});

