this.preparing_feast_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.preparing_feast";
		this.m.Name = "筹备盛宴";
		this.m.Description = "贵族们正在筹备一场宴会。各大食堂与厨房正在大量采购食材。";
		this.m.Icon = "ui/settlement_status/settlement_effect_29.png";
		this.m.Rumors = [
			"那些高高在上的贵族老爷正忙着在 %settlement% 办一场宴会，而我们这些泥腿子却只能守着陈年谷子直打噎……",
			"我叔叔在 %settlement% 当仆人，他告诉我那儿正准备一场大餐。不过你要是没收到邀请，去了也没用。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 3;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 0.25;
		_modifiers.FoodPriceMult *= 2.0;
	}

});

