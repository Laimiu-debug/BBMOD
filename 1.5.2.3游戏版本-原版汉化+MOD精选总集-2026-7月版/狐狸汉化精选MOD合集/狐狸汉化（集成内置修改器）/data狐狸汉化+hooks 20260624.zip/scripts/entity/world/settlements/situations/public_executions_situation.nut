this.public_executions_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.public_executions";
		this.m.Name = "公开处决";
		this.m.Description = "公开处决是一场不容错过的全民娱乐盛事。在此期间，食物和饮品供应充足，但商人们也可能借机向围观群众抬高物价。";
		this.m.Icon = "ui/settlement_status/settlement_effect_14.png";
		this.m.Rumors = [
			"一大群人正往 %settlement% 赶呢，就为了看那场大戏！男人，女人，小孩，全在路上等着看接下来的处刑！",
			"我听说他们在 %settlement% 附近抓了几个强盗，正要把他们送上断头台。这叫罪有应得，谁让他们在路上抢穷苦人……",
			"现如今我们穷人没有什么好享受的，但看场像样的绞刑总是受欢迎的。打入秋起我们这儿就没办过，不过 %randomname% 告诉我，%settlement% 那边正绞死人呢。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 2;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 1.35;
		_modifiers.FoodPriceMult *= 1.15;
	}

	function onUpdateShopList( _id, _list )
	{
		if (_id == "building.marketplace")
		{
			_list.push({
				R = 50,
				P = 1.0,
				S = "weapons/exesword"
			});
		}
	}

	function onUpdateDraftList( _draftList )
	{
		_draftList.push("executioner_background");
		_draftList.push("executioner_background");
		_draftList.push("executioner_background");
	}

});

