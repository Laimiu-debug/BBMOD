this.raided_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.raided";
		this.m.Name = "遭到劫掠";
		this.m.Description = "这地方最近遭到了劫掠！不仅蒙受了巨大破坏，损失了宝贵的商品与物资，更有许多人因此丧命。";
		this.m.Icon = "ui/settlement_status/settlement_effect_08.png";
		this.m.Rumors = [
			"你也是那帮劫掠者的一员？瞧你那长相和满身臭味儿，简直一模一样！是不是你带人洗劫了 %settlement%？我告诉你，滚远点，这儿不欢迎你们这种烂人！",
			"从 %settlement% 逃难过来的人说，那儿被洗劫抢掠得不成样子了。真是帮可怜虫，但咱们又能怎么办？我们自己也没剩下什么了。保卫他们那是领主老爷的事儿！",
			"佣兵，这年头确实世道险恶。我刚收到消息，就在两个晚上前，%settlement% 遭到了洗劫。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 4;
	}

	function getAddedString( _s )
	{
		return _s + "有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.RecruitsMult *= 0.5;
		_modifiers.RarityMult *= 0.5;
	}

});

