this.razed_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.razed";
		this.m.Name = "夷为平地";
		this.m.Description = "这里已被彻底摧毁。许多居民惨遭屠戮，所有值钱的财物都被洗劫一空。";
		this.m.Icon = "ui/settlement_status/settlement_effect_10.png";
		this.m.Rumors = [
			"几英里外都能看到那滚滚烟柱。在 %settlement% 曾经矗立的地方，如今只剩下一堆燃烧的瓦砾。",
			"大批难民正从 %settlement% 涌来。他们声称那儿大部分地方都被付之一炬了！这难道是真的吗？",
			"%settlement% 已经不复存在了，只剩下一具焦黑的残骸，还在冒着烟、闪着余烬……事情怎么就变成这样了？"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(false);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 0.5;
		_modifiers.BuyPriceMult *= 2.0;
		_modifiers.FoodPriceMult *= 2.0;
		_modifiers.RecruitsMult *= 0.25;
		_modifiers.RarityMult *= 0.25;
	}

});

