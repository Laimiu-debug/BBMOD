this.rich_veins_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.rich_veins";
		this.m.Name = "庞大矿脉";
		this.m.Description = "某个走运的矿工挖到了极其丰富的矿脉！在矿藏枯竭前，矿石与金属的产量将大幅提升，但该定居点的物价也会随之膨胀。";
		this.m.Icon = "ui/settlement_status/settlement_effect_33.png";
		this.m.Rumors = [
			"他们在 %settlement% 挖到了一个主矿脉。我自己也在矿井里干了几十年，到头来除了落下一身严重的咳嗽，什么也没落下。",
			"%settlement% 那帮狗运的家伙在矿里发现了一条新矿脉。就冲他们现在挖出来的那些宝贝，商队跑得再快都嫌慢。",
			"我听说 %settlement% 的矿井这些日子产量惊人。如果你是做买卖的，那可是个挣钱的好路子。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 4;
	}

	function getAddedString( _s )
	{
		return _s + "有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.SellPriceMult *= 1.1;
		_modifiers.BuyPriceMult *= 1.1;
		_modifiers.MineralRarityMult = 1.5;
	}

});

