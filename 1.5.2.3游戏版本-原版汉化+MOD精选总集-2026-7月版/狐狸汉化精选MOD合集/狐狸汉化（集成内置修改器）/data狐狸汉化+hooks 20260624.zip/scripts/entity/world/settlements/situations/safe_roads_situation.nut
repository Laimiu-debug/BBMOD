this.safe_roads_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.safe_roads";
		this.m.Name = "商路安全";
		this.m.Description = "通往这里的道路近来相当安全，这使得许多获利丰厚的贸易得以开展，定居点也随之变得繁荣。";
		this.m.Icon = "ui/settlement_status/settlement_effect_06.png";
		this.m.Rumors = [
			"看来在密集的巡逻下，%settlement% 附近的强盗日子可不好过。",
			"昨晚刚从 %settlement% 回来。路上连个强盗影子都没见着，谢天谢地。",
			"我跟我表哥说了多少年了，别再干拦路抢劫的勾当。那活儿没好下场。果然被我说中了，前几天他在 %settlement% 附近遭了报应。那地方到处都是民兵。"
		];
		this.m.IsStacking = false;
	}

	function onAdded( _settlement )
	{
		_settlement.removeSituationByID("situation.ambushed_trade_routes");
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.PriceMult *= 1.1;
		_modifiers.RarityMult *= 1.1;
	}

});

