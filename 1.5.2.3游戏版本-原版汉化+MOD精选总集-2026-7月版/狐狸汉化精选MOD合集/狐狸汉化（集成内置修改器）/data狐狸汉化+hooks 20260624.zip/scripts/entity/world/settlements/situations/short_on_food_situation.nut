this.short_on_food_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.short_on_food";
		this.m.Name = "食物短缺";
		this.m.Description = "近期的变故导致这里陷入饥荒。由于人们正处于饿死的边缘，食物变得极难寻获，物价也一路飞涨。";
		this.m.Icon = "ui/settlement_status/settlement_effect_04.png";
		this.m.Rumors = [
			"我听说 %settlement% 的男女老少都在挨饿，除了土什么都没得吃。我看我以后再也不会抱怨我那碗发霉的谷子汤了！",
			"今天刚有个农夫从 %settlement% 过来。他讲起那些被宰杀的牲畜、被焚毁的农田和空荡荡的粮仓。他自己看起来就像具活生生的骨架！"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodRarityMult *= 0.5;
		_modifiers.FoodPriceMult *= 3.0;
	}

});

