this.sickness_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.sickness";
		this.m.Name = "瘟疫蔓延";
		this.m.Description = "一场疾病击倒了这个定居点的许多人。可招募的新兵变少了，且食物与医疗物资都极度匮乏。";
		this.m.Icon = "ui/settlement_status/settlement_effect_23.png";
		this.m.Rumors = [
			"千万别靠近 %settlement%！那座可怜的城镇闹瘟疫了，那儿的人正像苍蝇一样成片成片地死掉……",
			"有些从 %settlement% 过来的人想进城，但我们在城门口就把他们给打发走了。谁都知道那座被诅咒的镇子里正流传着一种狠毒的怪病。",
			"瞧瞧我这根药草项链怎么样？它能保佑我不受最凶险的疫病侵害。要是你打算去 %settlement% 的话，最好也给自己弄一根。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.FoodPriceMult *= 2.0;
		_modifiers.MedicalPriceMult *= 3.0;
		_modifiers.RecruitsMult *= 0.25;
	}

});

