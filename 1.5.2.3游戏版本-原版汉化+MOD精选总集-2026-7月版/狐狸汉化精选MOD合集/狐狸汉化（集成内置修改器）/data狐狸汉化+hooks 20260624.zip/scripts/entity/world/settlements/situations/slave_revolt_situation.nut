this.slave_revolt_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.slave_revolt";
		this.m.Name = "奴隶起义";
		this.m.Description = "城邦的奴隶阶层——负债者，正拿起武器反抗他们的主人！现在很难招募到负债者，并且市场上的武器和盔甲已被席卷一空。";
		this.m.Icon = "ui/settlement_status/settlement_effect_40.png";
		this.m.Rumors = [
			"%settlement% 的那些奴隶拿起了武器，转行当了强盗并四处拦截路人。我是说那些‘无垢者’还是随他们怎么自称的家伙。像你这样的佣兵准有活儿干了。",
			"有消息传到这儿了，%settlement% 的奴隶们正在造反。要是闹大了，整座城市都得被掀翻，我倒希望他们真能成事。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "有一个" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.RecruitsMult *= 0.75;
		_modifiers.RarityMult *= 0.5;
	}

	function onUpdateDraftList( _draftList )
	{
		for( local i = _draftList.len() - 1; i >= 0; i = --i )
		{
			if (_draftList[i] == "slave_background" || _draftList[i] == "slave_southern_background")
			{
				_draftList.remove(i);
			}
		}
	}

});

