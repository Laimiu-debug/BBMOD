this.terrified_villagers_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.terrified_villagers";
		this.m.Name = "惊恐的村民";
		this.m.Description = "这里的村民正生活在对未知恐惧的战栗中。街头能招募到的新兵变少了，且人们对陌生人的态度也变得愈发冷淡。";
		this.m.Icon = "ui/settlement_status/settlement_effect_09.png";
		this.m.Rumors = [
			"死人并非真的死透了，有时候他们会回来纠缠活人！不信我？去 %settlement% 亲眼看看就知道了！",
			"你看起来像个能干的剑客！我听说 %settlement% 附近有死人复生的传闻。大概是胡扯，但受惊的人往往愿意出大价钱来换取一份安全感。"
		];
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.25;
		_modifiers.SellPriceMult *= 0.75;
		_modifiers.RecruitsMult *= 0.5;
	}

});

