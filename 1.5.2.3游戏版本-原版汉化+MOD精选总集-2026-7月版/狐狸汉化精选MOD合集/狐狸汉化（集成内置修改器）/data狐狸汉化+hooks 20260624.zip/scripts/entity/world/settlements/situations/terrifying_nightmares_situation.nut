this.terrifying_nightmares_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.terrifying_nightmares";
		this.m.Name = "噩梦";
		this.m.Description = "这个定居点的居民正遭受着噩梦的折磨。许多人宁愿整夜不睡，只求安宁。";
		this.m.Icon = "ui/settlement_status/settlement_effect_25.png";
		this.m.Rumors = [
			"前几天我路过 %settlement%。那儿有些不对劲。人们面色苍白、眼神疲惫、步履蹒跚。就像是一个星期没睡觉似的！",
			"我刚收到在 %settlement% 阿姨写来的信，信里说整个镇子都做噩梦。我也不知道，她总是喜欢大惊小怪。",
			"要想睡个好觉，最好的秘诀就是辛勤工作加一品脱麦芽酒！话说回来，该有人去把这个告诉 %settlement% 的那些家伙；据我所知，他们所有人都睡不着觉。"
		];
	}

	function getAddedString( _s )
	{
		return _s + "遭受" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再遭受" + this.m.Name;
	}

	function onUpdate( _modifiers )
	{
		_modifiers.RecruitsMult *= 0.75;
	}

});

