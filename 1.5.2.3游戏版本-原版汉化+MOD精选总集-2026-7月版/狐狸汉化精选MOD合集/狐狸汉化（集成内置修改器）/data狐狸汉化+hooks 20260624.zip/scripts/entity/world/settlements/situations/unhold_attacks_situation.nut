this.unhold_attacks_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.unhold_attacks";
		this.m.Name = "巨魔袭击";
		this.m.Description = "这片地区出现了巨大的巨魔，有时甚至能听到它们的咆哮声。镇民们因恐惧而不敢踏出定居点半步。";
		this.m.Icon = "ui/settlement_status/settlement_effect_26.png";
		this.m.Rumors = [
			"一个行商告诉我，他在离开 %settlement% 的路边看到了巨大的脚印。见鬼，我可一点都不想碰上留下那些脚印的畜生。",
			"前几天我在 %settlement% 的时候，有一队猎人失踪了。听说他们当时正打算去猎杀某种巨人……",
			"听说过巨魔吗？那种一脚就能踩碎整辆马车的庞然大物！我听说有人在 %settlement% 附近亲眼见到了它们。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
		_settlement.resetRoster(true);
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.1;
		_modifiers.SellPriceMult *= 0.9;
		_modifiers.RarityMult *= 0.9;
		_modifiers.RecruitsMult *= 0.75;
	}

});

