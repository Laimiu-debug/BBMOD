this.warehouse_burned_down_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.warehouse_burned_down";
		this.m.Name = "仓库失火";
		this.m.Description = "近期的一场大火烧毁了仓库并造成了重大损失。火灾中幸存的物资正以高价出售。";
		this.m.Icon = "ui/settlement_status/settlement_effect_21.png";
		this.m.Rumors = [
			"昨晚看到地平线上的烟了吗？听说那是 %settlement% 的一个大仓库被烧成了平地。",
			"我听说他们在 %settlement% 抓到了那个放火烧仓库的纵火犯。当场就把他吊死在树上了，但想要重新盖好那座仓库，他们还得花上好一阵子。"
		];
		this.m.IsStacking = false;
		this.m.ValidDays = 5;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.BuyPriceMult *= 1.25;
		_modifiers.SellPriceMult *= 1.05;
		_modifiers.RarityMult *= 0.5;
	}

});

