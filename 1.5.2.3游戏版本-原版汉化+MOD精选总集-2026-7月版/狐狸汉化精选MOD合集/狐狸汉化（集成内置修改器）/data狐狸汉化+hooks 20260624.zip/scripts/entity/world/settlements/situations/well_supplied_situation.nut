this.well_supplied_situation <- this.inherit("scripts/entity/world/settlements/situations/situation", {
	m = {},
	function create()
	{
		this.situation.create();
		this.m.ID = "situation.well_supplied";
		this.m.Name = "货物充足";
		this.m.Description = "这个地方近期补给了大量新鲜货品，只要价格合适，许多物资现在都能买到。";
		this.m.Icon = "ui/settlement_status/settlement_effect_03.png";
		this.m.Rumors = [
			"老兄，跟 %settlement% 的贸易正红火着呢！道路安全，库存满满，但愿能一直这么保持下去……",
			"我在 %settlement% 的亲戚一直在吹嘘他们那儿的小日子过多好。摊位上货全得很，哪像我们这破地方。"
		];
		this.m.IsStacking = false;
	}

	function getAddedString( _s )
	{
		return _s + "现在有" + this.m.Name;
	}

	function getRemovedString( _s )
	{
		return _s + "不再有" + this.m.Name;
	}

	function onAdded( _settlement )
	{
		_settlement.removeSituationByID("situation.ambushed_trade_routes");
		_settlement.resetShop();
	}

	function onUpdate( _modifiers )
	{
		_modifiers.PriceMult *= 0.9;
		_modifiers.RarityMult *= 1.15;
	}

});

