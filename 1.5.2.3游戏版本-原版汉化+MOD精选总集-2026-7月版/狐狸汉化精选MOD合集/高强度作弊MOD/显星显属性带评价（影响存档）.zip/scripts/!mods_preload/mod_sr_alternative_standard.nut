::mods_hookNewObjectOnce("ui/screens/world/modules/world_town_screen/town_hire_dialog_module", function ( o )
{	
	o.convertEntityHireInformationToUIDataAltered <- function( _entity )
	{
		local background = _entity.getBackground();
		local bgtext = background.getDescription();
		local HPMax = _entity.getBaseProperties().Hitpoints;
		local HPTalent = 0;
		if (1==1)
		{
			HPTalent = _entity.getTalents()[this.Const.Attributes.Hitpoints];
		}
		local FATMax = _entity.getBaseProperties().Stamina;
		local FATTalent = 0;
		if (1==1)
		{
			FATTalent = _entity.getTalents()[this.Const.Attributes.Fatigue];
		}
		local INITMax = _entity.getBaseProperties().Initiative;
		local INITTalent = 0;
		if (1==1)
		{
			INITTalent = _entity.getTalents()[this.Const.Attributes.Initiative];
		}
		local RESMax = _entity.getBaseProperties().Bravery;
		local RESTalent = 0;
		if (1==1)
		{
			RESTalent = _entity.getTalents()[this.Const.Attributes.Bravery];
		}
		local MAttSkill = _entity.getBaseProperties().MeleeSkill;
		local MAttTalent = 0;
		if (1==1)
		{
			MAttTalent = _entity.getTalents()[this.Const.Attributes.MeleeSkill];
		}
		local RAttSkill = _entity.getBaseProperties().RangedSkill;
		local RAttTalent = 0;
		if (1==1)
		{
			RAttTalent = _entity.getTalents()[this.Const.Attributes.RangedSkill];
		}
		local MDef = _entity.getBaseProperties().MeleeDefense;
		local MDefTalent = 0;
		if (1==1)
		{
			MDefTalent = _entity.getTalents()[this.Const.Attributes.MeleeDefense];
		}
		local RDef = _entity.getBaseProperties().RangedDefense;
		local RDefTalent = 0;
		if (1==1)
		{
			RDefTalent = _entity.getTalents()[this.Const.Attributes.RangedDefense];
		}
		local a = {
			Hitpoints = [
				50,
				60
			],
			Bravery = [
				30,
				40
			],
			Stamina = [
				90,
				100
			],
			MeleeSkill = [
				47,
				57
			],
			RangedSkill = [
				32,
				42
			],
			MeleeDefense = [
				0,
				5
			],
			RangedDefense = [
				0,
				5
			],
			Initiative = [
				100,
				110
			]
		};
		local c = background.onChangeAttributes();
		local HPM = a.Hitpoints[1] + c.Hitpoints[1];
		local RESM = a.Bravery[1] + c.Bravery[1];
		local STAM = a.Stamina[1] + c.Stamina[1];
		local MSM = a.MeleeSkill[1] + c.MeleeSkill[1];
		local MDM = a.MeleeDefense[1] + c.MeleeDefense[1];
		local RSM = a.RangedSkill[1] + c.RangedSkill[1];
		local RDM = a.RangedDefense[1] + c.RangedDefense[1];
		local INM = a.Initiative[1] + c.Initiative[1];
		local HPExtra = "";
		local ResExtra = "";
		local IntExtra = "";
		local FatExtra = "";
		local trts = [];
		foreach( s in _entity.m.Skills.m.Skills )
		{
			if (s.getType() == this.Const.SkillType.Trait)
			{
				trts.push({
					id = s.getID(),
					icon = s.getIconColored()
				});
			}
		}
		local HPTS = "";
		local HPT = HPMax;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				HPT = HPT+_entity.m.Attributes[this.Const.Attributes.Hitpoints][j];
			}
			HPTS = " ("+HPT+")";
		}
		local STATS = "";
		local STAT = FATMax;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				STAT = STAT+_entity.m.Attributes[this.Const.Attributes.Fatigue][j];
			}
			STATS = " ("+STAT+")";
		}
		local RESTS = "";
		local REST = RESMax;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				REST = REST+_entity.m.Attributes[this.Const.Attributes.Bravery][j];
			}
			RESTS = " ("+REST+")";
		}
		local INITIS = "";
		local INITI = INITMax;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				INITI = INITI+_entity.m.Attributes[this.Const.Attributes.Initiative][j];
			}
			INITIS = " ("+INITI+")";
		}
		local MSTS = "";
		local MST = MAttSkill;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				MST = MST+_entity.m.Attributes[this.Const.Attributes.MeleeSkill][j];
			}
			MSTS = " ("+MST+")";
		}
		local MDTS = "";
		local MDT = MDef;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				MDT = MDT+_entity.m.Attributes[this.Const.Attributes.MeleeDefense][j];
			}
			MDTS = " ("+MDT+")";
		}
		local RSTS = "";
		local RST = RAttSkill;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				RST = RST+_entity.m.Attributes[this.Const.Attributes.RangedSkill][j];
			}
			RSTS = " ("+RST+")";
		}
		local RDTS = "";
		local RDT = RDef;
		if (1==1)
		{
			for( local j = 0; j < 10; j = ++j )
			{
				RDT = RDT+_entity.m.Attributes[this.Const.Attributes.RangedDefense][j];
			}
			RDTS = " ("+RDT+")";
		}

		// 属性判断
		// HPMax 血量
		// STAT 疲劳
		// MST 近战攻击
		// MDT 近战防御
		// RST 远程攻击
		// RDT 远程防御
		// REST 决心
		// INITI 主动

		// 血量判定
		local treeText = "";
		if (HPMax >= 64) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*血量:极品(点巨人80以上 无需补加)[/color]\n";
		}else if (HPMax >= 56) {
			treeText += "*血量:合格(点巨人70以上 需补到80)\n";
		}else {
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*血量:拉胯(需要投入较多的加点到血量)[/color]\n";
		}
		// 决心判定
		if (RESMax >= 50) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*决心:极品(被围不会白旗)[/color]\n";
		}else if (RESMax >= 40) {
			treeText += "*决心:合格(不太容易白旗)\n";
		}else {
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*决心:拉胯(需竞技场buff和决心饰品)[/color]\n";
		}
		// 疲劳判定
		if (STAT >= 140) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*疲劳:极品(穿最重的甲 挨最毒的打)[/color]\n";
		}else if (STAT >= 130) {
			treeText += "*疲劳:合格(可穿重甲)\n";
		}else {
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*疲劳:拉胯(建议轻甲)[/color]\n";
		}
		// 近战判定
		if (MST >= 90) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*近战:极品(后期大哥)[/color]\n";
		}else if (MST >= 85) {
			treeText += "*近战:合格(前期过度)\n";
		}else {
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*近战:拉胯(不建议作为近战输出)[/color]\n";
		}
		// 远程判定
		if (RST >= 90) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*远程:极品(可以专职远程)[/color]\n";
		}else if (RST >= 85) {
			treeText += "*远程:不错(可以兼职远程)\n";
		}else {
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*远程:拉胯(不建议作为远程输出)[/color]\n";
		}
		// 加点建议
		if (MST >= 85 && MDT >= 25 && STAT >= 130) {
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:重甲近战输出[/color]\n";
		}else if (MST >= 85 && MDT >= 25 && STAT < 130){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:轻甲近战输出[/color]\n";
		}else if (RST >= 90){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:远程输出[/color]\n";
		}else if (MDT >= 35){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:盾卫[/color]\n";
		}else if (MST >= 80 && RST >= 80){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:多功能柄投[/color]\n";
		}else if (MST >= 80 && REST >= 80){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:扛旗队长[/color]\n";
		}else if (MST >= 90){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:后排长柄[/color]\n";
		}else if (RST >= 85 && REST >= 80){
			treeText += "[color=" + this.Const.UI.Color.PositiveValue + "]*加点建议:恐惧火枪队长[/color]\n";
		}else{
			treeText += "[color=" + this.Const.UI.Color.DamageValue + "]*加点建议:炮灰(不一定对,视特质而定)[/color]\n";
		}

		return {
			ID = _entity.getID(),
			Name = _entity.getName(),
			Level = _entity.getLevel(),
			InitialMoneyCost = _entity.getHiringCost(),
			DailyMoneyCost = _entity.getDailyCost(),
			DailyFoodCost = _entity.getDailyFood(),
			TryoutCost = _entity.getTryoutCost(),
			IsTryoutDone = true,
			ImagePath = _entity.getImagePath(),
			ImageOffsetX = _entity.getImageOffsetX(),
			ImageOffsetY = _entity.getImageOffsetY(),
			BackgroundImagePath = background.getIconColored(),
			Traits = trts,
			hitpointsMax = _entity.getBaseProperties().Hitpoints,
			hitpointsTalent = _entity.getTalents()[this.Const.Attributes.Hitpoints],
			fatigueMax = _entity.getBaseProperties().Stamina,
			fatigueTalent = _entity.getTalents()[this.Const.Attributes.Fatigue],
			initiativeMax = _entity.getBaseProperties().Initiative,
			initiativeTalent = _entity.getTalents()[this.Const.Attributes.Initiative],
			bravery = _entity.getBaseProperties().Bravery,
			braveryTalent = _entity.getTalents()[this.Const.Attributes.Bravery],
			meleeSkill = _entity.getBaseProperties().MeleeSkill,
			meleeSkillTalent = _entity.getTalents()[this.Const.Attributes.MeleeSkill],
			rangeSkill = _entity.getBaseProperties().RangedSkill,
			rangeSkillTalent = _entity.getTalents()[this.Const.Attributes.RangedSkill],
			meleeDefense = _entity.getBaseProperties().MeleeDefense,
			meleeDefenseTalent = _entity.getTalents()[this.Const.Attributes.MeleeDefense],
			rangeDefense = _entity.getBaseProperties().RangedDefense,
			rangeDefenseTalent = _entity.getTalents()[this.Const.Attributes.RangedDefense],
			BackgroundText = "[img]gfx/ui/icons/health.png[/img]"+HPMax+"/"+HPM+HPTS+"[img]gfx/ui/icons/talent_"+HPTalent+".png[/img]"+HPExtra+"[img]gfx/ui/icons/melee_skill.png[/img]"+MAttSkill+"/"+MSM+MSTS+"[img]gfx/ui/icons/talent_"+MAttTalent+".png[/img]\n[img]gfx/ui/icons/fatigue.png[/img]"+FATMax+"/"+STAM+STATS+"[img]gfx/ui/icons/talent_"+FATTalent+".png[/img]"+FatExtra+"[img]gfx/ui/icons/ranged_skill.png[/img]"+RAttSkill+"/"+RSM+RSTS+"[img]gfx/ui/icons/talent_"+RAttTalent+".png[/img]\n[img]gfx/ui/icons/bravery.png[/img]"+RESMax+"/"+RESM+RESTS+"[img]gfx/ui/icons/talent_"+RESTalent+".png[/img]"+ResExtra+"[img]gfx/ui/icons/melee_defense.png[/img]"+MDef+"/"+MDM+MDTS+"[img]gfx/ui/icons/talent_"+MDefTalent+".png[/img]\n[img]gfx/ui/icons/initiative.png[/img]"+INITMax+"/"+INM+INITIS+"[img]gfx/ui/icons/talent_"+INITTalent+".png[/img]"+IntExtra+"[img]gfx/ui/icons/ranged_defense.png[/img]"+RDef+"/"+RDM+RDTS+"[img]gfx/ui/icons/talent_"+RDefTalent+".png[/img]\n^"+treeText+bgtext,
		};
	}
	
	o.convertHireRosterToUIDataAltered <- function (_rosterID)
	{
		local result = [];
		local roster = this.World.getRoster(_rosterID);

		if (roster == null)
		{
			return null;
		}

		local entities = roster.getAll();

		if (entities != null)
		{
			local result = [];

			foreach( entity in entities )
			{
				result.push(this.convertEntityHireInformationToUIDataAltered(entity));
			}

			return result;
		}

		return null;
	}
	o.queryHireInformation = function()
	{
		return {
			Roster = this.convertHireRosterToUIDataAltered(this.m.RosterID),
			Assets = this.m.Parent.queryAssetsInformation()
		};
	}
	
	o.onTryoutRosterEntry = function (_entityID)
	{
		local entry = this.findEntityWithinRoster(_entityID);

		if (entry != null)
		{
			local roster = this.World.getPlayerRoster();
			local entities = roster.getAll();
			local currentMoney = this.World.Assets.getMoney();
			local tryoutCost = entry.getTryoutCost();

			if (currentMoney < tryoutCost)
			{
				return {
					Result = this.Const.UI.Error.NotEnoughMoney,
					Assets = null
				};
			}

			entry.setTryoutDone(true);
			this.World.Assets.addMoney(-tryoutCost);
			return {
				Result = 0,
				Roster = this.convertHireRosterToUIDataAltered(this.m.RosterID),
				Assets = this.m.Parent.queryAssetsInformation()
			};
		}

		return {
			Result = this.Const.UI.Error.RosterEntryNotFound,
			Assets = null
		};
	}
	
	o.onDismissRosterEntry <- function( _entityID )
	{
		local entry = this.findEntityWithinRoster(_entityID);

		if (entry != null)
		{
			local roster = this.World.getPlayerRoster();
			local entities = roster.getAll();
			local currentMoney = this.World.Assets.getMoney();
			local hiringCost = this.Math.ceil(entry.getHiringCost() * this.World.Assets.m.HiringCostMult);
			local gear = entry.getItems().getAllItems();
			for( local i = 0; i < gear.len(); i = ++i )
			{
				local itemprice = gear[i].getValue() * 0.2; //imitation of selling everything with good 20% modifier
				hiringCost = hiringCost - itemprice;
			}
			hiringCost = this.Math.max(hiringCost, 0);

			if (currentMoney < hiringCost)
			{
				return {
					Result = this.Const.UI.Error.NotEnoughMoney,
					Assets = null
				};
			}
			this.World.getRoster(this.m.RosterID).remove(entry);
			this.World.Assets.addMoney(-hiringCost);

			if (this.World.getRoster(this.m.RosterID).getSize() == 0)
			{
				this.m.Parent.getMainDialogModule().reload();
			}
			
			return {
				Result = 0,
				Assets = this.m.Parent.queryAssetsInformation()
			};
		}

		return {
			Result = this.Const.UI.Error.RosterEntryNotFound,
			Assets = null
		};
	}
	
	local HireRosterEntry = o.onHireRosterEntry;
	o.onHireRosterEntry = function(_entityID)
	{
		local entry = this.findEntityWithinRoster(_entityID);
		if (entry != null)
		{
			local roster = this.World.getPlayerRoster();
			local entities = roster.getAll();
			local currentMoney = this.World.Assets.getMoney();
			local currentBrothers = entities.len();
			local brothersMax = this.World.Assets.getBrothersMax();
			local hiringCost = this.Math.ceil(entry.getHiringCost() * this.World.Assets.m.HiringCostMult);

			if (currentMoney >= hiringCost && (currentBrothers + 1 <= brothersMax))
			{
				local background = entry.getBackground();
				local bgtext = background.getDescription();
				local HPMax = entry.getBaseProperties().Hitpoints;
				local FATMax = entry.getBaseProperties().Stamina;
				local INITMax = entry.getBaseProperties().Initiative;
				local RESMax = entry.getBaseProperties().Bravery;
				local MAttSkill = entry.getBaseProperties().MeleeSkill;
				local RAttSkill = entry.getBaseProperties().RangedSkill;
				local MDef = entry.getBaseProperties().MeleeDefense;
				local RDef = entry.getBaseProperties().RangedDefense;
				local a = {
					Hitpoints = [50,60],
					Bravery = [30,40],
					Stamina = [90,100],
					MeleeSkill = [47,57],
					RangedSkill = [32,42],
					MeleeDefense = [0,5],
					RangedDefense = [0,5],
					Initiative = [100,110]
				};
				local c = background.onChangeAttributes();
				local HPM = a.Hitpoints[1] + c.Hitpoints[1];
				local RESM = a.Bravery[1] + c.Bravery[1];
				local STAM = a.Stamina[1] + c.Stamina[1];
				local MSM = a.MeleeSkill[1] + c.MeleeSkill[1];
				local MDM = a.MeleeDefense[1] + c.MeleeDefense[1];
				local RSM = a.RangedSkill[1] + c.RangedSkill[1];
				local RDM = a.RangedDefense[1] + c.RangedDefense[1];
				local INM = a.Initiative[1] + c.Initiative[1];
				local HPExtra = "";
				local ResExtra = "";
				local IntExtra = "";
				local FatExtra = "";
				if (FATMax >= 100 && INITMax >= 100)
				{
					HPExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					ResExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
				}
				else if (FATMax >= 100)
				{
					HPExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					ResExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					if (INM >= 100)
					{
						IntExtra = "&nbsp;&nbsp;";
					}
					else
					{
						IntExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					}
				}
				else if (INITMax >= 100)
				{
					HPExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					ResExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					if (STAM >= 100)
					{
						FatExtra = "&nbsp;&nbsp;";
					}
					else
					{
						FatExtra = "&nbsp;&nbsp;&nbsp;&nbsp;";
					}
				}
				else if (INM >= 100 || STAM >= 100)
				{
					HPExtra = "&nbsp;&nbsp;";
					ResExtra = "&nbsp;&nbsp;";
					if (INM >= 100 && STAM < 100)
					{
						FatExtra = "&nbsp;&nbsp;";
					}
					else if (STAM >= 100 && INM < 100)
					{
						IntExtra = "&nbsp;&nbsp;";
					}
				}
				entry.getBackground().m.RawDescription = bgtext + "\n[img]gfx/ui/icons/health.png[/img]"+HPMax+"/"+HPM+"[img]gfx/ui/icons/talent_"+0+".png[/img]"+HPExtra+"&nbsp;&nbsp;&nbsp;[img]gfx/ui/icons/melee_skill.png[/img]"+MAttSkill+"/"+MSM+"[img]gfx/ui/icons/talent_"+0+".png[/img]\n[img]gfx/ui/icons/fatigue.png[/img]"+FATMax+"/"+STAM+"[img]gfx/ui/icons/talent_"+0+".png[/img]"+FatExtra+"&nbsp;&nbsp;&nbsp;[img]gfx/ui/icons/ranged_skill.png[/img]"+RAttSkill+"/"+RSM+"[img]gfx/ui/icons/talent_"+0+".png[/img]\n[img]gfx/ui/icons/bravery.png[/img]"+RESMax+"/"+RESM+"[img]gfx/ui/icons/talent_"+0+".png[/img]"+ResExtra+"&nbsp;&nbsp;&nbsp;[img]gfx/ui/icons/melee_defense.png[/img]"+MDef+"/"+MDM+"[img]gfx/ui/icons/talent_"+0+".png[/img]\n[img]gfx/ui/icons/initiative.png[/img]"+INITMax+"/"+INM+"[img]gfx/ui/icons/talent_"+0+".png[/img]"+IntExtra+"&nbsp;&nbsp;&nbsp;[img]gfx/ui/icons/ranged_defense.png[/img]"+RDef+"/"+RDM+"[img]gfx/ui/icons/talent_"+0+".png[/img]\n";
				entry.getBackground().buildDescription(true);
			}
		}
		local result = HireRosterEntry(_entityID);
		return result;
	};
});

::mods_hookNewObjectOnce("ui/screens/tooltip/tooltip_events", function(o) {
  local queryTooltipData = o.general_queryUIElementTooltipData;
  o.general_queryUIElementTooltipData = function(entityId, elementId, elementOwner)
  {
	local tooltip = queryTooltipData(entityId, elementId, elementOwner);
	if(tooltip != null) return tooltip;
	if(elementId == "sr-dismiss-tooltip")
	{
	  return [
		{
		  id = 1,
		  type = "title",
		  text = "刷人"
		},
		{
		  id = 2,
		  type = "description",
		  text = "后期有钱再用，解雇这名新兵。价格等于雇佣价格减去装备出售价格(与雇佣后再解雇是一样的，用来刷人，解雇后新人出现更快)."
		},
	  ];
	}
	return null;
  }
});