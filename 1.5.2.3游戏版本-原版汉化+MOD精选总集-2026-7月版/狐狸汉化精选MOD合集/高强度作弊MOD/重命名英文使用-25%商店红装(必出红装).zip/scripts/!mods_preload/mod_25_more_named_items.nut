::mods_hookNewObject("entity/world/settlement_modifiers", function(o) {
  o.RarityMult *= 1.25;
  local reset = o.reset;
  o.reset = function()
  {
    reset();
    this.RarityMult *= 1.25;
  }
});
