// BBForge Vanilla — Entry point (hooks, hotkey, tooltips)
// ============================================================================
// BBForge Vanilla — Bro Editor for Battle Brothers (no Legends required)
// Entry point — Registration, hooks, hotkey, tooltips
// Version: 0.1.0
// License: MIT
// Uses: Modern Hooks API (::Hooks.register)
// ============================================================================

local mod = ::Hooks.register("mod_bbforge_vanilla", "0.1.0", "BBForge Vanilla - Bro Editor");

mod.queue(function()
{
	::Hooks.registerJS("ui/mods/bbforge/bbforge_screen.js");
	::Hooks.registerCSS("ui/mods/bbforge/bbforge_screen.css");

	// ========================================================================
	// Error handler — crash safety with stack trace logging
	// (global call, not a hook)
	// ========================================================================
	try
	{
		local bf_error_count = 0;
		local bf_last_error = "";
		local bf_repeat_count = 0;

		::seterrorhandler(function(err)
		{
			// Suppress expected errors during catalog building / this.new() calls
			if ("bf_suppress_errors" in ::getroottable() && ::bf_suppress_errors)
				return;

			local errStr = typeof err == "string" ? err : "" + err;
			bf_error_count++;

			// Check if error originates from BBForge code
			local isBBForge = false;
			try
			{
				for (local i = 2; i < 20; i++)
				{
					local si = ::getstackinfos(i);
					if (si == null) break;
					local src = ("src" in si && si.src != null) ? si.src : "";
					if (src.find("bbforge") != null || src.find("BBForge") != null)
					{
						isBBForge = true;
						break;
					}
				}
			}
			catch(ex) {}

			// Track repeated identical errors
			if (errStr == bf_last_error)
				bf_repeat_count++;
			else
			{
				if (bf_repeat_count > 3)
					::logWarning("[BBForge] Previous error repeated " + bf_repeat_count + "x: " + bf_last_error);
				bf_repeat_count = 1;
				bf_last_error = errStr;
			}

			// Log first 5 of any error, then suppress
			local tag = isBBForge ? "[BBForge]" : "[BBForge:external]";
			if (bf_repeat_count <= 5)
				::logWarning(tag + " Error #" + bf_error_count + " (x" + bf_repeat_count + "): " + errStr);
			else if (bf_repeat_count == 6)
				::logWarning(tag + " Suppressing further repeats of: " + errStr);

			// Full stack trace for first occurrence of each error
			if (bf_repeat_count == 1)
			{
				::logWarning(tag + " === STACK TRACE ===");
				try
				{
					for (local i = 0; i < 20; i++)
					{
						local si = ::getstackinfos(i);
						if (si == null) break;
						local src = ("src" in si && si.src != null) ? si.src : "?";
						local func = ("func" in si && si.func != null) ? si.func : "?";
						local line = ("line" in si) ? si.line : 0;
						::logWarning(tag + "   #" + i + " " + func + " (" + src + ":" + line + ")");
					}
				}
				catch (ex) { ::logWarning(tag + " Stack trace failed: " + ex); }
				::logWarning(tag + " === END STACK TRACE ===");
			}

			return;
		});
	}
	catch (e) {}

	// ========================================================================
	// HOOK 1/2/3: world_state — Create/destroy screen, hotkey SHIFT+E
	// ========================================================================
	mod.hook("scripts/states/world_state", function(q)
	{
		// HOOK 1: Create screen on world UI init
		q.onInitUI = @(__original) function()
		{
			__original();

			try
			{
				this.m.BBForgeScreen <- this.new("scripts/ui/screens/bbforge/bbforge_screen");
				this.m.BBForgeScreen.setOnClosePressedListener((function()
				{
					if (this.m.MenuStack.hasBacksteps())
					{
						this.m.MenuStack.pop();
					}
				}).bindenv(this));
			}
			catch (e)
			{
				::logError("[BBForge] Failed to create screen: " + e);
			}

			// Patch UIDataHelper.convertEntityToUIData (doesn't exist at queue time)
			try
			{
				if ("UIDataHelper" in getroottable() && "convertEntityToUIData" in ::UIDataHelper)
				{
					local bf_orig_convert = ::UIDataHelper.convertEntityToUIData;
					::UIDataHelper.convertEntityToUIData = function(_entity, _activeEntity)
					{
						try
						{
							return bf_orig_convert.call(this, _entity, _activeEntity);
						}
						catch (e)
						{
							local fallback = {};
							try { fallback.Name <- _entity.getName(); } catch(ex) { fallback.Name <- "???"; }
							try { fallback.ID <- _entity.getID(); } catch(ex) { fallback.ID <- 0; }
							return fallback;
						}
					}
				}
			}
			catch (e) {}
		}

		// HOOK 2: Destroy screen on world UI destroy
		q.onDestroyUI = @(__original) function()
		{
			__original();

			if ("BBForgeScreen" in this.m && this.m.BBForgeScreen != null)
			{
				try { this.m.BBForgeScreen.destroy(); } catch (e) {}
				this.m.BBForgeScreen = null;
			}
		}

		// HOOK 3: Hotkey — SHIFT+E to open/close BBForge
		q.helper_handleContextualKeyInput = @(__original) function(_key)
		{
			// One-time trait/perk reapply on first key input after world load
			if (!("_bbf_skills_restored" in this.m))
			{
				this.m._bbf_skills_restored <- true;
				try
				{
					local roster = this.World.getPlayerRoster().getAll();
					foreach (b in roster)
					{
						try
						{
							local added = 0;
							local removed = 0;

							// Reapply traits (bbf_ / bbr_ flags) — vanilla CharacterTraits + Permanent injuries
							local bf_traitScripts = [];
							try
							{
								foreach (tr in ::Const.CharacterTraits)
								{
									try { bf_traitScripts.push(tr[1]); } catch(ex) {}
								}
							}
							catch(ex) {}
							try
							{
								foreach (inj in ::Const.Injury.Permanent)
								{
									try { bf_traitScripts.push("scripts/skills/" + inj.Script); } catch(ex) {}
								}
							}
							catch(ex) {}

							foreach (script in bf_traitScripts)
							{
								try
								{
									if (b.getFlags().has("bbf_" + script))
									{
										local sk = this.new(script);
										if (!b.getSkills().hasSkill(sk.getID()))
										{
											sk.m.IsNew = false;
											b.getSkills().add(sk);
											if (!b.getSkills().hasSkill(sk.getID()))
											{
												sk.m.Container = b.getSkills();
												b.getSkills().m.Skills.push(sk);
											}
											added++;
										}
									}

									if (b.getFlags().has("bbr_" + script))
									{
										local sk = this.new(script);
										local skId = sk.getID();
										if (b.getSkills().hasSkill(skId))
										{
											b.getSkills().removeByID(skId);
											removed++;
										}
									}
								}
								catch(ex) {}
							}

							// Remove hidden effects by ID (bbr_effects flag = comma-separated IDs)
							try
							{
								if (b.getFlags().has("bbr_effects"))
								{
									local effectList = b.getFlags().get("bbr_effects");
									if (typeof effectList == "string" && effectList.len() > 0)
									{
										local ids = split(effectList, ",");
										foreach (skId in ids)
										{
											try
											{
												if (skId.len() > 0 && b.getSkills().hasSkill(skId))
												{
													b.getSkills().removeByID(skId);
													removed++;
												}
											}
											catch(ex) {}
										}
									}
								}
							}
							catch(ex) {}

							// Reapply perks (bbf_perk_ / bbr_perk_ flags)
							// Vanilla: iterate Const.Perks.PerkDefs (array of perk definitions)
							// Use Const.Perks.findById() for lookup, add/remove via skill container
							try
							{
								foreach (perkGroup in ::Const.Perks.Perks)
								{
									foreach (perkDef in perkGroup)
									{
										try
										{
											local pid = perkDef.ID;
											if (b.getFlags().has("bbf_perk_" + pid))
											{
												if (!b.getSkills().hasSkill(pid))
												{
													local perkSk = this.new(perkDef.Script);
													perkSk.m.IsNew = false;
													b.getSkills().add(perkSk);
													if (!b.getSkills().hasSkill(pid))
													{
														perkSk.m.Container = b.getSkills();
														b.getSkills().m.Skills.push(perkSk);
													}
													added++;
												}
											}

											if (b.getFlags().has("bbr_perk_" + pid))
											{
												if (b.getSkills().hasSkill(pid))
												{
													b.getSkills().removeByID(pid);
													removed++;
												}
											}
										}
										catch(ex) {}
									}
								}
							}
							catch(ex) {}

							if (added > 0 || removed > 0)
							{
								b.getSkills().update();
								::logInfo("[BBForge] Auto-reapply for " + b.getName() + ": +" + added + " / -" + removed);
							}
						}
						catch(ex) {}
					}
				}
				catch(ex) {}
			}

			if (!__original(_key) && _key.getState() == 0)
			{
				// SHIFT+E: E = key 15, SHIFT = modifier 1
				if (_key.getKey() == 15 && _key.getModifier() == 1)
				{
					if (!this.m.MenuStack.hasBacksteps()
						&& !this.m.CharacterScreen.isVisible()
						&& !this.m.WorldTownScreen.isVisible()
						&& !this.m.EventScreen.isVisible()
						&& !this.m.EventScreen.isAnimating())
					{
						if ("BBForgeScreen" in this.m
							&& this.m.BBForgeScreen != null)
						{
							if (this.m.BBForgeScreen.isVisible())
							{
								if (this.m.MenuStack.hasBacksteps())
								{
									this.m.MenuStack.pop();
								}
							}
							else
							{
								this.setAutoPause(true);

								if ("BFCustomZoom" in this.m)
								{
									this.m.BFCustomZoom = this.World.getCamera().Zoom;
								}
								else
								{
									this.m.BFCustomZoom <- this.World.getCamera().Zoom;
								}

								this.World.getCamera().zoomTo(1.0, 4.0);
								this.Tooltip.hide();
								this.m.WorldScreen.hide();
								this.m.BBForgeScreen.show();
								this.Cursor.setCursor(this.Const.UI.Cursor.Hand);

								this.m.MenuStack.push(function()
								{
									this.World.getCamera().zoomTo(this.m.BFCustomZoom, 4.0);

									if (this.m.BBForgeScreen != null)
									{
										this.m.BBForgeScreen.hide();
									}

									this.m.WorldScreen.show();
									this.Cursor.setCursor(this.Const.UI.Cursor.Hand);
									this.setAutoPause(false);
								}, function()
								{
									return !this.m.BBForgeScreen.isAnimating();
								});
							}
						}
					}

					return true;
				}
			}
		}
	});

	// ========================================================================
	// Safety — protect convertEntityToUIData from entity delegation failures
	// The lindwurm tail delegates getHitpoints/getBaseProperties to its body
	// via WeakTableRef. If body ref is invalid, convertEntityToUIData crashes.
	// ========================================================================
	try
	{
		mod.hook("scripts/ui/global/data_helper", function(q)
		{
			q.convertEntityToUIData = @(__original) function(_entity, _activeEntity)
			{
				try
				{
					return __original(_entity, _activeEntity);
				}
				catch (e)
				{
					::logWarning("[BBForge] convertEntityToUIData failed: " + e);
					local id = 0;
					local name = "???";
					try { id = _entity.getID(); } catch(e2) {}
					try { name = _entity.getName(); } catch(e2) {}
					return {
						id = id,
						name = name,
						nameOnly = name,
						imagePath = "",
						imagePathFoW = "",
						imageOffsetX = 0,
						imageOffsetY = 0,
						isEnemy = false,
						isHiddenToPlayer = false,
						isWaitActionSpent = false,
						levelImagePath = "",
						hitpoints = 1,
						hitpointsMax = 1,
						fatigue = 0,
						fatigueMax = 100,
						actionPoints = 0,
						actionPointsMax = 9,
						morale = 2,
						moraleMax = 4,
						moraleLabel = "Steady",
						armorHead = 0,
						armorHeadMax = 0,
						armorBody = 0,
						armorBodyMax = 0,
						perkTree = []
					};
				}
			}
		});
	}
	catch (e)
	{
		::logWarning("[BBForge] data_helper hook failed: " + e);
	}

	// ========================================================================
	// Avatar persistence — restore custom avatar on updateLook
	// ========================================================================
	try
	{
		mod.hook("scripts/states/world/asset_manager", function(q)
		{
			q.updateLook = @(__original) function(...)
			{
				try
				{
					if (::World.Flags.has("bbforge_avatar_body"))
					{
						local player = ::World.State.getPlayer();
						local body = ::World.Flags.get("bbforge_avatar_body");
						local socket = ::World.Flags.get("bbforge_avatar_socket");
						local flipped = ::World.Flags.get("bbforge_avatar_flipped");
						player.getSprite("body").setBrush(body);
						player.getSprite("base").setBrush(socket);
						try { player.getSprite("body").setHorizontalFlipping(flipped); } catch(e) {}
						try { player.getSprite("base").setHorizontalFlipping(flipped); } catch(e) {}
						return;
					}
				}
				catch(e) { ::logWarning("[BBForge] avatar restore failed: " + e); }

				if (vargv.len() > 0)
					__original(vargv[0]);
				else
					__original();
			}
		});
	}
	catch (e)
	{
		::logWarning("[BBForge] asset_manager hook failed: " + e);
	}

	// ========================================================================
	// HOOK 8: Custom tooltips
	// ========================================================================
	mod.hook("scripts/ui/screens/tooltip/tooltip_events", function(q)
	{
		q.general_queryUIElementTooltipData = @(__original) function(_entityId, _elementId, _elementOwner)
		{
			if (_elementId != null && _elementId.len() >= 3 && _elementId.slice(0, 3) == "bf-")
			{
				local result = null;

					switch (_elementId)
					{
					case "bf-talent-tooltip":
						result = [
							{ id = 1, type = "title", text = "Talent Stars" },
							{ id = 2, type = "description", text = "Click to cycle talent level: 0-1-2-3-0. Higher talent = more attribute gain per level-up." }
						];
						break;
					case "bf-xp-tooltip":
						result = [
							{ id = 1, type = "title", text = "+1 Level" },
							{ id = 2, type = "description", text = "Grants enough XP to reach the next level. The brother will gain a level-up to spend." }
						];
						break;
					case "bf-stat-tooltip":
						result = [
							{ id = 1, type = "title", text = "Edit Attribute" },
							{ id = 2, type = "description", text = "Type a new value and press Enter or click outside. Format: Base (Effective) / Background Limit" }
						];
						break;
					case "bf-close-tooltip":
						result = [
							{ id = 1, type = "title", text = "Close" },
							{ id = 2, type = "description", text = "Close BBForge and return to the world map. All changes are applied immediately." }
						];
						break;
					case "bf-stat-hitpoints":
						result = [
							{ id = 1, type = "title", text = "Hitpoints (HP)" },
							{ id = 2, type = "description", text = "Maximum hit points. Format: Base (Effective) / Limit." }
						];
						break;
					case "bf-stat-stamina":
						result = [
							{ id = 1, type = "title", text = "Stamina / Fatigue (FAT)" },
							{ id = 2, type = "description", text = "Maximum fatigue before the brother becomes exhausted." }
						];
						break;
					case "bf-stat-initiative":
						result = [
							{ id = 1, type = "title", text = "Initiative (INI)" },
							{ id = 2, type = "description", text = "Determines turn order in combat." }
						];
						break;
					case "bf-stat-bravery":
						result = [
							{ id = 1, type = "title", text = "Bravery / Resolve (RES)" },
							{ id = 2, type = "description", text = "Resistance to morale checks and fear." }
						];
						break;
					case "bf-stat-meleeskill":
						result = [
							{ id = 1, type = "title", text = "Melee Skill (MEL)" },
							{ id = 2, type = "description", text = "Chance to hit in melee combat." }
						];
						break;
					case "bf-stat-rangedskill":
						result = [
							{ id = 1, type = "title", text = "Ranged Skill (RNG)" },
							{ id = 2, type = "description", text = "Chance to hit with ranged attacks." }
						];
						break;
					case "bf-stat-meleedefense":
						result = [
							{ id = 1, type = "title", text = "Melee Defense (MDF)" },
							{ id = 2, type = "description", text = "Chance to dodge melee attacks." }
						];
						break;
					case "bf-stat-rangeddefense":
						result = [
							{ id = 1, type = "title", text = "Ranged Defense (RDF)" },
							{ id = 2, type = "description", text = "Chance to dodge ranged attacks." }
						];
						break;
					case "bf-stat-perkpoints":
						result = [
							{ id = 1, type = "title", text = "Perk Points (PP)" },
							{ id = 2, type = "description", text = "Unspent perk points to assign." }
						];
						break;
					case "bf-stat-actionpoints":
						result = [
							{ id = 1, type = "title", text = "Action Points (AP)" },
							{ id = 2, type = "description", text = "Current AP. Read-only, set by equipped items and effects." }
						];
						break;
					case "bf-stat-dailywage":
						result = [
							{ id = 1, type = "title", text = "Daily Wage" },
							{ id = 2, type = "description", text = "Gold paid to this brother per day." }
						];
						break;
					case "bf-stat-xp":
						result = [
							{ id = 1, type = "title", text = "Experience (XP)" },
							{ id = 2, type = "description", text = "Current experience points." }
						];
						break;
					case "bf-stat-level":
						result = [
							{ id = 1, type = "title", text = "Level" },
							{ id = 2, type = "description", text = "Current character level." }
						];
						break;
					case "bf-stash-tooltip":
						try
						{
							local parts = split(_elementOwner, "|");
							local mode = parts[0];
							if (mode == "stash")
							{
								local idx = parts[1].tointeger();
								local stash = ::World.Assets.getStash();
								local slot = stash.getItemAtIndex(idx);
								if (slot != null && slot.item != null)
								{
									local item = slot.item;
									try { result = item.getTooltip(); }
									catch(ex)
									{
										local n = "Unknown";
										try { n = item.getName(); } catch(e2) {}
										result = [{ id = 1, type = "title", text = n }];
									}
									// Filter out image entries (layer previews render badly in ui-element tooltips)
									if (result != null)
									{
										local filtered = [];
										foreach (e in result)
										{
											try { if (e.type == "image") continue; } catch(x) {}
											filtered.push(e);
										}
										result = filtered;
									}
								}
								else
								{
									result = [{ id = 1, type = "title", text = "Empty slot" }];
								}
							}
							else if (mode == "catalog")
							{
								local script = parts[1];
								local item = this.new(script);
								try { result = item.getTooltip(); }
								catch(ex)
								{
									local n = "" + script;
									try { n = item.getName(); } catch(e2) {}
									result = [{ id = 1, type = "title", text = n }];
								}
							}
							else if (mode == "equip")
							{
								local broId = parts[1].tointeger();
								local slotName = parts[2];
								local bagIdx = parts.len() > 3 ? parts[3].tointeger() : -1;
								local b = null;
								try
								{
									local roster = ::World.getPlayerRoster().getAll();
									foreach (bro in roster)
									{
										if (bro.getID() == broId) { b = bro; break; }
									}
								}
								catch(e2) {}
								if (b != null)
								{
									local items = b.getItems();
									local item = null;
									if (slotName == "Bag" && bagIdx >= 0)
									{
										local bagItems = null;
										try { bagItems = items.getAllItemsAtSlot(::Const.ItemSlot.Bag); } catch(e2) {}
										if (bagItems != null && bagIdx < bagItems.len())
											item = bagItems[bagIdx];
									}
									else
									{
										try { item = items.getItemAtSlot(::Const.ItemSlot[slotName]); } catch(e2) {}
									}
									if (item != null)
									{
										try { result = item.getTooltip(); }
										catch(ex2)
										{
											local n2 = "Unknown";
											try { n2 = item.getName(); } catch(e3) {}
											result = [{ id = 1, type = "title", text = n2 }];
										}
										if (result != null)
										{
											local filtered = [];
											foreach (e in result)
											{
												try { if (e.type == "image") continue; } catch(x) {}
												filtered.push(e);
											}
											result = filtered;
										}
									}
								}
							}
						}
						catch (ex)
						{
							result = [{ id = 1, type = "title", text = "" + _elementOwner }];
						}
						break;
					case "bf-bg-tooltip":
						try
						{
							local bgtemp = this.new(_elementOwner);
							result = [
								{ id = 1, type = "title", text = bgtemp.m.Name },
								{ id = 2, type = "description", text = bgtemp.m.BackgroundDescription }
							];
						}
						catch (ex)
						{
							result = [
								{ id = 1, type = "title", text = "" + _elementOwner }
							];
						}
						break;
					case "bf-perk-tooltip":
						try
						{
							// Parse "perkId|broId" from elementOwner
							local parts = split(_elementOwner, "|");
							local perkId = parts[0];
							local broId = parts.len() > 1 ? parts[1].tointeger() : 0;

							// Find the selected bro
							local bro = null;
							if (broId != 0)
							{
								try
								{
									foreach (b in this.World.getPlayerRoster().getAll())
									{
										if (b.getID() == broId) { bro = b; break; }
									}
								}
								catch (ex) {}
							}

							// Find perk definition using Const.Perks.findById()
							local perkDef = null;
							try { perkDef = ::Const.Perks.findById(perkId); } catch(ex) {}

							// If bro has the perk, get tooltip from the live skill
							if (bro != null && bro.getSkills().hasSkill(perkId))
							{
								local skillOnBro = bro.getSkills().getSkillByID(perkId);
								if (skillOnBro != null)
								{
									try
									{
										result = skillOnBro.getTooltip();
										if (result != null && result.len() > 0) break;
									}
									catch(ex) {}
								}
							}

							// Fallback: instantiate from script and get tooltip
							if (perkDef != null)
							{
								try
								{
									local sk = this.new(perkDef.Script);
									if (bro != null)
									{
										local wasAdded = false;
										local wasForced = false;
										if (!bro.getSkills().hasSkill(perkId))
										{
											bro.getSkills().add(sk);
											if (bro.getSkills().hasSkill(perkId))
												wasAdded = true;
											else
											{
												sk.m.Container = bro.getSkills();
												bro.getSkills().m.Skills.push(sk);
												wasAdded = true;
												wasForced = true;
											}
										}

										local skillOnBro = bro.getSkills().getSkillByID(perkId);
										if (skillOnBro != null)
										{
											try
											{
												local tt = skillOnBro.getTooltip();
												if (tt != null && tt.len() > 2)
												{
													result = tt;
													if (wasAdded)
													{
														if (wasForced)
														{
															local arr = bro.getSkills().m.Skills;
															for (local ri = arr.len() - 1; ri >= 0; ri--)
															{
																if (arr[ri].getID() == perkId) { arr.remove(ri); break; }
															}
														}
														else
															bro.getSkills().removeByID(perkId);
													}
													break;
												}
											}
											catch (ex2) {}
										}

										// Cleanup if tooltip failed
										if (wasAdded)
										{
											if (wasForced)
											{
												try {
													local arr = bro.getSkills().m.Skills;
													for (local ri = arr.len() - 1; ri >= 0; ri--)
													{
														if (arr[ri].getID() == perkId) { arr.remove(ri); break; }
													}
												} catch (ex) {}
											}
											else
												try { bro.getSkills().removeByID(perkId); } catch (ex) {}
										}
									}

									// Static fallback: name + description
									local skName = perkId;
									local skDesc = "";
									try { skName = sk.getName(); } catch (ex) {}
									try { skDesc = sk.getDescription(); } catch (ex) {}
									result = [{ id = 1, type = "title", text = skName }];
									if (skDesc != "")
										result.push({ id = 2, type = "description", text = skDesc });
								}
								catch(ex) {}
							}

							// Last resort: just show the ID
							if (result == null)
								result = [{ id = 1, type = "title", text = perkId }];
						}
						catch (ex)
						{
							result = [{ id = 1, type = "title", text = "" + _elementOwner }];
						}
						break;
					case "bf-trait-tooltip":
						try
						{
							// Parse "script|broId" from elementOwner
							local parts = split(_elementOwner, "|");
							local trScript = parts[0];
							local broId = parts.len() > 1 ? parts[1].tointeger() : 0;

							// Handle "id:traitId" — look up directly on bro
							if (trScript.len() > 3 && trScript.slice(0, 3) == "id:")
							{
								local trId = trScript.slice(3);
								local bro = null;
								if (broId != 0)
								{
									try
									{
										foreach (b in this.World.getPlayerRoster().getAll())
										{
											if (b.getID() == broId) { bro = b; break; }
										}
									}
									catch (ex) {}
								}
								if (bro != null)
								{
									local skillOnBro = bro.getSkills().getSkillByID(trId);
									if (skillOnBro != null)
									{
										try
										{
											result = skillOnBro.getTooltip();
											if (result != null && result.len() > 0) break;
										}
										catch(ex) {}
										local n = trId;
										local d = "";
										try { n = skillOnBro.getName(); } catch(e) {}
										try { d = skillOnBro.getDescription(); } catch(e) {}
										result = [{ id = 1, type = "title", text = n }];
										if (d != "") result.push({ id = 2, type = "description", text = d });
										break;
									}
								}
								result = [{ id = 1, type = "title", text = trId }];
								break;
							}

							// Instantiate trait from script
							local sk = this.new(trScript);
							local skName = trScript;
							local skDesc = "";
							try { skName = sk.getName(); } catch (ex) {}
							try { skDesc = sk.getDescription(); } catch (ex) {}
							result = [{ id = 1, type = "title", text = skName }];
							if (skDesc != "")
								result.push({ id = 2, type = "description", text = skDesc });
						}
						catch (ex)
						{
							result = [{ id = 1, type = "title", text = "" + _elementOwner }];
						}
						break;
					case "bf-item-tooltip":
						try
						{
							// Parse "script|broId|slotName" or just "script"
							local parts = split(_elementOwner, "|");
							local itemScript = parts[0];
							local item = this.new(itemScript);
							try { result = item.getTooltip(); }
							catch(ex)
							{
								local n = "" + itemScript;
								try { n = item.getName(); } catch(e2) {}
								result = [{ id = 1, type = "title", text = n }];
							}
							// Filter out image entries
							if (result != null)
							{
								local filtered = [];
								foreach (e in result)
								{
									try { if (e.type == "image") continue; } catch(x) {}
									filtered.push(e);
								}
								result = filtered;
							}
						}
						catch (ex)
						{
							result = [{ id = 1, type = "title", text = "" + _elementOwner }];
						}
						break;
					}

				if (result != null)
				{
					return result;
				}
			}

			return __original(_entityId, _elementId, _elementOwner);
		}
	});
});
