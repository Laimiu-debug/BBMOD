this.bf_avatar_model <- this.inherit("scripts/entity/tactical/entity", {
	m = {},
	function getName()
	{
		return "BBForge Avatar Model";
	}

	function setFlipped( _flip )
	{
		this.getSprite("base").setHorizontalFlipping(_flip);
		this.getSprite("body").setHorizontalFlipping(_flip);
	}

	function onInit()
	{
		this.addSprite("socket");
		this.addSprite("base");
		this.addSprite("body");
	}

	function setDirty( _value )
	{
		this.getSprite("base").Scale = 1.5;
		this.getSprite("body").Scale = 1.5;
		this.m.ContentID = this.Math.rand() + this.Math.rand();
	}
});
