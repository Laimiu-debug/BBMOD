// ============================================================================
// BBForge Vanilla — Backend Squirrel
// Main screen object: lifecycle, data queries, handlers
// PART 1: Lifecycle, Roster, Stats, Perks, Traits
// ============================================================================

this.bbforge_screen <- {

	m = {
		JSHandle = null,
		Visible = null,
		Animating = null,
		OnConnectedListener = null,
		OnDisconnectedListener = null,
		OnClosePressedListener = null,

		// BBForge state
		FakeBro = null,

		// Appearance preview system (temp entity approach — like the barber)
		PreviewBroId = null,
		PreviewIsMonster = false,
		SavedAppearance = null,
		SavedGender = null,

		// Company tab — avatar state (kept server-side)
		bf_avatarSprites = null,
		bf_avatarNames = null,
		bf_avatarSockets = null,
		bf_avatarRow = 0,
		bf_avatarCol = 0,
		bf_avatarSocketIdx = 0,
		bf_avatarFlipped = false,
		bf_avatarTempModel = null,
		bf_itemCatalog = null,
		bf_bgCatalog = null
	},

	// ========================================================================
	// SECTION 1 — Lifecycle
	// ========================================================================

	function isVisible()
	{
		return this.m.Visible != null && this.m.Visible == true;
	},

	function isAnimating()
	{
		return this.m.Animating != null && this.m.Animating == true;
	},

	function setOnConnectedListener( _listener )
	{
		this.m.OnConnectedListener = _listener;
	},

	function setOnDisconnectedListener( _listener )
	{
		this.m.OnDisconnectedListener = _listener;
	},

	function setOnClosePressedListener( _listener )
	{
		this.m.OnClosePressedListener = _listener;
	},

	function clearEventListeners()
	{
		this.m.OnConnectedListener = null;
		this.m.OnDisconnectedListener = null;
		this.m.OnClosePressedListener = null;
	},

	function create()
	{
		this.m.Visible = false;
		this.m.Animating = false;
		this.m.JSHandle = this.UI.connect("BBForgeScreen", this);
	},

	function destroy()
	{
		this.cleanup();
		this.clearEventListeners();

		if (this.m.JSHandle != null)
		{
			this.UI.disconnect(this.m.JSHandle);
			this.m.JSHandle = null;
		}
	},

	function show( _withSlideAnimation = false )
	{
		this.Tooltip.hide();
		local data = this.queryRoster();
		this.m.JSHandle.asyncCall("show", data);
	},

	function hide( _withSlideAnimation = false )
	{
		if (this.m.Visible == false)
		{
			return;
		}

		this.m.JSHandle.asyncCall("hide", _withSlideAnimation);
	},

	// Screen event callbacks (called by JS via engine bridge)
	function onScreenConnected()
	{
		if (this.m.OnConnectedListener != null)
		{
			this.m.OnConnectedListener();
		}
	},

	function onScreenDisconnected()
	{
		if (this.m.OnDisconnectedListener != null)
		{
			this.m.OnDisconnectedListener();
		}
	},

	function onScreenShown()
	{
		this.m.Visible = true;
		this.m.Animating = false;
	},

	function onScreenHidden()
	{
		if (this.m.Visible == false)
		{
			return;
		}

		this.m.Visible = false;
		this.m.Animating = false;
		this.cleanup();
	},

	function onScreenAnimating()
	{
		this.m.Animating = true;
	},

	function onClose()
	{
		try
		{
			if (this.m.OnClosePressedListener != null)
			{
				this.m.OnClosePressedListener();
			}

			this.cleanup();
		}
		catch (e)
		{
			::logError("[BBForge] onClose CRASH: " + e);
		}
	},

	function onBFLog( _data )
	{
		return null;
	},

	function bfPing( _data )
	{
		return { Pong = true, Echo = _data.Message };
	},

	// ========================================================================
	// SECTION 2 — Cleanup
	// ========================================================================

	function cleanup()
	{
		this.bf_endPreview(false);
		this.bf_destroyAvatarTempModel();
		this.destroyFakeBro();

		// Final sync — skills.update() on all bros for persistence
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			foreach (b in brothers)
			{
				try
				{
					// Save DailyWage before skills.update() — onUpdate() recalculates it
					local bf_wageBase = 0;
					local bf_wageCur = 0;
					try { bf_wageBase = b.m.BaseProperties.DailyWage; } catch(e) {}
					try { bf_wageCur = b.m.CurrentProperties.DailyWage; } catch(e) {}

					b.getSkills().update();

					// Dedup skills — skills.update() can re-trigger bg onUpdate adding default traits
					try
					{
						local bf_seenIDs = {};
						local bf_clean = [];
						foreach (bf_sk in b.getSkills().m.Skills)
						{
							local bf_skid = "";
							try { bf_skid = bf_sk.getID(); } catch(ex2) {}
							if (bf_skid == "" || !(bf_skid in bf_seenIDs))
							{
								if (bf_skid != "") bf_seenIDs[bf_skid] <- true;
								bf_clean.push(bf_sk);
							}
						}
						b.getSkills().m.Skills = bf_clean;
					}
					catch(ex2) {}

					// Restore DailyWage after skills.update()
					try { b.m.BaseProperties.DailyWage = bf_wageBase; } catch(e) {}
					try { b.m.CurrentProperties.DailyWage = bf_wageCur; } catch(e) {}
				}
				catch(e) {}
			}
		}
		catch (e) {}

		try
		{
			if ("State" in this.World && this.World.State != null)
			{
				local player = this.World.State.getPlayer();
				if (player != null)
				{
					player.calculateModifiers();
				}
			}
		}
		catch (e)
		{
			// Silently ignore — State may not be available during transitions
		}
	},

	// ========================================================================
	// SECTION 3 — FakeBro management
	// ========================================================================

	function createFakeBro()
	{
		this.destroyFakeBro();

		try
		{
			local fakebro = this.World.getPlayerRoster().create("scripts/entity/tactical/player");
			fakebro.setStartValuesEx(["cripple_background"]);
			fakebro.setTitle("BFFakeBro");
			fakebro.setName("BBForge");
			this.m.FakeBro = fakebro;

			// Load all traits onto FakeBro for status-effect tooltips
			try
			{
				foreach (tr in ::Const.CharacterTraits)
				{
					try { fakebro.getSkills().add(this.new(tr[1])); } catch (ex) {}
				}
			}
			catch (ex) {}

			// Load all permanent injuries onto FakeBro
			try
			{
				foreach (inj in ::Const.Injury.Permanent)
				{
					try { fakebro.getSkills().add(this.new("scripts/skills/" + inj.Script)); } catch (ex) {}
				}
			}
			catch (ex) {}

			// Load all perks onto FakeBro for tooltip support
			// Vanilla: iterate Const.Perks.Perks (7 tiers) and add each perk individually
			try
			{
				for (local row = 0; row < this.Const.Perks.Perks.len(); row++)
				{
					local tier = this.Const.Perks.Perks[row];
					for (local i = 0; i < tier.len(); i++)
					{
						try
						{
							local perk = tier[i];
							if (!fakebro.getSkills().hasSkill(perk.ID))
							{
								local sk = this.new(perk.Script);
								fakebro.getSkills().add(sk);
							}
						}
						catch (ex) {}
					}
				}
			}
			catch (ex) {}

			return fakebro;
		}
		catch (e)
		{
			::logError("[BBForge] Failed to create FakeBro: " + e);
			return null;
		}
	},

	function destroyFakeBro()
	{
		// Remove any leftover fakebros (safety — also handles crash recovery)
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro")
				{
					this.World.getPlayerRoster().remove(b);
				}
			}
		}
		catch (e)
		{
			::logError("[BBForge] Error destroying FakeBro: " + e);
		}
		this.m.FakeBro = null;
	},

	// ========================================================================
	// SECTION 4 — Data Query (Roster)
	// ========================================================================

	function queryRoster( _broId = null )
	{
		// Create fakebro for tooltip support
		local fakebro = this.createFakeBro();

		// Base stat ranges for attribute display
		local baseStatRanges = [
			[50, 60],   // Hitpoints
			[80, 100],  // Stamina (Fatigue)
			[90, 110],  // Initiative
			[30, 40],   // Bravery (Resolve)
			[45, 60],   // MeleeSkill
			[30, 45],   // RangedSkill
			[0, 10],    // MeleeDefense
			[0, 10]     // RangedDefense
		];

		local statNames = [
			"Hitpoints", "Stamina", "Initiative", "Bravery",
			"MeleeSkill", "RangedSkill", "MeleeDefense", "RangedDefense"
		];

		local roster = [];
		local brothers = this.World.getPlayerRoster().getAll();

		foreach (b in brothers)
		{
			// Skip the fakebro
			if (b.getTitle() == "BFFakeBro")
			{
				continue;
			}

			// Skip if we only want one specific bro
			if (_broId != null && b.getID() != _broId)
			{
				continue;
			}

			try
			{
				local bp = b.getBaseProperties();
				local cp = b.getCurrentProperties();
				local bg = b.getBackground();

				// Get background attribute bonuses for BLimit calculation
				local bgBonuses = {};
				try
				{
					if (bg != null && "onChangeAttributes" in bg)
					{
						bgBonuses = bg.onChangeAttributes();
					}
				}
				catch (e)
				{
					// Some backgrounds may not support this
				}

				local bf_pp = b.m.PerkPoints;

				local bf_wage = 0;
				try { bf_wage = b.getDailyWage(); }
				catch(e) { try { bf_wage = b.m.BaseProperties.DailyWage; } catch(e2) {} }

				local entry = {
					ID = b.getID(),
					Name = b.getName(),
					Title = b.getTitle(),
					ImagePath = b.getImagePath(),
					ImageOffsetX = ("getImageOffsetX" in b) ? b.getImageOffsetX() : 0,
					ImageOffsetY = ("getImageOffsetY" in b) ? b.getImageOffsetY() : 0,
					Level = b.getLevel(),
					LevelUps = ("LevelUps" in b.m) ? b.m.LevelUps : 0,
					XpValue = b.getXP(),
					PerkPoints = bf_pp,
					ActionPoints = bp.ActionPoints,
					DailyWage = bf_wage,
					Background = (bg != null) ? bg.getID() : "",
					BackgroundName = (bg != null) ? bg.m.Name : "",
					BackgroundImagePath = "",
					BackgroundText = "",
					IsInReserves = false
				};

				try { entry.IsInReserves = b.isInReserves(); } catch(ex) {}

				local morale = 3;
				local moraleLabel = "Content";
				try { morale = b.getMoodState(); } catch(ex) {}
				try { moraleLabel = this.Const.MoodStateName[morale]; } catch(ex) {}
				entry.Morale <- morale;
				entry.MoraleLabel <- moraleLabel;

				// Get background icon and bio
				try
				{
					if (bg != null)
					{
						if ("getIconColored" in bg)
						{
							entry.BackgroundImagePath = bg.getIconColored();
						}
						if ("m" in bg && "Description" in bg.m)
						{
							entry.BackgroundText = bg.m.Description;
						}
					}
				}
				catch (e)
				{
					// Fallback — some backgrounds may crash on getIconColored
				}

				// Build attribute data
				for (local i = 0; i < statNames.len(); i++)
				{
					local sn = statNames[i];
					local baseVal = 0;
					local effectiveVal = 0;
					local talent = 0;
					local bLimit = baseStatRanges[i][1];

					try
					{
						if (sn in bp)
						{
							baseVal = bp[sn];
						}

						// Effective-value getters
						switch (sn)
						{
							case "Hitpoints":     effectiveVal = b.getHitpointsMax(); break;
							case "Stamina":       effectiveVal = b.getFatigueMax(); break;
							case "Initiative":    effectiveVal = b.getInitiative(); break;
							case "Bravery":       effectiveVal = b.getBravery(); break;
							case "MeleeSkill":    effectiveVal = b.m.CurrentProperties.getMeleeSkill(); break;
							case "RangedSkill":   effectiveVal = b.m.CurrentProperties.getRangedSkill(); break;
							case "MeleeDefense":  effectiveVal = b.m.CurrentProperties.getMeleeDefense(); break;
							case "RangedDefense": effectiveVal = b.m.CurrentProperties.getRangedDefense(); break;
							default:
								if (sn in cp) { effectiveVal = cp[sn]; }
								break;
						}
					}
					catch (e) {}

					// Get talent stars
					try
					{
						if ("Attributes" in this.Const)
						{
							local talentIndex = -1;
							switch (sn)
							{
								case "Hitpoints":     talentIndex = this.Const.Attributes.Hitpoints; break;
								case "Stamina":       talentIndex = this.Const.Attributes.Fatigue; break;
								case "Initiative":    talentIndex = this.Const.Attributes.Initiative; break;
								case "Bravery":       talentIndex = this.Const.Attributes.Bravery; break;
								case "MeleeSkill":    talentIndex = this.Const.Attributes.MeleeSkill; break;
								case "RangedSkill":   talentIndex = this.Const.Attributes.RangedSkill; break;
								case "MeleeDefense":  talentIndex = this.Const.Attributes.MeleeDefense; break;
								case "RangedDefense": talentIndex = this.Const.Attributes.RangedDefense; break;
							}
							local talents = b.getTalents();
							if (talentIndex >= 0 && talentIndex < talents.len())
							{
								talent = talents[talentIndex];
							}
						}
					}
					catch (e) {}

					// Calculate BLimit from background bonuses
					try
					{
						if (sn in bgBonuses)
						{
							bLimit = baseStatRanges[i][1] + bgBonuses[sn][1];
						}
					}
					catch (e) {}

					entry[sn] <- {
						Max = baseVal,
						MaxPlus = effectiveVal,
						Talent = talent,
						BLimit = bLimit
					};
				}

				roster.push(entry);
			}
			catch (entryErr)
			{
				::logError("[BBForge] queryRoster skipping entity: " + entryErr);
			}
		}

		// Sort: active bros first, reserves last
		roster.sort(function(a, b) {
			if (a.IsInReserves && !b.IsInReserves) return 1;
			if (!a.IsInReserves && b.IsInReserves) return -1;
			return 0;
		});

		local result = {
			Title = "BBForge",
			Roster = roster,
			FakeBroId = (fakebro != null) ? fakebro.getID() : 0
		};

		return result;
	},

	// ========================================================================
	// SECTION 5 — Stat Editing Handlers
	// ========================================================================

	function onSetMorale( _data )
	{
		// _data = { BroId, MoraleName }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			// Map mood names to Const.MoodState values
			local targetMood = 3;
			try { targetMood = this.Const.MoodState[_data.MoraleName]; }
			catch(e)
			{
				local moodMap = {
					Angry = 0, Disgruntled = 1, Dissatisfied = 2, Content = 3
				};
				if (_data.MoraleName in moodMap)
					targetMood = moodMap[_data.MoraleName];
				else if (_data.MoraleName == "In good spirit")
					targetMood = 4;
				else if (_data.MoraleName == "Eager")
					targetMood = 5;
				else if (_data.MoraleName == "Euphoric")
					targetMood = 6;
			}

			local currentMood = 3;
			try { currentMood = b.getMoodState(); } catch(e) {}

			// No setMoodState exists — use worsenMood/improveMood loop
			if (targetMood != currentMood)
			{
				// First reset to Angry (0)
				try { b.worsenMood(1000.0, ""); } catch(e) {}

				// Then improve until target reached
				if (targetMood > 0)
				{
					for (local step = 0; step < 500; step++)
					{
						local cur = 0;
						try { cur = b.getMoodState(); } catch(e) {}
						if (cur >= targetMood) break;
						try { b.improveMood(1.0, ""); } catch(e) {}
					}
				}
			}

			local finalMood = 3;
			try { finalMood = b.getMoodState(); } catch(e) {}
			local finalLabel = "Content";
			try { finalLabel = this.Const.MoodStateName[finalMood]; } catch(e) {}

			return { Success = true, Morale = finalMood, MoraleLabel = finalLabel };
		}
		catch (e)
		{
			::logError("[BBForge] onSetMorale error: " + e);
			return null;
		}
	},

	function onChangeAttributes( _result )
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();

			foreach( b in brothers )
			{
				if (b.getID() == _result.BroId)
				{
					if (_result.StatName == "PerkPoints")
					{
						b.m.PerkPoints = _result.Value;
						break;
					}
					else if (_result.StatName == "DailyWage")
					{
						b.getBaseProperties().DailyWage = b.getBaseProperties().DailyWage - (b.m.CurrentProperties.DailyWage - _result.Value);
						break;
					}
					else
					{
						b.getBaseProperties()[_result.StatName] = _result.Value;
						break;
					}
				}
			};
		}
		catch (e)
		{
			::logError("[BBForge] onChangeAttributes CRASH: " + e);
		}
	},

	function onChangeTalents( _result )
	{
		try
		{
			local talentconstants =
			{
				Hitpoints = this.Const.Attributes.Hitpoints,
				Stamina = this.Const.Attributes.Fatigue,
				Initiative = this.Const.Attributes.Initiative,
				Bravery = this.Const.Attributes.Bravery,
				MeleeSkill = this.Const.Attributes.MeleeSkill,
				RangedSkill = this.Const.Attributes.RangedSkill,
				MeleeDefense = this.Const.Attributes.MeleeDefense,
				RangedDefense = this.Const.Attributes.RangedDefense,
			}
			local talentconst = talentconstants[_result.StatName];

			local brothers = this.World.getPlayerRoster().getAll();
			foreach( b in brothers )
			{
				if (b.getID() == _result.BroId)
				{
					b.m.Talents[talentconst] = _result.TalentValue;
					b.m.Attributes.clear();
					b.fillAttributeLevelUpValues(this.Const.XP.MaxLevelWithPerkpoints - b.getLevel() + b.m.LevelUps);
					break;
				}
			};
		}
		catch (e)
		{
			::logError("[BBForge] onChangeTalents CRASH: " + e);
		}
	},

	function BDUpdateAttributes( _result )
	{
		try
		{
			local result = 0;
			local basestats = {
				Hitpoints = [50,60],
				Bravery = [30,40],
				Stamina = [90,100],
				MeleeSkill = [47,57],
				RangedSkill = [32,42],
				MeleeDefense = [0,5],
				RangedDefense = [0,5],
				Initiative = [100,110]
			};
			local brothers = this.World.getPlayerRoster().getAll();

			foreach( b in brothers )
			{
				if (b.getID() == _result.BroId)
				{
					b.getSkills().update();

					local background = b.getBackground();
					local additionalstats = {
						Hitpoints = [0, 0], Bravery = [0, 0], Stamina = [0, 0],
						MeleeSkill = [0, 0], RangedSkill = [0, 0],
						MeleeDefense = [0, 0], RangedDefense = [0, 0],
						Initiative = [0, 0]
					};

					if (background != null)
					{
						try { additionalstats = background.onChangeAttributes(); }
						catch(e) { ::logWarning("[BBForge] BDUpdateAttributes: onChangeAttributes failed: " + e); }
					}
					else
					{
						::logWarning("[BBForge] BDUpdateAttributes: getBackground() returned null — using defaults");
					}

					local bf_wage = 0;
					try { bf_wage = b.getDailyWage(); }
					catch(e) { try { bf_wage = b.m.BaseProperties.DailyWage; } catch(e2) {} }

					result = {
						PerkPoints = b.m.PerkPoints,
						Hitpoints = {
							Max = b.getBaseProperties().Hitpoints,
							MaxPlus = b.getHitpointsMax(),
							Talent = b.getTalents()[this.Const.Attributes.Hitpoints],
							BLimit = basestats.Hitpoints[1] + additionalstats.Hitpoints[1],
						},
						Stamina = {
							Max = b.getBaseProperties().Stamina,
							MaxPlus = b.getFatigueMax(),
							Talent = b.getTalents()[this.Const.Attributes.Fatigue],
							BLimit = basestats.Stamina[1] + additionalstats.Stamina[1],
						},
						Initiative = {
							Max = b.getBaseProperties().Initiative,
							MaxPlus = b.getInitiative(),
							Talent = b.getTalents()[this.Const.Attributes.Initiative],
							BLimit = basestats.Initiative[1] + additionalstats.Initiative[1],
						},
						Bravery = {
							Max = b.getBaseProperties().Bravery,
							MaxPlus = b.getBravery(),
							Talent = b.getTalents()[this.Const.Attributes.Bravery],
							BLimit = basestats.Bravery[1] + additionalstats.Bravery[1],
						},
						MeleeSkill = {
							Max = b.getBaseProperties().MeleeSkill,
							MaxPlus = b.m.CurrentProperties.getMeleeSkill(),
							Talent = b.getTalents()[this.Const.Attributes.MeleeSkill],
							BLimit = basestats.MeleeSkill[1] + additionalstats.MeleeSkill[1],
						},
						RangedSkill = {
							Max = b.getBaseProperties().RangedSkill,
							MaxPlus = b.m.CurrentProperties.getRangedSkill(),
							Talent = b.getTalents()[this.Const.Attributes.RangedSkill],
							BLimit = basestats.RangedSkill[1] + additionalstats.RangedSkill[1],
						},
						MeleeDefense = {
							Max = b.getBaseProperties().MeleeDefense,
							MaxPlus = b.m.CurrentProperties.getMeleeDefense(),
							Talent = b.getTalents()[this.Const.Attributes.MeleeDefense],
							BLimit = basestats.MeleeDefense[1] + additionalstats.MeleeDefense[1],
						},
						RangedDefense = {
							Max = b.getBaseProperties().RangedDefense,
							MaxPlus = b.m.CurrentProperties.getRangedDefense(),
							Talent = b.getTalents()[this.Const.Attributes.RangedDefense],
							BLimit = basestats.RangedDefense[1] + additionalstats.RangedDefense[1],
						},
						ActionPoints = b.getActionPointsMax(),
						DailyWage = bf_wage,
						XpValue = b.getXP(),
						Level = b.getLevel(),
						Name = b.getName(),
						Title = b.getTitle(),
						ImagePath = b.getImagePath(),
						ImageOffsetX = ("getImageOffsetX" in b) ? b.getImageOffsetX() : 0,
						ImageOffsetY = ("getImageOffsetY" in b) ? b.getImageOffsetY() : 0,
						BackgroundName = "",
					};

					try { result.BackgroundName = b.getBackground().m.Name; } catch(e) {}
				}
			};

			return result;
		}
		catch (e)
		{
			::logError("[BBForge] BDUpdateAttributes CRASH: " + e);
			return {};
		}
	},

	function onGiveXP( _data )
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local nextXP = b.getXPForNextLevel() - b.m.XP;
			if (nextXP > 0)
			{
				b.m.XP += nextXP;
				if ("CombatStats" in b.m && "XPGained" in b.m.CombatStats)
				{
					b.m.CombatStats.XPGained += nextXP;
				}
			}
			else
			{
				b.m.XP += 1000;
			}

			b.updateLevel();
			b.getSkills().update();

			local bf_wage = 0;
			try { bf_wage = b.getDailyWage(); }
			catch(e) { try { bf_wage = b.m.BaseProperties.DailyWage; } catch(e2) {} }

			return {
				Level = b.getLevel(),
				LevelUps = ("LevelUps" in b.m) ? b.m.LevelUps : 0,
				PerkPoints = b.m.PerkPoints,
				XpValue = b.getXP(),
				DailyWage = bf_wage
			};
		}
		catch (e)
		{
			::logError("[BBForge] onGiveXP error: " + e);
			return null;
		}
	},

	function onGiveYF( _data )
	{
		// _data = { BroId }
		// Youth Fountain: reset to level 1, call bg.onSetUp()
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			b.m.XP = 0;
			b.m.Level = 1;
			b.m.LevelUps = 0;
			b.m.PerkPoints = 0;
			if ("PerkPointsSpent" in b.m) b.m.PerkPointsSpent = 0;

			try
			{
				local bg = b.getBackground();
				if (bg != null && "onSetUp" in bg)
				{
					bg.onSetUp(b, false);
				}
			}
			catch (ex)
			{
				::logError("[BBForge] onGiveYF bg.onSetUp error: " + ex);
			}

			b.getSkills().update();

			return {
				Level = b.getLevel(),
				LevelUps = ("LevelUps" in b.m) ? b.m.LevelUps : 0,
				PerkPoints = b.m.PerkPoints,
				XpValue = b.getXP()
			};
		}
		catch (e)
		{
			::logError("[BBForge] onGiveYF error: " + e);
			return null;
		}
	},

	function refreshStats( _broId )
	{
		try
		{
			local b = this.bf_findBroById(_broId);
			if (b == null) return null;

			b.getSkills().update();

			local bp = b.getBaseProperties();
			local cp = b.getCurrentProperties();
			local statNames = [
				"Hitpoints", "Stamina", "Initiative", "Bravery",
				"MeleeSkill", "RangedSkill", "MeleeDefense", "RangedDefense"
			];

			local baseStatRanges = [
				[50, 60],   // Hitpoints
				[80, 100],  // Stamina
				[90, 110],  // Initiative
				[30, 40],   // Bravery
				[45, 60],   // MeleeSkill
				[30, 45],   // RangedSkill
				[0, 10],    // MeleeDefense
				[0, 10]     // RangedDefense
			];

			local bgBonuses = {};
			try
			{
				local bgObj = b.getBackground();
				if (bgObj != null && "onChangeAttributes" in bgObj)
				{
					bgBonuses = bgObj.onChangeAttributes();
				}
			}
			catch (ex) {}

			local bf_wage = 0;
			try { bf_wage = b.getDailyWage(); }
			catch(e) { try { bf_wage = b.m.BaseProperties.DailyWage; } catch(e2) {} }

			local result = {
				PerkPoints = b.m.PerkPoints,
				ActionPoints = bp.ActionPoints,
				DailyWage = bf_wage
			};

			for (local i = 0; i < statNames.len(); i++)
			{
				local sn = statNames[i];
				local baseVal = (sn in bp) ? bp[sn] : 0;
				local effVal = 0;
				local bLimit = baseStatRanges[i][1];
				try
				{
					switch (sn)
					{
						case "Hitpoints":     effVal = b.getHitpointsMax(); break;
						case "Stamina":       effVal = b.getFatigueMax(); break;
						case "Initiative":    effVal = b.getInitiative(); break;
						case "Bravery":       effVal = b.getBravery(); break;
						case "MeleeSkill":    effVal = b.m.CurrentProperties.getMeleeSkill(); break;
						case "RangedSkill":   effVal = b.m.CurrentProperties.getRangedSkill(); break;
						case "MeleeDefense":  effVal = b.m.CurrentProperties.getMeleeDefense(); break;
						case "RangedDefense": effVal = b.m.CurrentProperties.getRangedDefense(); break;
						default:
							if (sn in cp) { effVal = cp[sn]; }
							break;
					}
				}
				catch (ex) {}
				try
				{
					if (sn in bgBonuses) { bLimit = baseStatRanges[i][1] + bgBonuses[sn][1]; }
				}
				catch (ex) {}
				result[sn] <- {
					Max = baseVal,
					MaxPlus = effVal,
					BLimit = bLimit
				};
			}

			return result;
		}
		catch (e)
		{
			::logError("[BBForge] refreshStats error: " + e);
			return null;
		}
	},

	// ========================================================================
	// SECTION 6 — Utility functions
	// ========================================================================

	function bf_serializeItem( _item, _slotLabel )
	{
		local n = "";
		local ic = "";
		local id = "";
		local cond = 0;
		local condMax = 0;
		local isNamed = false;
		try { n = _item.getName(); } catch (ex) {}
		try { ic = _item.getIcon(); } catch (ex) {}
		try { id = _item.getID(); } catch (ex) {}
		try { cond = _item.getCondition(); } catch (ex) {}
		try { condMax = _item.getConditionMax(); } catch (ex) {}
		try
		{
			if ("isItemType" in _item)
			{
				isNamed = _item.isItemType(::Const.Items.ItemType.Named);
			}
		}
		catch (ex) {}
		local overlays = [];
		try { overlays = _item.getIconOverlay(); } catch (ex) {}

		return {
			Slot = _slotLabel,
			Name = n,
			Icon = ic,
			ID = id,
			Condition = cond,
			ConditionMax = condMax,
			IsNamed = isNamed,
			HasItem = true,
			Overlays = overlays
		};
	},

	function bf_findBroById( _id )
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			foreach (b in brothers)
			{
				if (b.getID() == _id)
				{
					return b;
				}
			}
		}
		catch (e)
		{
			::logError("[BBForge] bf_findBroById error: " + e);
		}
		return null;
	},

	function bf_statToTalentIndex( _statName )
	{
		try
		{
			switch (_statName)
			{
				case "Hitpoints":     return this.Const.Attributes.Hitpoints;
				case "Stamina":       return this.Const.Attributes.Fatigue;
				case "Initiative":    return this.Const.Attributes.Initiative;
				case "Bravery":       return this.Const.Attributes.Bravery;
				case "MeleeSkill":    return this.Const.Attributes.MeleeSkill;
				case "RangedSkill":   return this.Const.Attributes.RangedSkill;
				case "MeleeDefense":  return this.Const.Attributes.MeleeDefense;
				case "RangedDefense": return this.Const.Attributes.RangedDefense;
			}
		}
		catch (e) {}
		return -1;
	},

	// ========================================================================
	// SECTION 7 — Perk Handlers
	// ========================================================================

	function queryPerks( _data )
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			// Build owned skills lookup for fast checking
			local ownedSkills = {};
			try
			{
				foreach (sk in b.getSkills().m.Skills)
				{
					ownedSkills[sk.getID()] <- true;
				}
			}
			catch(ex) {}

			// Build perk data from Const.Perks.Perks (7 tiers)
			local categories = [];
			for (local row = 0; row < 7; row++)
			{
				if (row >= this.Const.Perks.Perks.len()) break;
				local tier = this.Const.Perks.Perks[row];
				if (tier.len() == 0) continue;

				local catPerks = [];
				foreach (perk in tier)
				{
					local isOwned = (perk.ID in ownedSkills);
					catPerks.push({
						ID = perk.ID,
						Name = perk.Name,
						Icon = perk.Icon,
						IconDisabled = perk.IconDisabled,
						IsOwned = isOwned,
						Row = row
					});
				}
				categories.push({ Name = "Tier " + (row + 1), Perks = catPerks });
			}

			return { Categories = categories };
		}
		catch (e)
		{
			::logError("[BBForge] queryPerks error: " + e);
			return null;
		}
	},

	function onTogglePerk( _data )
	{
		// _data = { BroId, PerkId }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local perkId = _data.PerkId;
			local hasSkill = b.getSkills().hasSkill(perkId);

			if (hasSkill)
			{
				// REMOVE perk: remove skill and restore 1 PP
				b.getSkills().removeByID(perkId);
				b.m.PerkPoints = b.m.PerkPoints + 1;
				if ("PerkPointsSpent" in b.m && b.m.PerkPointsSpent > 0)
					b.m.PerkPointsSpent = b.m.PerkPointsSpent - 1;
			}
			else
			{
				// ADD perk: find script via Const.Perks.findById, instantiate, add, consume 1 PP
				local perkDef = this.Const.Perks.findById(perkId);
				if (perkDef != null && "Script" in perkDef)
				{
					local sk = this.new(perkDef.Script);
					b.getSkills().add(sk);

					// Only consume PP if we actually added the skill
					if (b.getSkills().hasSkill(perkId))
					{
						if (b.m.PerkPoints > 0)
							b.m.PerkPoints = b.m.PerkPoints - 1;
						if ("PerkPointsSpent" in b.m)
							b.m.PerkPointsSpent = b.m.PerkPointsSpent + 1;
					}
				}
				else
				{
					::logWarning("[BBForge] onTogglePerk: perk def not found for " + perkId);
				}
			}

			b.getSkills().update();

			return { PerkPoints = b.m.PerkPoints };
		}
		catch (e)
		{
			::logError("[BBForge] onTogglePerk error: " + e);
			return null;
		}
	},

	function onResetPerks( _data )
	{
		// Use native Oblivion Potion item with fallback to manual removal
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local bf_success = false;

			// Try Oblivion Potion (native approach)
			try
			{
				this.new("scripts/items/misc/potion_of_oblivion_item").onUse(b);
				bf_success = true;
			}
			catch (potionErr)
			{
				::logWarning("[BBForge] Oblivion Potion failed, using manual removal: " + potionErr);

				// Fallback: manually remove all perks and restore PP
				try
				{
					local bf_removedCount = 0;
					local allSkills = b.getSkills().m.Skills;

					// Collect perk IDs to remove (don't modify array while iterating)
					local bf_perkIds = [];
					for (local i = 0; i < allSkills.len(); i++)
					{
						try
						{
							local skId = allSkills[i].getID();
							if (skId.find("perk.") == 0)
							{
								bf_perkIds.push(skId);
							}
						}
						catch(e) {}
					}

					// Remove each perk
					foreach (pid in bf_perkIds)
					{
						try
						{
							b.getSkills().removeByID(pid);
							bf_removedCount++;
						}
						catch(e) {}
					}

					// Restore PP from PerkPointsSpent
					local bf_spent = 0;
					try { bf_spent = b.m.PerkPointsSpent; } catch(e) {}
					b.m.PerkPoints = b.m.PerkPoints + bf_spent;
					if ("PerkPointsSpent" in b.m) b.m.PerkPointsSpent = 0;
				}
				catch (manualErr)
				{
					::logError("[BBForge] Manual perk removal also failed: " + manualErr);
				}
			}

			b.getSkills().update();

			return { PerkPoints = b.m.PerkPoints };
		}
		catch (e)
		{
			::logError("[BBForge] onResetPerks error: " + e);
			return null;
		}
	},

	// ========================================================================
	// SECTION 8 — Trait Handlers
	// ========================================================================

	function queryTraits( _data )
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local traitsList = [];

			// Vanilla traits from ::Const.CharacterTraits
			try
			{
				foreach (tr in ::Const.CharacterTraits)
				{
					local trId = tr[0];
					local trScript = tr[1];

					// missing_hand handled separately below (needs left/right variants)
					if (trId == "injury.missing_hand") continue;

					local icon = "";
					local name = trId;
					try
					{
						local skill = this.new(trScript);
						try { icon = skill.getIconColored(); } catch (ex) { icon = "ui/icons/unknown_traits.png"; }
						try { if ("getName" in skill) name = skill.getName(); } catch (ex) {}
					}
					catch (ex) {}

					traitsList.push({
						ID = trId,
						Script = trScript,
						Icon = icon,
						Name = name,
						IsOwned = b.getSkills().hasSkill(trId),
						Section = (trId.find("injury.") == 0) ? "injury" : "trait"
					});

					if (this.m.FakeBro != null && !this.m.FakeBro.getSkills().hasSkill(trId))
					{
						try { this.m.FakeBro.getSkills().add(this.new(trScript)); } catch (ex) {}
					}
				}
			}
			catch (ex)
			{
				::logError("[BBForge] queryTraits CharacterTraits: " + ex);
			}

			// Permanent injuries from ::Const.Injury.Permanent
			try
			{
				foreach (inj in ::Const.Injury.Permanent)
				{
					if (inj.ID == "injury.missing_hand") continue;

					local script = "scripts/skills/" + inj.Script;
					local icon = "";
					local name = inj.ID;
					try
					{
						local skill = this.new(script);
						try { icon = skill.getIconColored(); } catch (ex) { icon = "ui/icons/unknown_traits.png"; }
						try { if ("getName" in skill) name = skill.getName(); } catch (ex) {}
					}
					catch (ex) {}

					traitsList.push({
						ID = inj.ID,
						Script = script,
						Icon = icon,
						Name = name,
						IsOwned = b.getSkills().hasSkill(inj.ID),
						Section = "injury"
					});

					if (this.m.FakeBro != null && !this.m.FakeBro.getSkills().hasSkill(inj.ID))
					{
						try { this.m.FakeBro.getSkills().add(this.new(script)); } catch (ex) {}
					}
				}
			}
			catch (ex)
			{
				::logError("[BBForge] queryTraits Injuries: " + ex);
			}

			// Missing Hand — two variants (left/right) with custom IDs
			try
			{
				local mhScript = null;
				foreach (inj in ::Const.Injury.Permanent)
				{
					if (inj.ID == "injury.missing_hand") { mhScript = "scripts/skills/" + inj.Script; break; }
				}
				if (mhScript == null)
				{
					foreach (tr in ::Const.CharacterTraits)
					{
						if (tr[0] == "injury.missing_hand") { mhScript = tr[1]; break; }
					}
				}
				if (mhScript != null)
				{
					local mhIcon = "ui/icons/unknown_traits.png";
					try { local tmp = this.new(mhScript); try { mhIcon = tmp.getIconColored(); } catch(e) {} } catch(e) {}

					// Check if bro already has missing_hand and which hand
					local mhOwned = b.getSkills().hasSkill("injury.missing_hand");
					local mhOwnedHand = -1;
					if (mhOwned)
					{
						try
						{
							local sk = b.getSkills().getSkillByID("injury.missing_hand");
							if (sk != null && "Hand" in sk.m) mhOwnedHand = sk.m.Hand;
						}
						catch(e) {}
					}

					traitsList.push({
						ID = "injury.missing_hand_left",
						Script = mhScript,
						Icon = mhIcon,
						Name = "Missing Hand (Left)",
						IsOwned = (mhOwned && mhOwnedHand == 0),
						Section = "injury"
					});
					traitsList.push({
						ID = "injury.missing_hand_right",
						Script = mhScript,
						Icon = mhIcon,
						Name = "Missing Hand (Right)",
						IsOwned = (mhOwned && mhOwnedHand == 1),
						Section = "injury"
					});
				}
			}
			catch(ex) {}

			// Scan bro's actual skills for hidden/unknown traits not in catalog
			try
			{
				local knownIds = {};
				foreach (t in traitsList)
					knownIds[t.ID] <- true;

				local allSkills = b.getSkills().m.Skills;
				foreach (sk in allSkills)
				{
					try
					{
						local skId = sk.getID();
						// Skip if already in catalog
						if (skId in knownIds) continue;

						// Filter: only show passive-like skills (traits, effects, injuries)
						// Skip if it's an active skill (has ActionPointCost > 0)
						local isActive = false;
						try { if (sk.m.ActionPointCost > 0) isActive = true; } catch(e) {}
						if (isActive) continue;

						// Skip backgrounds
						local isBg = false;
						try { isBg = sk.isType(::Const.SkillType.Background); } catch(e) {}
						if (isBg) continue;

						// Skip perks (they belong in the Perks tab)
						if (skId.find("perk.") == 0) continue;

						// Get icon and name
						local skIcon = "ui/icons/unknown_traits.png";
						local skName = skId;
						try { skIcon = sk.getIconColored(); } catch(e) {}
						try { skName = sk.getName(); } catch(e) {}

						traitsList.push({
							ID = skId,
							Script = "",
							Icon = skIcon,
							Name = skName,
							IsOwned = true,
							Section = "effect"
						});
					}
					catch(e) {}
				}
			}
			catch(e) {}

			// Sort alphabetically by Name for stable order
			traitsList.sort(function(a, b) {
				if (a.Name < b.Name) return -1;
				else if (a.Name > b.Name) return 1;
				else return 0;
			});

			return { Traits = traitsList };
		}
		catch (e)
		{
			::logError("[BBForge] queryTraits error: " + e);
			return null;
		}
	},

	function onToggleTrait( _data )
	{
		// _data = { BroId, TraitId, TraitScript, Add }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			// Save appearance BEFORE toggle — onAdded()/onRemoved() can modify sprites
			local bf_savedSprites = {};
			{
				local bf_sprLayers = ["body", "head", "hair", "beard", "beard_top", "tattoo_body", "tattoo_head",
				   "body_blood", "dirt", "injury", "injury_body", "scar_head", "scar_body"];
				foreach (sn in bf_sprLayers)
				{
					try
					{
						local sp = b.getSprite(sn);
						if (sp != null)
						{
							bf_savedSprites[sn] <- {
								brush = (sp.HasBrush) ? sp.getBrush().Name : "",
								color = sp.Color,
								saturation = sp.Saturation,
								visible = sp.Visible
							};
						}
					}
					catch(e) {}
				}
			}

			// Resolve missing_hand variants to real trait ID
			local bf_realTraitId = _data.TraitId;
			local bf_missingHand = -1; // -1 = not missing_hand, 0 = left, 1 = right
			if (_data.TraitId == "injury.missing_hand_left")
			{
				bf_realTraitId = "injury.missing_hand";
				bf_missingHand = 0;
			}
			else if (_data.TraitId == "injury.missing_hand_right")
			{
				bf_realTraitId = "injury.missing_hand";
				bf_missingHand = 1;
			}

			// Save all skills before toggle — some traits' onAdded/onRemoved
			// can destroy weapon skills in the container
			local bf_preSkills = [];
			local bf_allSkills = b.getSkills().m.Skills;
			for (local i = 0; i < bf_allSkills.len(); i++)
			{
				bf_preSkills.push(bf_allSkills[i]);
			}

			if (_data.Add)
			{
				// Effects (hidden skills) have no Script — can only be removed, not added back
				if (_data.TraitScript == "") return { OK = false };

				if (!b.getSkills().hasSkill(bf_realTraitId))
				{
					local skill = this.new(_data.TraitScript);
					skill.m.IsNew = false;

					// Set hand BEFORE add — onAdded() reads m.Hand
					if (bf_missingHand >= 0)
					{
						try
						{
							if ("Hand" in skill.m)
								skill.m.Hand = bf_missingHand;
							else
								skill.m.Hand <- bf_missingHand;
						}
						catch(ex) {}
					}

					b.getSkills().add(skill);

					// Native add() may reject — force-push for non-standard entities
					if (!b.getSkills().hasSkill(bf_realTraitId))
					{
						skill.m.Container = b.getSkills();
						b.getSkills().m.Skills.push(skill);
					}
				}
			}
			else
			{
				b.getSkills().removeByID(bf_realTraitId);
			}

			b.getSkills().update();

			// Restore any skills lost during toggle (weapon skills, racials, etc.)
			foreach (sk in bf_preSkills)
			{
				try
				{
					if (sk.getID() == bf_realTraitId) continue;
					if (!b.getSkills().hasSkill(sk.getID()))
					{
						sk.m.Container = b.getSkills();
						b.getSkills().m.Skills.push(sk);
					}
				}
				catch(e) {}
			}

			// Restore appearance after toggle — prevent onAdded()/onRemoved() side effects
			if (bf_savedSprites.len() > 0)
			{
				foreach (sn, saved in bf_savedSprites)
				{
					try
					{
						local sp = b.getSprite(sn);
						if (sp != null)
						{
							if (saved.brush == "" || saved.brush == "empty_brush")
								sp.resetBrush();
							else
								sp.setBrush(saved.brush);
							sp.Color = saved.color;
							sp.Saturation = saved.saturation;
							sp.Visible = saved.visible;
						}
					}
					catch(e) {}
				}
				try { b.setDirty(true); } catch(e) {}
			}

			return { OK = true };
		}
		catch (e)
		{
			::logError("[BBForge] onToggleTrait error: " + e);
			return null;
		}
	},

	// --- PART 2: Backgrounds, Appearance, Items ---

	// ========================================================================
	// SECTION 9 — Background Handlers
	// ========================================================================

	// Helper: prettify a background script short name into display name
	// e.g. "beggar_background" -> "Beggar", "retired_soldier_background" -> "Retired Soldier"
	function bf_prettifyBgName(shortName)
	{
		local name = shortName;

		// Remove _background suffix
		if (name.len() > 11 && name.slice(name.len() - 11) == "_background")
			name = name.slice(0, name.len() - 11);

		// Replace _ with space and capitalize each word
		local result = "";
		local capitalize = true;
		for (local i = 0; i < name.len(); i++)
		{
			local ch = name.slice(i, i + 1);
			if (ch == "_")
			{
				result += " ";
				capitalize = true;
			}
			else if (capitalize)
			{
				result += ch.toupper();
				capitalize = false;
			}
			else
			{
				result += ch;
			}
		}

		return result;
	},

	// Build background catalog from vanilla Const.CharacterBackgrounds
	// Returns array of { ID, Script, Icon, Name }
	function bf_buildBackgroundCatalog()
	{
		local catalog = [];
		local seen = {};

		// 1. Add backgrounds from all roster bros (real instances — safe)
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			foreach (b in brothers)
			{
				try
				{
					local bg = b.getBackground();
					if (bg == null) continue;
					local bgId = bg.getID();
					if (bgId in seen) continue;
					seen[bgId] <- true;

					local bgScript = "";
					try { bgScript = this.IO.scriptFilenameByHash(bg.ClassNameHash); } catch(ex) {}
					local bgIcon = "";
					try { bgIcon = bg.m.Icon; } catch(ex) {}

					catalog.push({
						ID = bgId,
						Script = bgScript,
						Icon = bgIcon,
						Name = bg.m.Name
					});
				}
				catch(ex) {}
			}
		}
		catch(ex) {}

		// 2. Scan Const.CharacterBackgrounds (vanilla single flat array)
		local bf_scriptNames = [];
		local bf_scriptSeen = {};

		try
		{
			if ("CharacterBackgrounds" in ::Const)
			{
				foreach (shortName in ::Const.CharacterBackgrounds)
				{
					if (shortName in bf_scriptSeen) continue;
					bf_scriptSeen[shortName] <- true;
					bf_scriptNames.push(shortName);
				}
			}
		}
		catch(ex) {}

		// 3. Fallback: also scan CharacterCombatBackgrounds etc. if they exist (DLC/mods)
		local bf_extraArrays = [
			"CharacterCombatBackgrounds",
			"CharacterBackgroundsRandom"
		];
		foreach (arrName in bf_extraArrays)
		{
			try
			{
				if (!(arrName in ::Const)) continue;
				foreach (shortName in ::Const[arrName])
				{
					if (shortName in bf_scriptSeen) continue;
					bf_scriptSeen[shortName] <- true;
					bf_scriptNames.push(shortName);
				}
			}
			catch(ex) {}
		}

		// 4. For each script name, instantiate to get real data
		foreach (shortName in bf_scriptNames)
		{
			// Skip entries without _background suffix (not real backgrounds)
			if (shortName.len() <= 11 || shortName.slice(shortName.len() - 11) != "_background")
				continue;

			local bgScript = "scripts/skills/backgrounds/" + shortName;

			// Quick dedup with derived ID
			local idBase = shortName.slice(0, shortName.len() - 11);
			local derivedId = "background." + idBase;
			if (derivedId in seen) continue;

			try
			{
				local bgObj = this.new(bgScript);
				local bgId = derivedId;
				local bgDisplayName = shortName;
				local bgIcon = "";

				try { bgId = bgObj.getID(); } catch(ex) {}
				try { bgDisplayName = bgObj.m.Name; } catch(ex) {}
				try { bgIcon = bgObj.m.Icon; } catch(ex) {}

				// Dedup with real ID (may differ from derived)
				if (bgId in seen) continue;
				seen[bgId] <- true;
				seen[derivedId] <- true;

				catalog.push({
					ID = bgId,
					Script = bgScript,
					Icon = bgIcon,
					Name = bgDisplayName
				});
			}
			catch(ex) {}
		}

		// Sort by name
		catalog.sort(function(a, b) {
			if (a.Name < b.Name) return -1;
			if (a.Name > b.Name) return 1;
			return 0;
		});

		return catalog;
	},

	function queryBackgrounds(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local currentBgId = b.getBackground().getID();
			local currentBgName = "";
			try { currentBgName = b.getBackground().m.Name; } catch(ex) {}

			local catalog = this.bf_buildBackgroundCatalog();

			local found = false;
			foreach (bg in catalog)
			{
				if (bg.ID == currentBgId)
				{
					if (bg.Name == currentBgName)
					{
						bg.IsCurrent <- true;
						found = true;
					}
					else
					{
						bg.IsCurrent <- false;
					}
				}
				else
				{
					bg.IsCurrent <- false;
				}
			}

			// If no exact name match found, add the real current background at the top
			if (!found)
			{
				local curBg = b.getBackground();
				local bgScript = "";
				try { bgScript = this.IO.scriptFilenameByHash(curBg.ClassNameHash); } catch(e) {}
				local bgIcon = "";
				try { bgIcon = curBg.m.Icon; } catch(e) {}

				catalog.insert(0, {
					ID = currentBgId,
					Script = bgScript,
					Icon = bgIcon,
					Name = currentBgName,
					IsCurrent = true
				});
			}

			return { Backgrounds = catalog, CurrentBG = currentBgId };
		}
		catch (e)
		{
			::logError("[BBForge] queryBackgrounds error: " + e);
			return null;
		}
	},

	function onChangeBackground(_data)
	{
		// _data = { BroId, BgScript }
		local bf_rb = { Script = "", Name = "", Desc = "", XP = 0, Level = 1, LevelUps = 0, PP = 0, Title = "", Wage = 0 };
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local oldBg = b.getBackground();
			if (oldBg == null) return null;

			// Backup for rollback
			try { bf_rb.Script = this.IO.scriptFilenameByHash(oldBg.ClassNameHash); } catch(ex) {}
			try { bf_rb.Name = oldBg.m.Name; } catch(ex) {}
			try { bf_rb.Desc = oldBg.getDescription(); } catch(ex) {}
			bf_rb.XP = b.m.XP;
			bf_rb.Level = b.m.Level;
			bf_rb.LevelUps = b.m.LevelUps;
			bf_rb.PP = b.m.PerkPoints;
			bf_rb.Title = b.m.Title;
			try { bf_rb.Wage = b.m.BaseProperties.DailyWage; } catch(ex) {}
			local bf_rbWageCur = 0;
			try { bf_rbWageCur = b.m.CurrentProperties.DailyWage; } catch(ex) {}
			local oldBgId = oldBg.getID();

			// Create and swap
			local bg = this.new(_data.BgScript);
			bg.m.IsNew = false;
			b.getSkills().removeByID(oldBgId);
			b.getSkills().add(bg);

			local newBg = b.getBackground();
			if (newBg == null) throw "new background is null";

			// Preserve bio
			try { newBg.m.Description = bf_rb.Desc; } catch(ex) {}
			try { newBg.m.RawDescription = bf_rb.Desc; } catch(ex) {}

			// Restore state — skills.update() recalculates DailyWage, so save/restore around it
			b.m.XP = bf_rb.XP;
			b.m.Level = bf_rb.Level;
			b.m.LevelUps = bf_rb.LevelUps;
			b.m.PerkPoints = bf_rb.PP;
			b.m.Title = bf_rb.Title;
			b.getSkills().update();
			// Restore DailyWage AFTER skills.update() (update recalculates it)
			b.m.BaseProperties.DailyWage = bf_rb.Wage;
			try { b.m.CurrentProperties.DailyWage = bf_rbWageCur; } catch(ex) {}

			return {
				BackgroundID = newBg.getID(),
				BackgroundName = newBg.m.Name,
				BackgroundImagePath = newBg.getIconColored()
			};
		}
		catch (e)
		{
			::logError("[BBForge] onChangeBackground error: " + e);

			// Rollback — restore the old background
			try
			{
				if (bf_rb.Script != "")
				{
					local b = this.bf_findBroById(_data.BroId);
					if (b != null)
					{
						try { b.getSkills().removeByID(b.getBackground().getID()); } catch(ex) {}
						local restored = this.new(bf_rb.Script);
						restored.m.IsNew = false;
						b.getSkills().add(restored);
						try { b.getBackground().m.Name = bf_rb.Name; } catch(ex) {}
						try { b.getBackground().m.Description = bf_rb.Desc; } catch(ex) {}
						b.m.XP = bf_rb.XP;
						b.m.Level = bf_rb.Level;
						b.m.LevelUps = bf_rb.LevelUps;
						b.m.PerkPoints = bf_rb.PP;
						b.getSkills().update();
						::logInfo("[BBForge] onChangeBackground: rollback OK");
					}
				}
			}
			catch(ex) { ::logError("[BBForge] onChangeBackground rollback failed: " + ex); }

			return null;
		}
	},

	// ========================================================================
	// SECTION — Item Serialization
	// ========================================================================

	function bf_serializeItem(_item, _slotLabel)
	{
		local n = "";
		local ic = "";
		local id = "";
		local cond = 0;
		local condMax = 0;
		local isNamed = false;
		try { n = _item.getName(); } catch (ex) {}
		try { ic = _item.getIcon(); } catch (ex) {}
		try { id = _item.getID(); } catch (ex) {}
		try { cond = _item.getCondition(); } catch (ex) {}
		try { condMax = _item.getConditionMax(); } catch (ex) {}
		try
		{
			if ("isItemType" in _item)
			{
				isNamed = _item.isItemType(::Const.Items.ItemType.Named);
			}
		}
		catch (ex) {}

		local overlays = [];
		try { overlays = _item.getIconOverlay(); } catch (ex) {}

		return {
			Slot = _slotLabel,
			Name = n,
			Icon = ic,
			ID = id,
			Condition = cond,
			ConditionMax = condMax,
			IsNamed = isNamed,
			HasItem = true,
			Overlays = overlays
		};
	},

	// ========================================================================
	// SECTION — Items Query & Editor (equip/unequip/repair)
	// ========================================================================

	function queryItems(_data)
	{
		// _data = { BroId }
		// Returns equipped items with Name/Icon/Condition/IsNamed
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local slots = [];
			local items = b.getItems();

			// 4 vanilla slots: Mainhand, Offhand, Head, Body
			local singleSlotNames = ["Mainhand", "Offhand", "Head", "Body"];
			foreach (slotName in singleSlotNames)
			{
				try
				{
					local item = items.getItemAtSlot(this.Const.ItemSlot[slotName]);
					if (item != null)
						slots.push(this.bf_serializeItem(item, slotName));
					else
						slots.push({ Slot = slotName, HasItem = false });
				}
				catch (ex)
				{
					slots.push({ Slot = slotName, HasItem = false });
				}
			}

			// Bag items (array slot)
			try
			{
				local bagItems = null;
				try
				{
					bagItems = items.getAllItemsAtSlot(this.Const.ItemSlot.Bag);
				}
				catch (ex)
				{
					if ("m" in items && "Bag" in items.m)
					{
						bagItems = items.m.Bag;
					}
				}
				if (bagItems != null)
				{
					for (local i = 0; i < bagItems.len(); i++)
					{
						if (bagItems[i] != null)
						{
							local bEntry = this.bf_serializeItem(bagItems[i], "Bag " + (i + 1));
							bEntry.BagIndex <- i;
							slots.push(bEntry);
						}
					}
				}
			}
			catch (ex)
			{
				::logError("[BBForge] queryItems bag error: " + ex);
			}

			return { Slots = slots };
		}
		catch (e)
		{
			::logError("[BBForge] queryItems error: " + e);
			return null;
		}
	},

	function onEquipItemOnBro(_data)
	{
		// _data = { BroId, Script }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;
			local items = b.getItems();
			local item = this.new(_data.Script);
			try { item.updateVariant(); } catch(e) {}
			local success = false;
			try { success = items.equip(item); } catch(e) {}
			if (!success)
			{
				try { item.removeSelf(); } catch(e) {}
				return { Success = false, Error = "Could not equip item" };
			}
			local result = this.queryItems(_data);
			result.Success <- true;
			return result;
		}
		catch (e)
		{
			::logError("[BBForge] onEquipItemOnBro error: " + e);
			return null;
		}
	},

	function onUnequipSlot(_data)
	{
		// _data = { BroId, SlotName, BagIndex (optional) }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;
			local items = b.getItems();
			local item = null;

			if (_data.SlotName == "Bag")
			{
				local bagItems = null;
				try { bagItems = items.getAllItemsAtSlot(this.Const.ItemSlot.Bag); } catch(e) {}
				if (bagItems == null) try { if ("m" in items && "Bag" in items.m) bagItems = items.m.Bag; } catch(e) {}
				local idx = _data.BagIndex;
				if (bagItems != null && idx < bagItems.len() && bagItems[idx] != null)
					item = bagItems[idx];
			}
			else
			{
				try { item = items.getItemAtSlot(this.Const.ItemSlot[_data.SlotName]); } catch(e) {}
			}

			if (item != null)
			{
				try
				{
					items.unequip(item);
					local stash = ::World.Assets.getStash();
					stash.add(item);
				}
				catch(e)
				{
					::logError("[BBForge] onUnequipSlot unequip error: " + e);
				}
			}

			return this.queryItems(_data);
		}
		catch (e)
		{
			::logError("[BBForge] onUnequipSlot error: " + e);
			return null;
		}
	},

	function onRepairBroItems(_data)
	{
		// _data = { BroId }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;
			local items = b.getItems();
			local allItems = [];
			try { allItems = items.getAllItems(); } catch(e) {}
			foreach (item in allItems)
			{
				if (item == null) continue;
				try
				{
					local c = item.getCondition();
					local cm = item.getConditionMax();
					if (c < cm)
					{
						try { item.setArmor(item.getArmorMax()); }
						catch(e) { try { item.setCondition(cm); } catch(e2) {} }
					}
				}
				catch(e) {}
			}
			return this.queryItems(_data);
		}
		catch (e)
		{
			::logError("[BBForge] onRepairBroItems error: " + e);
			return null;
		}
	},

	function onUnequipAllFromBro(_data)
	{
		// _data = { BroId }
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;
			local items = b.getItems();
			local stash = ::World.Assets.getStash();
			local allItems = [];
			try { allItems = items.getAllItems(); } catch(e) {}

			// Collect refs first, then unequip (avoid modifying while iterating)
			local toRemove = [];
			foreach (item in allItems)
			{
				if (item != null) toRemove.push(item);
			}
			foreach (item in toRemove)
			{
				try
				{
					items.unequip(item);
					stash.add(item);
				}
				catch(e) {}
			}

			return this.queryItems(_data);
		}
		catch (e)
		{
			::logError("[BBForge] onUnequipAllFromBro error: " + e);
			return null;
		}
	},

	// ========================================================================
	// SECTION — Roster Tools (mass operations)
	// ========================================================================

	function onRosterHealAll(_data)
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			local count = 0;
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro") continue;
				try
				{
					local maxHP = b.getHitpointsMax();
					if (b.m.Hitpoints < maxHP)
					{
						b.m.Hitpoints = maxHP;
						count++;
					}
				}
				catch(e) {}
			}
			return { Success = true, Count = count };
		}
		catch (e)
		{
			::logError("[BBForge] onRosterHealAll error: " + e);
			return null;
		}
	},

	function onRosterMaxMoodAll(_data)
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			local count = 0;
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro") continue;
				try
				{
					local cur = b.getMoodState();
					if (cur < 6)
					{
						// BB mood API: no setMoodState(), use worsenMood + improveMood loop
						b.worsenMood(1000.0, "");
						for (local step = 0; step < 500; step++)
						{
							if (b.getMoodState() >= 6) break;
							b.improveMood(1.0, "");
						}
						count++;
					}
				}
				catch(e) {}
			}
			return { Success = true, Count = count };
		}
		catch (e)
		{
			::logError("[BBForge] onRosterMaxMoodAll error: " + e);
			return null;
		}
	},

	function onRosterRepairAllEquipment(_data)
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			local count = 0;
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro") continue;
				try
				{
					local items = b.getItems();
					local allItems = [];
					try { allItems = items.getAllItems(); } catch(e) {}
					foreach (item in allItems)
					{
						if (item == null) continue;
						try
						{
							local c = item.getCondition();
							local cm = item.getConditionMax();
							if (c < cm)
							{
								try { item.setArmor(item.getArmorMax()); }
								catch(e) { try { item.setCondition(cm); } catch(e2) {} }
								count++;
							}
						}
						catch(e) {}
					}
				}
				catch(e) {}
			}
			return { Success = true, Count = count };
		}
		catch (e)
		{
			::logError("[BBForge] onRosterRepairAllEquipment error: " + e);
			return null;
		}
	},

	function onRosterLevelUpAll(_data)
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			local count = 0;
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro") continue;
				try
				{
					local nextXP = b.getXPForNextLevel() - b.m.XP;
					if (nextXP > 0)
					{
						b.m.XP = b.m.XP + nextXP;
						if ("CombatStats" in b.m && "XPGained" in b.m.CombatStats)
							b.m.CombatStats.XPGained = b.m.CombatStats.XPGained + nextXP;
					}
					else
					{
						b.m.XP = b.m.XP + 1000;
					}
					b.updateLevel();
					b.getSkills().update();
					count++;
				}
				catch(e) {}
			}
			local freshData = this.queryRoster();
			freshData.Count <- count;
			return freshData;
		}
		catch (e)
		{
			::logError("[BBForge] onRosterLevelUpAll error: " + e);
			return null;
		}
	},

	function onRosterResetAllPerks(_data)
	{
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			local count = 0;
			foreach (b in brothers)
			{
				if (b.getTitle() == "BFFakeBro") continue;
				try
				{
					// Use native Oblivion Potion (same approach as onResetPerks)
					this.new("scripts/items/misc/potion_of_oblivion_item").onUse(b);
					b.getSkills().update();
					count++;
				}
				catch (ex) {}
			}
			local result = this.queryRoster({});
			result.Count <- count;
			result.Success <- true;
			return result;
		}
		catch (e)
		{
			::logError("[BBForge] onRosterResetAllPerks error: " + e);
			return null;
		}
	},

	// ========================================================================
	// SECTION — Export/Import Helpers
	// ========================================================================

	// Squirrel table/array -> JSON string serializer
	// BB has no native JSON.stringify, so we roll our own
	function bf_tableToJson(bf_obj)
	{
		if (bf_obj == null) return "null";
		local bf_t = typeof bf_obj;
		if (bf_t == "string")
		{
			local bf_s = "\"";
			for (local i = 0; i < bf_obj.len(); i++)
			{
				local bf_c = bf_obj.slice(i, i + 1);
				if (bf_c == "\"") bf_s += "\\\"";
				else if (bf_c == "\\") bf_s += "\\\\";
				else if (bf_c == "\n") bf_s += "\\n";
				else if (bf_c == "\r") bf_s += "\\r";
				else if (bf_c == "\t") bf_s += "\\t";
				else bf_s += bf_c;
			}
			return bf_s + "\"";
		}
		else if (bf_t == "integer") return "" + bf_obj;
		else if (bf_t == "float") return "" + bf_obj;
		else if (bf_t == "bool") return bf_obj ? "true" : "false";
		else if (bf_t == "array")
		{
			local bf_s = "[";
			for (local i = 0; i < bf_obj.len(); i++)
			{
				if (i > 0) bf_s += ",";
				bf_s += this.bf_tableToJson(bf_obj[i]);
			}
			return bf_s + "]";
		}
		else if (bf_t == "table")
		{
			local bf_s = "{";
			local bf_first = true;
			foreach (bf_k, bf_v in bf_obj)
			{
				if (!bf_first) bf_s += ",";
				bf_first = false;
				bf_s += "\"" + bf_k + "\":" + this.bf_tableToJson(bf_v);
			}
			return bf_s + "}";
		}
		return "null";
	},

	// ========================================================================
	// SECTION — Export Bro
	// ========================================================================

	function onExportBro(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return { ExportString = "" };

			local bp = b.getBaseProperties();

			// Block monsters — no background = not human
			try { if (b.getBackground() == null) return { ExportString = "", Message = "Export not supported for monsters" }; } catch(e) {}
			local bf_result = { v = 1, mod = "BBForge", sections = {} };

			// === MAIN STATS ===
			if (_data.IncludeMain)
			{
				local bf_m = {};

				// Identity
				bf_m.Name <- b.m.Name;
				try { bf_m.Title <- b.m.Title; } catch (ex) { bf_m.Title <- ""; }
				try { bf_m.Level <- b.m.Level; } catch (ex) { bf_m.Level <- 1; }
				try { bf_m.LevelUps <- b.m.LevelUps; } catch (ex) { bf_m.LevelUps <- 0; }
				try { bf_m.XP <- b.m.XP; } catch (ex) { bf_m.XP <- 0; }
				try { bf_m.PerkPoints <- b.m.PerkPoints; } catch (ex) { bf_m.PerkPoints <- 0; }
				try { bf_m.PerkPointsSpent <- b.m.PerkPointsSpent; } catch (ex) { bf_m.PerkPointsSpent <- 0; }
				bf_m.ActionPoints <- bp.ActionPoints;
				bf_m.DailyWage <- bp.DailyWage;
				try { bf_m.HitpointsPct <- b.getHitpointsPct(); } catch (ex) { bf_m.HitpointsPct <- 1.0; }

				// 8 base stats
				local bf_sns = ["Hitpoints", "Stamina", "Initiative", "Bravery",
				                "MeleeSkill", "RangedSkill", "MeleeDefense", "RangedDefense"];
				bf_m.Stats <- {};
				foreach (bf_sn in bf_sns)
				{
					try { bf_m.Stats[bf_sn] <- bp[bf_sn]; }
					catch (ex) { bf_m.Stats[bf_sn] <- 0; }
				}

				// Talents (8 values)
				bf_m.Talents <- [];
				try
				{
					for (local i = 0; i < b.m.Talents.len(); i++)
						bf_m.Talents.push(b.m.Talents[i]);
				}
				catch (ex) {}

				// Attributes (level-up stat gains per level)
				bf_m.Attributes <- [];
				try
				{
					for (local i = 0; i < b.m.Attributes.len(); i++)
					{
						local bf_row = [];
						for (local j = 0; j < b.m.Attributes[i].len(); j++)
							bf_row.push(b.m.Attributes[i][j]);
						bf_m.Attributes.push(bf_row);
					}
				}
				catch (ex)
				{
					::logError("[BBForge] Export Attributes error: " + ex);
				}

				// Appearance
				bf_m.Appearance <- {};
				try
				{
					bf_m.Appearance.Body <- ("Body" in b.m) ? b.m.Body : 0;
					bf_m.Appearance.Ethnicity <- ("Ethnicity" in b.m) ? b.m.Ethnicity : 0;

					local bf_sprNames = ["body", "head", "beard", "hair", "beard_top"];
					bf_m.Appearance.Sprites <- {};
					foreach (bf_sp in bf_sprNames)
					{
						try
						{
							local bf_spr = b.getSprite(bf_sp);
							if (bf_spr != null && bf_spr.HasBrush)
								bf_m.Appearance.Sprites[bf_sp] <- bf_spr.getBrush().Name;
							else
								bf_m.Appearance.Sprites[bf_sp] <- "";
						}
						catch (ex) { bf_m.Appearance.Sprites[bf_sp] <- ""; }
					}
				}
				catch (ex) {}

				// Skills (perks, traits, background)
				bf_m.Skills <- [];
				try
				{
					local bf_skillz = b.getSkills();
					foreach (bf_sk in bf_skillz.m.Skills)
					{
						try
						{
							// Filter: isSerialized + exclude non-permanent injuries + exclude drug effects
							if (!bf_sk.isSerialized()) continue;
							if (bf_sk.isType(this.Const.SkillType.Injury) && !bf_sk.isType(this.Const.SkillType.PermanentInjury)) continue;
							if (bf_sk.isType(this.Const.SkillType.DrugEffect)) continue;

							local bf_script = "";
							try { bf_script = this.IO.scriptFilenameByHash(bf_sk.ClassNameHash); }
							catch (ex) {}
							if (bf_script == "") continue;

							local bf_sid = "";
							try { bf_sid = bf_sk.getID(); } catch (ex) {}

							local bf_isNew = false;
							try { bf_isNew = bf_sk.m.IsNew; } catch (ex) {}

							local bf_skEntry = { ID = bf_sid, Script = bf_script, IsNew = bf_isNew };

							// Background
							if (bf_sk.isType(this.Const.SkillType.Background))
							{
								bf_skEntry.IsBackground <- true;
								try { bf_skEntry.BgName <- bf_sk.m.Name; } catch(ex) { bf_skEntry.BgName <- ""; }
								try { bf_skEntry.BgIcon <- bf_sk.getIconColored(); } catch(ex) { bf_skEntry.BgIcon <- ""; }
								try { bf_skEntry.Description <- bf_sk.m.Description; } catch(ex) { bf_skEntry.Description <- ""; }
								try { bf_skEntry.RawDescription <- bf_sk.m.RawDescription; } catch(ex) { bf_skEntry.RawDescription <- ""; }
								try { bf_skEntry.BgLevel <- bf_sk.m.Level; } catch(ex) { bf_skEntry.BgLevel <- 0; }
								try { bf_skEntry.DailyCostMult <- bf_sk.m.DailyCostMult; } catch(ex) { bf_skEntry.DailyCostMult <- 0; }
							}

							// Arena traits
							if (bf_sid == "trait.pit_fighter" || bf_sid == "trait.arena_fighter" || bf_sid == "trait.arena_veteran")
							{
								bf_skEntry.IsArenaTrait <- true;
								try { bf_skEntry.ArenaFights <- b.getFlags().getAsInt("ArenaFights"); } catch(ex) { bf_skEntry.ArenaFights <- 0; }
								try { bf_skEntry.ArenaFightsWon <- b.getFlags().getAsInt("ArenaFightsWon"); } catch(ex) { bf_skEntry.ArenaFightsWon <- 0; }
							}

							// For perks: include Row (tier) from perk tree for import
							if (bf_sid.len() >= 5 && bf_sid.slice(0, 5) == "perk.")
							{
								bf_skEntry.Row <- 1;
								try
								{
									local bf_bgTree = b.getBackground().getPerkTree();
									for (local ri = 0; ri < bf_bgTree.len(); ri++)
									{
										foreach (entry in bf_bgTree[ri])
										{
											if (entry.ID == bf_sid) { bf_skEntry.Row <- ri + 1; break; }
										}
									}
								}
								catch(ex) {}
							}

							bf_m.Skills.push(bf_skEntry);
						}
						catch (ex) {}
					}
				}
				catch (ex)
				{
					::logError("[BBForge] Export skills error: " + ex);
				}

				// Background (ID + Script path for import)
				try
				{
					local bf_bg = b.getBackground();
					bf_m.BackgroundID <- (bf_bg != null) ? bf_bg.getID() : "";
					try { bf_m.BackgroundScript <- this.IO.scriptFilenameByHash(bf_bg.ClassNameHash); }
					catch (ex) { bf_m.BackgroundScript <- ""; }
				}
				catch (ex) { bf_m.BackgroundID <- ""; bf_m.BackgroundScript <- ""; }

				bf_result.sections.main <- bf_m;
			}

			// === LIFETIME STATS ===
			if (_data.IncludeLifetime)
			{
				local bf_lf = {};
				try
				{
					local bf_ls = b.m.LifetimeStats;
					bf_lf.Kills <- ("Kills" in bf_ls) ? bf_ls.Kills : 0;
					bf_lf.Battles <- ("Battles" in bf_ls) ? bf_ls.Battles : 0;
					bf_lf.BattlesWithoutMe <- ("BattlesWithoutMe" in bf_ls) ? bf_ls.BattlesWithoutMe : 0;
					bf_lf.MostPowerfulVanquishedType <- ("MostPowerfulVanquishedType" in bf_ls) ? bf_ls.MostPowerfulVanquishedType : 0;
					bf_lf.MostPowerfulVanquished <- ("MostPowerfulVanquished" in bf_ls) ? bf_ls.MostPowerfulVanquished : "";
					bf_lf.MostPowerfulVanquishedXP <- ("MostPowerfulVanquishedXP" in bf_ls) ? bf_ls.MostPowerfulVanquishedXP : 0;
					bf_lf.FavoriteWeapon <- ("FavoriteWeapon" in bf_ls) ? bf_ls.FavoriteWeapon : "";
					bf_lf.FavoriteWeaponUses <- ("FavoriteWeaponUses" in bf_ls) ? bf_ls.FavoriteWeaponUses : 0;
					bf_lf.CurrentWeaponUses <- ("CurrentWeaponUses" in bf_ls) ? bf_ls.CurrentWeaponUses : 0;
				}
				catch (ex) {}
				bf_result.sections.lifetime <- bf_lf;
			}

			// === EQUIPMENT ===
			if (_data.IncludeEquipment)
			{
				local bf_eq = {};
				local bf_slotDefs = [
					{ N = "Mainhand", S = this.Const.ItemSlot.Mainhand },
					{ N = "Offhand", S = this.Const.ItemSlot.Offhand },
					{ N = "Head", S = this.Const.ItemSlot.Head },
					{ N = "Body", S = this.Const.ItemSlot.Body }
				];

				foreach (bf_sd in bf_slotDefs)
				{
					try
					{
						local bf_item = b.getItems().getItemAtSlot(bf_sd.S);
						if (bf_item != null)
						{
							local bf_id = {};
							try { bf_id.Script <- this.IO.scriptFilenameByHash(bf_item.ClassNameHash); } catch (ex) { bf_id.Script <- ""; }
							try { bf_id.Name <- bf_item.getName(); } catch (ex) { bf_id.Name <- ""; }
							try { bf_id.Variant <- bf_item.m.Variant; } catch (ex) {}
							try { bf_id.Condition <- bf_item.m.Condition; } catch (ex) {}
							try { bf_id.ConditionMax <- bf_item.getConditionMax(); } catch (ex) {}
							try { bf_id.IsToBeRepaired <- bf_item.m.IsToBeRepaired; } catch (ex) {}
							try { bf_id.PriceMult <- bf_item.m.PriceMult; } catch (ex) {}

							local bf_isW = false; try { bf_isW = bf_item.isItemType(this.Const.Items.ItemType.Weapon); } catch(ex){}
							local bf_isS = false; try { bf_isS = bf_item.isItemType(this.Const.Items.ItemType.Shield); } catch(ex){}
							local bf_isN = false; try { bf_isN = bf_item.isItemType(this.Const.Items.ItemType.Named); } catch(ex){}
							local bf_isA = false; try { bf_isA = bf_item.isItemType(this.Const.Items.ItemType.Ammo); } catch(ex){}

							if (bf_isA && !bf_isW) try { bf_id.Ammo <- bf_item.m.Ammo; } catch(ex){}

							if (bf_isW)
							{
								bf_id.IsWeapon <- true;
								try { bf_id.Ammo <- bf_item.m.Ammo; } catch(ex){}
								try { bf_id.AmmoMax <- bf_item.m.AmmoMax; } catch(ex){}
								if (bf_isN)
								{
									bf_id.IsNamedWeapon <- true;
									try { bf_id.StaminaModifier <- bf_item.m.StaminaModifier; } catch(ex){}
									try { bf_id.RegularDamage <- bf_item.m.RegularDamage; } catch(ex){}
									try { bf_id.RegularDamageMax <- bf_item.m.RegularDamageMax; } catch(ex){}
									try { bf_id.ArmorDamageMult <- bf_item.m.ArmorDamageMult; } catch(ex){}
									try { bf_id.ChanceToHitHead <- bf_item.m.ChanceToHitHead; } catch(ex){}
									try { bf_id.ShieldDamage <- bf_item.m.ShieldDamage; } catch(ex){}
									try { bf_id.AdditionalAccuracy <- bf_item.m.AdditionalAccuracy; } catch(ex){}
									try { bf_id.DirectDamageAdd <- bf_item.m.DirectDamageAdd; } catch(ex){}
									try { bf_id.FatigueOnSkillUse <- bf_item.m.FatigueOnSkillUse; } catch(ex){}
								}
							}

							if (bf_isS)
							{
								bf_id.IsShield <- true;
								if (bf_isN)
								{
									bf_id.IsNamedShield <- true;
									try { bf_id.StaminaModifier <- bf_item.m.StaminaModifier; } catch(ex){}
									try { bf_id.MeleeDefense <- bf_item.m.MeleeDefense; } catch(ex){}
									try { bf_id.RangedDefense <- bf_item.m.RangedDefense; } catch(ex){}
									try { bf_id.FatigueOnSkillUse <- bf_item.m.FatigueOnSkillUse; } catch(ex){}
								}
								try {
									if (bf_item.m.ID == "shield.faction_kite_shield" || bf_item.m.ID == "shield.faction_heater_shield")
										bf_id.Faction <- bf_item.m.Faction;
								} catch(ex){}
							}

							// Vanilla armor (no legend_armor/legend_helmet upgrade system)
							// Just export ConditionMax and StaminaModifier for named armor
							if (!bf_isW && !bf_isS && bf_isN)
							{
								try { bf_id.StaminaModifier <- bf_item.m.StaminaModifier; } catch(ex){}
							}

							bf_eq[bf_sd.N] <- bf_id;
						}
						else { bf_eq[bf_sd.N] <- null; }
					}
					catch (ex) { bf_eq[bf_sd.N] <- null; }
				}

				bf_result.sections.equipment <- bf_eq;
			}

			local bf_json = this.bf_tableToJson(bf_result);
			return { ExportString = bf_json };
		}
		catch (e)
		{
			::logError("[BBForge] onExportBro error: " + e);
			return { ExportString = "" };
		}
	},

	// ========================================================================
	// SECTION — Import Bro
	// ========================================================================

	// JSON parser for Squirrel (Coherent GT JSON.parse fails on large strings >16KB)
	function bf_parseJson(_str)
	{
		local pos = 0;
		local len = _str.len();

		local bf_skipWS = function() {
			while (pos < len)
			{
				local c = _str.slice(pos, pos + 1);
				if (c != " " && c != "\t" && c != "\n" && c != "\r") break;
				pos++;
			}
		}.bindenv(this);

		local bf_parseValue = null;
		local bf_parseString = null;
		local bf_parseNumber = null;
		local bf_parseObject = null;
		local bf_parseArray = null;

		bf_parseString = function() {
			if (_str.slice(pos, pos + 1) != "\"") throw "Expected '\"' at pos " + pos;
			pos++;
			local result = "";
			while (pos < len)
			{
				local c = _str.slice(pos, pos + 1);
				if (c == "\"") { pos++; return result; }
				if (c == "\\")
				{
					pos++;
					if (pos >= len) throw "Unexpected end in string";
					local esc = _str.slice(pos, pos + 1);
					if (esc == "\"") result += "\"";
					else if (esc == "\\") result += "\\";
					else if (esc == "n") result += "\n";
					else if (esc == "r") result += "\r";
					else if (esc == "t") result += "\t";
					else if (esc == "/") result += "/";
					else if (esc == "u") { result += "?"; pos += 4; } // skip unicode
					else result += esc;
					pos++;
				}
				else
				{
					result += c;
					pos++;
				}
			}
			throw "Unterminated string";
		}.bindenv(this);

		bf_parseNumber = function() {
			local start = pos;
			if (pos < len && _str.slice(pos, pos + 1) == "-") pos++;
			while (pos < len)
			{
				local c = _str.slice(pos, pos + 1);
				if ((c >= "0" && c <= "9") || c == "." || c == "e" || c == "E" || c == "+" || c == "-")
					pos++;
				else
					break;
			}
			local numStr = _str.slice(start, pos);
			if (numStr.find(".") != null || numStr.find("e") != null || numStr.find("E") != null)
				return numStr.tofloat();
			return numStr.tointeger();
		}.bindenv(this);

		bf_parseArray = function() {
			pos++; // skip [
			local arr = [];
			bf_skipWS();
			if (pos < len && _str.slice(pos, pos + 1) == "]") { pos++; return arr; }
			while (pos < len)
			{
				arr.push(bf_parseValue());
				bf_skipWS();
				if (pos >= len) break;
				local c = _str.slice(pos, pos + 1);
				if (c == "]") { pos++; return arr; }
				if (c == ",") { pos++; bf_skipWS(); }
				else throw "Expected ',' or ']' at pos " + pos;
			}
			throw "Unterminated array";
		}.bindenv(this);

		bf_parseObject = function() {
			pos++; // skip {
			local obj = {};
			bf_skipWS();
			if (pos < len && _str.slice(pos, pos + 1) == "}") { pos++; return obj; }
			while (pos < len)
			{
				bf_skipWS();
				local key = bf_parseString();
				bf_skipWS();
				if (pos >= len || _str.slice(pos, pos + 1) != ":") throw "Expected ':' at pos " + pos;
				pos++; // skip :
				bf_skipWS();
				local val = bf_parseValue();
				obj[key] <- val;
				bf_skipWS();
				if (pos >= len) break;
				local c = _str.slice(pos, pos + 1);
				if (c == "}") { pos++; return obj; }
				if (c == ",") { pos++; bf_skipWS(); }
				else throw "Expected ',' or '}' at pos " + pos;
			}
			throw "Unterminated object";
		}.bindenv(this);

		bf_parseValue = function() {
			bf_skipWS();
			if (pos >= len) throw "Unexpected end";
			local c = _str.slice(pos, pos + 1);
			if (c == "\"") return bf_parseString();
			if (c == "{") return bf_parseObject();
			if (c == "[") return bf_parseArray();
			if (c == "t" && _str.slice(pos, pos + 4) == "true") { pos += 4; return true; }
			if (c == "f" && _str.slice(pos, pos + 5) == "false") { pos += 5; return false; }
			if (c == "n" && _str.slice(pos, pos + 4) == "null") { pos += 4; return null; }
			if (c == "-" || (c >= "0" && c <= "9")) return bf_parseNumber();
			throw "Unexpected char '" + c + "' at pos " + pos;
		}.bindenv(this);

		local result = bf_parseValue();
		return result;
	},

	function onImportBroRaw(_data)
	{
		try
		{
			local raw = _data.RawJson;
			if (raw == null || raw == "") return { Success = false, Message = "No data" };

			local parsed = this.bf_parseJson(raw);
			if (parsed == null) return { Success = false, Message = "Parse returned null" };

			// Rebuild _data with parsed ImportData and forward to onImportBro
			_data.ImportData <- parsed;
			return this.onImportBro(_data);
		}
		catch (e)
		{
			::logError("[BBForge] onImportBroRaw error: " + e);
			return { Success = false, Message = "Parse error: " + e };
		}
	},

	function onImportBro(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return { Success = false, Message = "Brother not found" };

			local bf_imp = _data.ImportData;
			if (bf_imp == null) return { Success = false, Message = "No data" };
			if (!("v" in bf_imp) || bf_imp.v != 1) return { Success = false, Message = "Incompatible version" };
			if (!("sections" in bf_imp)) return { Success = false, Message = "No sections" };
			local bf_sec = bf_imp.sections;

			// Check at least one matching section exists
			local bf_hasAny = false;
			if (_data.IncludeMain && "main" in bf_sec && bf_sec.main != null) bf_hasAny = true;
			if (_data.IncludeEquipment && "equipment" in bf_sec && bf_sec.equipment != null) bf_hasAny = true;
			if (_data.IncludeLifetime && "lifetime" in bf_sec) bf_hasAny = true;
			if (!bf_hasAny) return { Success = false, Message = "No matching sections in data" };

			// Block monsters — no background = not human
			try { if (b.getBackground() == null) return { Success = false, Message = "Import not supported for monsters" }; } catch(e) {}

			// Granular import flags (backwards-compatible defaults: all true)
			local bf_incStats = !("IncludeStats" in _data) || _data.IncludeStats;
			local bf_incPerks = !("IncludePerks" in _data) || _data.IncludePerks;
			local bf_incTraits = !("IncludeTraits" in _data) || _data.IncludeTraits;
			local bf_incBg = !("IncludeBackground" in _data) || _data.IncludeBackground;
			local bf_incAppearance = !("IncludeAppearance" in _data) || _data.IncludeAppearance;
			local bf_mergePerks = ("MergePerks" in _data) && _data.MergePerks;

			// === MAIN SECTION (stats, skills, appearance) ===
			if (_data.IncludeMain && "main" in bf_sec && bf_sec.main != null)
			{
				local bf_m = bf_sec.main;

				// 1. IsUpdating = true (prevent onAdded/onRemoved side effects during bulk changes)
				local bf_skillz = b.getSkills();
				bf_skillz.m.IsUpdating = true;

				// 2. Remove skills selectively based on import flags
				// NEVER removeSelf() inside foreach — corrupts the array
				local bf_toRemove = [];
				foreach (bf_sk in bf_skillz.m.Skills)
				{
					try
					{
						local bf_sid = bf_sk.getID();
						local bf_isBg = bf_sk.isType(this.Const.SkillType.Background);
						local bf_isPerk = bf_sid.len() >= 5 && bf_sid.slice(0, 5) == "perk.";
						local bf_isTrait = bf_sk.isType(this.Const.SkillType.Trait);
						local bf_isInjury = bf_sk.isType(this.Const.SkillType.PermanentInjury) || bf_sk.isType(this.Const.SkillType.TemporaryInjury);

						// Skip categories not being imported
						if (bf_isBg && !bf_incBg) continue;
						if (bf_isPerk && !bf_incPerks) continue;
						if (bf_isPerk && bf_mergePerks) continue; // merge = don't remove existing
						if ((bf_isTrait || bf_isInjury) && !bf_incTraits) continue;

						// Only remove bg/trait/perk/injury, not specials/actives/items
						if (bf_isBg || bf_isTrait || bf_isPerk || bf_isInjury)
						{
							if (!bf_sk.isType(this.Const.SkillType.Special) && !bf_sk.isType(this.Const.SkillType.Active) && !bf_sk.isType(this.Const.SkillType.Item))
							{
								bf_toRemove.push(bf_sk);
							}
						}
					}
					catch(e){}
				}

					foreach (bf_sk in bf_toRemove) { try { bf_sk.removeSelf(); } catch(e){} }

				// Reset arena flags (only when importing traits)
				if (bf_incTraits)
				{
					try { b.getFlags().set("ArenaFights", 0); } catch(e){}
					try { b.getFlags().set("ArenaFightsWon", 0); } catch(e){}
				}

				// 3. Add imported skills — backgrounds FIRST (other skills may depend on bg)
				if ("Skills" in bf_m && bf_m.Skills != null)
				{
					local bf_addCount = 0;

					// Pass 1: backgrounds only (skip if not importing background)
					if (bf_incBg)
					{
						foreach (bf_skData in bf_m.Skills)
						{
							try
							{
								if (bf_skData == null) continue;
								if (!("Script" in bf_skData) || bf_skData.Script == "") continue;
								if (!("IsBackground" in bf_skData) || !bf_skData.IsBackground) continue;
								local bf_newSk = this.new(bf_skData.Script);
								if (!bf_newSk.isType(this.Const.SkillType.Background)) continue;

								// Background metadata
								if ("BgName" in bf_skData && bf_skData.BgName != "") try { bf_newSk.m.Name = bf_skData.BgName; } catch(e){}
								if ("BgIcon" in bf_skData && bf_skData.BgIcon != "") try { bf_newSk.m.Icon = bf_skData.BgIcon; } catch(e){}
								if ("IsNew" in bf_skData) try { bf_newSk.m.IsNew = bf_skData.IsNew; } catch(e){}
								if ("Description" in bf_skData) try { bf_newSk.m.Description = bf_skData.Description; } catch(e){}
								if ("RawDescription" in bf_skData) try { bf_newSk.m.RawDescription = bf_skData.RawDescription; } catch(e){}
								if ("BgLevel" in bf_skData) try { bf_newSk.m.Level = bf_skData.BgLevel; } catch(e){}
								if ("DailyCostMult" in bf_skData) try { bf_newSk.m.DailyCostMult = bf_skData.DailyCostMult; } catch(e){}

								bf_skillz.add(bf_newSk);
								bf_addCount++;
							}
							catch(e)
							{
								::logWarning("[BBForge] Skip background skill: " + e);
							}
						}
					}

					// Build set of exported skill IDs for later cleanup
					local bf_keepIDs = {};
					try { bf_keepIDs[""] <- true; } catch(e) {}
					foreach (bf_exp in bf_m.Skills)
					{
						try { if ("ID" in bf_exp && bf_exp.ID != "") bf_keepIDs[bf_exp.ID] <- true; } catch(e) {}
					}

					// Pass 2: non-background skills (perks, traits) — filtered by import flags
					foreach (bf_skData in bf_m.Skills)
					{
						try
						{
							if (bf_skData == null) continue;
							if (!("Script" in bf_skData) || bf_skData.Script == "") continue;
							if ("IsBackground" in bf_skData && bf_skData.IsBackground) continue;

							local bf_newSk = this.new(bf_skData.Script);
							if (bf_newSk.isType(this.Const.SkillType.Background)) continue;

							// Granular filter: skip categories not being imported
							local bf_newID = "";
							try { bf_newID = bf_newSk.getID(); } catch(e) {}
							if (bf_newID == "" && "ID" in bf_skData) bf_newID = bf_skData.ID;
							local bf_isPerk = bf_newID.len() >= 5 && bf_newID.slice(0, 5) == "perk.";
							local bf_isTrait = bf_newSk.isType(this.Const.SkillType.Trait);
							local bf_isInjury = bf_newSk.isType(this.Const.SkillType.PermanentInjury) || bf_newSk.isType(this.Const.SkillType.TemporaryInjury);
							if (bf_isPerk && !bf_incPerks) continue;
							if ((bf_isTrait || bf_isInjury) && !bf_incTraits) continue;

							// Skip if bro already has this skill (prevents duplicates)
							if (bf_newID != "" && bf_skillz.hasSkill(bf_newID)) continue;
							if ("IsNew" in bf_skData) try { bf_newSk.m.IsNew = bf_skData.IsNew; } catch(e){}
							if (bf_newSk.m.ID == "perk.gifted") try { bf_newSk.m.IsApplied = true; } catch(e){}

							// Arena traits
							if (bf_newSk.m.ID == "trait.pit_fighter" || bf_newSk.m.ID == "trait.arena_fighter" || bf_newSk.m.ID == "trait.arena_veteran")
							{
								if ("ArenaFights" in bf_skData) try { b.getFlags().set("ArenaFights", bf_skData.ArenaFights); } catch(e){}
								if ("ArenaFightsWon" in bf_skData) try { b.getFlags().set("ArenaFightsWon", bf_skData.ArenaFightsWon); } catch(e){}
							}

							// Add the skill via skills.add() — this is the vanilla-safe approach
							// No perk tree sync needed (no addPerk, no PerkTreeMap, no CustomPerkTree)
							bf_skillz.add(bf_newSk);

							// If add() silently rejected the skill, force-push it
							if (!bf_skillz.hasSkill(bf_newID))
							{
								bf_newSk.m.Container = bf_skillz;
								bf_skillz.m.Skills.push(bf_newSk);
							}

							bf_addCount++;
						}
						catch(e)
						{
							::logWarning("[BBForge] Skip skill: " + (bf_skData != null && "ID" in bf_skData ? bf_skData.ID : "?") + " - " + e);
						}
					}
				}

				// 4-9. Stats, Level, Talents, Attributes, Name/Title
				if (bf_incStats)
				{
					// 4. Set BaseProperties for 8 stats + ActionPoints + DailyWage
					if ("Stats" in bf_m && bf_m.Stats != null)
					{
						foreach (bf_sn, bf_val in bf_m.Stats)
						{
							try { b.m.BaseProperties[bf_sn] = bf_val; } catch(e){}
						}
					}
					if ("ActionPoints" in bf_m) try { b.m.BaseProperties.ActionPoints = bf_m.ActionPoints; } catch(e) {}
					if ("DailyWage" in bf_m) try { b.m.BaseProperties.DailyWage = bf_m.DailyWage; } catch(e) {}

					// 5. Set Level, PerkPoints, PerkPointsSpent, LevelUps
					if ("Level" in bf_m) try { b.m.Level = bf_m.Level; } catch(e) {}
					if ("PerkPoints" in bf_m) try { b.m.PerkPoints = bf_m.PerkPoints; } catch(e){}
					if ("PerkPointsSpent" in bf_m) try { b.m.PerkPointsSpent = bf_m.PerkPointsSpent; } catch(e){}
					if ("LevelUps" in bf_m) try { b.m.LevelUps = bf_m.LevelUps; } catch(e){}

					// 6. Set Talents[i] for 8 talents
					if ("Talents" in bf_m && bf_m.Talents != null)
					{
						try
						{
							b.m.Talents.resize(this.Const.Attributes.COUNT, 0);
							for (local i = 0; i < this.Const.Attributes.COUNT && i < bf_m.Talents.len(); i++)
							{
								local bf_tv = bf_m.Talents[i];
								if (typeof bf_tv == "float") bf_tv = bf_tv.tointeger();
								b.m.Talents[i] = bf_tv;
							}
						}
						catch(e) { ::logWarning("[BBForge] Skip Talents: " + e); }
					}

					// 7. Set Attributes if present
					if ("Attributes" in bf_m && bf_m.Attributes != null)
					{
						try
						{
							b.m.Attributes.resize(this.Const.Attributes.COUNT);
							for (local i = 0; i < this.Const.Attributes.COUNT && i < bf_m.Attributes.len(); i++)
							{
								b.m.Attributes[i] = [];
								if (bf_m.Attributes[i] != null)
								{
									for (local j = 0; j < bf_m.Attributes[i].len(); j++)
										b.m.Attributes[i].push(bf_m.Attributes[i][j]);
								}
							}
						}
						catch(e){ ::logError("[BBForge] Attributes: " + e); }
					}

					// 8. Set Name, Title
					if ("Name" in bf_m) try { b.m.Name = bf_m.Name; } catch(e) {}
					if ("Title" in bf_m) try { b.m.Title = bf_m.Title; } catch(e) {}
				} // end bf_incStats

				// 9. Appearance (body, ethnicity, sprites)
				if (bf_incAppearance && "Appearance" in bf_m && bf_m.Appearance != null)
				{
					local bf_app = bf_m.Appearance;

					try { if ("Body" in bf_app) { b.m.Body = bf_app.Body; } } catch(e){}
					try { if ("Ethnicity" in bf_app) b.m.Ethnicity = bf_app.Ethnicity; } catch(e){}

					// Sprites
					if ("Sprites" in bf_app && bf_app.Sprites != null)
					{
						local bf_sprNames = ["body", "head", "beard", "hair", "beard_top"];
						foreach (bf_sp in bf_sprNames)
						{
							try
							{
								if (bf_sp in bf_app.Sprites && bf_app.Sprites[bf_sp] != "")
								{
									b.getSprite(bf_sp).setBrush(bf_app.Sprites[bf_sp]);
								}
								else
								{
									b.getSprite(bf_sp).resetBrush();
								}
							}
							catch(e){}
						}
					}
				}

				// 10. IsUpdating = false — triggers onAdded() for all new skills
				try { bf_skillz.m.IsUpdating = false; } catch(e) { ::logWarning("[BBForge] Skip IsUpdating: " + e); }

				// 10b. Remove bg-generated skills that aren't in the export data
				// Only when importing background (otherwise we didn't change bg, so don't clean up)
				if (bf_incBg && "Skills" in bf_m && bf_m.Skills != null)
				{
					local bf_keepIDs = {};
					try { bf_keepIDs[""] <- true; } catch(e) {}
					foreach (bf_exp in bf_m.Skills)
					{
						try { if ("ID" in bf_exp && bf_exp.ID != "") bf_keepIDs[bf_exp.ID] <- true; } catch(e) {}
					}

					local bf_bgGenRemove = [];
					foreach (bf_sk in bf_skillz.m.Skills)
					{
						try
						{
							if (bf_sk.isType(this.Const.SkillType.Background)) continue;
							if (bf_sk.isType(this.Const.SkillType.Special)) continue;
							if (bf_sk.isType(this.Const.SkillType.Item)) continue;
							if (bf_sk.isType(this.Const.SkillType.Active)) continue;
							// Merge perks: don't remove existing perks that weren't in export
							local bf_skid = bf_sk.getID();
							if (bf_mergePerks && bf_skid.len() >= 5 && bf_skid.slice(0, 5) == "perk.") continue;

							if (!(bf_skid in bf_keepIDs))
							{
								bf_bgGenRemove.push(bf_sk);
							}
						}
						catch(e) {}
					}
					foreach (bf_sk in bf_bgGenRemove) { try { bf_sk.removeSelf(); } catch(e){} }
				}

				// 11. skills.update()
				try { bf_skillz.update(); } catch(e) { ::logWarning("[BBForge] Skip skills.update: " + e); }

				// 11a. Remove duplicate skills by rebuilding m.Skills array
				// skills.update() and bg.onAdded()/onUpdate() can re-add default traits
				try
				{
					local bf_seenIDs = {};
					local bf_clean = [];
					foreach (bf_sk in bf_skillz.m.Skills)
					{
						local bf_skid = "";
						try { bf_skid = bf_sk.getID(); } catch(e) {}
						if (bf_skid == "" || !(bf_skid in bf_seenIDs))
						{
							if (bf_skid != "") bf_seenIDs[bf_skid] <- true;
							bf_clean.push(bf_sk);
						}
					}
					bf_skillz.m.Skills = bf_clean;
				}
				catch(e) {}

				// 11b. Re-set Name, Title, BgName AFTER skills.update
				// (update() triggers background onAdded/onUpdate which overwrites these)
				if (bf_incStats)
				{
					if ("Name" in bf_m) try { b.m.Name = bf_m.Name; } catch(e) {}
					if ("Title" in bf_m) try { b.m.Title = bf_m.Title; } catch(e) {}
				}
				if (bf_incBg)
				{
					try
					{
						local bf_bg = b.getBackground();
						if (bf_bg != null)
						{
							foreach (bf_sk in bf_m.Skills)
							{
								if ("IsBackground" in bf_sk && bf_sk.IsBackground)
								{
									if ("BgName" in bf_sk && bf_sk.BgName != "") try { bf_bg.m.Name = bf_sk.BgName; } catch(e) {}
									if ("BgIcon" in bf_sk && bf_sk.BgIcon != "") try { bf_bg.m.Icon = bf_sk.BgIcon; } catch(e) {}
									break;
								}
							}
						}
					}
					catch(e) {}
				}

				// 12. Set XP + DailyWage AFTER skills.update (update recalculates them)
				if (bf_incStats && "XP" in bf_m) try { b.m.XP = bf_m.XP; } catch(e) {}
				if (bf_incStats && "DailyWage" in bf_m) try { b.m.BaseProperties.DailyWage = bf_m.DailyWage; b.m.CurrentProperties.DailyWage = bf_m.DailyWage; } catch(e) {}

			} // end Main section

			// 13. Equipment
			local bf_equipErrors = 0;
			if (_data.IncludeEquipment && "equipment" in bf_sec)
			{
				local bf_eq = bf_sec.equipment;
				if (bf_eq != null)
				{
					local bf_itemz = b.m.Items;

					// Save all skills before equipment manipulation — clear()/equip()
					// can trigger onUnequip/onEquip internally which calls skills.update()
					// and can silently destroy perks/traits
					local bf_preEqSkills = [];
					local bf_eqAllSk = b.getSkills().m.Skills;
					for (local bf_i = 0; bf_i < bf_eqAllSk.len(); bf_i++)
					{
						bf_preEqSkills.push(bf_eqAllSk[bf_i]);
					}

					try
					{
						bf_itemz.clear();
						bf_itemz.m.UnlockedBagSlots = b.getSkills().hasSkill("perk.bags_and_belts") ? 4 : 2;
					}
					catch(e)
					{
						::logWarning("[BBForge] Equipment clear failed: " + e);
						bf_equipErrors++;
					}

					local bf_slotOrder = ["Mainhand", "Offhand", "Head", "Body"];
					foreach (bf_slotName in bf_slotOrder)
					{
						try
						{
							if (!(bf_slotName in bf_eq) || bf_eq[bf_slotName] == null) continue;
							local bf_idata = bf_eq[bf_slotName];
							if (!("Script" in bf_idata) || bf_idata.Script == "") continue;

							local curitem = this.new(bf_idata.Script);
							if (curitem == null) { ::logWarning("[BBForge] " + bf_slotName + ": this.new null"); bf_equipErrors++; continue; }

							// --- Base fields ---
							if ("IsToBeRepaired" in bf_idata) try { curitem.m.IsToBeRepaired = bf_idata.IsToBeRepaired; } catch(e){}
							if ("Variant" in bf_idata) try { curitem.m.Variant = bf_idata.Variant; } catch(e){}
							if ("Condition" in bf_idata) try { curitem.m.Condition = bf_idata.Condition; } catch(e){}
							if ("PriceMult" in bf_idata) try { curitem.m.PriceMult = bf_idata.PriceMult; } catch(e){}
							if ("Name" in bf_idata) try { curitem.m.Name = bf_idata.Name; } catch(e){}

							// --- Ammo (non-weapon) ---
							try {
								if (curitem.isItemType(this.Const.Items.ItemType.Ammo) && !curitem.isItemType(this.Const.Items.ItemType.Weapon))
									if ("Ammo" in bf_idata) curitem.m.Ammo = bf_idata.Ammo;
							} catch(e){}

							// --- Weapon ---
							try {
								if (curitem.isItemType(this.Const.Items.ItemType.Weapon))
								{
									if ("Ammo" in bf_idata) curitem.m.Ammo = bf_idata.Ammo;
									local bf_isNW = false;
									try { bf_isNW = curitem.isItemType(this.Const.Items.ItemType.Named); } catch(e){}
									if (bf_isNW)
									{
										if ("ConditionMax" in bf_idata) curitem.m.ConditionMax = bf_idata.ConditionMax;
										if ("StaminaModifier" in bf_idata) curitem.m.StaminaModifier = bf_idata.StaminaModifier;
										if ("RegularDamage" in bf_idata) curitem.m.RegularDamage = bf_idata.RegularDamage;
										if ("RegularDamageMax" in bf_idata) curitem.m.RegularDamageMax = bf_idata.RegularDamageMax;
										if ("ArmorDamageMult" in bf_idata) curitem.m.ArmorDamageMult = bf_idata.ArmorDamageMult;
										if ("ChanceToHitHead" in bf_idata) curitem.m.ChanceToHitHead = bf_idata.ChanceToHitHead;
										if ("ShieldDamage" in bf_idata) curitem.m.ShieldDamage = bf_idata.ShieldDamage;
										if ("AdditionalAccuracy" in bf_idata) curitem.m.AdditionalAccuracy = bf_idata.AdditionalAccuracy;
										if ("DirectDamageAdd" in bf_idata) curitem.m.DirectDamageAdd = bf_idata.DirectDamageAdd;
										if ("FatigueOnSkillUse" in bf_idata) curitem.m.FatigueOnSkillUse = bf_idata.FatigueOnSkillUse;
										if ("AmmoMax" in bf_idata) curitem.m.AmmoMax = bf_idata.AmmoMax;
									}
									curitem.m.Condition = this.Math.minf(curitem.m.ConditionMax, curitem.m.Condition);
									if (curitem.m.Ammo != 0 && curitem.m.AmmoMax == 0) curitem.m.AmmoMax = curitem.m.Ammo;
								}
							} catch(e){}

							// --- Shield ---
							try {
								if (curitem.isItemType(this.Const.Items.ItemType.Shield))
								{
									local bf_isNS = false;
									try { bf_isNS = curitem.isItemType(this.Const.Items.ItemType.Named); } catch(e){}
									if (bf_isNS)
									{
										if ("ConditionMax" in bf_idata) curitem.m.ConditionMax = bf_idata.ConditionMax;
										if ("StaminaModifier" in bf_idata) curitem.m.StaminaModifier = bf_idata.StaminaModifier;
										if ("MeleeDefense" in bf_idata) curitem.m.MeleeDefense = bf_idata.MeleeDefense;
										if ("RangedDefense" in bf_idata) curitem.m.RangedDefense = bf_idata.RangedDefense;
										if ("FatigueOnSkillUse" in bf_idata) curitem.m.FatigueOnSkillUse = bf_idata.FatigueOnSkillUse;
									}
									if ("Faction" in bf_idata) curitem.m.Faction = bf_idata.Faction;
									curitem.m.Condition = this.Math.minf(curitem.m.ConditionMax, curitem.m.Condition);
								}
							} catch(e){}

							// --- Vanilla armor (named only — no upgrade system) ---
							try {
								if (!curitem.isItemType(this.Const.Items.ItemType.Weapon) && !curitem.isItemType(this.Const.Items.ItemType.Shield))
								{
									local bf_isNA = false;
									try { bf_isNA = curitem.isItemType(this.Const.Items.ItemType.Named); } catch(e){}
									if (bf_isNA)
									{
										if ("ConditionMax" in bf_idata) curitem.m.ConditionMax = bf_idata.ConditionMax;
										if ("StaminaModifier" in bf_idata) curitem.m.StaminaModifier = bf_idata.StaminaModifier;
									}
									curitem.m.Condition = this.Math.minf(curitem.m.ConditionMax, curitem.m.Condition);
								}
							} catch(e){}

							// --- updateVariant + equip ---
							curitem.updateVariant();
							local bf_win = bf_itemz.equip(curitem);
							if (!bf_win) { ::logWarning("[BBForge] Equip FAILED " + bf_slotName + " — destroying orphan"); try { curitem.removeSelf(); } catch(bf_re) {} bf_equipErrors++; }
						}
						catch (bf_ex)
						{
							::logWarning("[BBForge] Equipment skip " + bf_slotName + ": " + bf_ex);
							bf_equipErrors++;
						}
					}

					// Restore perks/traits lost during equipment clear/equip
					// (onUnequip/onEquip can trigger skills.update() which destroys perks)
					foreach (bf_sk in bf_preEqSkills)
					{
						try
						{
							if (bf_sk.isType(this.Const.SkillType.Item)) continue;
							if (bf_sk.isType(this.Const.SkillType.Active) && !bf_sk.isType(this.Const.SkillType.Perk)) continue;
							if (bf_sk.isType(this.Const.SkillType.Special)) continue;
							if (!b.getSkills().hasSkill(bf_sk.getID()))
							{
								bf_sk.m.Container = b.getSkills();
								b.getSkills().m.Skills.push(bf_sk);
							}
						}
						catch(e) {}
					}
				}
			}

			// Post-equipment recalc
			try { this.World.State.getPlayer().calculateModifiers(); } catch(e) {}

			return {
				Success = true,
				BroId = _data.BroId,
				Message = "Import OK" + (bf_equipErrors > 0 ? " (" + bf_equipErrors + " items skipped)" : "")
			};
		}
		catch (e)
		{
			::logError("[BBForge] onImportBro CRASH: " + e);
			return { Success = false, Message = "Error: " + e };
		}
	},


	// ========================================================================
	// SECTION — Biography
	// ========================================================================

	function queryBio(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;
			local bg = b.getBackground();
			local bio = "";
			if (bg != null)
			{
				try { bio = bg.getDescription(); } catch(e) {}
			}
			return { Bio = bio };
		}
		catch (e)
		{
			::logError("[BBForge] queryBio error: " + e);
			return null;
		}
	},

	function onSaveBio(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return { Success = false };
			local bg = b.getBackground();
			if (bg == null) return { Success = false };
			bg.m.Description = _data.Bio;
			bg.m.RawDescription = _data.Bio;
			return { Success = true };
		}
		catch (e)
		{
			::logError("[BBForge] onSaveBio error: " + e);
			return { Success = false };
		}
	},

	// ========================================================================
	// SECTION — Appearance helpers
	// ========================================================================

	// Extract hair color name from a brush name (e.g. "hair_brown_01" -> "brown")
	function bf_extractColor(_brushName)
	{
		if (_brushName.find("_black_") != null) return "black";
		if (_brushName.find("_grey_") != null) return "grey";
		if (_brushName.find("_blonde_") != null) return "blonde";
		if (_brushName.find("_red_") != null) return "red";
		if (_brushName.find("_brown_") != null) return "brown";
		return "brown";
	},

	// Get the brush name of a sprite layer (returns "" if empty/missing)
	function bf_getBrushName(_bro, _layer)
	{
		try
		{
			local sp = _bro.getSprite(_layer);
			if (sp != null)
			{
				local br = sp.getBrush();
				if (br != null && br.Name != "" && br.Name != "empty_brush")
					return br.Name;
			}
		}
		catch(e) {}
		return "";
	},

	// changeIndex — for body/head (full brush names in array)
	function bf_changeIndex(_bro, _layer, _list, _change)
	{
		if (_list.len() == 0) return;
		local current = this.bf_getBrushName(_bro, _layer);
		local idx = 0;
		for (local i = 0; i < _list.len(); i++)
		{
			if (_list[i] == current) { idx = i; break; }
		}
		idx = (idx + _change + _list.len()) % _list.len();
		try { _bro.getSprite(_layer).setBrush(_list[idx]); } catch(e) {}
	},

	// changeIndexEx — for hair/beard/tattoo (suffixes, builds composite brush)
	// brush = prefix + midfix + "_" + suffix   (or just suffix if prefix=="")
	// "" in the list = resetBrush (None)
	function bf_changeIndexEx(_bro, _layer, _list, _change, _prefix, _midfix, _suffix)
	{
		if (_list.len() == 0) return;

		// Find current index by matching the suffix portion
		local current = this.bf_getBrushName(_bro, _layer);
		local idx = 0;
		for (local i = 0; i < _list.len(); i++)
		{
			if (_list[i] == "" && current == "") { idx = i; break; }
			if (_list[i] != "")
			{
				local built = "";
				if (_prefix != "")
					built = _prefix + _midfix + "_" + _list[i];
				else if (_suffix != "")
					built = _list[i] + "_" + _suffix;
				else
					built = _list[i];
				if (built == current) { idx = i; break; }
			}
		}

		idx = (idx + _change + _list.len()) % _list.len();
		local entry = _list[idx];
		if (entry == "")
		{
			try { _bro.getSprite(_layer).resetBrush(); } catch(e) {}
		}
		else
		{
			local newBrush = "";
			if (_prefix != "")
				newBrush = _prefix + _midfix + "_" + entry;
			else if (_suffix != "")
				newBrush = entry + "_" + _suffix;
			else
				newBrush = entry;
			try { _bro.getSprite(_layer).setBrush(newBrush); } catch(e) {}
		}
	},

	function bf_findIndexInList(_list, _value)
	{
		for (local i = 0; i < _list.len(); i++)
		{
			if (_list[i] == _value) return i;
		}
		return 0;
	},

	function bf_findSuffixIndex(_list, _brushName, _prefix, _midfix, _suffix)
	{
		for (local i = 0; i < _list.len(); i++)
		{
			if (_list[i] == "" && _brushName == "") return i;
			if (_list[i] != "")
			{
				local built = "";
				if (_prefix != "")
					built = _prefix + _midfix + "_" + _list[i];
				else if (_suffix != "")
					built = _list[i] + "_" + _suffix;
				else
					built = _list[i];
				if (built == _brushName) return i;
			}
		}
		return 0;
	},

	// Compute appearance state for the preview entity — human male only (vanilla)
	// Detects ethnicity from body brush (southern_ prefix = Southern, else Northern)
	// Returns state with current indices for each appearance layer
	function bf_computeState(_pe, _bro, _bg)
	{
		local result = {
			HairIndex = 0, HairTotal = 0,
			BeardIndex = 0, BeardTotal = 0,
			HeadIndex = 0, HeadTotal = 0,
			BodyIndex = 0, BodyTotal = 0,
			TattooIndex = 0, TattooTotal = 0,
			ColorName = "brown", ColorIndex = 0, ColorTotal = 0,
			Ethnicity = "northern",
			ImagePath = "",
			CanBarber = true
		};

		try { result.ImagePath = _pe.getImagePath(); } catch(e) {}

		// Detect ethnicity from body brush
		local bodyBrush = this.bf_getBrushName(_pe, "body");
		local ethnicity = "northern";
		if (bodyBrush.find("southern") != null)
			ethnicity = "southern";
		result.Ethnicity = ethnicity;

		// Build arrays based on ethnicity
		// Hair: Const.Hair.Barber (23 styles including "" for bald)
		local hairArr = [];
		try
		{
			local raw = ::Const.Hair.Barber;
			for (local i = 0; i < raw.len(); i++)
				hairArr.push(raw[i]);
		}
		catch(e) {}
		if (hairArr.len() == 0) hairArr.push("");

		// Beard: Const.Beards.Barber (18 styles including "" for none)
		local beardArr = [];
		try
		{
			local raw = ::Const.Beards.Barber;
			for (local i = 0; i < raw.len(); i++)
				beardArr.push(raw[i]);
		}
		catch(e) {}
		if (beardArr.len() == 0) beardArr.push("");

		// Head: ethnicity-dependent
		local headArr = [];
		if (ethnicity == "southern")
		{
			try
			{
				local raw = ::Const.Faces.SouthernMale;
				for (local i = 0; i < raw.len(); i++)
					headArr.push(raw[i]);
			}
			catch(e) {}
		}
		if (headArr.len() == 0)
		{
			try
			{
				local raw = ::Const.Faces.AllMale;
				for (local i = 0; i < raw.len(); i++)
					headArr.push(raw[i]);
			}
			catch(e) {}
		}

		// Body: ethnicity-dependent
		local bodyArr = [];
		if (ethnicity == "southern")
		{
			try
			{
				local raw = ::Const.Bodies.SouthernMale;
				for (local i = 0; i < raw.len(); i++)
					bodyArr.push(raw[i]);
			}
			catch(e) {}
		}
		if (bodyArr.len() == 0)
		{
			try
			{
				local raw = ::Const.Bodies.AllMale;
				for (local i = 0; i < raw.len(); i++)
					bodyArr.push(raw[i]);
			}
			catch(e) {}
		}

		// Color: Const.HairColors.All (5 colors)
		local colorArr = [];
		try
		{
			local raw = ::Const.HairColors.All;
			for (local i = 0; i < raw.len(); i++)
				colorArr.push(raw[i]);
		}
		catch(e) {}
		if (colorArr.len() == 0) colorArr.push("brown");

		// Tattoo: Const.Tattoos.All (5 entries including "" for none)
		local tattooArr = [];
		try
		{
			local raw = ::Const.Tattoos.All;
			for (local i = 0; i < raw.len(); i++)
				tattooArr.push(raw[i]);
		}
		catch(e) {}
		if (tattooArr.len() == 0) tattooArr.push("");

		// Current brush names
		local hairBrush = this.bf_getBrushName(_pe, "hair");
		local beardBrush = this.bf_getBrushName(_pe, "beard");
		local headBrushCur = this.bf_getBrushName(_pe, "head");
		local tattooBrush = this.bf_getBrushName(_pe, "tattoo_body");

		// Color from hair brush
		local colorName = "brown";
		if (hairBrush != "") colorName = this.bf_extractColor(hairBrush);
		local colorIdx = 0;
		for (local i = 0; i < colorArr.len(); i++)
		{
			if (colorArr[i] == colorName) { colorIdx = i; break; }
		}

		// Head/Body indices (full names in array)
		local headIdx = this.bf_findIndexInList(headArr, headBrushCur);
		local bodyIdx = this.bf_findIndexInList(bodyArr, bodyBrush);

		// Hair index (suffix-based: "hair_" + color + "_" + suffix)
		local hairIdx = this.bf_findSuffixIndex(hairArr, hairBrush, "hair_", colorName, "");

		// Beard index (suffix-based: "beard_" + color + "_" + suffix)
		local beardIdx = 0;
		if (beardBrush == "" || beardArr.len() == 0 || (beardArr.len() == 1 && beardArr[0] == ""))
			beardIdx = 0;
		else
			beardIdx = this.bf_findSuffixIndex(beardArr, beardBrush, "beard_", colorName, "");

		// Tattoo index (prefix-based: tattoo_suffix + "_" + bodyBrush)
		local tattooIdx = 0;
		if (tattooBrush != "" && bodyBrush != "")
			tattooIdx = this.bf_findSuffixIndex(tattooArr, tattooBrush, "", "", bodyBrush);

		result.HairIndex = hairIdx;
		result.HairTotal = hairArr.len();
		result.BeardIndex = beardIdx;
		result.BeardTotal = beardArr.len();
		result.HeadIndex = headIdx;
		result.HeadTotal = headArr.len();
		result.BodyIndex = bodyIdx;
		result.BodyTotal = bodyArr.len();
		result.TattooIndex = tattooIdx;
		result.TattooTotal = tattooArr.len();
		result.ColorName = colorName;
		result.ColorIndex = colorIdx;
		result.ColorTotal = colorArr.len();

		return result;
	},

	// ========================================================================
	// SECTION — Appearance Preview System
	// ========================================================================

	// Get the entity used for preview (temp entity from TemporaryRoster)
	function bf_getPreviewEntity()
	{
		if (this.m.PreviewBroId == null) return null;

		try
		{
			local roster = this.World.getTemporaryRoster();
			local all = roster.getAll();
			if (all.len() > 0) return all[0];
		}
		catch(e) {}
		// Fallback: return real bro
		return this.bf_findBroById(this.m.PreviewBroId);
	},

	// Begin preview: save original appearance, create temp entity for editing
	function bf_beginPreview(_bro)
	{
		local layers = ["body", "head", "hair", "beard", "beard_top", "tattoo_body", "tattoo_head"];
		local sameBro = (this.m.PreviewBroId == _bro.getID());

		if (!sameBro)
		{
			// Different bro or first time: end previous preview and save original state
			this.bf_endPreview(false);

			this.m.PreviewBroId = _bro.getID();

			local savedApp = {};
			foreach (sn in layers)
			{
				savedApp[sn] <- this.bf_getBrushName(_bro, sn);
			}
			this.m.SavedAppearance = savedApp;
		}
		else
		{
			// Same bro: just recreate temp
			try { this.World.getTemporaryRoster().clear(); } catch(e) {}
		}

		// Create temp entity like the barber — copySpritesFrom
		try
		{
			local roster = this.World.getTemporaryRoster();
			roster.clear();
			local temp = roster.create("scripts/entity/tactical/human");
			temp.copySpritesFrom(_bro, layers);

			// Copy visual overlays (blood, dirt, injury)
			local overlays = ["body_blood", "dirt", "injury", "injury_body"];
			foreach (ol in overlays)
			{
				try
				{
					local src = _bro.getSprite(ol);
					local dst = temp.getSprite(ol);
					if (src != null && dst != null && src.HasBrush)
					{
						dst.setBrush(src.getBrush().Name);
						dst.Visible = src.Visible;
					}
				}
				catch(e2) {}
			}

			// Copy Color + Saturation for any tinted layers
			foreach (sn in layers)
			{
				try
				{
					local src = _bro.getSprite(sn);
					local dst = temp.getSprite(sn);
					if (src != null && dst != null)
					{
						dst.Color = src.Color;
						dst.Saturation = src.Saturation;
					}
				}
				catch(e2) {}
			}

			temp.setDirty(true);
		}
		catch(e)
		{
			::logError("[BBForge] bf_beginPreview temp entity error: " + e);
		}
	},

	// End preview: either accept (copy temp to real bro) or cancel (restore saved)
	function bf_endPreview(_accept)
	{
		if (this.m.PreviewBroId == null)
			return;

		local layers = ["body", "head", "hair", "beard", "beard_top", "tattoo_body", "tattoo_head"];

		try
		{
			local bro = this.bf_findBroById(this.m.PreviewBroId);

			if (_accept)
			{
				// Accept: copy appearance from temp to real bro
				if (bro != null)
				{
					local temp = this.bf_getPreviewEntity();
					if (temp != null)
					{
						bro.copySpritesFrom(temp, layers);
					}
				}
			}
			else
			{
				// Cancel: restore original appearance on real bro
				if (bro != null && this.m.SavedAppearance != null)
				{
					foreach (sn, brushName in this.m.SavedAppearance)
					{
						try
						{
							if (brushName == "")
								bro.getSprite(sn).resetBrush();
							else
								bro.getSprite(sn).setBrush(brushName);
						}
						catch(e) {}
					}
				}
			}

			// Always clear temp roster
			try { this.World.getTemporaryRoster().clear(); } catch(e) {}

			// Final update on real bro
			if (bro != null)
			{
				try { bro.setDirty(true); } catch(e) {}
			}
		}
		catch (e) { ::logError("[BBForge] bf_endPreview error: " + e); }

		this.m.PreviewBroId = null;
		this.m.SavedAppearance = null;
	},

	// ========================================================================
	// SECTION — Appearance queries & setters
	// ========================================================================

	// Cancel preview — restore original appearance
	function onCancelAppearance(_data)
	{
		local broId = this.m.PreviewBroId;
		this.bf_endPreview(false);
		if (broId != null)
		{
			try
			{
				local b = this.bf_findBroById(broId);
				if (b != null) return b.getImagePath();
			}
			catch(e) {}
		}
		return null;
	},

	// Accept preview — keep appearance changes (copy from temp to real bro)
	function onAcceptAppearance(_data)
	{
		local broId = this.m.PreviewBroId;
		this.bf_endPreview(true);
		if (broId != null)
		{
			try
			{
				local b = this.bf_findBroById(broId);
				if (b != null) return b.getImagePath();
			}
			catch(e) {}
		}
		return null;
	},

	// Query appearance — returns current state for the Look tab UI
	// Always human male in vanilla. Returns hair, beard, head, body, color, tattoo.
	function queryAppearance(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			// Begin preview (temp entity)
			this.bf_beginPreview(b);

			local bg = null;
			try { bg = b.getBackground(); } catch(e) {}
			local pe = this.bf_getPreviewEntity();
			if (pe == null) return null;

			return this.bf_computeState(pe, b, bg);
		}
		catch (e)
		{
			::logError("[BBForge] queryAppearance error: " + e);
			return null;
		}
	},

	// Set a single appearance layer (hair, beard, head, body, color, tattoo)
	function setAppearance(_data)
	{
		try
		{
			local b = this.bf_findBroById(_data.BroId);
			if (b == null) return null;

			local pe = this.bf_getPreviewEntity();
			if (pe == null) return null;

			local field = _data.Field;
			local change = ("Change" in _data) ? _data.Change : 0;

			// Detect ethnicity from body brush on preview entity
			local bodyBrush = this.bf_getBrushName(pe, "body");
			local ethnicity = "northern";
			if (bodyBrush.find("southern") != null)
				ethnicity = "southern";

			switch (field)
			{
				case "head":
				{
					local arr = [];
					if (ethnicity == "southern")
					{
						try { local raw = ::Const.Faces.SouthernMale; for (local i = 0; i < raw.len(); i++) arr.push(raw[i]); } catch(e) {}
					}
					if (arr.len() == 0)
					{
						try { local raw = ::Const.Faces.AllMale; for (local i = 0; i < raw.len(); i++) arr.push(raw[i]); } catch(e) {}
					}
					this.bf_changeIndex(pe, "head", arr, change);
					break;
				}

				case "body":
				{
					local arr = [];
					if (ethnicity == "southern")
					{
						try { local raw = ::Const.Bodies.SouthernMale; for (local i = 0; i < raw.len(); i++) arr.push(raw[i]); } catch(e) {}
					}
					if (arr.len() == 0)
					{
						try { local raw = ::Const.Bodies.AllMale; for (local i = 0; i < raw.len(); i++) arr.push(raw[i]); } catch(e) {}
					}
					this.bf_changeIndex(pe, "body", arr, change);

					// Re-apply tattoo with change=0 (body suffix changed)
					local tattooArr = [];
					try { local raw = ::Const.Tattoos.All; for (local i = 0; i < raw.len(); i++) tattooArr.push(raw[i]); } catch(e) {}
					if (tattooArr.len() == 0) tattooArr.push("");
					local newBodyBrush = this.bf_getBrushName(pe, "body");
					this.bf_changeIndexEx(pe, "tattoo_body", tattooArr, 0, "", "", newBodyBrush);

					// Sync tattoo_head
					local tattooBrush = this.bf_getBrushName(pe, "tattoo_body");
					if (tattooBrush != "")
					{
						local bodyB = this.bf_getBrushName(pe, "body");
						if (bodyB != "" && tattooBrush.find(bodyB) != null)
						{
							local tattooPrefix = tattooBrush.slice(0, tattooBrush.find(bodyB));
							if (tattooPrefix != "")
							{
								local headTattoo = tattooPrefix + "head";
								try { pe.getSprite("tattoo_head").setBrush(headTattoo); } catch(e) {}
							}
						}
					}
					else
					{
						try { pe.getSprite("tattoo_head").resetBrush(); } catch(e) {}
					}
					break;
				}

				case "hair":
				{
					local hairArr = [];
					try { local raw = ::Const.Hair.Barber; for (local i = 0; i < raw.len(); i++) hairArr.push(raw[i]); } catch(e) {}
					if (hairArr.len() == 0) hairArr.push("");

					local colorName = "brown";
					local hb = this.bf_getBrushName(pe, "hair");
					if (hb != "") colorName = this.bf_extractColor(hb);
					this.bf_changeIndexEx(pe, "hair", hairArr, change, "hair_", colorName, "");
					break;
				}

				case "beard":
				{
					local beardArr = [];
					try { local raw = ::Const.Beards.Barber; for (local i = 0; i < raw.len(); i++) beardArr.push(raw[i]); } catch(e) {}
					if (beardArr.len() == 0) beardArr.push("");

					local colorName = "brown";
					local bb = this.bf_getBrushName(pe, "beard");
					if (bb != "") colorName = this.bf_extractColor(bb);
					else
					{
						local hb = this.bf_getBrushName(pe, "hair");
						if (hb != "") colorName = this.bf_extractColor(hb);
					}

					this.bf_changeIndexEx(pe, "beard", beardArr, change, "beard_", colorName, "");

					// Sync beard_top
					local newBeard = this.bf_getBrushName(pe, "beard");
					if (newBeard != "")
					{
						try { pe.getSprite("beard_top").setBrush(newBeard + "_top"); }
						catch(e) { try { pe.getSprite("beard_top").resetBrush(); } catch(e2) {} }
					}
					else
					{
						try { pe.getSprite("beard_top").resetBrush(); } catch(e) {}
					}
					break;
				}

				case "color":
				{
					local colorArr = [];
					try { local raw = ::Const.HairColors.All; for (local i = 0; i < raw.len(); i++) colorArr.push(raw[i]); } catch(e) {}
					if (colorArr.len() == 0) break;

					// Find current color from hair brush
					local hairBrush = this.bf_getBrushName(pe, "hair");
					local curColor = "brown";
					if (hairBrush != "") curColor = this.bf_extractColor(hairBrush);
					local idx = 0;
					for (local i = 0; i < colorArr.len(); i++)
					{
						if (colorArr[i] == curColor) { idx = i; break; }
					}
					idx = (idx + change + colorArr.len()) % colorArr.len();
					local newColor = colorArr[idx];

					// Re-apply hair: extract style suffix, rebuild with new color
					// Hair brush format: "hair_{color}_{style}" e.g. "hair_brown_01"
					if (hairBrush != "")
					{
						// Strip "hair_" prefix and color to find style suffix
						// e.g. "hair_brown_01" -> strip "hair_" -> "brown_01" -> strip color "brown_" -> "01"
						local hairStyle = "";
						local afterPrefix = hairBrush.slice(5); // remove "hair_"
						local underscorePos = afterPrefix.find("_");
						if (underscorePos != null && underscorePos < afterPrefix.len() - 1)
							hairStyle = afterPrefix.slice(underscorePos + 1);

						if (hairStyle != "")
						{
							local newHairBrush = "hair_" + newColor + "_" + hairStyle;
							try { pe.getSprite("hair").setBrush(newHairBrush); } catch(e) {}
						}
					}

					// Re-apply beard: same logic
					local beardBrush = this.bf_getBrushName(pe, "beard");
					if (beardBrush != "")
					{
						local beardStyle = "";
						local afterPrefix = beardBrush.slice(6); // remove "beard_"
						local underscorePos = afterPrefix.find("_");
						if (underscorePos != null && underscorePos < afterPrefix.len() - 1)
							beardStyle = afterPrefix.slice(underscorePos + 1);

						if (beardStyle != "")
						{
							local newBeardBrush = "beard_" + newColor + "_" + beardStyle;
							try { pe.getSprite("beard").setBrush(newBeardBrush); } catch(e) {}

							// Sync beard_top
							try { pe.getSprite("beard_top").setBrush(newBeardBrush + "_top"); }
							catch(e) { try { pe.getSprite("beard_top").resetBrush(); } catch(e2) {} }
						}
					}
					break;
				}

				case "tattoo":
				{
					local tattooArr = [];
					try { local raw = ::Const.Tattoos.All; for (local i = 0; i < raw.len(); i++) tattooArr.push(raw[i]); } catch(e) {}
					if (tattooArr.len() == 0) tattooArr.push("");
					local bodyBrushCur = this.bf_getBrushName(pe, "body");
					this.bf_changeIndexEx(pe, "tattoo_body", tattooArr, change, "", "", bodyBrushCur);

					// Sync tattoo_head
					local tattooBrush = this.bf_getBrushName(pe, "tattoo_body");
					if (tattooBrush != "" && bodyBrushCur != "" && tattooBrush.find(bodyBrushCur) != null)
					{
						local tattooPrefix = tattooBrush.slice(0, tattooBrush.find(bodyBrushCur));
						if (tattooPrefix != "")
						{
							local headTattoo = tattooPrefix + "head";
							try { pe.getSprite("tattoo_head").setBrush(headTattoo); }
							catch(e) { try { pe.getSprite("tattoo_head").resetBrush(); } catch(e2) {} }
						}
						else
						{
							try { pe.getSprite("tattoo_head").resetBrush(); } catch(e) {}
						}
					}
					else
					{
						try { pe.getSprite("tattoo_head").resetBrush(); } catch(e) {}
					}
					break;
				}
			}

			// Force re-render on preview entity and return its image path
			try { pe.setDirty(true); } catch (e) {}
			return pe.getImagePath();
		}
		catch (e)
		{
			::logError("[BBForge] setAppearance error: " + e);
			return null;
		}
	},

	// ========================================================================
	// SECTION — Background catalog
	// ========================================================================

	function bf_prettifyBgName(shortName)
	{
		local name = shortName;

		// Remove _background suffix
		if (name.len() > 11 && name.slice(name.len() - 11) == "_background")
			name = name.slice(0, name.len() - 11);

		// Replace _ with space and capitalize each word
		local result = "";
		local capitalize = true;
		for (local i = 0; i < name.len(); i++)
		{
			local ch = name.slice(i, i + 1);
			if (ch == "_")
			{
				result += " ";
				capitalize = true;
			}
			else if (capitalize)
			{
				result += ch.toupper();
				capitalize = false;
			}
			else
			{
				result += ch;
			}
		}

		return result;
	},

	function bf_buildBackgroundCatalog()
	{
		local catalog = [];
		local seen = {};

		// 1. Add backgrounds from all roster bros (real instances)
		try
		{
			local brothers = this.World.getPlayerRoster().getAll();
			foreach (b in brothers)
			{
				try
				{
					local bg = b.getBackground();
					if (bg == null) continue;
					local bgId = bg.getID();
					if (bgId in seen) continue;
					seen[bgId] <- true;

					local bgScript = "";
					try { bgScript = this.IO.scriptFilenameByHash(bg.ClassNameHash); } catch(ex) {}
					local bgIcon = "";
					try { bgIcon = bg.m.Icon; } catch(ex) {}

					catalog.push({
						ID = bgId,
						Script = bgScript,
						Icon = bgIcon,
						Name = bg.m.Name
					});
				}
				catch(ex) {}
			}
		}
		catch(ex) {}

		// 2. Scan all Const background arrays for additional entries
		local bf_bgArrays = [
			"CharacterBackgrounds",
			"CharacterCombatBackgrounds",
			"CharacterBackgroundsAnimated",
			"CharacterPartyBackgrounds",
			"CharacterBackgroundsRandom"
		];

		local bf_scriptNames = [];
		local bf_scriptSeen = {};
		foreach (arrName in bf_bgArrays)
		{
			if (!(arrName in ::Const)) continue;
			foreach (shortName in ::Const[arrName])
			{
				if (shortName in bf_scriptSeen) continue;
				bf_scriptSeen[shortName] <- true;
				bf_scriptNames.push(shortName);
			}
		}

		// 3. For each script name, instantiate to get real data
		foreach (shortName in bf_scriptNames)
		{
			// Skip entries without _background suffix (not real backgrounds)
			if (shortName.len() <= 11 || shortName.slice(shortName.len() - 11) != "_background")
				continue;

			local bgScript = "scripts/skills/backgrounds/" + shortName;

			// Quick dedup with derived ID
			local idBase = shortName.slice(0, shortName.len() - 11);
			local derivedId = "background." + idBase;
			if (derivedId in seen) continue;

			try
			{
				local bgObj = this.new(bgScript);
				local bgId = derivedId;
				local bgDisplayName = shortName;
				local bgIcon = "";

				try { bgId = bgObj.getID(); } catch(ex) {}
				try { bgDisplayName = bgObj.m.Name; } catch(ex) {}
				try { bgIcon = bgObj.m.Icon; } catch(ex) {}

				// Dedup with real ID (may differ from derived)
				if (bgId in seen) continue;
				seen[bgId] <- true;
				seen[derivedId] <- true;

				catalog.push({
					ID = bgId,
					Script = bgScript,
					Icon = bgIcon,
					Name = bgDisplayName
				});
			}
			catch(ex) {}
		}

		// Sort by name
		catalog.sort(function(a, b) {
			if (a.Name < b.Name) return -1;
			if (a.Name > b.Name) return 1;
			return 0;
		});

		return catalog;
	},

	// =================================================================
	// COMPANY TAB — name, banner, avatar
	// =================================================================

	function bf_createAvatarTempModel()
	{
		try
		{
			local roster = ::World.getTemporaryRoster();
			roster.clear();

			local player = ::World.State.getPlayer();
			local socket = "world_base_01";
			local body = "figure_player_01";
			local flip = false;

			try { socket = player.getSprite("base").getBrush().Name; } catch(e) {}
			try { body = player.getSprite("body").getBrush().Name; } catch(e) {}
			try { flip = player.getSprite("body").isFlippedHorizontally(); } catch(e) {}

			this.m.bf_avatarTempModel = roster.create("scripts/entity/tactical/bf_avatar_model");
			this.m.bf_avatarTempModel.getSprite("base").setBrush(socket);
			this.m.bf_avatarTempModel.getSprite("body").setBrush(body);
			this.m.bf_avatarTempModel.setFlipped(flip);
			this.m.bf_avatarTempModel.setDirty(true);
			return true;
		}
		catch(e)
		{
			::logWarning("[BBForge] bf_createAvatarTempModel error: " + e);
			this.m.bf_avatarTempModel = null;
			return false;
		}
	},

	function bf_updateAvatarPreview(_body, _socket, _flipped)
	{
		try
		{
			if (this.m.bf_avatarTempModel == null) return;

			this.m.bf_avatarTempModel.getSprite("body").setBrush(_body);
			this.m.bf_avatarTempModel.getSprite("base").setBrush(_socket);
			this.m.bf_avatarTempModel.setFlipped(_flipped);
			this.m.bf_avatarTempModel.setDirty(true);

			local imagePath = this.m.bf_avatarTempModel.getImagePath();
			this.m.JSHandle.asyncCall("updateAvatarImage", imagePath);
		}
		catch(e)
		{
			::logWarning("[BBForge] bf_updateAvatarPreview error: " + e);
		}
	},

	function bf_destroyAvatarTempModel()
	{
		this.m.bf_avatarTempModel = null;
		try { ::World.getTemporaryRoster().clear(); } catch(e) {}
	},

	function bf_initAvatarCatalog()
	{
		if (this.m.bf_avatarSprites != null) return;

		this.m.bf_avatarSprites = [];
		this.m.bf_avatarNames = [];

		// Player
		local arr = [];
		for (local i = 1; i <= 18; i++)
			arr.push("figure_player_" + format("%02d", i));
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Player");

		// Civilian
		arr = [];
		foreach (s in ["figure_civilian_01","figure_civilian_02","figure_civilian_03","figure_civilian_04","figure_civilian_05","figure_civilian_06",
			"figure_mercenary_01","figure_mercenary_02","figure_militia_01","figure_militia_02"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Civilian");

		// Noble
		arr = [];
		for (local n = 1; n <= 3; n++)
		{
			arr.push("figure_noble_" + format("%02d", n));
			for (local v = 1; v <= 10; v++)
				arr.push("figure_noble_" + format("%02d", n) + "_" + format("%02d", v));
		}
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Noble");

		// Raider
		arr = [];
		foreach (s in ["figure_bandit_01","figure_bandit_02","figure_bandit_03","figure_bandit_04",
			"figure_wildman_01","figure_wildman_02","figure_wildman_03","figure_wildman_04"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Raider");

		// Southern
		arr = [];
		foreach (s in ["figure_refugee_01","figure_refugee_02","figure_slave_01",
			"figure_southern_01","figure_southern_01_01","figure_southern_02","figure_southern_02_01",
			"figure_nomad_01","figure_nomad_02","figure_nomad_03","figure_nomad_04","figure_nomad_05"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Southern");

		// Undead
		arr = [];
		foreach (s in ["figure_necromancer_01","figure_necromancer_02","figure_ghost_01",
			"figure_zombie_01","figure_zombie_02","figure_zombie_03","figure_zombie_04",
			"figure_vampire_01","figure_vampire_02",
			"figure_skeleton_01","figure_skeleton_02","figure_skeleton_03","figure_skeleton_04"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Undead");

		// Greenskin
		arr = [];
		foreach (s in ["figure_goblin_01","figure_goblin_02","figure_goblin_03","figure_goblin_04","figure_goblin_05",
			"figure_orc_01","figure_orc_02","figure_orc_03","figure_orc_04","figure_orc_05","figure_orc_06"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Greenskin");

		// Misc
		arr = [];
		foreach (s in ["figure_hexe_01","figure_alp_01","figure_ghoul_01","figure_ghoul_02",
			"figure_golem_01","figure_golem_02","figure_hyena_01","figure_kraken_01",
			"figure_lindwurm_01","figure_schrat_01","figure_serpent_01","figure_spider_01",
			"figure_unhold_01","figure_unhold_02","figure_unhold_03","figure_werewolf_01"])
			arr.push(s);
		this.m.bf_avatarSprites.push(arr);
		this.m.bf_avatarNames.push("Misc");

		// Sockets
		this.m.bf_avatarSockets = [];
		foreach (s in ["world_base_01","world_base_02","world_base_03","world_base_05",
			"world_base_07","world_base_08","world_base_09","world_base_10",
			"world_base_11","world_base_12","world_base_13","world_base_14"])
			this.m.bf_avatarSockets.push(s);
	},

	function queryCompany(_data = null)
	{
		try
		{
			local result = {};

			// Company name
			try { result.Name <- ::World.Assets.m.Name; }
			catch(e) { result.Name <- "Unknown"; }

			// Banner
			try
			{
				result.CurrentBanner <- ::World.Assets.getBanner();
				local allBanners = [];
				foreach (b in ::Const.PlayerBanners)
					allBanners.push(b);
				result.Banners <- allBanners;
				result.BannerIndex <- 0;
				for (local i = 0; i < allBanners.len(); i++)
				{
					if (allBanners[i] == result.CurrentBanner)
					{
						result.BannerIndex = i;
						break;
					}
				}
			}
			catch(e)
			{
				::logWarning("[BBForge] queryCompany banner error: " + e);
				result.CurrentBanner <- "banner_01";
				result.Banners <- [];
				result.BannerIndex <- 0;
			}

			// Avatar state
			try
			{
				this.bf_initAvatarCatalog();
				local player = ::World.State.getPlayer();

				local curBody = "";
				local curSocket = "";
				try { curBody = player.getSprite("body").getBrush().Name; } catch(e) {}
				try { curSocket = player.getSprite("base").getBrush().Name; } catch(e) {}
				try { this.m.bf_avatarFlipped = player.getSprite("body").isFlippedHorizontally(); } catch(e) {}

				// Find current position in catalog
				local found = false;
				for (local r = 0; r < this.m.bf_avatarSprites.len(); r++)
				{
					for (local c = 0; c < this.m.bf_avatarSprites[r].len(); c++)
					{
						if (this.m.bf_avatarSprites[r][c] == curBody)
						{
							this.m.bf_avatarRow = r;
							this.m.bf_avatarCol = c;
							found = true;
							break;
						}
					}
					if (found) break;
				}
				for (local si = 0; si < this.m.bf_avatarSockets.len(); si++)
				{
					if (this.m.bf_avatarSockets[si] == curSocket)
					{
						this.m.bf_avatarSocketIdx = si;
						break;
					}
				}

				result.HasAvatar <- true;
				result.AvatarType <- this.m.bf_avatarNames[this.m.bf_avatarRow];
				result.AvatarSprite <- curBody;
				result.AvatarSocket <- curSocket;
				result.AvatarFlipped <- this.m.bf_avatarFlipped;
				result.AvatarSpriteCount <- this.m.bf_avatarSprites[this.m.bf_avatarRow].len();
				result.AvatarSpriteIdx <- this.m.bf_avatarCol + 1;
				result.AvatarSocketIdx <- this.m.bf_avatarSocketIdx + 1;
				result.AvatarSocketCount <- this.m.bf_avatarSockets.len();

				// Create temp model for preview
				if (this.bf_createAvatarTempModel())
				{
					local imagePath = this.m.bf_avatarTempModel.getImagePath();
					result.AvatarImagePath <- imagePath;
				}
				else
				{
					result.AvatarImagePath <- "";
				}
			}
			catch(e)
			{
				::logWarning("[BBForge] queryCompany avatar error: " + e);
				result.HasAvatar <- false;
			}

			return result;
		}
		catch(e)
		{
			::logError("[BBForge] queryCompany error: " + e);
			return null;
		}
	},

	function onChangeCompanyName(_data)
	{
		try
		{
			local name = _data.Name;
			// Strip "The " prefix like the game does
			if (name.len() > 4 && name.slice(0, 4) == "The ")
				name = name.slice(4);
			else if (name.len() > 4 && name.slice(0, 4) == "the ")
				name = name.slice(4);
			::World.Assets.m.Name = name;
			return true;
		}
		catch(e)
		{
			::logError("[BBForge] onChangeCompanyName error: " + e);
			return false;
		}
	},

	function onChangeBanner(_data)
	{
		try
		{
			local bannerStr = _data.Banner;
			::World.Assets.m.Banner = bannerStr;

			// Extract numeric ID from banner string
			local idStr = bannerStr.slice(bannerStr.find("_") + 1);
			local bannerId = idStr.tointeger();
			try { ::World.Assets.m.BannerID = bannerId; } catch(e) {}

			// Update player entity sprites
			try
			{
				local player = ::World.State.getPlayer();
				player.getSprite("banner").setBrush(bannerStr);
				player.getSprite("zoom_banner").setBrush(bannerStr);
			}
			catch(e) { ::logWarning("[BBForge] onChangeBanner sprite error: " + e); }

			// Update physical banner item (in stash or equipped)
			try
			{
				local stashBanner = ::World.Assets.getStash().getItemByID("weapon.player_banner");
				if (stashBanner != null)
				{
					stashBanner.setVariant(bannerId);
					try { stashBanner.updateVariant(); } catch(e) {}
				}
			}
			catch(e) {}

			// Check equipped banners on roster bros
			try
			{
				local roster = ::World.getPlayerRoster().getAll();
				foreach (bro in roster)
				{
					try
					{
						local allItems = bro.getItems().getAllItems();
						foreach (item in allItems)
						{
							try
							{
								if (item != null && item.getID() == "weapon.player_banner")
								{
									item.setVariant(bannerId);
									try { item.updateVariant(); } catch(e) {}
								}
							}
							catch(e) {}
						}
					}
					catch(e) {}
				}
			}
			catch(e) {}

			return true;
		}
		catch(e)
		{
			::logError("[BBForge] onChangeBanner error: " + e);
			return false;
		}
	},

	function onChangeAvatar(_data)
	{
		try
		{
			this.bf_initAvatarCatalog();
			local action = _data.Action;

			if (action == "next_sprite")
			{
				local total = this.m.bf_avatarSprites[this.m.bf_avatarRow].len();
				this.m.bf_avatarCol = (this.m.bf_avatarCol + 1) % total;
			}
			else if (action == "prev_sprite")
			{
				local total = this.m.bf_avatarSprites[this.m.bf_avatarRow].len();
				this.m.bf_avatarCol = (this.m.bf_avatarCol - 1 + total) % total;
			}
			else if (action == "next_type")
			{
				this.m.bf_avatarRow = (this.m.bf_avatarRow + 1) % this.m.bf_avatarSprites.len();
				this.m.bf_avatarCol = 0;
			}
			else if (action == "next_socket")
			{
				this.m.bf_avatarSocketIdx = (this.m.bf_avatarSocketIdx + 1) % this.m.bf_avatarSockets.len();
			}
			else if (action == "flip")
			{
				this.m.bf_avatarFlipped = !this.m.bf_avatarFlipped;
			}

			// Apply to player entity
			local player = ::World.State.getPlayer();
			local body = this.m.bf_avatarSprites[this.m.bf_avatarRow][this.m.bf_avatarCol];
			local socket = this.m.bf_avatarSockets[this.m.bf_avatarSocketIdx];

			player.getSprite("body").setBrush(body);
			player.getSprite("base").setBrush(socket);
			try { player.getSprite("body").setHorizontalFlipping(this.m.bf_avatarFlipped); } catch(e) {}
			try { player.getSprite("base").setHorizontalFlipping(this.m.bf_avatarFlipped); } catch(e) {}

			// Persist
			try
			{
				::World.Flags.set("bbforge_avatar_body", body);
				::World.Flags.set("bbforge_avatar_socket", socket);
				::World.Flags.set("bbforge_avatar_flipped", this.m.bf_avatarFlipped);
			}
			catch(e) {}

			// Update preview via asyncCall (push to JS)
			this.bf_updateAvatarPreview(body, socket, this.m.bf_avatarFlipped);

			// Return current state for JS labels
			return {
				Type = this.m.bf_avatarNames[this.m.bf_avatarRow],
				Sprite = body,
				SpriteIdx = (this.m.bf_avatarCol + 1),
				SpriteCount = this.m.bf_avatarSprites[this.m.bf_avatarRow].len(),
				SocketIdx = (this.m.bf_avatarSocketIdx + 1),
				SocketCount = this.m.bf_avatarSockets.len(),
				Flipped = this.m.bf_avatarFlipped
			};
		}
		catch(e)
		{
			::logError("[BBForge] onChangeAvatar error: " + e);
			return null;
		}
	},

	// =================================================================
	// STASH TAB — Stash Management
	// =================================================================

	function queryStash(_data = null)
	{
		try
		{
			local stash = ::World.Assets.getStash();
			local items = [];
			local count = 0;

			foreach (i, item in stash.m.Items)
			{
				if (item == null) continue;

				count++;
				local entry = {
					Index = i,
					Name = "",
					Icon = "",
					ID = "",
					Condition = 0,
					ConditionMax = 0,
					IsNamed = false
				};

				try { entry.Name = item.getName(); } catch(e) {}
				try { entry.Icon = item.getIcon(); } catch(e) {}
				try { entry.ID = item.getID(); } catch(e) {}
				try { entry.Condition = item.getCondition(); } catch(e) {}
				try { entry.ConditionMax = item.getConditionMax(); } catch(e) {}
				try { entry.IsNamed = item.isItemType(::Const.Items.ItemType.Named); } catch(e) {}

				// Instance ID for native tooltip binding
				try { entry.InstanceID <- item.getInstanceID(); } catch(e) { entry.InstanceID <- ""; }

				// Overlay icons (layered armor etc.)
				local overlays = [];
				try { overlays = item.getIconOverlay(); } catch(e) {}
				entry.Overlays <- overlays;

				items.push(entry);
			}

			local stashID = "";
			try { stashID = stash.getID(); } catch(e) {}

			return {
				Items = items,
				Count = count,
				Capacity = stash.getCapacity(),
				StashID = stashID
			};
		}
		catch(e)
		{
			::logError("[BBForge] queryStash error: " + e);
			return null;
		}
	},

	function onAddItemToStash(_data)
	{
		try
		{
			local script = _data.Script;
			local item = ::new(script);
			local stash = ::World.Assets.getStash();
			local idx = stash.add(item);

			if (idx == null)
				return { Success = false, Error = "Stash is full" };

			return { Success = true };
		}
		catch(e)
		{
			::logError("[BBForge] onAddItemToStash error: " + e);
			return { Success = false, Error = "" + e };
		}
	},

	function onRemoveStashItem(_data)
	{
		try
		{
			local stash = ::World.Assets.getStash();
			local removed = stash.removeByIndex(_data.Index);

			if (removed == null)
				return { Success = false, Error = "Item not found" };

			return { Success = true };
		}
		catch(e)
		{
			::logError("[BBForge] onRemoveStashItem error: " + e);
			return { Success = false, Error = "" + e };
		}
	},

	function onSortStash(_data = null)
	{
		try
		{
			::World.Assets.getStash().sort();
			return this.queryStash();
		}
		catch(e)
		{
			::logError("[BBForge] onSortStash error: " + e);
			return null;
		}
	},

	function onRepairAllStash(_data = null)
	{
		try
		{
			foreach (item in ::World.Assets.getStash().m.Items)
			{
				if (item == null) continue;

				try
				{
					if (::isKindOf(item, "armor") || ::isKindOf(item, "helmet"))
						item.setArmor(item.getArmorMax());
					else
						item.setCondition(item.getConditionMax());
				}
				catch(e) {}
			}
			return this.queryStash();
		}
		catch(e)
		{
			::logError("[BBForge] onRepairAllStash error: " + e);
			return null;
		}
	},

	// =================================================================
	// STASH TAB — Item Catalog
	// =================================================================

	function bf_initItemCatalog()
	{
		if (this.m.bf_itemCatalog != null) return;

		this.m.bf_itemCatalog = [];

		// Build valid icon set from gfx filesystem
		local validIcons = {};
		try
		{
			local imgFiles = ::IO.enumerateFiles("gfx/ui/items/");
			foreach (f in imgFiles)
				validIcons[f.slice("gfx/ui/items/".len()) + ".png"] <- true;
		}
		catch(e)
		{
			::logWarning("[BBForge] Could not enumerate item icons: " + e);
		}

		local prefix = "scripts/items/";
		local allScripts = ::IO.enumerateFiles(prefix);
		local skipPrefixes = [
			"scripts/items/armor/",
			"scripts/items/helmets/",
			"scripts/items/armor_upgrades/"
		];
		local invalidScripts = [
			"scripts/items/item",
			"scripts/items/item_container",
			"scripts/items/stash_container"
		];

		foreach (script in allScripts)
		{
			try
			{
				local skip = false;
				foreach (inv in invalidScripts)
				{
					if (script == inv) { skip = true; break; }
				}
				if (skip) continue;

				foreach (sp in skipPrefixes)
				{
					if (script.len() >= sp.len() && script.slice(0, sp.len()) == sp)
					{
						skip = true;
						break;
					}
				}
				if (skip) continue;

				local item = ::new(script);
				local name = "";
				local icon = "";
				local id = "";

				try { name = item.getName(); } catch(e) {}
				try { icon = item.getIcon(); } catch(e) {}
				try { id = item.getID(); } catch(e) {}

				if (name == "" || icon == "" || id == "") continue;

				// Validate icon exists in gfx files
				if (validIcons.len() > 0 && !(icon in validIcons)) continue;

				local cat = "Misc";
				try
				{
					if (item.isItemType(::Const.Items.ItemType.Shield))
						cat = "Shield";
					else if (item.isItemType(::Const.Items.ItemType.RangedWeapon))
						cat = "Ranged";
					else if (item.isItemType(::Const.Items.ItemType.MeleeWeapon))
						cat = "Melee";
					else if (item.isItemType(::Const.Items.ItemType.Weapon))
						cat = "Weapon";
					else if (item.isItemType(::Const.Items.ItemType.Armor))
						cat = "Armor";
					else if (item.isItemType(::Const.Items.ItemType.Helmet))
						cat = "Helmet";
					else if (item.isItemType(::Const.Items.ItemType.Accessory))
						cat = "Accessory";
					else if (item.isItemType(::Const.Items.ItemType.Supply) || item.isItemType(::Const.Items.ItemType.Food))
						cat = "Supply";
					else if (item.isItemType(::Const.Items.ItemType.Usable))
						cat = "Usable";
				}
				catch(e) {}

				this.m.bf_itemCatalog.push({
					Script = script,
					Name = name,
					Icon = icon,
					ID = id,
					Cat = cat
				});
			}
			catch(e) {}
		}

		this.m.bf_itemCatalog.sort(function(a, b)
		{
			if (a.Name < b.Name) return -1;
			if (a.Name > b.Name) return 1;
			return 0;
		});

		::logInfo("[BBForge] Item catalog built: " + this.m.bf_itemCatalog.len() + " items");
	},

	function queryItemCatalog(_data = null)
	{
		this.bf_initItemCatalog();

		local search = "";
		local category = "All";

		if (_data != null)
		{
			if ("Search" in _data) search = _data.Search;
			if ("Category" in _data) category = _data.Category;
		}

		search = search.tolower();
		local results = [];

		foreach (entry in this.m.bf_itemCatalog)
		{
			if (category != "All" && entry.Cat != category)
				continue;

			if (search != "")
			{
				local nameLower = entry.Name.tolower();
				local idLower = entry.ID.tolower();
				if (nameLower.find(search) == null && idLower.find(search) == null)
					continue;
			}

			results.push({
				Script = entry.Script,
				Name = entry.Name,
				Icon = entry.Icon,
				Cat = entry.Cat
			});
		}

		return {
			Items = results,
			Total = results.len(),
			CatalogSize = this.m.bf_itemCatalog.len()
		};
	}

};
// END bbforge_screen (Part 3 — Appearance, Stash, Company, Item Catalog)
