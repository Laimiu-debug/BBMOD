// ============================================================================
// BBForge Vanilla — Frontend JavaScript (PART 1)
// Screen UI: roster panel, stats editor, tabbed navigation
// LAYOUT: position:absolute throughout
// ============================================================================
"use strict";


// =====================================================================
// CONSTANTS (defined ONCE, never duplicated)
// =====================================================================
var BF_MODE = {
	STATS: 'stats',
	PERKS: 'perks',
	TRAITS: 'traits',
	BACKGROUNDS: 'backgrounds',
	ITEMS: 'items',
	APPEARANCE: 'appearance',
	EXPORT: 'export',
	ROSTER_TOOLS: 'roster_tools',
	STASH: 'stash',
	COMPANY: 'company',
	HELP: 'help'
};

var BF_STAT_NAMES = [
	'Hitpoints', 'Stamina', 'Initiative', 'Bravery',
	'MeleeSkill', 'RangedSkill', 'MeleeDefense', 'RangedDefense'
];

var BF_STAT_LABELS = {
	'Hitpoints': 'HP',
	'Stamina': 'FAT',
	'Initiative': 'INI',
	'Bravery': 'RES',
	'MeleeSkill': 'MEL',
	'RangedSkill': 'RNG',
	'MeleeDefense': 'MDF',
	'RangedDefense': 'RDF'
};

var BF_STAT_ICONS = {
	'Hitpoints':     'ui/icons/health.png',
	'Stamina':       'ui/icons/fatigue.png',
	'Initiative':    'ui/icons/initiative.png',
	'Bravery':       'ui/icons/bravery.png',
	'MeleeSkill':    'ui/icons/melee_skill.png',
	'RangedSkill':   'ui/icons/ranged_skill.png',
	'MeleeDefense':  'ui/icons/melee_defense.png',
	'RangedDefense': 'ui/icons/ranged_defense.png',
	'PerkPoints':    'ui/icons/perks.png',
	'ActionPoints':  'ui/icons/action_points.png',
	'DailyWage':     'ui/icons/money.png'
};

// =====================================================================
// HELPERS
// =====================================================================
// Talent text — fixed-width format
function bfTalentText(_talent)
{
	if (_talent <= 0) return '---';
	if (_talent === 1) return '*--';
	if (_talent === 2) return '**-';
	return '***';
}

// Full stat display text: "Max (MaxPlus) / BLimit"
function bfStatText(_max, _maxPlus, _bLimit)
{
	return String(_max) + ' (' + String(_maxPlus) + ') / ' + String(_bLimit);
}

// Raw <input type="text"> with all styles inline — bypasses BB's createInput() which
// injects background-image via inline JS .css() (cannot be overridden by CSS !important).
// _parent: jQuery element to append to
// _initValue: initial string value
// _leftRem: CSS left position (e.g. '6.6rem')
// _widthRem: CSS width (e.g. '16rem')
// _onFocusCb(inp): called on focus with the jQuery <input> element
// _onAcceptCb(inp): called on blur/Enter with the jQuery <input> element
function bfMakeInput(_parent, _initValue, _leftRem, _widthRem, _onFocusCb, _onAcceptCb)
{
	var inp = $('<input type="text"/>').val(_initValue).css({
		'position': 'absolute',
		'top': '0.4rem',
		'left': _leftRem,
		'width': _widthRem,
		'height': '2.6rem',
		'background': 'rgba(14, 12, 8, 0.9)',
		'border': '1px solid #5a4a30',
		'border-radius': '2px',
		'color': '#ffd700',
		'font-size': '1.3rem',
		'font-weight': 'bold',
		'text-align': 'center',
		'outline': 'none',
		'box-sizing': 'border-box',
		'padding': '0 0.3rem'
	});

	inp.on('focus', function()
	{
		$(this).css('border-color', '#ffd700');
		if (typeof _onFocusCb === 'function') { _onFocusCb($(this)); }
	});
	inp.on('focusout', function()
	{
		$(this).css('border-color', '#5a4a30');
		if (typeof _onAcceptCb === 'function') { _onAcceptCb($(this)); }
	});
	inp.on('keydown', function(e)
	{
		if ((e.which || e.keyCode) === 13) { $(this).trigger('focusout'); }
	});

	_parent.append(inp);
	return inp;
}

// =====================================================================
// MODEL (separated from view — no data in DOM)
// =====================================================================
var BFModel = {
	roster: [],
	selectedBroId: null,
	selectedBro: null,
	mode: BF_MODE.STATS,
	fakeBroId: 0
};

// =====================================================================
// SCREEN CONSTRUCTOR
// =====================================================================
var BBForgeScreen = function()
{
	this.mSQHandle = null;
	this.mContainer = null;
	this.mDialogContainer = null;
	this.mDialog = null;
	this.mListContainer = null;
	this.mListScrollContainer = null;
	this.mTabsContainer = null;
	this.mContentPanel = null;
	this.mIsVisible = false;
	this.mSelectedEntry = null;

	// mStatsOptions stores refs to createInput widgets per stat
	this.mData = null;
	this.mStatsOptions =
	{
		Hitpoints:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/health.png',
			TooltipId: 'bf-stat-hitpoints',
		},
		Stamina:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/fatigue.png',
			TooltipId: 'bf-stat-stamina',
		},
		Initiative:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/initiative.png',
			TooltipId: 'bf-stat-initiative',
		},
		Bravery:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/bravery.png',
			TooltipId: 'bf-stat-bravery',
		},
		MeleeSkill:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/melee_skill.png',
			TooltipId: 'bf-stat-meleeskill',
		},
		RangedSkill:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/ranged_skill.png',
			TooltipId: 'bf-stat-rangedskill',
		},
		MeleeDefense:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/melee_defense.png',
			TooltipId: 'bf-stat-meleedefense',
		},
		RangedDefense:
		{
			SVal: null,
			TalentButton: null,
			IconPath: Path.GFX + 'ui/icons/ranged_defense.png',
			TooltipId: 'bf-stat-rangeddefense',
		},
		ActionPoints:
		{
			SVal: null,
			IconPath: Path.GFX + 'ui/icons/action_points.png',
			TooltipId: 'bf-stat-actionpoints',
		},
		DailyWage:
		{
			SVal: null,
			IconPath: Path.GFX + 'ui/icons/money.png',
			TooltipId: 'bf-stat-dailywage',
		},
		PerkPoints:
		{
			SVal: null,
			IconPath: Path.GFX + 'ui/icons/perks.png',
			TooltipId: 'bf-stat-perkpoints',
		},
		XpValue:
		{
			SVal: null,
			IconPath: Path.GFX + 'ui/icons/xp_received.png',
			TooltipId: 'bf-stat-xp',
		},
		Level:
		{
			SVal: null,
			IconPath: Path.GFX + 'ui/icons/leveled_up.png',
			TooltipId: 'bf-stat-level',
		},
	};
};

// =====================================================================
// CONNECTION LIFECYCLE
// =====================================================================
BBForgeScreen.prototype.isConnected = function()
{
	return this.mSQHandle !== null;
};

BBForgeScreen.prototype.onConnection = function(_handle)
{
	this.mSQHandle = _handle;
	this.register($('.root-screen'));
};

BBForgeScreen.prototype.onDisconnection = function()
{
	this.mSQHandle = null;
	this.unregister();
};

BBForgeScreen.prototype.getModule = function(_name)
{
	return null;
};

BBForgeScreen.prototype.getModules = function()
{
	return [];
};

// =====================================================================
// DOM CREATION — createDialog() for focus, position:absolute for layout
// =====================================================================
BBForgeScreen.prototype.createUI = function(_parentDiv)
{
	// Root screen container
	this.mContainer = $('<div class="bbforge-screen display-none opacity-none"/>');
	_parentDiv.append(this.mContainer);

	// createDialog() is REQUIRED for createInput() keyboard focus
	var dialogLayout = $('<div class="l-bbforge-dialog-container"/>');
	this.mContainer.append(dialogLayout);
	this.mDialogContainer = dialogLayout.createDialog('BBForge', '', '', true, 'dialog-1024-768');

	// Use the dialog as our mDialog — all children appended here with position:absolute
	this.mDialog = this.mDialogContainer;

	// Left column — roster list, position:absolute
	this.createRosterPanel(this.mDialog);

	// Tabs — position:absolute
	this.createTabs(this.mDialog);

	// Content panel — position:absolute
	this.mContentPanel = $('<div class="bf-content-panel"/>');
	this.mDialog.append(this.mContentPanel);

	// Smooth mousewheel scroll — prevent Coherent GT from jumping to bottom
	this.mContentPanel.on('mousewheel DOMMouseScroll', function(e) {
		e.stopPropagation();
		var delta = e.originalEvent.wheelDelta || -e.originalEvent.detail;
		this.scrollTop += (delta > 0 ? -40 : 40);
		e.preventDefault();
	});

	// Footer — position:absolute
	this.createFooter(this.mDialog);
};

BBForgeScreen.prototype.createRosterPanel = function(_parent)
{
	var leftColumn = $('<div class="bf-left-column"/>');
	_parent.append(leftColumn);

	leftColumn.append($('<div class="bf-save-warning"/>').text('SAVE BEFORE EDITING'));
	leftColumn.append($('<div class="bf-list-header"/>').text('Roster'));

	var listLayout = $('<div class="bf-list-layout"/>');
	leftColumn.append(listLayout);
	this.mListContainer = listLayout.createList(1.77, 'bf-roster-list', true);
	this.mListScrollContainer = this.mListContainer.findListScrollContainer();
};

BBForgeScreen.prototype.createTabs = function(_parent)
{
	this.mTabsContainer = $('<div class="bf-tabs"/>');
	_parent.append(this.mTabsContainer);

	var self = this;
	var tabs = [
		{ id: BF_MODE.STATS, label: 'Stats' },
		{ id: BF_MODE.PERKS, label: 'Perks' },
		{ id: BF_MODE.TRAITS, label: 'Traits' },
		{ id: BF_MODE.BACKGROUNDS, label: 'BG' },
		{ id: BF_MODE.ITEMS, label: 'Items' },
		{ id: BF_MODE.APPEARANCE, label: 'Look' },
		{ id: BF_MODE.EXPORT, label: 'Export' },
		{ id: BF_MODE.ROSTER_TOOLS, label: 'Roster' },
		{ id: BF_MODE.STASH, label: 'Stash' },
		{ id: BF_MODE.COMPANY, label: 'Company' },
		{ id: BF_MODE.HELP, label: 'Help' }
	];

	for (var i = 0; i < tabs.length; i++)
	{
		var tab = tabs[i];
		var tabEl = $('<div class="bf-tab"/>');
		tabEl.attr('data-tab', tab.id);
		tabEl.text(tab.label);

		if (tab.id === BF_MODE.STATS)
		{
			tabEl.addClass('is-active');
		}

		tabEl.on('click', function()
		{
			var tabId = $(this).attr('data-tab');
			self.switchTab(tabId);
		});

		this.mTabsContainer.append(tabEl);
	}
};

BBForgeScreen.prototype.createFooter = function(_parent)
{
	var footer = $('<div class="bf-footer"/>');
	_parent.append(footer);

	var self = this;

	var closeBtnLayout = $('<div class="bf-close-btn-layout"/>');
	footer.append(closeBtnLayout);
	closeBtnLayout.createTextButton('Close', function()
	{
		self.notifyBackendClosePressed();
	}, '', 1);
};

// =====================================================================
// TAB SWITCHING
// =====================================================================
BBForgeScreen.prototype.switchTab = function(_tabId)
{
	var self = this;

	// Cancel preview when leaving Look tab without Accept
	if (BFModel.mode === BF_MODE.APPEARANCE && _tabId !== BF_MODE.APPEARANCE)
	{
		SQ.call(this.mSQHandle, 'onCancelAppearance', {}, function(imagePath)
		{
			if (imagePath && BFModel.selectedBro)
			{
				BFModel.selectedBro.ImagePath = imagePath;
				if (BFModel.selectedBro.BroImage)
					BFModel.selectedBro.BroImage.attr('src', Path.GFX + Path.PROCEDURAL + imagePath);
			}
		});
	}

	BFModel.mode = _tabId;

	this.mTabsContainer.find('.bf-tab').removeClass('is-active');
	this.mTabsContainer.find('.bf-tab[data-tab="' + _tabId + '"]').addClass('is-active');

	switch (_tabId)
	{
		case BF_MODE.STATS:
			this.createStatsPanel();
			break;

		case BF_MODE.PERKS:
			this.createPerksPanel();
			break;

		case BF_MODE.TRAITS:
			this.createTraitsPanel();
			break;

		case BF_MODE.BACKGROUNDS:
			this.createBackgroundsPanel();
			break;

		case BF_MODE.ITEMS:
			this.createItemsPanel();
			break;

		case BF_MODE.APPEARANCE:
			this.createAppearancePanel();
			break;

		case BF_MODE.EXPORT:
			this.createExportPanel();
			break;

		case BF_MODE.ROSTER_TOOLS:
			this.createRosterToolsPanel();
			break;

		case BF_MODE.STASH:
			this.createStashPanel();
			break;

		case BF_MODE.COMPANY:
			this.createCompanyPanel();
			break;

		case BF_MODE.HELP:
			this.createHelpPanel();
			break;
	}
};

// =====================================================================
// ROSTER LIST
// =====================================================================
BBForgeScreen.prototype.addListEntry = function(_broData)
{
	var result = $('<div class="l-row"/>');
	this.mListScrollContainer.append(result);

	var entry = $('<div class="ui-control list-entry"/>');
	result.append(entry);
	entry.data('entry', _broData);

	entry.click(this, function(_event)
	{
		var s = _event.data;
		s.selectBro($(this));
	});

	// Left column: portrait
	var column = $('<div class="column is-left"/>');
	entry.append(column);
	var imageOffsetX = ('ImageOffsetX' in _broData ? _broData.ImageOffsetX : 0);
	var imageOffsetY = ('ImageOffsetY' in _broData ? _broData.ImageOffsetY : 0);
	_broData.BroImage = column.createImage(Path.PROCEDURAL + _broData.ImagePath, function(_image)
	{
		_image.centerImageWithinParent(imageOffsetX, imageOffsetY, 0.64);
		_image.removeClass('opacity-none');
	}, null, 'opacity-none');

	// Right column: name (top row) + level (bottom row)
	column = $('<div class="column is-right"/>');
	entry.append(column);

	var rowTop = $('<div class="row is-top"/>');
	column.append(rowTop);
	_broData.BroName = $('<div class="name title-font-normal font-bold font-color-brother-name">' + _broData.Name + '</div>');
	rowTop.append(_broData.BroName);

	var rowBot = $('<div class="row is-bottom"/>');
	column.append(rowBot);
	_broData.BroLevel = $('<div class="name title-font-small font-color-description">Lvl ' + _broData.Level + '</div>');
	rowBot.append(_broData.BroLevel);
};

BBForgeScreen.prototype.selectBro = function(_element)
{
	this.mListScrollContainer.find('.list-entry.is-selected').removeClass('is-selected');
	_element.addClass('is-selected');
	this.mSelectedEntry = _element;

	var broData = _element.data('entry');
	if (!broData) return;

	BFModel.selectedBroId = broData.ID;
	BFModel.selectedBro = broData;

	this.switchTab(BFModel.mode);
};

// =====================================================================
// SCREEN LIFECYCLE
// =====================================================================
BBForgeScreen.prototype.create = function(_parentDiv)
{
	this.createUI(_parentDiv);
};

BBForgeScreen.prototype.destroy = function()
{
	if (this.mListContainer !== null)
	{
		this.mListScrollContainer.empty();
		this.mListScrollContainer = null;
		this.mListContainer.destroyList();
		this.mListContainer.remove();
		this.mListContainer = null;
	}

	if (this.mContainer !== null)
	{
		this.mContainer.empty().remove();
		this.mContainer = null;
	}
};

BBForgeScreen.prototype.register = function(_parentDiv)
{
	if (this.mContainer !== null)
	{
		return;
	}
	this.create(_parentDiv);
	this.notifyBackendOnConnected();
};

BBForgeScreen.prototype.unregister = function()
{
	this.notifyBackendOnDisconnected();
	this.destroy();
};

BBForgeScreen.prototype.isRegistered = function()
{
	return this.mContainer !== null && this.mContainer.parent().length > 0;
};

BBForgeScreen.prototype.isVisible = function()
{
	return this.mIsVisible;
};

BBForgeScreen.prototype.show = function(_data)
{
	this.loadFromData(_data);

	var self = this;
	this.mContainer.velocity("finish");
	this.mContainer.velocity({
		opacity: 1
	}, {
		duration: 300,
		easing: "swing",
		begin: function()
		{
			self.notifyBackendOnAnimating();
			self.mContainer.removeClass('display-none');
		},
		complete: function()
		{
			self.mIsVisible = true;
			self.notifyBackendOnShown();
		}
	});
};

BBForgeScreen.prototype.hide = function(_withSlideAnimation)
{
	if (!this.mIsVisible)
	{
		return;
	}
	this.mIsVisible = false;

	var self = this;
	this.mContainer.velocity("finish");
	this.mContainer.velocity({
		opacity: 0
	}, {
		duration: 300,
		easing: "swing",
		begin: function()
		{
			self.notifyBackendOnAnimating();
		},
		complete: function()
		{
			self.mContainer.addClass('display-none');
			self.notifyBackendOnHidden();
		}
	});
};

BBForgeScreen.prototype.loadFromData = function(_data)
{
	BFModel.roster = _data.Roster || [];
	BFModel.fakeBroId = _data.FakeBroId || 0;
	BFModel.selectedBroId = null;
	BFModel.selectedBro = null;
	BFModel.mode = BF_MODE.STATS;

	this.mListScrollContainer.empty();
	this.mContentPanel.empty();

	// SQ already filters out fakebro and sorts active first, reserves last
	var reserveSeparatorAdded = false;
	for (var i = 0; i < BFModel.roster.length; i++)
	{
		if (!reserveSeparatorAdded && BFModel.roster[i].IsInReserves)
		{
			var sep = $('<div class="bf-roster-separator"/>').text('Reserves');
			this.mListScrollContainer.append(sep);
			reserveSeparatorAdded = true;
		}
		this.addListEntry(BFModel.roster[i]);
	}

	var firstEntry = this.mListContainer.findListEntryByIndex(0);
	if (firstEntry !== null && firstEntry.length > 0)
	{
		this.selectBro(firstEntry);
	}
	else
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('No brothers in roster'));
	}
};

// =====================================================================
// BACKEND NOTIFY FUNCTIONS
// =====================================================================
BBForgeScreen.prototype.notifyBackendOnConnected = function()
{
	SQ.call(this.mSQHandle, 'onScreenConnected');
};

BBForgeScreen.prototype.notifyBackendOnDisconnected = function()
{
	SQ.call(this.mSQHandle, 'onScreenDisconnected');
};

BBForgeScreen.prototype.notifyBackendOnShown = function()
{
	SQ.call(this.mSQHandle, 'onScreenShown');
};

BBForgeScreen.prototype.notifyBackendOnHidden = function()
{
	SQ.call(this.mSQHandle, 'onScreenHidden');
};

BBForgeScreen.prototype.notifyBackendOnAnimating = function()
{
	SQ.call(this.mSQHandle, 'onScreenAnimating');
};

BBForgeScreen.prototype.notifyBackendClosePressed = function()
{
	if (this.mSQHandle !== null)
	{
		SQ.call(this.mSQHandle, 'onClose');
	}
};

// =====================================================================
// STATS PANEL — header + createAttributesControlDIV
// =====================================================================
BBForgeScreen.prototype.createStatsPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var bro = BFModel.selectedBro;
	var self = this;
	this.mData = bro;

	// Brother header — position:relative container, absolute children (CSS handles it)
	var header = $('<div class="bf-bro-header"/>');

	// Portrait — absolute, top:0.5rem left:0
	var portrait = $('<div class="bf-bro-portrait"/>');
	var imgOffX = ('ImageOffsetX' in bro ? bro.ImageOffsetX : 0);
	var imgOffY = ('ImageOffsetY' in bro ? bro.ImageOffsetY : 0);
	portrait.createImage(Path.PROCEDURAL + bro.ImagePath, function(_image)
	{
		_image.centerImageWithinParent(imgOffX, imgOffY, 0.64);
	});
	header.append(portrait);

	// Name block — absolute, left:8rem (after portrait), right:1rem
	var nameBlock = $('<div class="bf-bro-name-block"/>');
	nameBlock.append($('<div class="bf-bro-name"/>').text(bro.Name));
	nameBlock.append($('<div class="bf-bro-title"/>').text(bro.BackgroundName || bro.Title || ''));
	nameBlock.append($('<div class="bf-bro-level"/>').text('Level ' + bro.Level + (bro.LevelUps > 0 ? ' (+' + bro.LevelUps + ')' : '')));
	header.append(nameBlock);

	// Action buttons — below portrait
	var btnContainer = $('<div/>').css({
		'position': 'absolute',
		'left': '0',
		'top': '5.8rem',
		'height': '3rem',
		'width': '40rem'
	});
	header.append(btnContainer);

	var opHeaderLayout = $('<div/>').css({ 'position': 'absolute', 'left': '0', 'width': '12rem', 'height': '3rem' });
	btnContainer.append(opHeaderLayout);
	opHeaderLayout.createTextButton('Oblivion Potion', function() { self.onResetPerks(); }, '', 1);

	var yfBtnLayout = $('<div/>').css({ 'position': 'absolute', 'left': '13rem', 'width': '11rem', 'height': '3rem' });
	btnContainer.append(yfBtnLayout);
	yfBtnLayout.createTextButton('Youth Fountain', function() { self.onGiveYF(); }, '', 1);

	var xpBtnLayout = $('<div/>').css({ 'position': 'absolute', 'left': '25rem', 'width': '6rem', 'height': '3rem' });
	btnContainer.append(xpBtnLayout);
	xpBtnLayout.createTextButton('+1 Level', function() { self.onGiveXP(); }, '', 1);

	this.mContentPanel.append(header);

	// Two-column layout: stats left, bio right
	var twoCol = $('<div class="bf-two-col"/>');
	this.mContentPanel.append(twoCol);

	// Stats area — left side
	var statsArea = $('<div class="bf-stats-area"/>');
	twoCol.append(statsArea);

	// 8 base stats with talent buttons
	for (var i = 0; i < BF_STAT_NAMES.length; i++)
	{
		var sn = BF_STAT_NAMES[i];
		if (!(sn in bro) || !bro[sn]) continue;
		this.bfCreateStatRow(statsArea, sn, bro[sn]);
	}

	// Level row (read-only)
	this.bfCreateSimpleRow(statsArea, 'Level', bro.Level, this.mStatsOptions.Level, true);
	// XP row (read-only)
	this.bfCreateSimpleRow(statsArea, 'XpValue', bro.XpValue, this.mStatsOptions.XpValue, true);
	// PP row
	this.bfCreateSimpleRow(statsArea, 'PerkPoints', bro.PerkPoints, this.mStatsOptions.PerkPoints);
	// AP row — read-only
	this.bfCreateSimpleRow(statsArea, 'ActionPoints', bro.ActionPoints, this.mStatsOptions.ActionPoints);
	// Wage row
	this.bfCreateSimpleRow(statsArea, 'DailyWage', bro.DailyWage, this.mStatsOptions.DailyWage);

	// Morale row
	var moraleRow = $('<div class="bf-stat-row bf-no-stars"/>');
	statsArea.append(moraleRow);
	var moraleIcon = $('<div class="bf-stat-icon"/>');
	moraleIcon.append($('<img/>').attr('src', Path.GFX + 'ui/icons/morale.png'));
	moraleRow.append(moraleIcon);

	var moraleStates = ['Angry', 'Disgruntled', 'Dissatisfied', 'Content', 'In good spirit', 'Eager', 'Euphoric'];
	var moraleColors = { 'Angry': '#c03030', 'Disgruntled': '#c06030', 'Dissatisfied': '#c0a030', 'Content': '#a0a080', 'In good spirit': '#70a060', 'Eager': '#50a050', 'Euphoric': '#30c030' };
	var currentMorale = bro.MoraleLabel || 'Content';

	var moraleWrap = $('<div class="bf-morale-wrap"/>');
	moraleRow.append(moraleWrap);

	for (var mi = 0; mi < moraleStates.length; mi++)
	{
		var makeMoraleBtn = function(state)
		{
			var btn = $('<div class="bf-morale-btn"/>').text(state);
			btn.css('color', moraleColors[state]);
			if (state === currentMorale) btn.addClass('is-active');
			btn.on('click', function()
			{
				SQ.call(self.mSQHandle, 'onSetMorale', { BroId: BFModel.selectedBroId, MoraleName: state }, function(_result)
				{
					if (_result && _result.Success)
					{
						BFModel.selectedBro.Morale = _result.Morale;
						BFModel.selectedBro.MoraleLabel = _result.MoraleLabel;
						moraleWrap.find('.bf-morale-btn').removeClass('is-active');
						btn.addClass('is-active');
					}
				});
			});
			moraleWrap.append(btn);
		};
		makeMoraleBtn(moraleStates[mi]);
	}

	// Bio panel — right side
	var bioPanel = $('<div class="bf-bio-panel"/>');
	twoCol.append(bioPanel);
	bioPanel.append($('<div class="bf-export-subtitle"/>').text('Biography'));
	var bioDisplay = $('<div class="bf-bio-display"/>');
	bioPanel.append(bioDisplay);

	SQ.call(this.mSQHandle, 'queryBio', {
		BroId: BFModel.selectedBroId
	}, function(_result)
	{
		var bioText = (_result && _result.Bio) ? _result.Bio : '';
		if (bioText)
			bioDisplay.html(bioText.replace(/\n/g, '<br>'));
		else
			bioDisplay.html('<span class="bf-bio-empty">No biography.</span>');

		// Edit input below display
		var inputWrap = $('<div class="l-input bf-bio-input"/>');
		bioPanel.append(inputWrap);
		var initText = bioText.replace(/\n/g, ' ');
		inputWrap.createInput(initText, 0, 5000, null, null, 'title-font-medium font-color-brother-name', function(_input)
		{
			var text = _input.getInputText();
			if (text && text !== '')
				self.onSaveBio(text, bioDisplay, _input);
		});
		var realInput = inputWrap.find('input');
		realInput.on('keydown', function(e) { e.stopPropagation(); });
		realInput.on('keyup', function(e) { e.stopPropagation(); });

		bioPanel.append($('<div class="bf-bio-hint"/>').text('Enter to save | use \\n for line breaks | for longer text, write in a .txt and paste here'));
	});
};

// =====================================================================
// Stat row — vanilla createInput(7 params) + mousedown strip + accept on blur/Enter
// =====================================================================
BBForgeScreen.prototype.bfCreateStatRow = function(_parent, _key, _statData)
{
	var self = this;
	var row = $('<div class="bf-stat-row"/>');
	_parent.append(row);

	var opts = this.mStatsOptions[_key];

	// Icon
	var iconLayout = $('<div class="bf-stat-icon"/>');
	var iconImg = $('<img/>').attr('src', opts.IconPath);
	iconLayout.append(iconImg);
	iconImg.bindTooltip({ contentType: 'ui-element', elementId: opts.TooltipId });
	row.append(iconLayout);

	var inputLayout = $('<div class="l-input"/>');
	row.append(inputLayout);

	var key = _key;
	var accepting = false;
	var acceptStat = function(_input)
	{
		if (accepting) return;
		accepting = true;
		var val = parseInt(_input.val(), 10);
		var cur = BFModel.selectedBro && BFModel.selectedBro[key];

		if (!isNaN(val) && cur && val !== cur.Max)
		{
			SQ.call(self.mSQHandle, 'onChangeAttributes', {
				BroId: BFModel.selectedBroId,
				StatName: key,
				Value: val
			});
			SQ.call(self.mSQHandle, 'BDUpdateAttributes', {
				BroId: BFModel.selectedBroId
			}, function(_result)
			{
				if (_result && key in _result && BFModel.selectedBro)
				{
					BFModel.selectedBro[key].Max = _result[key].Max;
					BFModel.selectedBro[key].MaxPlus = _result[key].MaxPlus;
					BFModel.selectedBro[key].BLimit = _result[key].BLimit;
					realInput.val(_result[key].Max + ' (' + _result[key].MaxPlus + ') / ' + _result[key].BLimit);
				}
				accepting = false;
			});
		}
		else
		{
			if (cur) _input.val(cur.Max + ' (' + cur.MaxPlus + ') / ' + cur.BLimit);
			accepting = false;
		}
	};

	var sval = inputLayout.createInput('', 0, 30, null, null, 'title-font-medium font-bold font-color-brother-name',
		function(_input) { acceptStat(_input); }
	);

	// Set initial display text (bypass maxLength via .val() directly)
	var realInput = inputLayout.find('input');
	realInput.val(_statData.Max + ' (' + _statData.MaxPlus + ') / ' + _statData.BLimit);

	// mousedown handler — force focus + strip to base value
	realInput.on('mousedown', function(e)
	{
		e.stopPropagation();
		var inp = $(this);
		setTimeout(function()
		{
			inp.focus();
			var text = inp.val();
			var space = text.indexOf(' ');
			if (space > 0)
			{
				inp.val(text.slice(0, space));
			}
			inp[0].select();
		}, 10);
	});

	// focusout — save on click-away (no inputid=2 to avoid visual border)
	realInput.on('focusout', function() { acceptStat($(this)); });

	// Talent button
	var talentLayout = $('<div class="l-talent-button-container"/>');
	row.append(talentLayout);

	var curTalent = _statData.Talent || 0;
	var NStars = '';
	for (var s = 0; s < curTalent; s++) { NStars += '*'; }

	var talentBtn = talentLayout.createTextButton(NStars, function()
	{
		var bro = BFModel.selectedBro;
		if (!bro || !bro[key]) return;
		var newTalent = (bro[key].Talent >= 3) ? 0 : (bro[key].Talent + 1);
		bro[key].Talent = newTalent;
		var stars = '';
		for (var s = 0; s < newTalent; s++) { stars += '*'; }
		talentBtn.changeButtonText(stars);
		SQ.call(self.mSQHandle, 'onChangeTalents', {
			BroId: BFModel.selectedBroId,
			StatName: key,
			TalentValue: newTalent
		});
	}, 'font-bold', 8);
	talentBtn.bindTooltip({ contentType: 'ui-element', elementId: 'bf-talent-tooltip' });
};

// Simple value row (PP, Wage, XP, Level, AP) — vanilla createInput, single number
// _readOnly: if true, accept callback just resets value (no SQ.call)
BBForgeScreen.prototype.bfCreateSimpleRow = function(_parent, _key, _value, _opts, _readOnly)
{
	var self = this;
	var row = $('<div class="bf-stat-row bf-no-stars"/>');
	_parent.append(row);

	var iconLayout = $('<div class="bf-stat-icon"/>');
	var iconImg = $('<img/>').attr('src', _opts.IconPath);
	iconLayout.append(iconImg);
	iconImg.bindTooltip({ contentType: 'ui-element', elementId: _opts.TooltipId });
	row.append(iconLayout);

	var inputLayout = $('<div class="l-input"/>');
	row.append(inputLayout);

	var key = _key;
	var initValue = _value;
	var accepting = false;
	var acceptSimple = function(_input)
	{
		if (accepting) return;
		if (_readOnly)
		{
			_input.val(String(initValue));
			return;
		}
		accepting = true;

		var val = parseInt(_input.val(), 10);
		var curVal = BFModel.selectedBro ? BFModel.selectedBro[key] : _value;

		if (!isNaN(val) && val !== curVal)
		{
			SQ.call(self.mSQHandle, 'onChangeAttributes', {
				BroId: BFModel.selectedBroId,
				StatName: key,
				Value: val
			});
			SQ.call(self.mSQHandle, 'BDUpdateAttributes', {
				BroId: BFModel.selectedBroId
			}, function(_result)
			{
				if (_result && key in _result && BFModel.selectedBro)
				{
					BFModel.selectedBro[key] = _result[key];
					_input.val(String(_result[key]));
				}
				accepting = false;
			});
		}
		else
		{
			_input.val(String(curVal));
			accepting = false;
		}
	};

	var sval = inputLayout.createInput('', 0, 10, null, null, 'title-font-medium font-bold font-color-brother-name',
		function(_input) { acceptSimple(_input); }
	);

	// Set initial value + force focus on mousedown
	var realInput = inputLayout.find('input');
	realInput.val(String(_value));
	realInput.on('mousedown', function(e)
	{
		e.stopPropagation();
		var inp = $(this);
		setTimeout(function()
		{
			inp.focus();
			inp[0].select();
		}, 10);
	});

	// focusout — save on click-away
	if (!_readOnly) realInput.on('focusout', function() { acceptSimple($(this)); });
};

// =====================================================================
// STATS ACTION BUTTONS (XP, Youth Fountain, Oblivion Potion)
// =====================================================================
BBForgeScreen.prototype.onGiveXP = function()
{
	if (BFModel.selectedBroId === null) return;

	var self = this;
	SQ.call(this.mSQHandle, 'onGiveXP', {
		BroId: BFModel.selectedBroId
	}, function(_result)
	{
		if (_result !== null && BFModel.selectedBro !== null)
		{
			BFModel.selectedBro.Level = _result.Level;
			BFModel.selectedBro.LevelUps = _result.LevelUps;
			BFModel.selectedBro.PerkPoints = _result.PerkPoints;
			BFModel.selectedBro.XpValue = _result.XpValue;
			BFModel.selectedBro.DailyWage = _result.DailyWage;
			if (BFModel.selectedBro.BroLevel)
			{
				BFModel.selectedBro.BroLevel.text('Lvl ' + _result.Level);
			}
			self.createStatsPanel();
		}
	});
};

BBForgeScreen.prototype.onGiveYF = function()
{
	if (BFModel.selectedBroId === null) return;

	var self = this;
	SQ.call(this.mSQHandle, 'onGiveYF', {
		BroId: BFModel.selectedBroId
	}, function(_result)
	{
		if (_result !== null && BFModel.selectedBro !== null)
		{
			BFModel.selectedBro.Level = _result.Level;
			BFModel.selectedBro.LevelUps = _result.LevelUps;
			BFModel.selectedBro.PerkPoints = _result.PerkPoints;
			BFModel.selectedBro.XpValue = _result.XpValue;
			if (BFModel.selectedBro.BroLevel)
			{
				BFModel.selectedBro.BroLevel.text('Lvl ' + _result.Level);
			}
			self.createStatsPanel();
		}
	});
};

BBForgeScreen.prototype.onResetPerks = function()
{
	if (BFModel.selectedBroId === null) return;

	var self = this;
	SQ.call(this.mSQHandle, 'onResetPerks', {
		BroId: BFModel.selectedBroId
	}, function(_result)
	{
		if (_result !== null && BFModel.selectedBro !== null)
		{
			BFModel.selectedBro.PerkPoints = _result.PerkPoints;
			self.createStatsPanel();
		}
	});
};

// =====================================================================
// BIOGRAPHY
// =====================================================================
BBForgeScreen.prototype.onSaveBio = function(_text, _display, _input)
{
	if (BFModel.selectedBroId === null) return;

	// Convert literal \n typed by user into real newlines
	var bio = _text.replace(/\\n/g, '\n');

	SQ.call(this.mSQHandle, 'onSaveBio', {
		BroId: BFModel.selectedBroId,
		Bio: bio
	}, function(_result)
	{
		if (_result && _result.Success)
		{
			if (_display)
				_display.html(bio.replace(/\n/g, '<br>'));
			_input.setInputText(bio.replace(/\n/g, ' '));
		}
	});
};

// =====================================================================
// PERKS PANEL — 2-state: owned (gold border) / not owned (dim)
// =====================================================================
BBForgeScreen.prototype.createPerksPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var self = this;

	var searchWrap = $('<div class="bf-search-wrap"/>');
	var searchBar = $('<input class="bf-search-bar" type="text" placeholder="Search perks..."/>');
	searchWrap.append(searchBar);
	this.mContentPanel.append(searchWrap);

	// Tier filter buttons
	var filterWrap = $('<div class="bf-filter-bar"/>');
	var activeTier = 0; // 0 = all
	var tierBtns = [];
	var allBtn = $('<div class="bf-filter-btn is-active"/>').text('All');
	filterWrap.append(allBtn);
	tierBtns.push({ el: allBtn, tier: 0 });
	for (var t = 1; t <= 7; t++)
	{
		var btn = $('<div class="bf-filter-btn"/>').text('T' + t).attr('data-tier', t);
		filterWrap.append(btn);
		tierBtns.push({ el: btn, tier: t });
	}
	this.mContentPanel.append(filterWrap);

	var loading = $('<div class="bf-empty-state"/>').text('Loading perks...');
	this.mContentPanel.append(loading);

	SQ.call(this.mSQHandle, 'queryPerks', { BroId: BFModel.selectedBroId }, function(_data)
	{
		loading.remove();

		if (_data === null || !_data.Categories)
		{
			self.mContentPanel.append($('<div class="bf-empty-state"/>').text('Failed to load perk data.'));
			return;
		}

		var allIcons = [];
		var allHeaders = [];
		var allGrids = [];

		for (var i = 0; i < _data.Categories.length; i++)
		{
			var cat = _data.Categories[i];
			var header = $('<div class="bf-section-header"/>').text(cat.Name + ' (' + cat.Perks.length + ')');
			self.mContentPanel.append(header);
			allHeaders.push({ el: header, catIndex: i });

			var grid = $('<div class="bf-icon-grid"/>');

			for (var j = 0; j < cat.Perks.length; j++)
			{
				var perk = cat.Perks[j];
				var iconEl = self.createPerkIcon(perk);
				grid.append(iconEl);
				allIcons.push({ el: iconEl, perk: perk, catIndex: i });
			}

			self.mContentPanel.append(grid);
			allGrids.push({ el: grid, catIndex: i });
		}

		// Combined filter function (search + tier)
		var applyFilters = function()
		{
			var q = searchBar.val().toLowerCase();
			var visiblePerCat = {};

			for (var k = 0; k < allIcons.length; k++)
			{
				var id = allIcons[k].perk.ID.toLowerCase();
				var row = allIcons[k].perk.Row || 0;
				var ci = allIcons[k].catIndex;
				var matchSearch = (q === '' || id.indexOf(q) !== -1);
				var matchTier = (activeTier === 0 || row === activeTier);

				if (matchSearch && matchTier)
				{
					allIcons[k].el.show();
					visiblePerCat[ci] = true;
				}
				else
				{
					allIcons[k].el.hide();
				}
			}

			// Hide empty category headers and grids
			for (var h = 0; h < allHeaders.length; h++)
			{
				if (visiblePerCat[allHeaders[h].catIndex])
					allHeaders[h].el.show();
				else
					allHeaders[h].el.hide();
			}
			for (var g = 0; g < allGrids.length; g++)
			{
				if (visiblePerCat[allGrids[g].catIndex])
					allGrids[g].el.show();
				else
					allGrids[g].el.hide();
			}
		};

		searchBar.on('keyup change', applyFilters);

		for (var ti = 0; ti < tierBtns.length; ti++)
		{
			(function(tb) {
				tb.el.on('click', function()
				{
					activeTier = tb.tier;
					filterWrap.find('.bf-filter-btn').removeClass('is-active');
					tb.el.addClass('is-active');
					applyFilters();
				});
			})(tierBtns[ti]);
		}
	});
};

// Perk icon — 2-state: owned (gold border, is-owned) / not owned (dim, is-available)
// Single click toggles between owned and not owned.
BBForgeScreen.prototype.createPerkIcon = function(_perk)
{
	var self = this;
	var icon = $('<div class="bf-icon"/>');
	icon.attr('title', _perk.ID);

	if (_perk.IsOwned)
		icon.addClass('is-owned');
	else
		icon.addClass('is-available');

	if (_perk.Icon && _perk.Icon !== '')
		icon.append($('<img/>').attr('src', Path.GFX + _perk.Icon).attr('alt', _perk.ID));

	icon.bindTooltip({ contentType: 'ui-perk', entityId: BFModel.fakeBroId, perkId: _perk.ID });

	icon.on('click', function()
	{
		if (_perk.IsOwned)
		{
			// Gold -> dim: remove perk
			_perk.IsOwned = false;
			$(this).removeClass('is-owned').addClass('is-available');
			self.onTogglePerk(_perk.ID, false, _perk.Row || 0);
		}
		else
		{
			// Dim -> gold: add perk
			_perk.IsOwned = true;
			$(this).removeClass('is-available').addClass('is-owned');
			self.onTogglePerk(_perk.ID, true, _perk.Row || 0);
		}
	});

	return icon;
};

BBForgeScreen.prototype.onTogglePerk = function(_perkId, _add, _row)
{
	if (BFModel.selectedBroId === null) return;

	var self = this;
	SQ.call(this.mSQHandle, 'onTogglePerk', {
		BroId: BFModel.selectedBroId,
		PerkId: _perkId,
		Add: _add,
		Row: _row || 0
	}, function(_result)
	{
		if (_result !== null && BFModel.selectedBro !== null)
		{
			BFModel.selectedBro.PerkPoints = _result.PerkPoints;
		}
	});
};

// =====================================================================
// TRAITS PANEL — Character Traits + Permanent Injuries (no Active Effects)
// =====================================================================
BBForgeScreen.prototype.createTraitsPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var self = this;

	var searchWrap = $('<div class="bf-search-wrap"/>');
	var searchBar = $('<input class="bf-search-bar" type="text" placeholder="Search traits & injuries..."/>');
	searchWrap.append(searchBar);
	this.mContentPanel.append(searchWrap);

	var loading = $('<div class="bf-empty-state"/>').text('Loading traits...');
	this.mContentPanel.append(loading);

	SQ.call(this.mSQHandle, 'queryTraits', { BroId: BFModel.selectedBroId }, function(_data)
	{
		loading.remove();

		if (_data === null || !_data.Traits)
		{
			self.mContentPanel.append($('<div class="bf-empty-state"/>').text('Failed to load trait data.'));
			return;
		}

		// Split into traits and injuries only (no active effects section)
		var traits = [];
		var injuries = [];
		var ownedTraits = 0;
		var ownedInjuries = 0;
		for (var i = 0; i < _data.Traits.length; i++)
		{
			var t = _data.Traits[i];
			if (t.Section === 'injury')
			{
				injuries.push(t);
				if (t.IsOwned) ownedInjuries++;
			}
			else if (t.Section !== 'effect')
			{
				traits.push(t);
				if (t.IsOwned) ownedTraits++;
			}
		}

		var allIcons = [];

		// Character Traits section
		self.mContentPanel.append($('<div class="bf-section-header"/>').text('Character Traits (' + ownedTraits + ' active)'));
		var traitGrid = $('<div class="bf-icon-grid"/>');
		for (var i = 0; i < traits.length; i++)
		{
			var iconEl = self.createTraitIcon(traits[i]);
			traitGrid.append(iconEl);
			allIcons.push({ el: iconEl, trait: traits[i] });
		}
		self.mContentPanel.append(traitGrid);

		// Permanent Injuries section
		self.mContentPanel.append($('<div class="bf-section-header bf-injury-header"/>').text('Permanent Injuries (' + ownedInjuries + ' active)'));
		var injuryGrid = $('<div class="bf-icon-grid"/>');
		for (var i = 0; i < injuries.length; i++)
		{
			var iconEl = self.createTraitIcon(injuries[i]);
			injuryGrid.append(iconEl);
			allIcons.push({ el: iconEl, trait: injuries[i] });
		}
		self.mContentPanel.append(injuryGrid);

		searchBar.on('keyup change', function()
		{
			var q = $(this).val().toLowerCase();
			for (var k = 0; k < allIcons.length; k++)
			{
				var id = allIcons[k].trait.ID.toLowerCase();
				var name = (allIcons[k].trait.Name || '').toLowerCase();
				if (q === '' || id.indexOf(q) !== -1 || name.indexOf(q) !== -1)
					allIcons[k].el.show();
				else
					allIcons[k].el.hide();
			}
		});
	});
};

BBForgeScreen.prototype.createTraitIcon = function(_trait)
{
	var self = this;
	var icon = $('<div class="bf-icon"/>');
	icon.attr('title', _trait.Name || _trait.ID);

	if (_trait.IsOwned)
		icon.addClass('is-owned');
	else
		icon.addClass('is-available');

	if (_trait.Icon && _trait.Icon !== '')
		icon.append($('<img/>').attr('src', Path.GFX + _trait.Icon).attr('alt', _trait.ID));

	// Add overlay label for missing_hand variants
	if (_trait.ID === 'injury.missing_hand_left')
		icon.append($('<span class="bf-icon-label">L</span>'));
	else if (_trait.ID === 'injury.missing_hand_right')
		icon.append($('<span class="bf-icon-label">R</span>'));

	// Tooltip — uses bf-skill-tooltip handler in SQ preload
	var tooltipOwner = (_trait.Script && _trait.Script !== '') ? (_trait.Script + '|' + BFModel.selectedBroId) : ('id:' + _trait.ID + '|' + BFModel.selectedBroId);
	icon.bindTooltip({ contentType: 'ui-element', elementId: 'bf-skill-tooltip', elementOwner: tooltipOwner });

	icon.on('click', function()
	{
		var isNowOwned = !_trait.IsOwned;
		_trait.IsOwned = isNowOwned;
		$(this).toggleClass('is-owned is-available');
		self.onToggleTrait(_trait.ID, _trait.Script, isNowOwned);
	});

	return icon;
};

BBForgeScreen.prototype.onToggleTrait = function(_traitId, _traitScript, _add)
{
	if (BFModel.selectedBroId === null) return;

	SQ.call(this.mSQHandle, 'onToggleTrait', {
		BroId: BFModel.selectedBroId,
		TraitId: _traitId,
		TraitScript: _traitScript,
		Add: _add
	}, function(_result) {});
};

// =====================================================================
// BACKGROUNDS PANEL — grid with search, no monster transform
// =====================================================================
BBForgeScreen.prototype.createBackgroundsPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var self = this;

	var searchWrap = $('<div class="bf-search-wrap"/>');
	var searchBar = $('<input class="bf-search-bar" type="text" placeholder="Search backgrounds..."/>');
	searchWrap.append(searchBar);
	this.mContentPanel.append(searchWrap);

	this.mContentPanel.append($('<div class="bf-bg-warning"/>').text('Changing background preserves XP, Level, Perk Points, and existing perks.'));

	var loading = $('<div class="bf-empty-state"/>').text('Loading backgrounds...');
	this.mContentPanel.append(loading);

	SQ.call(this.mSQHandle, 'queryBackgrounds', { BroId: BFModel.selectedBroId }, function(_data)
	{
		loading.remove();

		if (_data === null || !_data.Backgrounds)
		{
			self.mContentPanel.append($('<div class="bf-empty-state"/>').text('Failed to load background data.'));
			return;
		}

		var grid = $('<div class="bf-bg-grid"/>');
		var allItems = [];

		for (var i = 0; i < _data.Backgrounds.length; i++)
		{
			var bg = _data.Backgrounds[i];
			var item = self.createBackgroundItem(bg);
			grid.append(item);
			allItems.push({ el: item, bg: bg });
		}

		self.mContentPanel.append(grid);

		searchBar.on('keyup change', function()
		{
			var q = $(this).val().toLowerCase();
			for (var k = 0; k < allItems.length; k++)
			{
				var name = allItems[k].bg.Name.toLowerCase();
				var id = allItems[k].bg.ID.toLowerCase();
				if (q === '' || name.indexOf(q) !== -1 || id.indexOf(q) !== -1)
					allItems[k].el.show();
				else
					allItems[k].el.hide();
			}
		});
	});
};

BBForgeScreen.prototype.createBackgroundItem = function(_bg)
{
	var self = this;
	var item = $('<div class="bf-bg-item"/>');

	if (_bg.IsCurrent)
		item.addClass('is-current');

	var img = $('<div class="bf-bg-img"/>');
	if (_bg.Icon && _bg.Icon !== '')
		img.append($('<img/>').attr('src', Path.GFX + _bg.Icon).attr('alt', _bg.Name));
	else
		img.append($('<div class="bf-bg-letter"/>').text(_bg.Name ? _bg.Name.charAt(0) : '?'));
	item.append(img);

	item.append($('<div class="bf-bg-name"/>').text(_bg.Name));

	item.on('click', function()
	{
		if (_bg.IsCurrent) return;
		self.onChangeBackground(_bg);
	});

	// Background tooltip — uses bf-bg-tooltip handler in SQ preload
	img.bindTooltip({ contentType: 'ui-element', elementId: 'bf-bg-tooltip', elementOwner: _bg.Script });

	return item;
};

BBForgeScreen.prototype.onChangeBackground = function(_bg)
{
	if (BFModel.selectedBroId === null) return;

	var self = this;
	SQ.call(this.mSQHandle, 'onChangeBackground', {
		BroId: BFModel.selectedBroId,
		BgScript: _bg.Script
	}, function(_result)
	{
		if (_result !== null && BFModel.selectedBro !== null)
		{
			BFModel.selectedBro.Background = _result.BackgroundID;
			BFModel.selectedBro.BackgroundName = _result.BackgroundName;
			BFModel.selectedBro.BackgroundImagePath = _result.BackgroundImagePath;
			self.createBackgroundsPanel();
		}
	});
};

// =====================================================================
// ITEMS PANEL — icon + slot label + name (gold=named) + condition bar
// =====================================================================
BBForgeScreen.prototype.createItemsPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var self = this;

	var panel = $('<div class="bf-items-panel"/>');
	this.mContentPanel.append(panel);

	// ===========================
	// LEFT: Equipment Slots
	// ===========================
	var leftCol = $('<div class="bf-items-left"/>');
	panel.append(leftCol);

	var toolbar = $('<div class="bf-items-toolbar"/>');
	leftCol.append(toolbar);

	var equipLabel = $('<div class="bf-items-label"/>').text('Equipment');
	toolbar.append(equipLabel);

	var unequipAllBtn = $('<div class="bf-stash-tool-btn"/>').text('Unequip All');
	toolbar.append(unequipAllBtn);

	var repairBtn = $('<div class="bf-stash-tool-btn"/>').text('Repair All');
	toolbar.append(repairBtn);

	var slotsContainer = $('<div class="bf-items-slots"/>');
	leftCol.append(slotsContainer);

	// ===========================
	// RIGHT: Item Catalog
	// ===========================
	var rightCol = $('<div class="bf-items-right"/>');
	panel.append(rightCol);

	rightCol.append($('<div class="bf-stash-catalog-title"/>').text('Equip Item'));

	var searchWrap = $('<div class="bf-stash-search-wrap"/>');
	var searchInput = $('<input class="bf-stash-search" type="text"/>');
	searchWrap.append(searchInput);
	rightCol.append(searchWrap);

	var filterBar = $('<div class="bf-stash-filters"/>');
	var categories = ['All', 'Melee', 'Ranged', 'Shield', 'Armor', 'Helmet', 'Accessory', 'Supply', 'Usable', 'Misc'];
	var activeFilter = 'All';

	for (var c = 0; c < categories.length; c++)
	{
		var makeCatBtn = function(cat)
		{
			var btn = $('<div class="bf-stash-filter-btn"/>').text(cat);
			if (cat === 'All') btn.addClass('is-active');
			btn.on('click', function()
			{
				activeFilter = cat;
				filterBar.find('.bf-stash-filter-btn').removeClass('is-active');
				$(this).addClass('is-active');
				searchCatalog();
			});
			filterBar.append(btn);
		};
		makeCatBtn(categories[c]);
	}
	rightCol.append(filterBar);

	var catalogList = $('<div class="bf-stash-catalog-list"/>');
	rightCol.append(catalogList);

	var catalogStatus = $('<div class="bf-stash-catalog-status"/>');
	rightCol.append(catalogStatus);

	// ===========================
	// Equipment refresh
	// ===========================
	var refreshEquipment = function()
	{
		SQ.call(self.mSQHandle, 'queryItems', { BroId: BFModel.selectedBroId }, function(_data)
		{
			slotsContainer.empty();
			if (!_data || !_data.Slots)
			{
				slotsContainer.append($('<div class="bf-empty-state"/>').text('Failed to load equipment.'));
				return;
			}

			for (var i = 0; i < _data.Slots.length; i++)
			{
				var makeSlot = function(slot)
				{
					var row = $('<div class="bf-items-slot"/>');

					// Icon
					var iconWrap = $('<div class="bf-items-slot-icon"/>');
					if (slot.HasItem && slot.Icon && slot.Icon !== '')
					{
						var img = $('<img class="bf-items-slot-img"/>');
						img.attr('src', Path.GFX + 'ui/items/' + slot.Icon);
						img[0].onerror = function()
						{
							$(this).replaceWith($('<div class="bf-items-slot-fallback"/>').text('?'));
						};
						iconWrap.append(img);

						if (slot.Overlays)
						{
							for (var ov = 0; ov < slot.Overlays.length; ov++)
							{
								if (slot.Overlays[ov] && slot.Overlays[ov] !== '')
									iconWrap.append($('<img class="bf-items-slot-overlay"/>').attr('src', Path.GFX + 'ui/items/' + slot.Overlays[ov]));
							}
						}
					}
					row.append(iconWrap);

					// Slot label
					row.append($('<div class="bf-items-slot-label"/>').text(slot.Slot));

					// Item name
					var nameEl = $('<div class="bf-items-slot-name"/>');
					if (!slot.HasItem)
					{
						nameEl.addClass('is-empty').text('(empty)');
					}
					else
					{
						nameEl.text(slot.Name);
						if (slot.IsNamed) nameEl.addClass('is-named');
					}
					row.append(nameEl);

					// Condition
					if (slot.HasItem && slot.ConditionMax > 0)
					{
						var pct = Math.max(0, Math.min(1, slot.Condition / slot.ConditionMax));
						var color = pct > 0.6 ? '#5a9a5a' : (pct > 0.3 ? '#c8a020' : '#9a3030');
						var condBar = $('<div class="bf-items-slot-condbar"/>');
						condBar.append($('<div class="bf-items-slot-condfill"/>').css({ 'width': Math.round(pct * 100) + '%', 'background': color }));
						row.append(condBar);

						row.append($('<div class="bf-items-slot-condtext"/>').text(slot.Condition + ' / ' + slot.ConditionMax));
					}

					// Unequip button
					if (slot.HasItem)
					{
						var unBtn = $('<div class="bf-items-slot-unequip"/>').text('\u00D7');
						var slotName = slot.Slot;
						var bagIndex = slot.BagIndex !== undefined ? slot.BagIndex : -1;
						unBtn.on('click', function(e)
						{
							e.stopPropagation();
							var params = { BroId: BFModel.selectedBroId };
							if (slotName.indexOf('Bag') === 0)
							{
								params.SlotName = 'Bag';
								params.BagIndex = bagIndex;
							}
							else
							{
								params.SlotName = slotName;
							}
							SQ.call(self.mSQHandle, 'onUnequipSlot', params, function() { refreshEquipment(); });
						});
						row.append(unBtn);

						// Tooltip
						var tooltipSlot = slotName;
						var tooltipBagIdx = -1;
						if (slotName.indexOf('Bag') === 0)
						{
							tooltipSlot = 'Bag';
							tooltipBagIdx = bagIndex;
						}
						row.bindTooltip({ contentType: 'ui-element', elementId: 'bf-stash-tooltip', elementOwner: 'equip|' + BFModel.selectedBroId + '|' + tooltipSlot + '|' + tooltipBagIdx });
					}

					slotsContainer.append(row);
				};
				makeSlot(_data.Slots[i]);
			}
		});
	};

	// ===========================
	// Catalog search
	// ===========================
	var searchTimer = null;
	var searchCatalog = function()
	{
		var q = searchInput.val();
		catalogList.empty();
		catalogStatus.text('Searching...');

		SQ.call(self.mSQHandle, 'queryItemCatalog', { Search: q, Category: activeFilter }, function(_data)
		{
			catalogList.empty();

			if (!_data || !_data.Items)
			{
				catalogStatus.text('Failed to load catalog.');
				return;
			}

			var total = _data.Total;
			var shown = Math.min(total, 200);
			catalogStatus.text(total + ' items' + (total > shown ? ' (showing first ' + shown + ')' : '') + ' — catalog: ' + _data.CatalogSize);

			for (var i = 0; i < shown; i++)
			{
				var makeRow = function(item)
				{
					var row = $('<div class="bf-stash-catalog-row"/>');
					row.bindTooltip({ contentType: 'ui-element', elementId: 'bf-stash-tooltip', elementOwner: 'catalog|' + item.Script });

					var icon = $('<div class="bf-stash-catalog-icon"/>');
					if (item.Icon && item.Icon !== '')
						icon.append($('<img/>').attr('src', Path.GFX + 'ui/items/' + item.Icon));
					row.append(icon);

					row.append($('<div class="bf-stash-catalog-name"/>').text(item.Name));

					row.append($('<div class="bf-stash-catalog-cat"/>').text(item.Cat));

					var addBtn = $('<div class="bf-stash-catalog-add"/>').text('+');
					addBtn.on('click', function(e)
					{
						e.stopPropagation();
						SQ.call(self.mSQHandle, 'onEquipItemOnBro', { BroId: BFModel.selectedBroId, Script: item.Script }, function(_result)
						{
							if (_result && _result.Success)
								refreshEquipment();
							else
								equipLabel.text('Equipment (equip failed)');
						});
					});
					row.append(addBtn);

					catalogList.append(row);
				};
				makeRow(_data.Items[i]);
			}
		});
	};

	// ===========================
	// Toolbar actions
	// ===========================
	repairBtn.on('click', function()
	{
		SQ.call(self.mSQHandle, 'onRepairBroItems', { BroId: BFModel.selectedBroId }, function() { refreshEquipment(); });
	});

	unequipAllBtn.on('click', function()
	{
		SQ.call(self.mSQHandle, 'onUnequipAllFromBro', { BroId: BFModel.selectedBroId }, function() { refreshEquipment(); });
	});

	// Search input handling
	searchInput.on('keydown', function(e) { e.stopPropagation(); });
	searchInput.on('keyup', function(e)
	{
		e.stopPropagation();
		if (searchTimer) clearTimeout(searchTimer);
		searchTimer = setTimeout(searchCatalog, 250);
	});

	// Mousewheel fix for Coherent GT nested scroll containers
	var wireScroll = function(jqEl)
	{
		var el = jqEl[0];
		var handler = function(evt)
		{
			evt.stopPropagation();
			evt.preventDefault();
			var delta = evt.deltaY !== undefined ? evt.deltaY : (-evt.wheelDelta || 0);
			el.scrollTop += (delta > 0 ? 1 : -1) * 50;
		};
		el.addEventListener('wheel', handler, false);
		el.addEventListener('mousewheel', handler, false);
	};
	wireScroll(slotsContainer);
	wireScroll(catalogList);

	self.mContentPanel[0].addEventListener('wheel', function(evt)
	{
		evt.preventDefault();
	}, false);

	// Initial load
	refreshEquipment();
	searchCatalog();
};

// =====================================================================
// APPEARANCE PANEL (barber-style) — vanilla: human male only
// =====================================================================

BBForgeScreen.prototype.createAppearancePanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBroId === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother first.'));
		return;
	}

	var self = this;
	SQ.call(this.mSQHandle, 'queryAppearance', { BroId: BFModel.selectedBroId }, function(_data)
	{
		if (_data === null)
		{
			self.mContentPanel.empty();
			self.mContentPanel.append($('<div class="bf-empty-state"/>').text('Could not load appearance data.'));
			return;
		}
		self.buildAppearanceUI(_data);
	});
};

BBForgeScreen.prototype.buildAppearanceUI = function(_data)
{
	this.mContentPanel.empty();

	var panel = $('<div class="bf-app-panel"/>');
	this.mContentPanel.append(panel);

	var self = this;

	// Stored reference to the portrait image element (updated via attr, like the barber)
	var portraitImage = null;

	// Refresh the preview portrait — uses attr('src') like the barber, no recreation
	var refreshPortrait = function(imagePath)
	{
		if (!imagePath) return;
		if (portraitImage !== null && portraitImage.length > 0)
		{
			portraitImage.attr('src', Path.PROCEDURAL + imagePath);
			portraitImage.centerImageWithinParent(0, 0, 1.0);
		}
	};

	// Send +1/-1 to SQ, update portrait from response (receives imagePath string)
	var sendChange = function(field, change)
	{
		var payload = { BroId: BFModel.selectedBroId, Field: field, Change: change };
		SQ.call(self.mSQHandle, 'setAppearance', payload, function(imagePath)
		{
			if (imagePath) refreshPortrait(imagePath);
		});
	};

	// Build a barber-style control:  [<] Label [>]
	var buildBarberControl = function(parent, cssClass, label, total, field)
	{
		var control = $('<div class="bf-barber-control ' + cssClass + '"/>');
		parent.append(control);

		var layoutL = $('<div class="l-button"/>');
		control.append(layoutL);
		layoutL.createImageButton(Path.GFX + Asset.BUTTON_ARROW_LEFT, function()
		{
			sendChange(field, -1);
		}, '', 6);

		var lbl = $('<div class="ui-control text text-font-normal font-color-value font-bottom-shadow">' + label + '</div>');
		control.append(lbl);

		var layoutR = $('<div class="l-button"/>');
		control.append(layoutR);
		layoutR.createImageButton(Path.GFX + Asset.BUTTON_ARROW_RIGHT, function()
		{
			sendChange(field, 1);
		}, '', 6);

		if (total <= 1)
		{
			layoutL.find('.ui-control').attr('disabled', 'disabled');
			layoutR.find('.ui-control').attr('disabled', 'disabled');
		}

		return control;
	};

	// --- Layout ---
	var grid = $('<div class="bf-app-grid"/>');
	panel.append(grid);

	// Row 1: Hair Color + Hair
	buildBarberControl(grid, 'bf-barber-color', 'Hair Color', _data.ColorTotal, 'color');
	buildBarberControl(grid, 'bf-barber-hair', 'Hair', _data.HairTotal, 'hair');

	// Row 2: Head + Beard
	buildBarberControl(grid, 'bf-barber-head', 'Head', _data.HeadTotal, 'head');
	buildBarberControl(grid, 'bf-barber-beard', 'Beard', _data.BeardTotal, 'beard');

	// Portrait (center) — nude preview, created once and updated via attr('src')
	var portrait = $('<div class="bf-app-portrait"/>');
	grid.append(portrait);
	var imgPath = _data.ImagePath || (BFModel.selectedBro ? BFModel.selectedBro.ImagePath : '');
	portraitImage = portrait.createImage(
		imgPath ? Path.PROCEDURAL + imgPath : null,
		function(_image)
		{
			_image.centerImageWithinParent(0, 0, 1.0);
			_image.removeClass('opacity-none');
		}, null, 'opacity-none'
	);

	// Row 3: Body + Tattoo
	buildBarberControl(grid, 'bf-barber-body', 'Body', _data.BodyTotal, 'body');
	buildBarberControl(grid, 'bf-barber-tattoo', 'Tattoo', _data.TattooTotal, 'tattoo');

	// Accept / Cancel buttons
	var acceptRow = $('<div class="bf-barber-accept-row"/>');
	grid.append(acceptRow);
	var acceptLayout = $('<div class="l-barber-button"/>');
	acceptRow.append(acceptLayout);
	acceptLayout.createTextButton("Accept", function()
	{
		SQ.call(self.mSQHandle, 'onAcceptAppearance', {}, function(imagePath)
		{
			if (imagePath)
			{
				// Update roster portrait with final equipped image
				if (BFModel.selectedBro)
				{
					BFModel.selectedBro.ImagePath = imagePath;
					if (BFModel.selectedBro.BroImage)
						BFModel.selectedBro.BroImage.attr('src', Path.GFX + Path.PROCEDURAL + imagePath);
				}
				// Refresh header portrait
				var header = self.mContentPanel.parent().find('.bf-bro-portrait');
				if (header.length > 0)
				{
					header.empty();
					header.createImage(Path.PROCEDURAL + imagePath, function(_image)
					{
						_image.centerImageWithinParent(0, 0, 0.64);
						_image.removeClass('opacity-none');
					}, null, 'opacity-none');
				}
			}
			// Re-enter appearance panel (fresh preview)
			self.createAppearancePanel();
		});
	}, '', 1);
};

BBForgeScreen.prototype.refreshPortrait = function(_imagePath)
{
	if (!_imagePath) return;

	if (BFModel.selectedBro)
		BFModel.selectedBro.ImagePath = _imagePath;

	var header = this.mContentPanel.parent().find('.bf-bro-portrait');
	if (header.length > 0)
	{
		header.empty();
		header.createImage(Path.PROCEDURAL + _imagePath, function(_image)
		{
			_image.centerImageWithinParent(0, 0, 0.64);
			_image.removeClass('opacity-none');
		}, null, 'opacity-none');
	}

	if (BFModel.selectedBro && BFModel.selectedBro.BroImage)
		BFModel.selectedBro.BroImage.attr('src', Path.GFX + Path.PROCEDURAL + _imagePath);
};

// =====================================================================
// EXPORT / IMPORT PANEL
// =====================================================================

BBForgeScreen.prototype.createExportPanel = function()
{
	this.mContentPanel.empty();

	if (BFModel.selectedBro === null)
	{
		this.mContentPanel.append($('<div class="bf-empty-state"/>').text('Select a brother from the roster'));
		return;
	}

	var self = this;
	var panel = $('<div class="bf-export-tab-panel"/>');

	// Header + instructions
	panel.append($('<div class="bf-section-header"/>').text('Export / Import / Clone'));
	panel.append($('<div class="bf-export-instructions"/>').html(
		'<b>Export:</b> Toggle sections, click Export, Select All + CTRL+C.<br>' +
		'<b>Import:</b> Paste in the import field, toggle sections, click Import.<br>' +
		'<b>Clone:</b> Export from one bro, select another, paste + Import.'
	));

	// -- EXPORT SECTION --
	panel.append($('<div class="bf-export-subtitle"/>').text('Export'));
	var exportToggles = $('<div class="bf-export-toggles"/>');
	var toggleMain = $('<div class="bf-export-toggle bf-toggle-on" data-section="main"/>').text('Main');
	var toggleLife = $('<div class="bf-export-toggle bf-toggle-off" data-section="lifetime"/>').text('Life');
	var toggleEquip = $('<div class="bf-export-toggle bf-toggle-off" data-section="equipment"/>').text('Gear');
	exportToggles.on('click', '.bf-export-toggle', function() {
		$(this).toggleClass('bf-toggle-on bf-toggle-off');
	});
	exportToggles.append(toggleMain).append(toggleLife).append(toggleEquip);
	panel.append(exportToggles);

	// Export buttons
	var btnRowExp = $('<div class="bf-export-buttons"/>');
	var bw = { 'display': 'inline-block', 'width': '8rem', 'height': '3rem', 'margin-right': '0.2rem' };
	var btnExpL = $('<div/>').css(bw); btnRowExp.append(btnExpL);
	btnExpL.createTextButton('Export', function() { self.onExportBro(); }, '', 1);
	var btnSelL = $('<div/>').css($.extend({}, bw, {'width': '9.5rem'})); btnRowExp.append(btnSelL);
	btnSelL.createTextButton('Select All', function() { self.onSelectAll(); }, '', 1);
	panel.append(btnRowExp);

	// Export output field
	var expOutputWrap = $('<div class="l-input bf-export-field"/>');
	panel.append(expOutputWrap);
	expOutputWrap.createInput('', 0, 1000000, null, null, 'title-font-medium font-bold font-color-brother-name', null);
	this.mExportOutput = expOutputWrap.find('input');
	this.mExportToggles = { main: toggleMain, life: toggleLife, equip: toggleEquip };
	this.mExportOutput.on('keydown', function(e) { e.stopPropagation(); });
	this.mExportOutput.on('keyup', function(e) { e.stopPropagation(); });

	panel.append($('<div class="bf-export-note"/>').text('Select All \u2192 CTRL+C to copy'));

	// -- IMPORT SECTION --
	panel.append($('<div class="bf-export-subtitle bf-import-header"/>').text('Import'));

	// Import section toggles
	var importToggles = $('<div class="bf-export-toggles"/>');
	var itStats  = $('<div class="bf-export-toggle bf-toggle-on" data-import="stats"/>').text('Stats');
	var itPerks  = $('<div class="bf-export-toggle bf-toggle-on" data-import="perks"/>').text('Perks');
	var itTraits = $('<div class="bf-export-toggle bf-toggle-on" data-import="traits"/>').text('Traits');
	var itBg     = $('<div class="bf-export-toggle bf-toggle-on" data-import="bg"/>').text('BG');
	var itLook   = $('<div class="bf-export-toggle bf-toggle-on" data-import="look"/>').text('Look');
	var itGear   = $('<div class="bf-export-toggle bf-toggle-on" data-import="gear"/>').text('Gear');
	importToggles.append(itStats).append(itPerks).append(itTraits).append(itBg).append(itLook).append(itGear);

	importToggles.on('click', '.bf-export-toggle', function() {
		$(this).toggleClass('bf-toggle-on bf-toggle-off');
	});

	panel.append(importToggles);

	this.mImportToggles = { stats: itStats, perks: itPerks, traits: itTraits, bg: itBg, look: itLook, gear: itGear };

	// Import buttons (same widths as Export row for alignment)
	var btnRowImp = $('<div class="bf-export-buttons"/>');
	var btnImpL = $('<div/>').css(bw); btnRowImp.append(btnImpL);
	btnImpL.createTextButton('Import', function() { self.onImportBro(); }, '', 1);
	var btnClrL = $('<div/>').css($.extend({}, bw, {'width': '9.5rem'})); btnRowImp.append(btnClrL);
	btnClrL.createTextButton('Clear', function() { self.onClearExport(); }, '', 1);
	panel.append(btnRowImp);

	// Import paste field
	var impInputWrap = $('<div class="l-input bf-export-field"/>');
	panel.append(impInputWrap);
	impInputWrap.createInput('', 0, 1000000, null, null, 'title-font-medium font-bold font-color-brother-name', null);
	this.mImportInput = impInputWrap.find('input');
	this.mImportInput.on('keydown', function(e) { e.stopPropagation(); });
	this.mImportInput.on('keyup', function(e) { e.stopPropagation(); });

	panel.append($('<div class="bf-export-note"/>').text('CTRL+V to paste'));

	// Keep mExportInput as alias for backwards compat
	this.mExportInput = this.mImportInput;

	this.mContentPanel.append(panel);
};

BBForgeScreen.prototype.onExportBro = function()
{
	if (BFModel.selectedBroId === null || !this.mExportOutput) return;

	var self = this;
	var t = this.mExportToggles;
	SQ.call(this.mSQHandle, 'onExportBro', {
		BroId: BFModel.selectedBroId,
		IncludeMain: t.main.hasClass('bf-toggle-on'),
		IncludeLifetime: t.life.hasClass('bf-toggle-on'),
		IncludeEquipment: t.equip.hasClass('bf-toggle-on')
	}, function(_result)
	{
		if (_result && _result.ExportString)
		{
			self.mExportOutput.val(_result.ExportString);

			try {
				self.mExportOutput[0].focus();
				self.mExportOutput[0].select();
			} catch (e) {}
		}
	});
};

BBForgeScreen.prototype.onSelectAll = function()
{
	if (!this.mExportOutput) return;
	try {
		this.mExportOutput[0].focus();
		this.mExportOutput[0].select();
	} catch (e) {}
};

BBForgeScreen.prototype.onClearExport = function()
{
	if (this.mImportInput) this.mImportInput.val('');
};

BBForgeScreen.prototype.onImportBro = function()
{
	if (BFModel.selectedBroId === null || !this.mImportInput) return;

	var raw = this.mImportInput.val().trim();
	if (raw === '') return;

	// Coherent GT JSON.parse fails on large strings (>~16KB)
	// Workaround: split into chunks, parse each, reassemble
	var parsed = null;
	try { parsed = JSON.parse(raw); }
	catch (e)
	{
		// Fallback: send raw string to SQ backend for import
		// SQ will parse it using compilestring
		var self = this;
		var it = this.mImportToggles;
		var isOn = function(t) { return t && t.hasClass('bf-toggle-on'); };
		SQ.call(this.mSQHandle, 'onImportBroRaw', {
			BroId: BFModel.selectedBroId,
			RawJson: raw,
			IncludeMain: true,
			IncludeLifetime: true,
			IncludeEquipment: it ? isOn(it.gear) : true,
			IncludeStats: it ? isOn(it.stats) : true,
			IncludePerks: it ? isOn(it.perks) : true,
			IncludeTraits: it ? isOn(it.traits) : true,
			IncludeBackground: it ? isOn(it.bg) : true,
			IncludeAppearance: it ? isOn(it.look) : true
		}, function(_result)
		{
			if (_result && _result.Success)
			{
				SQ.call(self.mSQHandle, 'BDUpdateAttributes', {
					BroId: BFModel.selectedBroId
				}, function(_fresh)
				{
					if (_fresh && BFModel.selectedBro)
					{
						var sns = ['Hitpoints','Stamina','Initiative','Bravery','MeleeSkill','RangedSkill','MeleeDefense','RangedDefense'];
						for (var i = 0; i < sns.length; i++)
						{
							if (sns[i] in _fresh) BFModel.selectedBro[sns[i]] = _fresh[sns[i]];
						}
						if ('PerkPoints' in _fresh) BFModel.selectedBro.PerkPoints = _fresh.PerkPoints;
						if ('Level' in _fresh) BFModel.selectedBro.Level = _fresh.Level;
						if ('Name' in _fresh) BFModel.selectedBro.Name = _fresh.Name;
						self.mImportInput.val('Import OK');
					}
				});
			}
			else
			{
				self.mImportInput.val('ERROR: ' + (_result ? _result.Message : 'Unknown'));
			}
		});
		return;
	}

	if (!parsed || parsed.mod !== 'BBForge')
	{
		this.mImportInput.val('ERROR: Not a BBForge string');
		return;
	}

	var self = this;

	var it = this.mImportToggles;
	var isOn = function(t) { return t && t.hasClass('bf-toggle-on'); };

	SQ.call(this.mSQHandle, 'onImportBro', {
		BroId: BFModel.selectedBroId,
		ImportData: parsed,
		IncludeMain: true,
		IncludeLifetime: true,
		IncludeEquipment: it ? isOn(it.gear) : true,
		IncludeStats: it ? isOn(it.stats) : true,
		IncludePerks: it ? isOn(it.perks) : true,
		IncludeTraits: it ? isOn(it.traits) : true,
		IncludeBackground: it ? isOn(it.bg) : true,
		IncludeAppearance: it ? isOn(it.look) : true
	}, function(_result)
	{
		if (_result && _result.Success)
		{
			// Refresh: get fresh stats from SQ, update model, rebuild tab
			SQ.call(self.mSQHandle, 'BDUpdateAttributes', {
				BroId: BFModel.selectedBroId
			}, function(_fresh)
			{
				if (_fresh && BFModel.selectedBro)
				{
					// Update all stats
					var sns = ['Hitpoints','Stamina','Initiative','Bravery','MeleeSkill','RangedSkill','MeleeDefense','RangedDefense'];
					for (var i = 0; i < sns.length; i++)
					{
						if (sns[i] in _fresh) BFModel.selectedBro[sns[i]] = _fresh[sns[i]];
					}
					if ('PerkPoints' in _fresh) BFModel.selectedBro.PerkPoints = _fresh.PerkPoints;
					if ('ActionPoints' in _fresh) BFModel.selectedBro.ActionPoints = _fresh.ActionPoints;
					if ('DailyWage' in _fresh) BFModel.selectedBro.DailyWage = _fresh.DailyWage;
					if ('DailyFood' in _fresh) BFModel.selectedBro.DailyFood = _fresh.DailyFood;
					if ('XpValue' in _fresh) BFModel.selectedBro.XpValue = _fresh.XpValue;
					if ('Level' in _fresh) BFModel.selectedBro.Level = _fresh.Level;
					if ('Name' in _fresh) BFModel.selectedBro.Name = _fresh.Name;
					if ('Title' in _fresh) BFModel.selectedBro.Title = _fresh.Title;
					if ('BackgroundName' in _fresh) BFModel.selectedBro.BackgroundName = _fresh.BackgroundName;

					// Update portrait image
					if ('ImagePath' in _fresh)
					{
						BFModel.selectedBro.ImagePath = _fresh.ImagePath;
						if ('ImageOffsetX' in _fresh) BFModel.selectedBro.ImageOffsetX = _fresh.ImageOffsetX;
						if ('ImageOffsetY' in _fresh) BFModel.selectedBro.ImageOffsetY = _fresh.ImageOffsetY;
						// Update roster list entry image
						if (BFModel.selectedBro.BroImage)
							BFModel.selectedBro.BroImage.attr('src', Path.PROCEDURAL + _fresh.ImagePath);
					}

					// Update roster list entry text
					if (BFModel.selectedBro.BroLevel)
						BFModel.selectedBro.BroLevel.text('Lvl ' + BFModel.selectedBro.Level);
					if (BFModel.selectedBro.BroName)
						BFModel.selectedBro.BroName.text(BFModel.selectedBro.Name);
				}
				self.mImportInput.val(_result.Message || 'Import OK');
			});
		}
		else
		{
			self.mImportInput.val('ERROR: ' + (_result ? _result.Message : '?'));
		}
	});
};

// =====================================================================
// ROSTER TOOLS PANEL (mass operations)
// =====================================================================

BBForgeScreen.prototype.createRosterToolsPanel = function()
{
	this.mContentPanel.empty();
	var self = this;

	var panel = $('<div class="bf-roster-panel"/>');
	this.mContentPanel.append(panel);

	panel.append($('<div class="bf-roster-header"/>').text('Roster Tools'));
	panel.append($('<div class="bf-roster-subtitle"/>').text('Mass operations for all brothers'));

	var grid = $('<div class="bf-roster-grid"/>');
	panel.append(grid);

	var statusBar = $('<div class="bf-roster-status"/>');
	panel.append(statusBar);

	var showStatus = function(text, color)
	{
		statusBar.text(text).css('color', color || '#a0c060');
		setTimeout(function() { statusBar.text(''); }, 4000);
	};

	var actions = [
		{
			icon: 'ui/icons/hp.png',
			title: 'Heal All',
			desc: 'Restore HP to maximum for all brothers',
			color: '#5a9a5a',
			sqCall: 'onRosterHealAll',
			onResult: function(r) {
				if (r && r.Success) showStatus('Healed ' + r.Count + ' brother' + (r.Count !== 1 ? 's' : ''));
			}
		},
		{
			icon: 'ui/icons/morale.png',
			title: 'Max Mood All',
			desc: 'Set all brothers to Euphoric mood',
			color: '#50a050',
			sqCall: 'onRosterMaxMoodAll',
			onResult: function(r) {
				if (r && r.Success) showStatus('Mood maxed for ' + r.Count + ' brother' + (r.Count !== 1 ? 's' : ''));
			}
		},
		{
			icon: 'ui/icons/armor_body.png',
			title: 'Repair All Equipment',
			desc: 'Repair all equipped items on all brothers',
			color: '#8b7355',
			sqCall: 'onRosterRepairAllEquipment',
			onResult: function(r) {
				if (r && r.Success) showStatus('Repaired ' + r.Count + ' item' + (r.Count !== 1 ? 's' : ''));
			}
		},
		{
			icon: 'ui/icons/xp_received.png',
			title: '+1 Level All',
			desc: 'Grant one level to every brother in the roster',
			color: '#c8a020',
			sqCall: 'onRosterLevelUpAll',
			onResult: function(r) {
				if (r && r.Count !== undefined)
				{
					showStatus('Leveled up ' + r.Count + ' brother' + (r.Count !== 1 ? 's' : ''));
					var savedMode = BFModel.mode;
					self.loadFromData(r);
					BFModel.mode = savedMode;
				}
			}
		},
		{
			icon: 'ui/icons/perks.png',
			title: 'Reset All Perks',
			desc: 'Oblivion Potion on all brothers, refund perk points',
			color: '#9060a0',
			sqCall: 'onRosterResetAllPerks',
			onResult: function(r) {
				if (r && r.Count !== undefined)
				{
					showStatus('Reset perks for ' + r.Count + ' brother' + (r.Count !== 1 ? 's' : ''));
					var savedMode = BFModel.mode;
					self.loadFromData(r);
					BFModel.mode = savedMode;
				}
			}
		}
	];

	for (var i = 0; i < actions.length; i++)
	{
		var makeCard = function(action)
		{
			var card = $('<div class="bf-roster-card"/>');

			var iconWrap = $('<div class="bf-roster-card-icon"/>');
			iconWrap.append($('<img/>').attr('src', Path.GFX + action.icon));
			card.append(iconWrap);

			card.append($('<div class="bf-roster-card-title"/>').text(action.title));
			card.append($('<div class="bf-roster-card-desc"/>').text(action.desc));

			var btn = $('<div class="bf-roster-card-btn"/>').text('Execute');
			btn.css('border-color', action.color);
			btn.css('color', action.color);
			btn.on('click', function()
			{
				btn.text('...');
				SQ.call(self.mSQHandle, action.sqCall, {}, function(_result)
				{
					btn.text('Execute');
					action.onResult(_result);
				});
			});
			card.append(btn);

			grid.append(card);
		};
		makeCard(actions[i]);
	}
};

// =====================================================================
// STASH PANEL — Browse / Add / Remove items from company stash
// =====================================================================

BBForgeScreen.prototype.createStashPanel = function()
{
	this.mContentPanel.empty();
	var self = this;

	var panel = $('<div class="bf-stash-panel"/>');
	this.mContentPanel.append(panel);

	// Two-column layout
	var leftCol = $('<div class="bf-stash-left"/>');
	var rightCol = $('<div class="bf-stash-right"/>');
	panel.append(leftCol);
	panel.append(rightCol);

	// ===========================
	// LEFT: Current Stash
	// ===========================
	var toolbar = $('<div class="bf-stash-toolbar"/>');
	leftCol.append(toolbar);

	var stashLabel = $('<div class="bf-stash-count"/>').text('Stash (loading...)');
	toolbar.append(stashLabel);

	var repairBtn = $('<div class="bf-stash-tool-btn"/>').text('Repair All');
	toolbar.append(repairBtn);

	var sortBtn = $('<div class="bf-stash-tool-btn"/>').text('Sort');
	toolbar.append(sortBtn);

	var stashGrid = $('<div class="bf-stash-grid"/>');
	leftCol.append(stashGrid);

	// ===========================
	// RIGHT: Item Catalog
	// ===========================
	rightCol.append($('<div class="bf-stash-catalog-title"/>').text('Add Items'));

	var searchWrap = $('<div class="bf-stash-search-wrap"/>');
	var searchInput = $('<input class="bf-stash-search" type="text"/>');
	searchWrap.append(searchInput);
	rightCol.append(searchWrap);

	// Category filters
	var filterBar = $('<div class="bf-stash-filters"/>');
	var categories = ['All', 'Melee', 'Ranged', 'Shield', 'Armor', 'Helmet', 'Accessory', 'Supply', 'Usable', 'Misc'];
	var activeFilter = 'All';

	for (var c = 0; c < categories.length; c++)
	{
		var makeCatBtn = function(cat)
		{
			var btn = $('<div class="bf-stash-filter-btn"/>').text(cat);
			if (cat === 'All') btn.addClass('is-active');
			btn.on('click', function()
			{
				activeFilter = cat;
				filterBar.find('.bf-stash-filter-btn').removeClass('is-active');
				$(this).addClass('is-active');
				searchCatalog();
			});
			filterBar.append(btn);
		};
		makeCatBtn(categories[c]);
	}
	rightCol.append(filterBar);

	var catalogList = $('<div class="bf-stash-catalog-list"/>');
	rightCol.append(catalogList);

	var catalogStatus = $('<div class="bf-stash-catalog-status"/>');
	rightCol.append(catalogStatus);

	// ===========================
	// Stash refresh
	// ===========================
	var refreshStash = function(data)
	{
		var render = function(_data)
		{
			if (!_data || !_data.Items)
			{
				stashLabel.text('Stash (error)');
				return;
			}
			stashLabel.text('Stash (' + _data.Count + '/' + _data.Capacity + ')');
			stashGrid.empty();

			for (var i = 0; i < _data.Items.length; i++)
			{
				var makeCell = function(item)
				{
					var cell = $('<div class="bf-stash-item"/>');
					cell.bindTooltip({ contentType: 'ui-element', elementId: 'bf-stash-tooltip', elementOwner: 'stash|' + item.Index });

					if (item.Icon && item.Icon !== '')
					{
						var baseImg = $('<img class="bf-stash-item-img"/>');
						baseImg.attr('src', Path.GFX + 'ui/items/' + item.Icon);
						// Fallback if image fails to load
						baseImg[0].onerror = function()
						{
							$(this).replaceWith($('<div class="bf-stash-item-fallback"/>').text(item.Name.substring(0, 3)));
						};
						cell.append(baseImg);

						// Overlay icons (layered armor, etc.)
						if (item.Overlays)
						{
							for (var ov = 0; ov < item.Overlays.length; ov++)
							{
								if (item.Overlays[ov] && item.Overlays[ov] !== '')
									cell.append($('<img class="bf-stash-item-overlay"/>').attr('src', Path.GFX + 'ui/items/' + item.Overlays[ov]));
							}
						}
					}
					else
					{
						cell.append($('<div class="bf-stash-item-fallback"/>').text(item.Name.substring(0, 3)));
					}

					if (item.IsNamed) cell.addClass('is-named');

					// Condition bar (only if damaged)
					if (item.ConditionMax > 0 && item.Condition < item.ConditionMax)
					{
						var pct = item.Condition / item.ConditionMax;
						var color = pct > 0.6 ? '#5a9a5a' : (pct > 0.3 ? '#c8a020' : '#9a3030');
						var bar = $('<div class="bf-stash-item-cond"/>');
						bar.append($('<div/>').css({ 'width': Math.round(pct * 100) + '%', 'background': color, 'height': '100%' }));
						cell.append(bar);
					}

					// Click: select, second click: remove
					cell.on('click', function()
					{
						if (cell.hasClass('is-selected'))
						{
							SQ.call(self.mSQHandle, 'onRemoveStashItem', { Index: item.Index }, function(_result)
							{
								if (_result && _result.Success)
									refreshStash();
							});
						}
						else
						{
							stashGrid.find('.bf-stash-item').removeClass('is-selected');
							cell.addClass('is-selected');
						}
					});

					stashGrid.append(cell);
				};
				makeCell(_data.Items[i]);
			}
		};

		if (data)
			render(data);
		else
			SQ.call(self.mSQHandle, 'queryStash', {}, render);
	};

	// ===========================
	// Catalog search
	// ===========================
	var searchTimer = null;
	var searchCatalog = function()
	{
		var q = searchInput.val();
		catalogList.empty();
		catalogStatus.text('Searching...');

		SQ.call(self.mSQHandle, 'queryItemCatalog', { Search: q, Category: activeFilter }, function(_data)
		{
			catalogList.empty();

			if (!_data || !_data.Items)
			{
				catalogStatus.text('Failed to load catalog.');
				return;
			}

			var total = _data.Total;
			var shown = Math.min(total, 200);
			catalogStatus.text(total + ' items' + (total > shown ? ' (showing first ' + shown + ')' : '') + ' — catalog: ' + _data.CatalogSize);

			for (var i = 0; i < shown; i++)
			{
				var makeRow = function(item)
				{
					var row = $('<div class="bf-stash-catalog-row"/>');
					row.bindTooltip({ contentType: 'ui-element', elementId: 'bf-stash-tooltip', elementOwner: 'catalog|' + item.Script });

					var icon = $('<div class="bf-stash-catalog-icon"/>');
					if (item.Icon && item.Icon !== '')
						icon.append($('<img/>').attr('src', Path.GFX + 'ui/items/' + item.Icon));
					row.append(icon);

					row.append($('<div class="bf-stash-catalog-name"/>').text(item.Name));

					var catBadge = $('<div class="bf-stash-catalog-cat"/>').text(item.Cat);
					row.append(catBadge);

					var addBtn = $('<div class="bf-stash-catalog-add"/>').text('+');
					addBtn.on('click', function(e)
					{
						e.stopPropagation();
						SQ.call(self.mSQHandle, 'onAddItemToStash', { Script: item.Script }, function(_result)
						{
							if (_result && _result.Success)
								refreshStash();
							else if (_result && _result.Error)
								stashLabel.text('Stash (FULL)');
						});
					});
					row.append(addBtn);

					catalogList.append(row);
				};
				makeRow(_data.Items[i]);
			}
		});
	};

	// ===========================
	// Toolbar actions
	// ===========================
	sortBtn.on('click', function()
	{
		SQ.call(self.mSQHandle, 'onSortStash', {}, function(_data)
		{
			refreshStash(_data);
		});
	});

	repairBtn.on('click', function()
	{
		SQ.call(self.mSQHandle, 'onRepairAllStash', {}, function(_data)
		{
			refreshStash(_data);
		});
	});

	// Search input handling
	searchInput.on('keydown', function(e) { e.stopPropagation(); });
	searchInput.on('keyup', function(e)
	{
		e.stopPropagation();
		if (searchTimer) clearTimeout(searchTimer);
		searchTimer = setTimeout(searchCatalog, 250);
	});

	// Mousewheel fix for Coherent GT nested scroll containers
	var wireScroll = function(jqEl)
	{
		var el = jqEl[0];
		var handler = function(evt)
		{
			evt.stopPropagation();
			evt.preventDefault();
			var delta = evt.deltaY !== undefined ? evt.deltaY : (-evt.wheelDelta || 0);
			el.scrollTop += (delta > 0 ? 1 : -1) * 50;
		};
		el.addEventListener('wheel', handler, false);
		el.addEventListener('mousewheel', handler, false);
	};
	wireScroll(stashGrid);
	wireScroll(catalogList);

	// Prevent content panel from stealing wheel events
	self.mContentPanel[0].addEventListener('wheel', function(evt)
	{
		evt.preventDefault();
	}, false);

	// Initial load
	refreshStash();
	searchCatalog();
};

// =====================================================================
// COMPANY PANEL (name, banner, avatar)
// =====================================================================

BBForgeScreen.prototype.createCompanyPanel = function()
{
	this.mContentPanel.empty();
	var self = this;

	SQ.call(this.mSQHandle, 'queryCompany', {}, function(_data)
	{
		if (_data === null)
		{
			self.mContentPanel.empty();
			self.mContentPanel.append($('<div class="bf-empty-state"/>').text('Could not load company data.'));
			return;
		}
		self.buildCompanyUI(_data);
	});
};

BBForgeScreen.prototype.buildCompanyUI = function(_data)
{
	this.mContentPanel.empty();
	var self = this;

	var panel = $('<div class="bf-company-panel"/>');
	this.mContentPanel.append(panel);

	// Two-column layout
	var leftCol = $('<div class="bf-company-left"/>');
	var rightCol = $('<div class="bf-company-right"/>');
	panel.append(leftCol);
	panel.append(rightCol);

	// ===============================
	// LEFT: Company Name + Map Avatar
	// ===============================

	// --- COMPANY NAME ---
	var nameSection = $('<div class="bf-company-section"/>');
	leftCol.append(nameSection);
	nameSection.append($('<div class="bf-company-label"/>').text('Company Name'));

	var currentName = _data.Name || '';
	var nameDisplay = $('<div class="bf-company-name-display"/>').text('Current: ' + currentName);
	nameSection.append(nameDisplay);

	var nameInputWrap = $('<div class="l-input bf-company-name-input"/>');
	nameSection.append(nameInputWrap);
	nameInputWrap.createInput(currentName, 1, 32, null, null, 'title-font-big font-bold font-color-brother-name', function(_input)
	{
		var text = _input.getInputText();
		if (text && text.length >= 1)
		{
			SQ.call(self.mSQHandle, 'onChangeCompanyName', { Name: text });
			nameDisplay.text('Current: ' + text);
		}
	});
	var realInput = nameInputWrap.find('input');
	realInput.on('keydown', function(e) { e.stopPropagation(); });
	realInput.on('keyup', function(e) { e.stopPropagation(); });

	// --- MAP AVATAR ---
	if (!_data.HasAvatar)
	{
		var noAvatar = $('<div class="bf-company-section"/>');
		leftCol.append(noAvatar);
		noAvatar.append($('<div class="bf-company-label"/>').text('Map Avatar'));
		noAvatar.append($('<div class="bf-empty-state"/>').text('Avatar editing not available.'));
	}
	else
	{
		var avatarSection = $('<div class="bf-company-section"/>');
		leftCol.append(avatarSection);
		avatarSection.append($('<div class="bf-company-label"/>').text('Map Avatar'));

		// Preview + info side by side
		var avatarTopRow = $('<div class="bf-company-avatar-top"/>');
		avatarSection.append(avatarTopRow);

		var avatarPreview = $('<img class="bf-company-avatar-img"/>');
		avatarTopRow.append(avatarPreview);
		self.mAvatarPreview = avatarPreview;

		if (_data.AvatarImagePath && _data.AvatarImagePath !== '')
			avatarPreview.attr('src', Path.PROCEDURAL + _data.AvatarImagePath);

		var avatarInfo = $('<div class="bf-company-avatar-info"/>');
		avatarInfo.text((_data.AvatarType || 'Player') + ' ' + (_data.AvatarSpriteIdx || 1) + '/' + (_data.AvatarSpriteCount || 1));
		avatarTopRow.append(avatarInfo);

		var updateAvatarLabels = function(result)
		{
			if (!result) return;
			avatarInfo.text((result.Type || 'Player') + ' ' + (result.SpriteIdx || 1) + '/' + (result.SpriteCount || 1));
			typeBtn.text('Type: ' + (result.Type || 'Player'));
			socketBtn.text('Base: ' + (result.SocketIdx || 1) + '/' + (result.SocketCount || 1));
			flipBtn.text(result.Flipped ? 'Flip: ON' : 'Flip: OFF');
		};

		var sendAvatarAction = function(action)
		{
			SQ.call(self.mSQHandle, 'onChangeAvatar', { Action: action }, function(_result)
			{
				updateAvatarLabels(_result);
			});
		};

		// Sprite arrows:  [<] Sprite [>]
		var spriteControl = $('<div class="bf-barber-control bf-company-avatar-sprite"/>');
		avatarSection.append(spriteControl);

		var spriteLblLayout = $('<div class="l-button"/>');
		spriteControl.append(spriteLblLayout);
		spriteLblLayout.createImageButton(Path.GFX + Asset.BUTTON_ARROW_LEFT, function()
		{
			sendAvatarAction('prev_sprite');
		}, '', 6);

		var spriteLbl = $('<div class="ui-control text text-font-normal font-color-value font-bottom-shadow">Sprite</div>');
		spriteControl.append(spriteLbl);

		var spriteRLayout = $('<div class="l-button"/>');
		spriteControl.append(spriteRLayout);
		spriteRLayout.createImageButton(Path.GFX + Asset.BUTTON_ARROW_RIGHT, function()
		{
			sendAvatarAction('next_sprite');
		}, '', 6);

		// Action buttons
		var typeRow = $('<div class="bf-company-avatar-buttons"/>');
		avatarSection.append(typeRow);

		var typeBtn = $('<div class="bf-company-action-btn"/>').text('Type: ' + (_data.AvatarType || 'Player'));
		typeRow.append(typeBtn);
		typeBtn.on('click', function() { sendAvatarAction('next_type'); });

		var socketBtn = $('<div class="bf-company-action-btn"/>').text('Base: ' + (_data.AvatarSocketIdx || 1) + '/' + (_data.AvatarSocketCount || 1));
		typeRow.append(socketBtn);
		socketBtn.on('click', function() { sendAvatarAction('next_socket'); });

		var flipBtn = $('<div class="bf-company-action-btn"/>').text(_data.AvatarFlipped ? 'Flip: ON' : 'Flip: OFF');
		typeRow.append(flipBtn);
		flipBtn.on('click', function() { sendAvatarAction('flip'); });
	}

	// Hint at the bottom of left column
	leftCol.append($('<div class="bf-company-hint"/>').text('All changes are applied immediately and saved with your game. The map avatar updates when you close BBForge.'));

	// ===============================
	// RIGHT: Banner
	// ===============================
	rightCol.append($('<div class="bf-company-label bf-company-banner-title"/>').text('Banner'));

	var banners = [];
	if (_data.Banners)
	{
		for (var i = 0; i < _data.Banners.length; i++)
			banners.push(_data.Banners[i]);
	}
	var bannerIndex = _data.BannerIndex || 0;

	var bannerImg = $('<img class="bf-company-banner-img"/>');
	bannerImg.attr('src', Path.GFX + 'ui/banners/' + (_data.CurrentBanner || 'banner_01') + '.png');

	var bannerCounter = $('<div class="bf-company-banner-counter"/>');
	bannerCounter.text((bannerIndex + 1) + ' / ' + banners.length);

	var updateBanner = function()
	{
		if (banners.length === 0) return;
		var banner = banners[bannerIndex];
		bannerImg.attr('src', Path.GFX + 'ui/banners/' + banner + '.png');
		bannerCounter.text((bannerIndex + 1) + ' / ' + banners.length);
		SQ.call(self.mSQHandle, 'onChangeBanner', { Banner: banner });
	};

	// Banner image centered
	var bannerFrame = $('<div class="bf-company-banner-frame"/>');
	rightCol.append(bannerFrame);
	bannerFrame.append(bannerImg);

	// Arrows + counter below banner
	var bannerNav = $('<div class="bf-company-banner-nav"/>');
	rightCol.append(bannerNav);

	var btnLeftLayout = $('<div class="l-button"/>');
	bannerNav.append(btnLeftLayout);
	btnLeftLayout.createImageButton(Path.GFX + Asset.BUTTON_ARROW_LEFT, function()
	{
		bannerIndex = (bannerIndex - 1 + banners.length) % banners.length;
		updateBanner();
	}, '', 6);

	bannerNav.append(bannerCounter);

	var btnRightLayout = $('<div class="l-button"/>');
	bannerNav.append(btnRightLayout);
	btnRightLayout.createImageButton(Path.GFX + Asset.BUTTON_ARROW_RIGHT, function()
	{
		bannerIndex = (bannerIndex + 1) % banners.length;
		updateBanner();
	}, '', 6);
};

// Called by SQ asyncCall to update avatar preview image
BBForgeScreen.prototype.updateAvatarImage = function(_imagePath)
{
	if (this.mAvatarPreview && _imagePath)
	{
		var newSrc = Path.PROCEDURAL + _imagePath;
		if (this.mAvatarPreview.attr('src') !== newSrc)
			this.mAvatarPreview.attr('src', newSrc);
	}
};

// =====================================================================
// HELP PANEL
// =====================================================================
BBForgeScreen.prototype.createHelpPanel = function()
{
	this.mContentPanel.empty();

	var panel = $('<div class="bf-help-panel"/>');
	this.mContentPanel.append(panel);

	panel.append($('<div class="bf-help-title"/>').text('BBForge Help'));

	var sections = [
		{
			title: 'Stats',
			lines: [
				'Edit base attributes (HP, FAT, INI, RES, MEL, RNG, MDF, RDF), Perk Points, Daily Wage and Daily Food.',
				'Click a value to edit, press Enter or click away to save.',
				'Click stars to cycle talents (0 > 1 > 2 > 3).',
				'Mood: select a mood state from the dropdown. Persists through save/load.',
				'Biography: type in the text field below the bio display. Use \\n for line breaks.',
				'+1 Level: grants XP to reach the next level.',
				'Youth Fountain: resets the brother to level 1.',
				'Oblivion Potion: removes all perks and refunds perk points.'
			]
		},
		{
			title: 'Perks',
			lines: [
				'Browse all available perks organized by category.',
				'Click a perk to cycle through 3 states:',
				'  1) Added to perk tree (green border, available for purchase with PP)',
				'  2) Invested / unlocked (gold border, no PP cost)',
				'  3) Removed entirely',
				'Use tier filters (T1 to T7) to narrow down by row.',
				'Search bar filters perks by name.'
			]
		},
		{
			title: 'Traits',
			lines: [
				'Toggle character traits and permanent injuries on or off.',
				'Hover a trait to see its tooltip with stat effects.'
			]
		},
		{
			title: 'BG (Background)',
			lines: [
				'Change a brother\'s background from the full catalog.',
				'Mod-added backgrounds are automatically detected.',
				'Search bar filters by name.'
			]
		},
		{
			title: 'Items (Equipment)',
			lines: [
				'View all equipped items with condition bars and tooltips.',
				'Equip items from the catalog: browse by category, search by name, click to equip.',
				'Hover an equipped item and click X to unequip (sent to stash).',
				'Unequip All: strips all equipment in one click.',
				'Repair All: fully repairs all equipped items.'
			]
		},
		{
			title: 'Look (Appearance)',
			lines: [
				'Edit appearance: Hair, Beard, Head, Body, Hair Color, Tattoos.',
				'Uses a preview entity (like the barber). Click Accept to apply.'
			]
		},
		{
			title: 'Export',
			lines: [
				'Export: copies brother data as text (stats, perks, traits, background, look, gear).',
				'Import: paste exported data to apply it on the selected brother.',
				'Toggle sections on/off before importing (Stats, Perks, Traits, BG, Look, Gear).'
			]
		},
		{
			title: 'Roster Tools',
			lines: [
				'Mass operations applied to all brothers at once:',
				'Heal All: restore HP to maximum.',
				'Max Mood: set everyone to Euphoric.',
				'Repair All Equipment: repair all equipped items on all brothers.',
				'+1 Level All: grant one level to every brother.',
				'Reset All Perks: Oblivion Potion on the entire roster.'
			]
		},
		{
			title: 'Stash',
			lines: [
				'Browse all items in your stash with icons and tooltips.',
				'Add items from the catalog (search + category filters).',
				'Right-click to remove items from stash.',
				'Sort: reorganize your stash with one click.',
				'Repair All: repair all damaged stash items.'
			]
		},
		{
			title: 'Company',
			lines: [
				'Company Name: edit your company name directly.',
				'Banner: browse and change your company banner with arrow navigation.',
				'Map Avatar: change your world map avatar sprite by category, with flip option.'
			]
		},
		{
			title: 'Shortcuts',
			lines: [
				'SHIFT+E: open or close BBForge at any time on the world map.'
			]
		}
	];

	for (var i = 0; i < sections.length; i++)
	{
		var sec = sections[i];
		var block = $('<div class="bf-help-section"/>');
		block.append($('<div class="bf-help-section-title"/>').text(sec.title));

		for (var j = 0; j < sec.lines.length; j++)
		{
			block.append($('<div class="bf-help-line"/>').text(sec.lines[j]));
		}

		panel.append(block);
	}

	var el = panel[0];
	var handler = function(evt)
	{
		evt.stopPropagation();
		evt.preventDefault();
		var delta = evt.deltaY !== undefined ? evt.deltaY : (-evt.wheelDelta || 0);
		el.scrollTop += (delta > 0 ? 1 : -1) * 50;
	};
	el.addEventListener('wheel', handler, false);
	el.addEventListener('mousewheel', handler, false);
};

// =====================================================================
// SCREEN REGISTRATION
// =====================================================================
Screens["BBForgeScreen"] = new BBForgeScreen();
engine.call("registerScreen", "BBForgeScreen");
