local namedWeaponInfo = {
	named_billhook = 6,
	named_fencing_sword = 3,
	named_greataxe = 6,
	named_greatsword = 8,
    named_mace = 8,
    named_polehammer = 3,
    named_shamshir = 4,
    named_spear = 6,
    named_sword = 6,
    named_two_handed_flail = 4,
    named_two_handed_hammer = 4,
    named_two_handed_mace = 3,
    named_warbow = 5,
    named_warhammer = 5,
	named_bardiche = 3,
	named_pike = 5,
	named_warbrand = 5,
	named_swordlance = 5,
	named_cleaver = 5
};

local up_name = function(sc,vnum)
{
 	::ModWeaponSkins.HooksMod.hook("scripts/items/weapons/named/" + sc , function(q) {
		q.create = @(__original) function()
		{
			__original();
			this.m.Variant = ::Math.rand(1, vnum);
			this.updateVariant();
		}
	});
}

foreach (sc,vnum in namedWeaponInfo)
{
	up_name(sc,vnum);
};