foreach( script in [
	"arming_sword",
	"bardiche",
	"battle_whip",
	"billhook",
	"bludgeon",
	"boar_spear",
	"butchers_cleaver",
	"crossbow",
	"dagger",
	"falchion",
	"fencing_sword",
	"fighting_axe",
	"fighting_spear",
	"flail",
	"goedendag",
	"greataxe",
	"greatsword",
	"hand_axe",
	"hatchet",
	"heavy_crossbow",
	"hooked_blade",
	"hunting_bow",
	"javelin",
	"knife",
	"light_crossbow",
	"longaxe",
	"longsword",
	"military_cleaver",
	"military_pick",
	"militia_spear",
	"morning_star",
	"noble_sword",
	"pickaxe",
	"pike",
	"pitchfork",
	"polehammer",
	"reinforced_wooden_flail",
	"rondel_dagger",
	"scimitar",
	"scramasax",
	"shamshir",
	"short_bow",
	"shortsword",
	"spetum",
	"staff_sling",
	"three_headed_flail",
	"throwing_axe",
	"throwing_spear",
	"two_handed_flail",
	"two_handed_flanged_mace",
	"two_handed_hammer",
	"two_handed_mace",
	"two_handed_wooden_flail",
	"two_handed_wooden_hammer",
	"war_bow",
	"warbrand",
	"warfork",
	"warhammer",
	"winged_mace",
	"woodcutters_axe",
	"wooden_flail",
	"wooden_stick",
	"ancient/ancient_spear",
	"ancient/ancient_sword",
	"ancient/bladed_pike",
	"ancient/broken_ancient_sword",
	"ancient/broken_bladed_pike",
	"ancient/crypt_cleaver",
	"ancient/falx",
	"ancient/khopesh",
	"ancient/rhomphaia",
	"ancient/warscythe",
	"barbarians/antler_cleaver",
	"barbarians/axehammer",
	"barbarians/blunt_cleaver",
	"barbarians/claw_club",
	"barbarians/crude_axe",
	"barbarians/heavy_javelin",
	"barbarians/heavy_rusty_axe",
	"barbarians/heavy_throwing_axe",
	"barbarians/rusty_warblade",
	"barbarians/skull_hammer",
	"barbarians/thorned_whip",
	"barbarians/two_handed_spiked_mace",
	"greenskins/goblin_bow",
	"greenskins/goblin_crossbow",
	"greenskins/goblin_falchion",
	"greenskins/goblin_heavy_bow",
	"greenskins/goblin_notched_blade",
	"greenskins/goblin_pike",
	"greenskins/goblin_spear",
	"greenskins/goblin_spiked_balls",
	"greenskins/goblin_staff",
	"greenskins/orc_axe",
	"greenskins/orc_axe_2h",
	"greenskins/orc_cleaver",
	"greenskins/orc_flail_2h",
	"greenskins/orc_javelin",
	"greenskins/orc_metal_club",
	"greenskins/orc_wooden_club",
	"oriental/composite_bow",
	"oriental/firelance",
	//"oriental/handgonne",
	"oriental/heavy_southern_mace",
	"oriental/light_southern_mace",
	"oriental/nomad_mace",
	"oriental/nomad_sling",
	"oriental/polemace",
	"oriental/qatal_dagger",
	"oriental/saif",
	"oriental/swordlance",
	"oriental/two_handed_saif",
	"oriental/two_handed_scimitar"
])
{
	::ModWeaponSkins.HooksMod.hook("scripts/items/weapons/" + script, function(q) {
		q.m.OldIcons <- {};
		q.create = @(__original)function()
		{
			__original();
			this.m.Variant = ::Math.rand(0, 2);
			this.m.OldIcons.IconLarge <- this.m.IconLarge.slice(0, this.m.IconLarge.len() - 4);
			this.m.OldIcons.Icon <- this.m.Icon.slice(0, this.m.Icon.len() - 9);
			this.m.OldIcons.ArmamentIcon <- this.m.ArmamentIcon;
			this.updateVariant();
		}
		q.updateVariant <- function()
		{
			if (this.m.rawget("OldIcons") == null || this.m.OldIcons.len() == 0)
			{
				return;
			}
			this.m.IconLarge = this.m.OldIcons.IconLarge + "_" + this.m.Variant + ".png";
			this.m.Icon = this.m.OldIcons.Icon + this.m.Variant + "_70x70.png";
			this.m.ArmamentIcon = this.m.OldIcons.ArmamentIcon + "_" + this.m.Variant;
		}
	});
}

//for handgonne
::ModWeaponSkins.HooksMod.hook("scripts/items/weapons/oriental/handgonne", function(q) {
	q.create = @(__original)function()
	{
		__original();
		this.m.Variant = ::Math.rand(0, 2);
		this.updateVariant();
	}
	q.updateVariant <- function()
	{
		this.m.IconLarge = "weapons/ranged/handgonne_01_" + this.m.Variant + ".png";
		this.m.Icon = "weapons/ranged/handgonne_01_" + this.m.Variant + "_70x70.png";
		this.m.ArmamentIcon = "icon_handgonne_01_" + this.m.Variant + "_loaded";
	}
	q.setLoaded = @()function( _l )
	{
		this.m.IsLoaded = _l;
		if (_l)
		{
			this.m.ArmamentIcon = "icon_handgonne_01_" + this.m.Variant + "_loaded";
		}
		else
		{
			this.m.ArmamentIcon = "icon_handgonne_01_" + this.m.Variant + "_empty";
		}
		this.updateAppearance();
	}
});