foreach (file in ::IO.enumerateFiles("mod_ws/hooks"))
{
	::include(file);
}