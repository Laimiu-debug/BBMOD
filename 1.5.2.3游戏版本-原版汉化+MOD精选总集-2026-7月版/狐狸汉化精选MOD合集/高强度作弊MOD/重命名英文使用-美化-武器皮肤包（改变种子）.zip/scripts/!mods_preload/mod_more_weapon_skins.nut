::ModWeaponSkins <- {
	ID = "mod_more_weapon_skins",
	Name = "More Weapon Skins",
	Version = "0.8.0",
};

::ModWeaponSkins.HooksMod <- ::Hooks.register(::ModWeaponSkins.ID, ::ModWeaponSkins.Version, ::ModWeaponSkins.Name);

::ModWeaponSkins.HooksMod.queue(">mod_msu", ">mod_reforged",">mod_legends" function()
{
	//::ModWeaponSkins.Mod <- ::MSU.Class.Mod(::ModWeaponSkins.ID, ::ModWeaponSkins.Version, ::ModWeaponSkins.Name);
	::include("mod_ws/load.nut");
});